<html>
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<style>
		h2{
			margin-bottom:-10px;
		}
		body{ background#ccc;
		margin:0;
		}

	</style>
	<body>
	<div id="container">
		<div id="content-area">
			<div id="title" style><h2>SALES INVOICE</h2><hr></div>
			<div id="left-col">Invoice NO.:<input type='text'></div>
			<div id="right-col">Date:<input type='date'></div>
			<div id="left-col">Customer Name:<input type='text'><input type="button" id='input' style="width:30px;"><input type="button" id='input' style="width:30px;"></div>
			<div id="right-col">Terms:<input type='text' ></div>
			<div id="row">Address:<input type='text' style="width:250px"></div>
			<div id="left-col">Search Item:<input type='text'><input type="button" id='input' style="width:30px;"><input type="button" id='input' style="width:30px;"></div>
			<div id="right-col">Item Code<input type='text'></div>

		</div>
	</div>
	</body>
</html>