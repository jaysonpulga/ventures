<div id="container">
			<! -- Top Contents (Navigations,Logo) -->
			<div id="header">
				<div id="welcome" style="color:#FFFFFF;right:50px;top:5px;position:absolute;z-index:10;">
					Welcome &nbsp;<span style="font-weight:bold;"><?php echo $_SESSION["username"]; ?></span> <span style="font-weight:bold;"></span><span style="margin:5px;"> | </span><a href="#" onclick = 'logmeout()'>LOGOUT</a>
				</div>
				
				<div id="logo">
					<img src="../images/logo.png" border=0 />
				</div>
				
				<div id="menu">
					<ul>
						<li class="transaction" rel="dropmenu"><a href='' ><span>TRANSACTION</span></a></li>
						<li class="stocks" rel="dropmenu2"><a href=''><span>STOCKS</span></a></li>
						<li class="customers" rel="dropmenu3"><a href=''>CUSTOMERS</a></li>
						<li class="reports" rel="dropmenu4"><a href=''>REPORTS</a></li>
						<li class="management" rel="dropmenu5"><a href=''>MANAGEMENT</a></li>
						<li class="settings" rel="dropmenu6"><a href=''>SETTINGS</a></li>
					</ul>
				</div>
				
				<div class="nav-bar" style="margin-top:-2px">
					<span>
						<label><h4 style="padding-top:2px" >Branch:&nbsp;<span style="color:#fff;"><?php echo $_SESSION["branch_name"]; ?></span><h4></label>
					</span>
					
				</div>
				
				<div style="position:absolute;right:10px;top:105px;z-index:9" class="nav-bar2" style="margin-top:-2px">
					<label style="color:#FFF">Today is <?php echo date("F d, Y"); ?></label>
				</div>
				
				
			</div>
			
			<div id="dropmenu" style="display:none;">
				<div id="separator"></div>
				<ul>
					<li><a href="../transaction/sales.php?menu=transaction">Sales Invoice</a></li>
					<li><a href="../transaction/sales_return.php?menu=transaction">Sales Return</a></li>
					<?php
					if($_SESSION["branch_id"] == 1 ){
					echo '<li><a href="../transaction/purchase.php?menu=transaction">Purchase Order</a></li>';
					}
					?>
					<li><a href="../transaction/purchase_return.php?menu=transaction">Purchase Return</a></li>
					<li><a href="../transaction/transferItem.php?menu=transaction">Transfer Item</a></li>
					<li><a href="../transaction/collections.php?menu=transaction">Collections</a></li>
					<li><a href="../transaction/disbursement.php?menu=transaction">Disbursement</a></li>
				</ul>
			</div>
			<div id="dropmenu2" style="display:none">
				<div id="separator"></div>
				<ul>
					<li><a href="../stocks/motorcycle.php?menu=stocks">Motorcycle</a></li>
					<li><a href="../stocks/parts.php?menu=stocks">Parts</a></li>
					<li><a href="../stocks/promoItems.php?menu=stocks">Promo Items</a></li>
					<li><a href="../stocks/consumables.php?menu=stocks">Consumables</a></li>
					<li><a href="../stocks/repoUnits.php?menu=stocks">Repo Units</a></li>
				</ul>
			</div>
			<div id="dropmenu3" style="display:none">
			<div id="separator"></div>
				<ul>
					<li><a href="../customers/information.php?menu=customers">Information</a></li>
					<li><a href="../customers/ledger.php?menu=customers">Ledger</a></li>
				</ul>
			</div>
			<div id="dropmenu4" style="display:none">
			<div id="separator"></div>
				<ul>
					<li><a href="../reports/inventory.php?menu=reports">Inventory</a></li>
					<li><a href="../reports/stockCard.php?menu=reports">Stock Card</a></li>
					<li><a href="../reports/dailySales.php?menu=reports">Daily Sales</a></li>
					<li><a href="../reports/monthlySales.php?menu=reports">Monthly Sales</a></li>
					<li><a href="../reports/rLedger.php?menu=reports">Ledger</a></li>
						<li><a href="../reports/loan_reports.php?menu=reports">Loan</a></li>
					<li><a href="../reports/rDisbursements.php?menu=reports">Disbursements</a></li>
				</ul>
			</div>
			<div id="dropmenu5" style="display:none">
			<div id="separator"></div>
				<ul>
					<li><a href="../managements/priceList.php?menu=management">Price List</a></li>
					<li><a href="../managements/branches.php?menu=management">Branches</a></li>
					<li><a href="../managements/items.php?menu=management">Items</a></li>
					<li><a href="../managements/supplier.php?menu=management">Supplier</a></li>
					<li><a href="../managements/requisition.php?menu=management">Requisition</a></li>
					<li><a href="../managements/loan.php?menu=management">Loan</a></li>
				<ul>
			</div>
			<div id="dropmenu6" style="display:none">
			<div id="separator"></div>
				<ul>
				<li><a href="../settings/systemBackup.php?menu=settings">System Backup</a></li>
				<li><a href="../settings/logs.php?menu=settings">Logs</a></li>
				<li><a href="../settings/security.php?menu=settings">Security</a></li>
				</ul>
			</div>
			
		</div>
	</div>
	
	<script>
	function logmeout(){
			jConfirm("Are you sure you want to logout?","Confirmation Dialog", function(r) {
				if(r) window.location = "../logout.php?logout=true";
			});
		}
	
	</script>