<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px;">
					<div style="margin-top:10px">
						<span>
							<label>D.V. No.:<label>
							<input type="text" style="margin-left:14px">
						</span>
						</span>
							<label style="margin-left:126px">Date:</label>
							<input type="date" style="margin-left:35px">
						</span>
					</div>
					<div>
						<span>
							<label>Voucher:</label>
							<select id = 'category' name='category' style="margin-left:13px">
								<option value="Category">Category </option>
							</select>
						</span>
						<span>
							<label style="margin-left:134px">Supplier:</label>
							<select id = 'category' name='category' style="margin-left:12px">
								<option value="Category" >Category </option>
							</select>
						</span>
					</div>
					<div>
						<span>
							<label>Particulars:<label>
							<input type="text">
						</span>
						<span>
							<label style="margin-left:126px">Item Code:<label>
							<input type="text">
						</span>
					</div>
					<div>
						<span>
							<label>Details:</label>
							<label style="margin-left:115px">Debit</label>
							<label style="margin-left:68px">Credit</label>
						<span>
					</div>
					<div>
						<span>
							<select id = 'category' name='category'>
							<option value="Category">Category </option>
							</select>
							<input type="text" style="width:100px">
							<input type="text" style="width:100px">
							<input type="button" value="SAVE" style="width:100px;top:1px;">
							<input type="button" value="CANCEL" style="width:100px;top:1px;">
						</span>
					</div>
					<div  class="contents">
						<table style="width:620px">
							<br>
								<tr><th>NO.</th><th>ACCOUNT TITLE</th><th>DEBIT</th><th>CREDIT</th></tr>
								<tbody>
								<tr><td>1</td><td>A</td><td>A</td><td>A</td></tr>
								<tr><td>2</td><td>A</td><td>A</td><td>A</td></tr>
								<tr><td>3</td><td>A</td><td>A</td><td>A</td></tr>
								</tbody>
						</table>
					</div>
					<div>
						<span>
							<label style="margin-left:380px">__________</label>
							<label style="margin-left:60px">__________</label>
						</span>
					</div>
					<div style="margin-top:10px">
						<span>
							<input type="button" value="PRINT" style="width:100px;top:1px;">
							<input type="button" value="CANCEL" style="width:100px;top:1px; margin-left:212px">
							<input type="button" value="CANCEL" style="width:100px;top:1px;">
							<input type="button" value="CANCEL" style="width:100px;top:1px;">
						</span>
					</div>
			</div>
		<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
	});	
	
	
</body>
</html>