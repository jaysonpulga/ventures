<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<form name='item_form' id='item_form' method='POST'>
			<div id="sample" style="text-align:left;padding:10px;">
				<div style="margin-top:10px">
					<label>P.O. No.:<label>
					<input type="text" style="margin-left:44px" id="po">
				</div>
				<div style="margin-top:10px">
					<label >Date Created:</label>
					<input type="date" id="date_created" style="margin-left:15px; text-align:center">
				</div>
				<div style="margin-top:10px">
					<label>Supplier:</label>
					<select id = 'supplier' name='category' style="margin-left:43px">
						<option value="">- Select -</option>
					</select>
				</div>
				<div style="margin-top:10px">
					<label>Terms:<label>
					<input type="text" style="margin-left:58px" id="terms">
				</div>
							
				<div align="center" style="margin-top:30px">
					<span>
						<input type="button" value="CREATE" style="width:100px;top:1px;" onclick="create_PO();">
							
						<input type="button" value="CANCEL" style="width:100px;top:1px;" onclick="cancel();">
					</span>
				</div>
			</div>
			</form>
		</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	var type = getUrlVars()["type"];
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadSupplier();
		
	});
	function loadSupplier(){
		var url="function2.php?request=ajax&action=loadSupplier";
		var counter=1;
	
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				 $("#supplier").append("<option value="+ res.id +">" + res.supplier_name + "</option>"); 
			});
		});				
	}
	
	function cancel(){
		window.parent.cancelIframe();
	}

	function create_PO(){
		
			var po_no=$('#po').val(),date_created=$('#date_created').val(),supplier=$('#supplier').val(),terms=$('#terms').val(),errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");;

			if(po_no == ""){
				errormsg+="-Delivery Receipt No.\n";
			}
			if(date_created == ""){
				errormsg+="-Date Created\n";
			}
			if(supplier == ""){
				errormsg+="-Supplier\n";
			}
			if(errormsg.length== emsg){
			
			$.ajax({
					url: "function2.php",
					data:{"request":"ajax","action":"savePO","po_no":po_no,"date_created":date_created,"supplier":supplier,"terms":terms},
					success: function(reply){
						console.log(reply);
							if(reply == 'saved'){
								var link="newPO.php?menu=transaction&po_no="+po_no;
								window.parent.closeIframe(link);
							}
							else if(reply == 'exist'){
								jAlert('PO No. Already Exists','Alert Dialog');
							}
							else{
								jAlert('Error','Error Message');
								event.preventDefault();
							}	
						}
				});
					
			}else{
				
				jAlert(errormsg,"Alert Dialog");
				event.preventDefault();
			}
	}
	
	
			
	</script>
	
</body>
</html>