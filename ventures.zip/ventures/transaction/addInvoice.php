<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:700px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>SALES INVOICE</h2><hr></label>
							</span>
						</div>
						<div>
							<span>
								<label>Invoice No.:</label>
								<input type="text" id = "txtinvoice" style="margin-left:37px; width:100px" maxlength = "6">
							</span>
							<span>
								<label style="margin-left:225px">Date:</label>
								<input type="date" id = "txtdate" value="<?php echo date('Y-m-d'); ?>" style="margin-left:41px">
							</span>
						</div>
						<div>
							<span>
								<input type = "hidden" id = "txtcusid">
								<label>Customer Name:</label>
								<input type="text" id = "txtcusname" style = "margin-left:7px; text-align:center; width:250px;">
								<a href="#"  style="width:30px;" onclick="search_customer();"><img src="" id="search" valign="bottom"></a>
								<a href="#"  style="width:30px;" onclick="new_customer();"><img src="" id="new" valign="bottom"></a>
								
							</span>
							<span>
								<label style="margin-left:9px">Terms:</label>
								<select id = "txtterms" style="margin-left:32px; width:163px;">
									<option value = "">- SELECT -</option>
									<option value = "3">3</option>
									<option value = "6">6</option>
									<option value = "9">9</option>
									<option value = "12">12</option>
									<option value = "15">15</option>
									<option value = "18">18</option>
									<option value = "21">21</option>
									<option value = "24">24</option>
								</select>
							</span>
						</div>
						<div>
							<span>
								<label>Address:</label>
								<input type="text" id = "txtaddress" style=" width:316px; margin-left:57px">
							</span>
						</div>
						<div align = "center" style = "margin-top: 20px;">
							<span>
								<input type = "button" id = "btnadd" value = "CREATE" onclick = "Add();">
								<input type = "button" id = "btncancel" value = "CANCEL" onclick = "window.location='sales.php?menu=transaction'">
							</span>
						</div>
						
						<div id="search_items" style="display:none;">
							<iframe id="search_dialog" width="954" height="595" style="border:none"></iframe>
						</div>
						<div id="new_items" style="display:none;">
							<iframe id="new_dialog" width="954" height="415" style="border:none"></iframe>
						</div>
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	});
	
	function search_customer(){
			$("#search_items").attr("title","SEARCH CUSTOMER");
			$("#search_dialog").attr('src','customer_name.php');
			$("#search_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#search_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	function new_customer() {
			$("#new_items").attr("title","NEW CUSTOMER");
			$("#new_dialog").attr('src','newCustomer.php');
			$("#new_items").dialog({
				width: 955,
				height: 460,
				modal: true,
				resizable:false,
				close: function () {
					$("#new_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	function closeIframe(id,name,address) {
		$("#search_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
	}
	
	function closeIframeNew(id,name,address) {
		$("#new_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
	}
	
	function Add() {
		var invoice_no=$("#txtinvoice").val();	
		var date_issued=$("#txtdate").val();	
		var customer_id=$("#txtcusid").val();
		var terms=$("#txtterms :selected").val();	
		var address=$("#txtaddress").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(invoice_no == ""){
			errormsg+="- Input Invoice No.\n";
		}
		if(date_issued == ""){
			errormsg+="- Input Date Issued.\n";
		}
		if(customer_id == ""){
			errormsg+="- Input Customer Name.\n";
		}
		if(terms == ""){
			errormsg+="- Input Terms.\n";
		}
		if(address == ""){
			errormsg+="- Input Address.\n";
		}
		
		if(errormsg.length==emsg){
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"saveInvoice","invoice_no":invoice_no,"date_issued":date_issued,"customer_id":customer_id,"terms":terms,"address":address},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Invoice Successfully Added!", "Alert Dialog");
							window.location = "viewInvoice2.php?menu=transaction&invoice_no="+invoice_no;
							
						}else if(reply == 'exists'){
							jAlert('Invoice No. Already Exists!', 'Alert Dialog');
						}
						else{
							jAlert('An Error Occured');
							event.preventDefault();
						}
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		
	}
	
	</script>