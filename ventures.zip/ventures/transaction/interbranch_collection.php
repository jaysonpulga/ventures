<?php
session_start();
?>
<html>
<title>Collection</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
	<script src="../js/FormatNUmberBy3.js" type="text/javascript"></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:800px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>INTER BRANCH COLLECTION</h2><hr></label>
							</span>
						</div>
						<div>
							<span>
							<input type="hidden" id = "or_no" name="or_no" value="<?php echo $_REQUEST['or_no'] ?>">
								<label>O.R No.:</label>
								<input type="text" id = "txtor_no" readonly style="margin-left:60px; width:100px" maxlength = "3">
							</span>
							<span>
								<label style="margin-left:330px">Date:</label>
								<input type="date" id = "txtdate" style="margin-left:41px">
							</span>
						</div>
						<div style="margin-top:10px">
							<span>
								<input type = "hidden" id = "txtcusid">
								<label>Customer Name:</label>
								<input type="text" id = "txtcusname" style = "margin-left:7px; text-align:center; width:250px;">
								<a href="#"  style="width:30px;" onclick="search_customer();"><img src="" id="search" valign="bottom"></a>
								<a href="#"  style="width:30px;" onclick="new_customer();"><img src="" id="new" valign="bottom"></a>
								
							</span>
							<span>
								<label style="margin-left:110px">BRANCH:</label>
								<select id="txtbranch" name="txtbranch" style="margin-left:20px">
								</select>
							</span>
						</div>
						
						
						<div style="margin-top:10px">
							<span>
								<label>Address:</label>
								<input type="text" id = "txtaddress" style=" width:380px; margin-left:55px">
							
							</span>
							
						</div>
						
							
						<div style="margin-top:25px">
						<form action="" method="">
							<span>
								<label><b>Amount:</b></label>
								<input type="text" id = "amount" placeholder="AMOUNT"  onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')" style=" width:150px; margin-left:10px">
							</span>
							
							<span style=" margin-left:30px">
								<label><b>Remarks:</b></label>
								<input type="text" id = "ramarks" placeholder="REMARKS"  style=" width:200px; margin-left:10px">
							</span>
							
							<span style=" margin-left:10px">
								<input type = "button" id = "btnadd" value = "ADD" onclick = "Addamount();">
								<input type = "reset" id = "button" value = "RESET">
							</span>
							</form>
						</div>
						
						
						<div  class="contents" style="border:0px solid #000; width:800px;margin-top:10px" cellspacing="0">
							<h3>INTER BRANCH COLLECTION</h3>
							<table id = "interbranch_collection_list">
								<thead align = "center">
								<tr>
									<th>UNIT</th><th style="width:40%">PARTICULARS</th><th>AMOUNT</th><th colspan = "2">ACTION</th>
								</tr>
								</thead>
								<tbody id = "interbranch_collection_data"></tbody>
							</table>
						</div>
						
						
						<div align = "right" style = "margin-top:10px; font-weight:bold;">
							<span>
								<label>AMOUNT DUE: </label>
								<input type = "text" id = "total_amount"  style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>VAT_TAX(12%): </label>
								<input type = "text" id = "txtvat" style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>TOTAL SALES: </label>
								<input type = "text" id = "txttotal" style = "text-align: right;" disabled>
							</span>
						</div>
						
						
						
						
						<div align = "center" style = "margin-top: 20px;">
							<span>
								<input type = "button" id = "btnadd" value = "SAVE" onclick = "update();">
								<input type = "button" id = "btncancel" value = "PRINT" onclick="window.open('print_interbranch_Collection.php?or_no=<?php echo $_REQUEST['or_no']; ?>','_blank')">
								<input type = "button" id = "btncancel" value = "CANCEL" onclick = "window.location='collections.php?menu=transaction'">
							</span>
						</div>
						
						<div id="customer_items" style="display:none;">
							<iframe id="item_dialog" width="954" height="595" style="border:none"></iframe>
						</div>
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
	loadData();
	load_inter_collection();
	
	});
	
	var or_no = $("#or_no").val();
	
	
	
	function load_inter_collection(){

	var count=0,x=0,total_amout = 0,vat=0,amount_due=0;	
	var container=$("#interbranch_collection_list > tbody");
	
		$.ajax({
					url:"function_transaction.php",
					
					
					data:{"request":"ajax","action":"load_collection_interbranch","or_no":or_no},
					
				
					dataType:'json',
					beforeSend: function(){
						
					},
			success: function(reply){
							//console.log(reply.length);
				if(reply.length > 0){
					container.empty();
							$.each(reply, function(i,res){
								count++;
								

								 total_amout += parseFloat(res.amount);
								 vat = total_amout*0.12;
								 amount_due = total_amout-vat;
								 
								 $("#txtvat").val(FormatNumberBy3((Math.round(vat)).toFixed(2)));
								 $("#total_amount").val(FormatNumberBy3((Math.round(total_amout)).toFixed(2))); 
								 $("#txttotal").val(FormatNumberBy3((Math.round(amount_due)).toFixed(2))); 
								
								
						container.append("<tr class='x' id='record"+res.or_no+"'  ></td><td>1</td><td align='center'>"+res.remarks.toUpperCase()+"</td><td><input type='text' id='selling"+res.or_no+"' name='selling"+res.or_no+"'style='width:120px;margin-left:23px;text-align:right;' value = '"+FormatNumberBy3((Math.round(res.amount)).toFixed(2))+"' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\"></td><td align='center'><a href='#' alt='Update' title='Update' class='edit' onclick=\"view_collection('"+res.type+"','"+res.or_no+"');\"></a></td><td align='center'><a href='#' alt='Update' title='Update' class='delete' onclick=\"delete_item('"+res.id+"');\"></a></td></tr>");
																
				});
				}
				else{
					
				container.append("<tr id = 'noItems'><th colspan = '13' align = 'center'> No Items on record! </th></tr>");
				}
			}
		});

	}
	
	
	function loadData(){

			
			  var url="function_transaction.php?request=ajax&action=view_or_collection&or_no="+or_no;
			var counter=1;
		
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){
					var name = res.last_name+", "+res.first_name+" "+res.middle_name;
					$('#txtor_no').val(res.or_no);
					$('#txtdate').val(res.date);
					$('#txtcusname').val(name);
					$('#txtaddress').val(res.address);
					$('#txtcusid').val(res.customer_id);
					loadBranch(res.branch_code);
				
				});	
			});
			
		}
	
	function search_customer(){
			$("#customer_items").attr("title","SEARCH CUSTOMER");
			$("#item_dialog").attr('src','customer_name.php');
			$("#customer_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	function new_customer() {
			$("#customer_items").attr("title","NEW CUSTOMER");
			$("#item_dialog").attr('src','newCustomer.php');
			$("#customer_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	

	
	function loadBranch(branch_code){
		var count=0, x=0;
		var select = $("#txtbranch");

		$.ajax({
				url:"functions.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					
					
					
					if(reply.length > 0){
						select.empty();
								
							$.each(reply, function(i,res){
							 count++;
							 
							if(res.branch_code == branch_code ){
							select.append("<option  value='"+res.branch_code+"' selected='selected' >"+res.branch_code+"</option>");
							}	else{
							select.append("<option  value='"+res.branch_code+"'>"+res.branch_code+"</option>");
							}	
								
																		
							});
			
					}
				}
			});
	}
	
	
	function saveChanges(id,address,branch_code){
	
		jConfirm('Do you want to save this Changes?','Confirmation Dialog',function(e){	
			
		if(e){
			
			
			
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"updateORnumber","id":id,"address":address,"branch_code":branch_code,"or_no":or_no},
				success: function(reply){
					if(reply =="saved"){
						jAlert("Successfully Saved");
					}
				}
			});
			
	
  		}
		
		});
	
	}
	
	function closeIframe(id,name,address,branch_code) {
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
		loadBranch(branch_code);
		saveChanges(id,address,branch_code)
	}
	
	
	function closeIframeNew(id,name,address,branch_code) {
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
		loadBranch(branch_code);
		saveChanges(id,address,branch_code);
	}
	
	function Addamount() {
	
		var txtor_no=$("#txtor_no").val();
		var amount=$("#amount").val();
		var ramarks=$("#ramarks").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(amount == ""){
			errormsg+="- Input Amount\n";
		}
		
		if(ramarks == ""){
			errormsg+="- Input Remarks \n";
		}
		
		if(errormsg.length==emsg){
			$.ajax({
				url: "function_transaction.php",
				data:{"request":"ajax","action":"save_inter_collection","txtor_no":txtor_no,"amount":amount,"ramarks":ramarks},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Successfully Added!", "Alert Dialog");
							load_inter_collection();
							$('#amount').val('');
							$('#ramarks').val('');
						}
						else{
							alert('Error');
							event.preventDefault();
						}
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		
	}
	
	
	function delete_item(id){

		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
		if(e){
		
			var table =  "collection_interbranch";
			$.ajax({
				url: "../managements/function_items.php",
				data:{"request":"ajax","action":"deleteSingleItem","id":id,"table_name":table,"table_id":"id"},
				success: function(reply){
					load_inter_collection();
				}
			});
			
				
			jAlert("successfully Deleted");
		
	
  		}
		
		});
	}
	
		function update() {
		var txtor_no=$("#txtor_no").val();	
		var date_issued=$("#txtdate").val();	
		var customer_id=$("#txtcusid").val();
		var txtbranch=$("#txtbranch").val();	
		var address=$("#txtaddress").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(txtor_no == ""){
			errormsg+="- Input O.R. No.\n";
		}
		if(date_issued == ""){
			errormsg+="- Input Date Issued.\n";
		}
		if(customer_id == ""){
			errormsg+="- Input Customer Name.\n";
		}
		if(txtbranch == ""){
			errormsg+="- Input Branch.\n";
		}
		
		if(errormsg.length==emsg){
			$.ajax({
				url: "function_transaction.php",
				data:{"request":"ajax","action":"UPDATE_INTERBRANCH","txtor_no":txtor_no,"date_issued":date_issued,"customer_id":customer_id,"txtbranch":txtbranch,"address":address},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Successfully Updated!", "Alert Dialog");
							$("#interbranch_collection_list > tbody").empty();
									loadData();
									load_inter_collection();
						}else{
							jAlert('Error');
							event.preventDefault();
						}
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		
	}
	
	</script>