<html>
<title>Sales</title>
<head>
<?php
include('../database.php');  
$db = new Database();  
$db->connect();
?>

	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px;">
					<div style="margin-top:10px" align="center">
						<span>
							<label>Branch</label>
							<select id= 'branch' name='branch' style="margin-left:42px;" >
							</select>
						</span>
					</div>
					<div align="center">
						<span>
							<input type="hidden" id="po_no" value="<?php echo $_REQUEST['po_no']; ?>"  name="po_no" >
							<label>Manufacturer:</label>
							<select id= 'brand' name='brand' onchange = "changeCategory(this.value)" >
								<option value="">--Select--</option>
							</select>
						</span>
					</div>
					<div id="second" align="center">
					</div>
					<div align="center">
						<span>
							<label>Unit Cost:</label>
							<input type="text" id="unit_cost" name="unit_cost" style="margin-left:35px;text-align:right;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
						</span>
					</div>
					<div align="center">
						<span>
							<label>Quantity:</label>
							<input type="text" id="qty" name="qty" style="margin-left:35px" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
						</span>
					</div>
					<div id="fourth">
					</div>
					
					<div align="center">
						<span>
							<br>
							<input type="button" value="ADD" onclick="Add_stock()" style="width:100px;top:1px;">
							<input type="button" value="CANCEL" onclick="Cancel()" style="width:100px;top:1px;">
						</span>
					</div>
			</div>
		<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	var table= getUrlVars()["table"];
	var cat= getUrlVars()["cat"];
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		var brand = $("#brand").val()
		$('#br').val(brand);
		var b = $('#br').val();
		
		loadBranches();
		loadBrand();
		
		//select_model(b);
		select_Item_code(b,table);
		secondinput(cat);
				
	});	
	
	function loadBrand(){
					
			
		var url="function2.php?request=ajax&action=loadBrand&category="+cat;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				 $("#brand").append("<option value="+ res.id +">" + res.brand + "</option>"); 
			});
		});	
					
	}
	
	function secondinput(cat){
		if(cat == "1"){
			$("#second").append('<span><label>Model:</label><select id = "model" name="model" style="margin-left:45px" onchange = "Select_unit_Cost(this.value)" ></select></span>');
			$("#fourth").append('<span><label style="margin-left:57px">Color:</label><input type="text" id="color" name="color" style="margin-left:58px"></span>');
		}else{
			$("#second").append('<span><label>Item Code:</label><select id = "item_code" name="item_code" style="margin-left:20px" onchange = "Select_unit_Cost(this.value)"</select></span>');
			$("#fourth").append('<span><label style="margin-left:55px" >Description:</label><br><span><textarea readonly="readonly" rows="3" id="description" name="description" style="margin-left:150px; margin-top:-17px"></textarea></span>');
		}
	}
	
	function Cancel(){
		var action = "cancel";
		window.parent.closeIframe(action);
	}
	
	function loadBranches(){
		var url="function2.php?request=ajax&action=loadBranches";
	
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				 $("#branch").append("<option value='"+ res.branch_code +"'>" + res.branch_name + "</option>"); 
			});
		});
	}	
	
	function changeCategory(brand){
		$('#br').val(brand);	
		$("#unit_cost").val("");
		$("#description").val("");
		select_model(brand);
		select_Item_code(brand)
		
	}

	
	function select_model(brand){

	event.preventDefault();

	var url="function2.php?request=ajax&action=load_select_model&id="+brand+"&table="+table;
	var counter=1;

		$.getJSON(url,function(data){
	
		$("#model").empty();
		$("#unit_cost").val("");
		
			$("#model").append("<option  value=''>--Select Model--</option>");
			$.each(data.members, function(i,res){
						
				$("#model").append("<option value='"+res.motor_id+"' >"+res.model+"</option>");
			
			counter++;
				
			});
			if (counter <= 1){
				$("#model").append("<option>NO RECORD</option>");
			}
		});	
		
		
	
	}
	
	
	function select_Item_code(brand){

	event.preventDefault();

	var url="function2.php?request=ajax&action=load_select_ItemCode&id="+brand+"&table="+table;
	var counter=1;

		$.getJSON(url,function(data){
	
		$("#item_code").empty();
		$("#unit_cost").val("");
		
			$("#item_code").append("<option  value=''>--Select--</option>");
			$.each(data.members, function(i,res){
				if(res.parts_id){
					var id = res.parts_id;
				}
				else if(res.promo_id){
					var id = res.promo_id;
				}
				else if(res.con_id){
					var id = res.con_id;
				}
						
				$("#item_code").append("<option value='"+id+"' >"+res.item_code+"</option>");
				
				counter++;
				
			});
			if (counter <= 1){
				$("#item_code").append("<option>NO RECORD</option>");
			}
			
			
			
		});	
	
	}
	
	
	function Select_unit_Cost(motor_id){
		if(motor_id == ""){
			$("#unit_cost").val("");
			$("#description").val("");
		}

	event.preventDefault();

	var url="function2.php?request=ajax&action=select_unit_cost&id="+motor_id+"&table="+table;
		$.getJSON(url,function(data){
	
		$("#unit_cost").val("");
		$("#description").val("");
			$.each(data.members, function(i,res){
					
				var unit = (Math.round(res.unit_cost)).toFixed(2);
						
				$("#unit_cost").val(unit);
				$("#description").val(res.description);
			
			});
			
		});	
	
	}
	
	function Add_stock(){
		
		event.preventDefault();
		
		var po= getUrlVars()["po_no"];
		var category = getUrlVars()["cat"];
		var brand = $('#brand').val();
		var branch = $('#branch').val();
		var item_code = $('#item_code').val();
		
		var model = $('#model').val();
		var color = $('#color').val();
		var unit_cost = $('#unit_cost').val();
		var qty = $('#qty').val();
		
		var errormsg="Please complete the following fields: \n";
		var emsg= errormsg.length;

			if(branch == ""){
				errormsg+="- Branch \n";
				
			}
			if(brand == ""){
				errormsg+="- Manufacturer \n";
				
			}
			if(item_code == "" && category != "1"){
				errormsg+="- Item Code \n";
				
			}
			if(model == "" && category == "1"){
				errormsg+="- Model \n";
				
			}
			if(qty == "" ) {
				errormsg+="-Quantity \n";
				
			}
			
			if(errormsg.length== emsg){
			
			
		$.ajax({
			
				   url: "function2.php",
					data:{"request":"ajax","action":"add_stock","po_no":po,"category":category,"brand":brand,"branch":branch,"item_code":item_code,"model":model,"color":color,"unit_cost":unit_cost,"qty":qty},
					success: function(reply){
						console.log(reply);
							if(reply == 'saved'){	
								var actions="add";
								window.parent.closeIframe(actions);
							}else{
								jAlert("Error Adding Item");
							}
						
						}
			
			
			
			});
			
			}else{
				jAlert(errormsg);
				event.preventDefault();
			}
	
	}
	
	
	
	
	</script>
	
</body>
</html>