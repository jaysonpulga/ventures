<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION["username"];
$branch_name = $_SESSION["branch_name"];
$branch_id = $_SESSION['branch_id'];

?>
<!DOCTYPE HTML>
<html lang="en">
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:800px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>SALES RETURN</h2><hr></label>
								<input type="hidden" id = "branch_id" value = "<?php echo $branch_id; ?>" >
								<input type="hidden" id = "branch_name" value = "<?php echo $branch_name; ?>" >
								<input type="hidden" id = "customer" value = "<?php echo $_REQUEST['customer_id']; ?>" >
							</span>
						</div>
						<div>
							<span>
								<label>SR No.:</label>
								<input type="text" id = "txtreturn" value = "<?php echo $_REQUEST['sr_no']; ?>" style="margin-left:67px; width:100px" readonly>
							</span>
							<span>
								<label style="margin-left:315px">Date:</label>
								<input type="date" id = "txtdate" style="margin-left:41px; width:160px;">
							</span>
						</div>
						<div>
							<span>
								<label>Customer Name:</label>
								<input type="text" id = "txtcusname" style = "margin-left:7px; text-align:center; width:300px;">
							
							</span>
						</div>
						<div>
							<span>
								<label>Address</label>
								<input type="text" id = "txtaddress" style=" width:400px; margin-left:61px">
							</span>
						</div>
						<div>
							<span>
								<label>Search Item</label>
								<select id = 'search_item' name='brand' style="margin-left:38px">
									<option value="">--SELECT--</option>
									<option value="invoice">INVOICE #</option>
									<option value="or">O.R #</option>
								</select>
								<a href="#" style="width:30px;"  onclick="search_stocks();"><img src="" id="search" valign="bottom"></a>
							</span>
						
						
						</div>
						<div  class="contents" style="border:0px solid #000; width:800px" cellspacing="0">
							<h3>ORDER SALES</h3>
							<table id = "return_list">
								<thead align = "center">
								<tr>
									<th>INV #</th><th>QTY</th><th style="width:45%">PARTICULARS</th><th>UNIT PRICE</th><th>AMOUNT</th><th colspan>ACTION</th>
								</tr>
								</thead>
								<tbody id = "return_data"></tbody>
							</table>
						</div>
						<input type = "hidden" id = "txtid" value = "<?php echo $_REQUEST['id']; ?>">
						<input type = "hidden" id = "txtqty">
						<input type = "hidden" id = "txtitemid">
						<div align = "right" style = "margin-top:10px; font-weight:bold;">
							<span>
								<label>AMOUNT DUE: </label>
								<input type = "text" id = "txtdue"  style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>VAT: </label>
								<input type = "text" id = "txtvat" style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>TOTAL: </label>
								<input type = "text" id = "txttotal" style = "text-align: right;" disabled>
							</span>
						</div>
						<div align="center" style="margin-top:10px">
							<span>
								<input type="button" value="UPDATE" onclick = "Update();">
								<input type="button" value="PRINT" onclick="window.open('printSalesReturn.php?sr_no=<?php echo $_REQUEST['sr_no']; ?>','_blank')">
								<input type="button" value="CANCEL" onclick="window.location='sales_return.php?menu=transaction'">
							</span>
						</div>
						
						<div id="customer_items" style="display:none;">
							<iframe id="item_dialog" width="954" height="595" style="border:none"></iframe>
						</div>
						
						<div id="add_item" title="" style="display:none;">
							<iframe id="add_dialog" width="800" height="500" style="border:none"></iframe>
						</div>
						
						<div id="new_items2" title="" style="display:none;">
								<iframe align="center" id="item_dialog2" width="954" height="595" style="border:none"></iframe>
						</div>
						
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}

		var item_id = $("#txtitemid").val();
		
		loadUpper();
		load_invoice_return()
			
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
	});
	
	
	var sr = $("#txtreturn").val();
	var customer =  $("#customer").val();
	
	
	var branch_id = $("#branch_id").val();
	var branch_name = $("#branch_name").val();
	
	
	
	function loadUpper() {
		var sr = $("#txtreturn").val();
		var url="functions.php?request=ajax&action=loadReturnData&sr_no="+sr;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
			
				$("#txtdate").val(res.date_returned);
				$("#txtcusid").val(res.customer_id);
				$("#txtcusname").val(res.customer_name);
				$("#txtaddress").val(res.address);
			
			});
		});
		
	}


	function search_stocks() {
	

			var val = $('#search_item').val();

			if(val == ""){
				jAlert("Please Select",'ALERT DIALOG');
			
			}else{
			if(val == "invoice"){
			
				var table = "sales_invoice";
			}
			if(val == "or"){
				var table = "collections";
			}
				
				$("#new_items2").attr("title",val+"-"+branch_name);
					$("#item_dialog2").attr('src','viewReturn_inv_or.php?table='+table+'&sr='+sr+'&customer='+customer);
					$("#new_items2").dialog({
						width: 955,
						height: 643,
						modal: true,
						resizable:false,
						close: function () {
							$("#item_dialog").attr('src',"about:blank");
						}
					});
					return false;
			} 
	
	}
	
	function closeIframe(id,name,address) {
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
	}
	
	function closeIframeNew(id,name,address) {
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
	}
	
	function closeIframeItem(sr_no) {
		$("#add_item").dialog('close');
		loadTable(sr_no);
	}
	
	
	function load_invoice_return(){

	
	
	var url="function_transaction.php?request=ajax&action=load_return&sr="+sr ;
	var counter=1;
	var x = 1,total_sale =0,vat=0,amount_due=0;

		$.getJSON(url,function(data){
		
			$("#return_list > tbody").empty();
					$.each(data.members, function(i,res){
				
				if(res.category == '1'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.model+"<br> ENGINE NO: "+res.engine_no+"<br> FRAME NO:"+res.frame_no+"<br>COLOR:"+res.color;
				
				}
				
				else if(res.category == '5'){
			
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.model+"<br> ENGINE NO: "+res.engine_no+"<br> FRAME NO:"+res.frame_no+"<br>COLOR:"+res.color;
				
				}
				
				
				else if (res.category == '3'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no+"<br>COLOR: "+res.color;
				
				}
				
				else if(res.category == '2'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no;
				
				}
				
				else if(res.category == '4'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no;
				
				}
				
				var cate = res.qty;
				
				var total_amount = parseFloat(cate) * parseFloat(res.amount);
				
				 total_sale += parseFloat(res.amount) *  parseFloat(cate);
				  vat = total_sale*0.12;
				  amount_due = total_sale-vat;
				  
				  if(isNaN(total_amount)){
					total_amount = 0;
				 }
				 if(isNaN(total_sale)){
					total_sale = 0;
				 }
				
				 if(isNaN(vat)){
					vat = 0;
				 }
				 if(isNaN(amount_due)){
					amount_due = 0;
				 }
			
								$("#txtvat").val(FormatNumberBy3((Math.round(vat)).toFixed(2)));
								 $("#txtdue").val(FormatNumberBy3((Math.round(total_sale)).toFixed(2))); 
								 $("#txttotal").val(FormatNumberBy3((Math.round(amount_due)).toFixed(2))); 
			
				
				
				
				
				
				$("#return_list > tbody").append("<tr class='x' id='record"+res.invoice_id+"'><td align='center'>"+res.invoice_no+"</td><td align='center'>"+cate+"</td><td align='center'>"+particulars+"</td><td>"+FormatNumberBy3((Math.round(res.amount)).toFixed(2))+"</td><td style='text-align:right'>"+FormatNumberBy3((Math.round(total_amount)).toFixed(2))+"</td><td align='center'><a href='#' alt='Update' title='delete' class='delete' onclick=\"delete_item('"+res.invoice_no+" ','"+res.stock_id+" ','"+res.category+"','"+res.qty+"','"+res.sr_id+"','"+res.source+"');\"></a></td></tr>");
									
						 counter++;
						 
			});	
			
		
			if (counter <= 1){
				$("#return_list > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Items on record! </th></tr>");
			}
					
					
		});
	

	}
	
	function deleteItem(id,item_id,type) {
	
		var sr = $("#txtreturn").val();
	
		jConfirm('Do you really want to DELETE this ITEM?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "functions.php",
					data:{"request":"ajax","action":"deleteReturnItem","id":id,"item_id":item_id,"item_type":type},
					success: function(reply){
						console.log(reply);
							if(reply == 'deleted'){
								jAlert('Item Deleted','Alert Dialog');
								window.location="viewReturn.php?menu=transaction&sr_no="+sr+"&id="+id;
							}else{
								jAlert('Error','Alert Dialog');
								event.preventDefault();
							}
						}
				});
			}
		});
	
	}
	
	function Update() {
		
		var sr = $("#txtreturn").val();
		var id = $("#txtid").val();
		var date_returned = $("#txtdate").val();
		var customer_id = $("#txtcusid").val();
		var address = $("#txtaddress").val();
		
		jConfirm('Do you really want to UPDATE this DATA?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "functions.php",
					data:{"request":"ajax","action":"updateReturnDetails","id":id,"sr_no":sr,"date_returned":date_returned,"customer_id":customer_id,"address":address},
					success: function(reply){
						console.log(reply);
							if(reply == 'updated'){
								jAlert("Data was successfully Updated!", "Alert Dialog");
								window.location = "sales_return.php?menu=transaction";
								
							}else if(reply == 'exists'){
								jAlert('SR No. Already Exists!', 'Alert Dialog');
							}
							else{
								alert('Error');
								event.preventDefault();
							}
					}
				});
			}
		});
	}
	function closeIframe2(actions){
		if(actions=="add"){
			jAlert("Successfully Added");
			load_invoice_return();
		}
		else if(actions=="edit"){
			jAlert("Successfully Updated");
		}
		else if(actions=="cancel"){
			$('#new_items2').dialog('close');
		}
		$('#new_items2').dialog('close');
		loadUpper();
		loadTable(invoice);
		
		
		
		return false;
	}
	
	function delete_item(invoice_no,stock_id,category,qty,sr_id,source){
	


	 jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
		 if(e){
		
			
			 $.ajax({
				 url: "function_transaction.php",
				 data:{"request":"ajax","action":"delete_sale_return","invoice_no":invoice_no,"stock_id":stock_id,"quantity":qty,"category":category,"sr_id":sr_id,"source":source},
				 success: function(reply){
						 jAlert("successfully Deleted");
						 load_invoice_return();
				 }
			 });
				
		
		
	
  		 }
		
		 }); 
	
	
	}
	
	
	</script>
	
</body>
</html>