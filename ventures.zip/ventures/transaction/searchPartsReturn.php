<!DOCTYPE HTML>
<html lang="en">
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px; margin-left:15px;" >
				<div align = "center">
					<select id = 'txtbrand' name='brand'>
						<option value="">- BRAND -</option>
					</select>
				</div>
				<div align = "center">				
					<select id = 'txtcode' name='brand'>
						<option value="">- ITEM CODE -</option>
					</select>
				</div>	
				<input type = "hidden" id = "txtreturn" value = "<?php echo $_REQUEST['sr_no']; ?>">
				<table id = "parts_list" class="contents" width="750px" align = "center" style="margin-top:10px;">
					<thead align="center">
					<tr>
						<th></th><th>INVOICE<BR>NO.</th><th>SERIAL<BR>NO.</th><th>TOTAL<BR>ON HAND</th><th>QTY</th>
					</tr>
					</thead>
						<tbody id = "parts_data"></tbody>
				</table>
				<div>
					<span>
						<label>Reason</label>
						<textarea id = "txtreason"></textarea>
					</span>
				</div>
				<div align="center" style="margin-top:15px">
					<span>
					<input type="button" value="ADD" onclick = "checkbox()">
					<input type="button" value="CANCEL"  onclick = "window.parent.closeIframeItem();">
					</span>
				</div>
			</div>
		</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadBrand();
		loadTable();
		
		$('#txtcode')
		.prop('disabled', true)
		.empty()
		.append('<option value="">- ITEM CODE -</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$( "#txtbrand" ).change(function() {
			$('#txtcode')
			.prop('disabled', false)
			.empty()
			.append('<option value="">- ITEM CODE -</option>')
			.find('option:first')
			.attr("selected","selected")
			;
			
			brand_id=$("#txtbrand :selected").val();
			brand_name=$("#txtbrand :selected").text();
			
			loadTable();
			loadModel(brand_id);
			
		});
		
		$( "#txtcode" ).change(function() {
			
			parts_id=$("#txtcode :selected").val();
			parts_name=$("#txtcode :selected").text();
			
			loadTable(parts_id);
			
		});
		
	});
	
	function loadBrand() {
		
		var url="functions.php?request=ajax&action=loadBrandReturn&category=2";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){

				$("#txtbrand").append("<option value="+ res.id+">" + res.brand + "</option>");

			});
		});
		
	}
	
	function loadModel(id){
		
		var url="functions.php?request=ajax&action=loadCodeReturn&brand_id="+id;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtcode").append("<option value="+ res.parts_id+">" + res.item_code + "</option>");

			});
		});
	}
	
	function loadTable(id) {
		$("#parts_list > tbody").empty();
	
		var url="functions.php?request=ajax&action=loadStockPartsReturn&item_code="+id;
		var counter=0;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				if(res.remain == 0){
				
				$("#parts_list > tbody").append("<tr class='x' id='record"+res.id+"' ><td></td><td><input type = 'hidden' id = 'txtinvoice' value = '"+res.invoice_no+"'>"+res.invoice_no+"</td><td align='center'>"+res.serial_no+"</td><td align='center'>"+res.remain+"</td><td align='center'><input type='text' id='quantity"+res.serial_no+"' name='quantity"+res.serial_no+"'style='width:60px;margin-left:1px;text-align:center;' disabled='disabled' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\"></td></tr>");
				}else{
				
				$("#parts_list > tbody").append("<tr class='x' id='record"+res.id+"' ><td><input type='checkbox'  id='checkmo"+res.id+"' name='chk[]' class='checkboxrecord' value='"+res.serial_no+"' onclick='checkmo("+res.id+")'   /></td><td><input type = 'hidden' id = 'txtinvoice' value = '"+res.invoice_no+"'>"+res.invoice_no+"</td><td align='center'>"+res.serial_no+"</td><td align='center'>"+res.remain+"</td><td align='center'><input type='text' disabled id='quantity"+res.serial_no+"' class='textbox"+res.id+"' name='quantity"+res.serial_no+"'style='width:60px;margin-left:1px;text-align:center;' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, ''),myFunction("+res.id+")\" ></td><input type = 'hidden' id = 'txtprice' value = "+res.selling_price+"></tr>");
				
				}
				counter++;
			});
			if (counter <= 0){
				$("#parts_list > tbody").append("<tr id = 'noItems'><th colspan = '5' align = 'center'> No Selected Items! </th></tr>");
			}
		});
		
	}
	
	function checkmo(id) {
			
		var checked = $("#checkmo"+id).is(":checked");
		
		if(checked == true){
			$('.textbox'+id).attr("disabled", false);
			$('.textbox'+id).focus();
		}else{
			$('.textbox'+id).attr("value", "");
			$('.textbox'+id).attr("disabled", true);
		} 
	}
	
	/* function Add() {
		var item_id;
		var sr_no=$("#txtreturn").val();
		var invoice_no=$("#txtinvoice").val();
		var count=0;
		var item_type="parts";
		
		var selling_price = $("#txtprice").val();
		var qty = 1;
		var reason = $("#txtreason").val();
	
		$("#txtcheck:checked").each(function(){
			item_id=$(this).val();
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"saveReturnData","sr_no":sr_no,"invoice_no":invoice_no,"item_type":item_type,"item_id":item_id,"qty":qty,"selling_price":selling_price,"reason":reason},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Data was Successfully Saved!", "Alert Dialog");
							window.parent.closeIframeItem(sr_no);
						}
						else if(reply == 'exists'){
							jAlert('Item Already Exists!', 'Alert Dialog');
						}
						else{
							alert('Error');
							event.preventDefault();
						}
				}
			});
		});
		
	} */
	
	function checkbox(){
	
		var Checkarray =[];
	  
		var checkbox = $(".checkboxrecord");
		$.each(checkbox, function(key,val){
			if($(this).prop("checked")){
				Checkarray.push($(this).attr('value'));
			}
	  
		});
		
		var selling_price = $("#txtprice").val();
		var sr_no=$("#txtreturn").val();
		var invoice_no=$("#txtinvoice").val();
		var item_type="parts";
		var quantity = $("#quantity"+Checkarray).val();
		var reason = $("#txtreason").val();
		
		var errormsg="Please complete the following fields: \n";
		var emsg= errormsg.length;
	  
		if(quantity == ""){
			errormsg+="-Quantity \n";
		}
	  
		if(errormsg.length== emsg){
			if(Checkarray.length > 0){
				$.ajax({
					url: 'functions.php',
					data:{"request":"ajax","action":"saveReturnParts","array":Checkarray,"sr_no":sr_no,"invoice_no":invoice_no,"item_type":item_type,"quantity":quantity,"selling_price":selling_price,"reason":reason},
				
					beforeSend: function(){
					}, success : function(returnData){
						
						if(returnData == "uhryt"){
								
							jAlert("Data was Successfully Saved!", "Alert Dialog");
							window.parent.closeIframeItem(sr_no);
						}
																
					}, error: function(){}
				});
			  
		  
			}else {
				jAlert("Please make a selection","Alert Dialog");
			}
		}else{
			jAlert(errormsg);
			event.preventDefault();
		}  
	
	}
	
	function myFunction(id){
		
		  var Checkarray =[];
		  
		 var checkbox = $(".checkboxrecord");
		  $.each(checkbox, function(key,val){
		  
		  if($(this).prop("checked")){
			Checkarray.push($(this).attr('value'));
		  }
	  
		});
		var table = "stocks_parts a, invoice_details b";
		var quantity = $('#quantity'+Checkarray).val();
	  if(Checkarray !="" && id !=""){
				var qty = parseInt(quantity);
				
				var url="function_transaction.php?request=ajax&action=check_datareturn&table="+table+"&array="+Checkarray;
				
					$.getJSON(url,function(data){
						$.each(data.members, function(i,res){
							var val = res.remaining;
							var val2 = parseInt(val);
							
								if(qty > val2){
									jAlert("Remaning Balance:"+ val);
									$('#quantity'+Checkarray).val(val);
									return false;
								}
							
						});	
					});
	}else{
		jAlert("Please make a selection","Alert Dialog");
	} 
		
				
	}
	
	</script>
	
</body>
</html>