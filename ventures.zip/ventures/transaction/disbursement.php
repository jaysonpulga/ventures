<html>
<title>Disbursement</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<table width="780px">
						<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2 style="margin-top:10px;">DISBURSEMENT</h2>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
							<form name="search" action="" method="POST">
							<select id = 'category' name='category'>
								<option value="Category">Category </option>
							</select>
								<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Report">
								<input type="button" value="CREATE NEW" id='input' style="width:120px;" onclick="add_item();">
								</form>
							</td>
						</tr>
					</table>
				</div>
					
				<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:780px" cellspacing="0">
					<table>
						<tr><th>D.V.</th><th>DATE</th><th>PARTICULARS</th><th>SUPPLIER</th><th>CHECK NO.</th><th style="width:15px;">ACTION</th></tr>
						<tbody>
						<tr><td>D.V.</td><td>Date</td><td>particulars</td><td>Supplier</td><td>Cheack No.</td><td><a href='#' class="view" title="VIEW link"></a></td></tr>					
						</tbody>
					</table>
				</div>	
				<div id="new_items" title="NEW DISBURSEMENT " style="display:none;">
				<iframe id="item_dialog" width="680" height="410" style="border:none"></iframe>
				</div>
			</div>		
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
	});	
	function add_item(){
		
			$("#item_dialog").attr('src','../transaction/newDisbursement.php?ref_no=');
			$("#new_items").dialog({
				width:681,
				height: 460,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
		}
	</script>
	
</body>
</html>