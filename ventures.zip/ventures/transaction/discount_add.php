<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
<form  name="frm"  method="POST">


<input  type="hidden" id="or_no" name="or_no" value="<?php echo $_REQUEST['or_no']; ?>" style="margin-left:17px">

	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px;">
				<div style="margin-top:10px;">
				
				
					<span>
						<label style="margin-left:10px">JV NO:</label>
						<input readonly type="text"id="JV" name="JV" style="margin-left:35px"  >
					</span>
				</div>
				
				<div>
					<span>
						<label style="margin-left:10px">TYPE:</label>
						<select id='type' style="margin-left:43px">
						<option value='CR'>CR</option>
						<option value='DR'>DR</option>
						
						</select>
					</span>
				</div>
				
				
					<div>
					<span>
						<label style="margin-left:10px">ACCT NO:</label>
						<input readonly type="text" id="acct" name="acct" value="<?php echo $_REQUEST['acct']; ?>" style="margin-left:17px">
					</span>
				</div>
				
				
				
				
				
				<div style="margin-top:10px">
					<span>
						<label style="margin-left:10px;margin-top:10px">AMOUNT:</label>
						<input type="text" id="amount" name="amount" style="margin-left:17px">
					</span>
				</div>
	
			
				<div align="center">
					<span><br>
					
				
					<input type="button" value="SAVE" onClick="save_discount()" >		
					<input type="button" value="CANCEL" onClick="Cancel();">
					
					</span>
				</div>
			</div>
		</div>
	</div>

	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		 load_id();
	});	
	var acct = $("#txtaccount").val();
	var or_no = $("#or_no").val();
	
	
	function load_id(){
	
		var url="function_transaction.php?request=ajax&action=select_max_id";
			var counter=1;
		
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){	
					
					$('#JV').val(res.JV);
							
				});	
			});
	
	
	}

	
	
	function save_discount(){

	
	 event.preventDefault();
	
	var amount = $('#amount').val();
	var type = $('#type').val();
	var or_no = $('#or_no').val();
	var acct = $('#acct').val();
	
	var desc = "DISCOUNT";
	
	
	var errormsg="Please complete the following fields: \n";
	var emsg= errormsg.length;

		if(amount == ""){
			errormsg+="-Amount\n";
			
		}
		if(type == ""){
			errormsg+="-Type \n";
			
		}
		if(errormsg.length== emsg){
		
		
	$.ajax({
		
		       url: "function_transaction.php",
				data:{"request":"ajax","action":"discount_add","amount":amount,"type":type,"or_no":or_no,"acct":acct,"desc":desc},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){	
							var actions="add";
							window.parent.closeIframe(actions);
						}else if(reply == 'duplicate'){
						
							jAlert("DEBIT/CREDIT MEMO Already existing");		
							
						}else{
							jAlert("cannot add information");
						}
					
					}
		
		
		
		});
		
		}else{
			jAlert(errormsg);
			event.preventDefault();
		} 
		
	}
	
	


	
	function Cancel(){
		var action = "cancel";
	window.parent.closeIframe(action);
	}
	</script>
	
</body>
</html>