<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<style>
.contents2 th{
	text-align:center;

}
</style>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px; margin-left:15px;" >
				
					<div  class="contents2" style="border:0px solid #000;width:800px" cellspacing="0">	
							<table id="table">
								<thead>
									<tr align="center"><th width=5%></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'a.sr_no')">S.R.#</a></th><th  style="width:20%"><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'a.date')">DATE</a></th><th style="width:10%"><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'a.branch_code')">BRANCH</a></th><th  style="width:25%">ITEM</th><th style="width:10%"><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'b.quantity')">QTY</a></th><th style="width:10%"><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'b.unit_cost')">UNIT COST</a></th></tr>
								</thead>
								<tbody id="alldata">
								</tbody>
							</table>
					</div>
					
					<div id="pagination" style = "margin-top: 30px;"> 
						<div class="holder" ></div>
						<center><i>Pages</i></center>
					</div>
					
					<div align="center" style="margin-top:10px">
						<span>
							<input type="button" value="ADD" onclick="AddItem();">
							<input type="button" value="CANCEL" onclick="Cancel();" >
						</span>
					</div>
			</div>
		<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	function jpages(){
		$("div.holder").jPages({
		  containerID : "alldata",
		  previous : "←",
		  next : "→",
		  perPage : 10,
		  delay :10,
		  startPage    : 1,
		  startRange   : 1,
		  midRange     : 5,
		  endRange     : 1
		});
	}
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
				
	var sortType = "ASC";
	
	function filter_list(index,cVar){
		sort = cVar;
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadRequisitions(sort,sortType);
	}
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		loadRequisitions("a.date","DESC");
	});	
	
	function loadRequisitions(sort,sortType){
				
					
		$("#table > tbody").empty();
		
		var url="function2.php?request=ajax&action=loadRequisitions&sort="+sort+"&sortType="+sortType;
		
	
		$.getJSON(url,function(data){
			var counter=0;
		
			$.each(data.members, function(i,res){
				if(res.status=="ON PROCESS"){ 	
					$("#table > tbody").append("<tr style='background-color:#f3f2f2'><td><input type='checkbox' name='chk[]' class='checkBoxRecord' value='"+res.stock_id+"'></td><td>"+res.sr_no+"</td><td>"+res.date+"</td><td>"+res.branch+"</td><td>"+res.particulars+"</td><td>"+res.qty+"</td><td><div align='right'>"+parseFloat(res.unit_cost).toFixed(2)+"</div></td></td></tr>");
				}
				else{
					$("#table > tbody").append("<tr style='background-color:#ff6767'><td><input type='checkbox' name='chk[]' class='checkBoxRecord' value='"+res.stock_id+"'></td><td >"+res.sr_no+"</td><td>"+res.date+"</td><td>"+res.branch+"</td><td>"+res.particulars+"</td><td>"+res.qty+"</td><td><div align='right'>"+parseFloat(res.unit_cost).toFixed(2)+"</div></td></td></tr>");
				}
				counter++;
				
			});
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
				//$( "#qty" ).html("<label style='font-weight:bold'> "+counter+" </label>");	
			}
			jpages();

		});
		
		
	}
	
	function AddItem(){
		var po = getUrlVars()["po_no"];
		var dArr = [];
		var checkBoxRecord = $(".checkBoxRecord");
			$.each(checkBoxRecord, function(key,val){
				if($(this).prop("checked")){
					dArr.push($(this).attr('value'));
				}
			});
			
			if(dArr.length > 0){
				
				jConfirm("Add all selected items?","Confirmation Dialog", function(e){
				if(e){
						$.ajax({
							url: "function2.php",
							data:{"request":"ajax","action":"addRequest","po_no":po,"array":dArr},
							success: function(reply){
								console.log(reply);
									if(reply == 'saved'){	
										var actions="add";
										window.parent.closeIframe(actions);
									}else{
										jAlert("Error Adding Item");
									}
								
								}
						});
							
						}
					});
				}
			else {
				jAlert("Please make a selection","Alert Dialog");
			}					
	}
	function Cancel(){
		window.parent.closeIframe();
	}
	</script>
	
</body>
</html>