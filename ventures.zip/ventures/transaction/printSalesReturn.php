<html>
<title>SALES RETURN</title>
</html>
<?php
include('../database.php');  
$db = new Database();  
$db->connect(); 

	/* $dataArray_motors=array();
	$dataArray_parts=array();
	$dataArray_cons=array();
	$dataArray_promo=array();
	$dataArray=array(); */
	
	$dataArray=array();
	$dataArray6=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$sortType="DESC";
	$sort="a.id";
	$sr_no=$_REQUEST["sr_no"];
	
	$rows = "a.*,b.last_name,b.first_name,b.middle_name";
	$where = "a.sr_no=$sr_no AND a.customer_id=b.id";
	$order = "$sort $sortType";
	$db->select("sales_return a,tbl_customer b",$rows,$where);

	$result = $db->getResult();
	
	$total_qty=0;
	$total_amount=0;
	$i=0;
	foreach($result as $key){
		$sr_no=$key["sr_no"];
		$date_returned=$key["date_returned"];
		$customer_name=$key["last_name"].", ".$key["first_name"]." ".$key["middle_name"];
		
		$rows = "a.sr_no,b.*";
		$where = "b.sr_no=$sr_no AND a.sr_no=b.sr_no";
		$db->select("sales_return a,sr_details b",$rows,$where);
	
		$result2 = $db->getResult();
	
		foreach($result2 as $key){
		
		
			$category=$key["category"];
		    $sr_no=$key["sr_no"];
		    $source=$key["source"];
		 
				 if($source == "invoice"){
					
					 $tablex = "sale_invoice_details";
				 }else if($source == "cash"){
					
					 $tablex = "collection_cash";
				 }
				 
				 if($category == '1'){
					 
						$row = "a.reason,a.source,a.inv_id,a.category,a.id as sr_id,a.stock_id,a.qty,b.engine_no,b.frame_no,b.color,c.model,d.brand,e.amount,a.invoice_no";
						$table = "sr_details a,stocks_motors b,tbl_motorcycle c,tbl_manufacturer d,$tablex e";
						$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = d.category AND a.sr_no = '$sr_no' AND a.inv_id = e.id AND a.qty != 0"; 
						$db->select($table,$row,$where);
						$result = $db->getResult();
						$dataArray=$result;	
					 }
					 
					else if($category == '5'){
					
					 
						$row = "a.reason,a.source,a.inv_id,a.category,a.id as sr_id,a.stock_id,a.qty,b.engine engine_no,b.frame frame_no,b.color,c.model,d.brand,e.amount,a.invoice_no";
						
						$table = "sr_details a,stock_repo b,tbl_motorcycle c,tbl_manufacturer d,$tablex e";
						
						$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = 5 AND a.sr_no = '$sr_no' AND a.inv_id = e.id AND a.qty != 0"; 
						$db->select($table,$row,$where);
						$result = $db->getResult();
						$dataArray6=$result;	
					 }
					 
					  else if($category == '2'){

						$row = "a.reason,a.source,a.inv_id,a.category,a.id as sr_id,a.stock_id,a.qty as qty,b.serial_no,c.item_code,d.brand,e.amount,a.invoice_no";
						
						$table = "sr_details a, stocks_parts b,tbl_parts c, tbl_manufacturer d,$tablex e";
						
						$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.parts_id AND b.brand = d.id AND a.category = d.category AND a.sr_no = '$sr_no' AND a.inv_id = e.id AND a.qty != 0" ;
						$db->select($table,$row,$where);
						$result = $db->getResult();
						$dataArray2=$result;
					   
					 
					 }
					 else if($category == '3'){
						
						
						$row = "a.reason,a.source,a.inv_id,a.category,a.id as sr_id,a.stock_id,a.qty,b.serial_no,b.color,c.item_code,d.brand,e.amount,a.invoice_no";
						
						$table = "sr_details a, stocks_promo b,tbl_promo c,tbl_manufacturer d,$tablex e";
						
						$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.promo_id AND b.brand = d.id AND a.category = d.category AND a.sr_no = '$sr_no' AND a.inv_id = e.id AND a.qty != 0";
						$db->select($table,$row,$where);
						$result = $db->getResult();
						$dataArray3=$result;
					  
					 }
					 else if($category == '4'){
						
						
						$row = "a.reason,a.source,a.inv_id,a.category,a.id as sr_id,a.stock_id,a.qty,b.serial_no,c.item_code,d.brand,e.amount,a.invoice_no";
						
						$table = "sr_details a,stocks_consumables b,tbl_consumables c,tbl_manufacturer d,$tablex e";
						
						$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.con_id AND b.brand = d.id AND a.category = d.category AND a.sr_no = '$sr_no' AND a.inv_id = e.id AND a.qty != 0";
						
						
						$db->select($table,$row,$where);
						$result = $db->getResult();
						$dataArray4=$result;
					   
					 } 
				 
			$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4,$dataArray6);
		
		}
		
	
		
		
		
	}
	

	
	echo"
	<div align='center' style='font-family:Calibri'>
	<table border=0 width='1000' cellpadding=2 cellspacing=0>
		<tr><td colspan=2><b>SR No.:</b></td><td colspan=3>$sr_no</td><td align='right' colspan=3><b>Date Returned:</b> $date_returned</td></tr>
		<tr><td colspan=2><b>Customer Name:</b></td><td colspan=3>$customer_name</td></tr>
		<tr><td colspan=7 align='center' style='padding:20px 0px 10px 0px;border-bottom:2px solid #000'><b>SALES RETURN DETAILS</b></td></tr>
		<tr><td width='10%' style='border-bottom:2px solid #000' align='center'><b>SI No.</b></td><td style='border-bottom:2px solid #000' align='center' width='10%'><b>QUANTITY</b></td><td colspan=2 align='center' style='border-bottom:2px solid #000' width = '40%'><b>ITEM DESCRIPTION</b></td><td width='10%' align='center' style='border-bottom:2px solid #000'><b>UNIT PRICE</b></td><td width='10%' align='center' style='border-bottom:2px solid #000'><b>AMOUNT</b></td><td width = '15%' style='border-bottom:2px solid #000' align='center'><b>REASON</b></td></tr>";
	
	if(count($output)>0){
		foreach($output as $key){
		
		
				if($key['category'] == '1'){
					
				$particulars = "MAKE & MODEL:".$key['brand'].",".$key['model'].+"<br> ENGINE NO: ".$key['engine_no']."<br> FRAME NO:".$key['frame_no']."<br>COLOR:".$key['color'];
				
				}
				
				else if($key['category'] == '5'){
			
					
				$particulars = "MAKE & MODEL:".$key['brand'].",".$key['model'].+"<br> ENGINE NO: ".$key['engine_no']."<br> FRAME NO:".$key['frame_no']."<br>COLOR:".$key['color'];
				
				}
				
				
				else if ($key['category'] == '3'){
					
				$particulars = "MAKE & MODEL:".$key['brand'].",".$key['item_code']."<br> SERIAL NO: ".$key['serial_no']."<br>COLOR:".$key['color'];
				
				}
				
				else if($key['category'] == '2'){
					
				$particulars = "MAKE & MODEL:".$key['brand'].",".$key['item_code']."<br> SERIAL NO: ".$key['serial_no'];
				
				}
				
				else if($key['category']== '4'){
					
				$particulars = "MAKE & MODEL:".$key['brand'].",".$key['item_code']."<br> SERIAL NO: ".$key['serial_no'];
				
				}
		
				$total_amount = $key['qty'] * $key['amount'];
		
				$total_qty = $total_qty + $key['qty'];
				$total_amount2 = $total_amount2 + $total_amount;
		
			echo "<tr align='center'><td>".$key['invoice_no']."</td><td>".$key['qty']."</td><td colspan=2>".$particulars."</td><td align = 'center'>".$key['amount']."</td><td align = 'center'>".$total_amount."</td><td>".$key['reason']."</td></tr>";
		}
	}
	else{
		echo "<tr align='center'><td colspan=6  style='padding:20px 0px 0px 0px;'>*** NO ITEMS TO DISPLAY ***</td></tr>";
	}
	echo "<tr><td colspan=7 align='center' style='padding:10px 0px 10px 0px;border-bottom:2px solid #000'></td></tr>";
	echo "<tr><td colspan=6 style='padding:10px 0px 10px 0px;' align='right'><b>TOTAL AMOUNT:</b></td><td align='right'>$total_amount2</td></tr>";
	echo "<tr><td colspan=6 style='padding:10px 0px 10px 0px;' align='right'><b>TOTAL QTY:</b></td><td align='right'>$total_qty</td></tr>";
	echo "</table></div>";	
?>