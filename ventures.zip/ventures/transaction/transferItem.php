<?php
session_start();

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Transfer Item</title>
<head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
.ui-dialog-title{
	text-align:left;
}
</style>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
    <link rel="stylesheet" href="../css/jPages.css" type="text/css" media="screen">
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
    <script src="../js/jPages.js" type="text/javascript" ></script>
	<script type="text/javascript" src=""></script>
	<script src="../js/FormatNUmberBy3.js" type="text/javascript"></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
		<div id="main" align="center">
				<div id="options-top" align="center" style="width:950px">
					<div>
						<table width="950px">
							<tr>
								<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
								<h2 style="margin-top:10px;">INTER BRANCH TRANSFER</h2>
								
								<input type="hidden" id="branch_id" value="<?php echo $_SESSION['branch_id']; ?>" >
								<input type="hidden" id="branch_name" value="<?php echo $_SESSION['branch_name']; ?>" >
								<input type="hidden" id="branch_code" value="<?php echo $_SESSION['branch_code']; ?>" >
								
								
								</td>
								<td style="text-align:right;background:#FFF;padding:0px;border:none">
									<form name="search" action="" method="POST">
									<select id = 'category' name='category'>
										<option value="a.dr_no">D.R NO</option>
										<option value="a.date">DATE</option>
										<option value="a.branch_code">FROM</option>
										<option value="a.move_to">TO</option>
									</select>
									<input type="search" name="txtsearch" id="txtsearch">
									<input type="button" value="TRANSFER" id='input' onClick="addnew();">
									</form>
								</td>
							</tr>
						</table>
					</div>
			
								
					<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:950px" cellspacing="0">
						<table  align="center" id="table">
						<thead>
						<tr>
						<th width=5%><input type='checkbox' id = 'checkBoxTH' onchange='checkBoxtry();'></th>
						<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'a.dr_no')">D.R NO.</a></th>
						<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'a.date')"> DATE</a></th>
						<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'no_of_item')">ITEM</a></th>
						<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'a.branch_code')">FROM</a></th>
						<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'a.move_to')">TO</a></th>
						<th colspan="2">ACTION</th></tr>
						</thead>
						<tbody id="alldata"></tbody>
						</table>
					</div>
					<div align="left" style="margin-top:10px" id="actions">
							<h3 ><a  href="" onclick='checkBox(true);' >Select All</a>|<a href="" onclick='checkBox(false);'> Unselect All</a></h3>
							<input type="button" value="  DELETE" name="btndelete" class="button_del" onClick="deleteALL()" style="" >
					</div>
					
					<div id="new_items" title="ADD UNIT " style="display:none;">
							<iframe id="item_dialog" width="370" height="270" style="border:none"></iframe>
					</div>
				</div>
				<div id="pagination" style="top:-50px;"> 
						<div class="holder" ></div>
						<div style='font-size:11px;margin-top:5px;' align='center'><i>Pages</i></div>
				</div>
		</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
				menu="transaction";
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		load_data_item("ASC","a.dr_no");

		
	});
	
	  var branch_id = $("#branch_id").val()
	var branch_name = $("#branch_name").val()
	var branch_code = $("#branch_code").val()
	
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
	var sortType = "ASC";
	function filter_list(index,sorts){
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		load_data_item(sortType,sorts);			
	}

	
	function checkBoxtry()
	{
				
				var checked = $("#checkBoxTH").is(':checked');
				$("INPUT[class='checkBoxRecord']").prop('checked', checked);
				
	}
	
	function checkBox(trip){
				$("INPUT[class='checkBoxRecord']").prop('checked', trip);
				event.preventDefault();
			}

	$("#txtsearch").live('keyup change',function(){
		$("#table > tbody").empty();
		load_data_item("ASC","a.dr_no");				
	})
	
	function load_data_item(sortType,sort){

	var count=0,x=0;	
	var container=$("#table > tbody");
	
		$.ajax({
					url:"function_transaction.php",
					
					
					data:{"request":"ajax","action":"load_item_data","inputsearch":$("#txtsearch").val(),"category":$("#category").val(),"sort":sort,"sortType":sortType,"branch_code":branch_code},
					
				
					dataType:'json',
					beforeSend: function(){
						
					},
			success: function(reply){
							//console.log(reply.length);
				if(reply.length > 0){
					container.empty();
							$.each(reply, function(i,res){
								count++;
								
						container.append("<tr class='x' id='record"+res.dr_no+"'  onmouseover='clickSearch()' > </td><td><input type='checkbox' name='chdkDel[]'  class='checkBoxRecord' value='"+res.dr_no+"' /></td><td align='center'>"+res.dr_no+"</td><td align='center'>"+res.date+"</td><td align='center'>"+res.no_of_item+"</td><td align='center'>"+res.branch_code+"</td><td align='center'>"+res.move_to+"</td><td align='center'><a href='#' alt='Update' title='Update' class='view' onclick=\"view_item('"+res.dr_no+"');\"></a></td><td align='center'><a href='#' alt='Update' title='Update' class='delete' onclick=\"delete_item('"+res.dr_no+"');\"></a></td></tr>");
																
				});
				jpages();
				}
				else{
					
				container.append("<tr id = 'noItems'><th colspan = '13' align = 'center'> No Items on record! </th></tr>");
				}
			}
		});

	}
	
	function addnew(){
			$("#new_items").attr("title","ADD NEW STOCK" );
			$("#item_dialog").attr('src','../transaction/addTransfer.php');
			$("#new_items").dialog({
				width:370,
				height: 320,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
			
	}
	
	function closeIframe(actions){
		if(actions=="add"){
			jAlert("successfully Added");
		}
		else if(actions=="edit"){
			jAlert("Successfully Updated");
		}
		else if(actions=="cancel"){
			$('#new_items').dialog('close');
		}
		$('#new_items').dialog('close');
		
		return false;
	}
	
	function Nexturl(actions,link){
		
		if(actions=="add"){
			jAlert("successfully Added");
		}
		$('#new_items').dialog('close');
		window.location = link;
		return false;
	}
	
	
	function deleteALL(){
	
	
		var container = [];
		var chkname = $("INPUT[class='checkBoxRecord']:checked");
		$.each(chkname, function(key,val){
			container.push($(this).attr('value'))
		});
			
		var meronCheck= $("INPUT[class='checkBoxRecord']:checked").length > 0;
				
					if(meronCheck!=0){
						jConfirm('Delete this records!','Confirmation Box',function(e){
							if(e){
							$.ajax({
								url:"function_transaction.php",
								data:{"request":"ajax","action":"multiple_delete","array":container},
								success: function(response){
									//console.log(response);
									if(response == 'deleted'){
												jAlert('Account/s Successfully Deleted!','Alert Box');
												$("#table > tbody").empty();
												load_data_item("ASC","a.dr_no");
											}
											
										}
							
							});
						}	
						
						})
					}else{
						jAlert('Please Select a Record/s you want to DELETE!','Alert Box');
					}
	
	}
	
	
	function view_item(id){

			window.location = "transfer.php?dr_no="+id+"&menu=transaction";
	}
	
	
	function delete_item(id){
	
			jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
			if(e){
			
				var table1 =  "transfer_details";
				var table2 =  "transfer_item";
				$.ajax({
					url: "function_transaction.php",
					data:{"request":"ajax","action":"deleteTwotable","id":id,"table1":table1,"table2":table2,"table_id":"dr_no"},
					success: function(reply){

					}
				});
				
				$('#record'+id).animate({ backgroundColor: '#fbc7c7' }, 'fast')
			.animate({ opacity: "hide" }, "slow");
				
			jAlert("successfully Deleted");
			load_data_item("ASC","a.dr_no");
			}
		
		});	
	}
	function jpages(){
			$("div.holder").jPages({
			  containerID : "alldata",
			   previous : "←",
				next : "→",
			  perPage : 10,
			  delay :10,
			  startPage    : 1,
			  startRange   : 1,
			  midRange     : 5,
			  endRange     : 1
			});
	}
	
	function clickSearch() {
	
	$("#txtsearch").blur();	
	
	}
	
	
	</script>
	
</body>
</html>