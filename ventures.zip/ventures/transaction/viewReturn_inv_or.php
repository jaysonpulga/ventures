<html>
<title>Sales</title>
<head>
<?php
include('../database.php');  
$db = new Database();  
$db->connect();
?>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
	<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
				
			<div id="sample" style="text-align:left;padding:10px; margin-left:20px;" >
			
				
					<div align='center'  class="contents" style="border:0px solid #000; width:95%" cellspacing="0">	
					<input type="hidden" id="type" name="type" value="<?php echo $_REQUEST['table']; ?>" />
					<input type="hidden" id="branch_id"  value="<?php echo $_REQUEST['branch_id']; ?>" />
					<input type="hidden" id="sr" name="sr" value="<?php echo $_REQUEST['sr']; ?>" />
					<input type="hidden" id="customer"  value="<?php echo $_REQUEST['customer']; ?>" />
					
					
							
							<div align="center" style="padding-top:50px;" >
							
							<table id = "invoice_list">
							<thead>
								<tr>
									<th></th><th style="width:45%">PARTICULARS</th><th>UNIT PRICE</th><th>TOTAL <br>ON HAND</th><th>QTY</th>
								</tr>
							</thead>
							
							<tbody id = "invoice_data"></tbody>
							</table>
							</div>
							
							<div align="left" style="padding-top:20px;" >
									<label><b>REASON:</b></label>
							</div>
							
							<div align="left" style="padding-top:3px;" >
									<span>
									<textarea id="reason"  rows="3" cols="500" style="width:350px;"></textarea>
									</span>
							</div>
							
					</div>
					<div align="center" style="margin-top:50px">
						<span>
							<input type="button" value="ADD" onclick="add()">
							<input type="button" value="CANCEL" onclick="Cancel()">
						</span>
					</div>
			</div>
		<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="stocks#"){
			menu="stocks";
		}
		else{
			menu = getUrlVars()["menu"];
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -25px 5px no-repeat",
		"padding":"30px 36px 0px 36px",
		"border-bottom":"4px solid #c95447"
		});
		load_invoice_cash();
		
	});
	
	var customer =  $("#customer").val();
	var type =  $("#type").val();
	var sr =  $("#sr").val();
		
	function load_invoice_cash(){
	
	var url="function_sales.php?request=ajax&action=load_invoice_cash&customer="+customer+"&table="+type ;
	var counter=1;
	var x = 1,total_sale =0,vat=0,amount_due=0;

		$.getJSON(url,function(data){
		
			$("#invoice_list > tbody").empty();
					$.each(data.members, function(i,res){
				
				if(res.category == '1'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.model+"<br> ENGINE NO: "+res.engine_no+"<br> FRAME NO:"+res.frame_no+"<br>COLOR:"+res.color;
				
				}
				
				
				else if(res.category == '5'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.model+"<br> ENGINE NO: "+res.engine_no+"<br> FRAME NO:"+res.frame_no+"<br>COLOR:"+res.color;
				
				}
				
				
				else if (res.category == '3'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no+"<br>COLOR: "+res.color;
				
				}
				
				else{
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no;
				
				}
				
				var cate = res.qty;
				
				var total_amount = parseFloat(cate) * parseFloat(res.amount);
				
				total_sale += parseFloat(res.amount) *  parseFloat(cate);
				vat = total_sale*0.12;
				amount_due = total_sale-vat;
			
				$("#txtvat").val(FormatNumberBy3((Math.round(vat)).toFixed(2)));
				$("#txtdue").val(FormatNumberBy3((Math.round(total_sale)).toFixed(2))); 
				$("#txttotal").val(FormatNumberBy3((Math.round(amount_due)).toFixed(2))); 
			
				
				$("#invoice_list > tbody").append("<tr class='x' id='record"+res.invoice_id+"'><td><input type='checkbox'  id='checkmo"+res.invoice_id+"' name='chk[]' class='checkboxrecord' value='"+res.invoice_id+"' onclick='checkmo("+res.invoice_id+")'  /></td><td align='center'>"+particulars+"</td><td style='text-align:right'>"+FormatNumberBy3((Math.round(total_amount)).toFixed(2))+"</td><td align='center'>"+cate+"</td><td align='center'><input type='text' disabled id='quantity"+res.invoice_id+"' class='textbox"+res.invoice_id+"' name='quantity"+res.invoice_id+"'style='width:60px;margin-left:1px;text-align:center;' onkeyup=\"change('"+res.invoice_id+"');\"></td><input type='hidden' id='remaining"+res.invoice_id+"' value='"+res.qty+"'/><input type='hidden' id='category"+res.invoice_id+"' value='"+res.category+"'/></tr>");
			
								
				
				
						 counter++;
						 
			});	
			
		
			if (counter <= 1){
				$("#invoice_list > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Items on record! </th></tr>");
			}
					
					
		});
	

	}
	
	
	function checkmo(id) {
			
			
			 var checked = $("#checkmo"+id).is(":checked");
				
				if(checked == true){
					$('.textbox'+id).attr("disabled", false);
					$('.textbox'+id).focus();
				}else{
					$('.textbox'+id).attr("value", "");
					$('.textbox'+id).attr("disabled", true);
				} 
	} 
	
	function change(invoice_id){
			var remaining = $("#remaining"+invoice_id).val();
			var quantity = $("#quantity"+invoice_id).val();
		
			if(parseFloat(quantity) > parseFloat(remaining)){
				jAlert("Remaning Balance:"+ remaining);
					$('#quantity'+invoice_id).val(remaining);
					return false;
			} 

	}
	
	
	function Cancel(){
		var action = "cancel";
	window.parent.closeIframe2(action);
	}
	
	
	 function add(){
	
	
	var container = [];
	 var quantity= "";
	 var category= "";


			
			var x="";
			var y="";
	
		
			var chkname = $("input[class='checkboxrecord']:checked");
			$.each(chkname, function(key,val){
				
						x=$(this).attr('value');
						quantity=$("#quantity"+x).val();
						category=$("#category"+x).val();
						
						container.push({
							'invoice_id':x,
							'quantity':quantity,
							'category':category
							
						});
			}); 
			
		var reason = $('#reason').val();

		var errormsg="Please complete the following fields: \n";
				  var emsg= errormsg.length;
				  
				  if(quantity == ""){
							errormsg+="-Quantity \n";
				  }
					if(errormsg.length== emsg){
							  if(container.length > 0){
							  
							  
						
							  
								 $.ajax({
									url: 'function_sales.php',
									data: {'request':'ajax','action':'Add_invoice_return','array':container,'sr':sr,"reason":reason,"table":type },
									
									beforeSend: function(){
																		
											}, success : function(returnData){
																				
												if(returnData == "uhryt"){
												
													var actions="add";
													window.parent.closeIframe2(actions);
						
													
												}
																				
											}, error: function(){}
									}); 
							  
							  
							  }else {
									jAlert("Please make a selection","Alert Dialog");
						}
					}else{
						jAlert(errormsg);
						event.preventDefault();
					} 
			
	
	}
	
	
	
	
	
	</script>
	</body>
</html>
