<?php
session_start();
?>
<html>
<title>Purchase</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
	<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:1000px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>NEW PURCHASE ORDER</h2><hr></label>
							</span>
						</div>
						<div>
							<span>
								<label>P.O. No.:</label>
								<input type="text" style=" width:100px;margin-left:10px;" id="po" value="<?php echo $_REQUEST["po_no"]; ?>" readonly="read_only">
							</span>
							<span>
								<label style="margin-left:612px">Date:</label>
								<input type="date" style="margin-left:10px; text-align:center" id="date_created">
							</span>
						</div>
						<div>
							<span>
								<label>Supplier:</label>
								<select id = 'supplier' name='category' style="margin-left:10px">
									<option value="">- Select -</option>
								</select>	
							</span>
							<span>
								<label style="margin-left:465px">Terms (in Months):</label>
								<input type="text" id="terms" style="width:160px;margin-left:10px;"  >
							</span>
						</div>
						<div>
							<span>
								<label><h3>Search Item</h3></label>
							</span>
						</div>
						<div>
							<span>
								<select id = "cat" name="category" onchange = "changeCategory(this.value)">
								<option value="motorcycle">MOTORCYCLE</option>
								<option value="parts">PARTS</option>
								<option value="promo item">PROMO ITEM</option>
								<option value="consumables">CONSUMABLES</option>
								</select>
								<input type="button" value="SEARCH" onclick="search_item();">
								<span>
									<input type="button" id="input" value="STOCK REQUISITIONS" style="width:200px;" onclick="add_item();">
								</span>
							</span>
						</div>
						<div  class="contents" style="border:0px solid #000; width:1000px" cellspacing="0">	
							<table id="table">
								<thead>
									<tr><th>BRANCH</th><th style="width:40%">PARTICULARS</th><th>QTY</th><th>UNIT PRICE</th><th>AMOUNT</th><th colspan=2>ACTIONS</th></tr>
								</thead>
								<tbody>
								</tbody>
							</table>
						</div>
					
						
						<div align="center" style="margin-top:10px">
							<span>
								<input type="button" value="SAVE">
								<input type="button" value="PRINT" onclick="window.open('printPO.php?po_no=<?php echo $_REQUEST['po_no']; ?>','_blank')">
								<input type="button" value="CANCEL" onclick="cancel()">
							</span>
						</div>
						<div id="new_items" title="VIEW REQUEST" style="display:none;">
						<iframe id="item_dialog" width="750" height="290" style="border:none"></iframe>
						</div>
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>

	var po = getUrlVars()["po_no"];
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadSupplier();
		
		loadPO(po);
	});	
	
	function search_item(){
	
	var val = $('#cat').val();

	if(val =="motorcycle"){
		var cat = 1;
		var table = "tbl_motorcycle";
	}
	else if(val =="parts"){
		var cat = 2;
		var table = "tbl_parts";
	}
	else if(val =="promo item"){
		var cat = 3;
		var table = "tbl_promo";
	}
	else if(val =="consumables"){
		var cat = 4;
		var table = "tbl_consumables";
	}
	
	
		$("#new_items").attr("title","ADD ITEM");
		$("#item_dialog").attr({
			height:340,
			width:400,
		});
			
		$("#item_dialog").attr('src','stockMotorcycle.php?&cat='+cat+'&table='+table+'&po_no='+po);
		$("#new_items").dialog({
			width: 401,
			height: 385,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src',"about:blank");
				window.location.reload();
			}
		});
		return false;
			
			
	}
	
	function add_item(){
		
			$("#item_dialog").attr('src','../transaction/viewRequest.php?po_no='+po);
			$("#item_dialog").attr({
				height:650,
				width:850,
			});
			$("#new_items").dialog({
				width:851,
				height:650,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
	}
	
	function loadPO(po){
		var url="function2.php?request=ajax&action=loadPO&po_no="+po;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				//alert(res.branch);
				$('#supplier option[value='+res.supplier+']').attr('selected', 'selected');
				$('#date_created').val(res.date);
				$('#terms').val(res.terms);
			});
		});
		
		loadPurchaseOrders(po);	
	}
	
	function loadPurchaseOrders(po){
				
					
		$("#table > tbody").empty();
		
		var url="function2.php?request=ajax&action=loadPurchaseOrders&po_no="+po;
		
	
		$.getJSON(url,function(data){
			var counter=0;
		
			$.each(data.members, function(i,res){
					var amount=(parseFloat(res.qty)*parseFloat(res.unit_cost)).toFixed(2);
				 $("#table > tbody").append("<tr><td>"+res.branch+"</td><td>"+res.particulars+"</td><td><input type='text' id='qty"+res.id+"' style='text-align:center;text-transform:uppercase;width:120px;' value='"+res.qty+"' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\" ></td><td><input type='text' id='unit_cost"+res.id+"' style='text-align:right;text-transform:uppercase;width:130px' value='"+FormatNumberBy3((Math.round(res.unit_cost)).toFixed(2))+"' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\" ></td><td><div align='right'>"+amount+"</div></td><td><a href='#' alt='Update' title='Update' class='edit_item' onclick='editItem("+res.id+");'><img src='../images/edit.png' /></a></td><td><a href='#' onclick='deleteItem("+res.id+");' alt='Delete' title='Delete'><img src='../images/delete.png' /></a></td></tr>");
				 counter++;
				//$( "#qty" ).html("<label style='font-weight:bold'> "+counter+" </label>");	
			});
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
				//$( "#qty" ).html("<label style='font-weight:bold'> "+counter+" </label>");	
			}

		});
		
		
	}
	
	function loadSupplier(){
					
			
		var url="function2.php?request=ajax&action=loadSupplier";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				 $("#supplier").append("<option value="+ res.id +">" + res.supplier_name + "</option>"); 
			});
		});	
		
		loadPODetails();
					
	}
	
	
	function loadPODetails(){
					
		var po = getUrlVars()["po_no"];	
		var url="function2.php?request=ajax&action=loadPODetails&po_no="+po;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				 $('#supplier option[value='+res.supplier+']').attr('selected', 'selected');
				 $('#date_created').val(res.date);
				 $('#terms').val(res.terms);
				 
			});
		});	
					
	}
	
	function closeIframe(actions)
	{
		$('#new_items').dialog('close');
		if(actions=="add"){
			jAlert("Item Added","Alert Dialog");
		}
		return false;
	}
	
	function cancel(){
		window.location="purchase.php?menu=transaction";
	}
	
	function deleteItem(id){
		var po = getUrlVars()["po_no"];
		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "function2.php",
					data:{"request":"ajax","action":"deletePurchaseOrders","id":id},
					success: function(reply){
						console.log(reply);
							if(reply == 'deleted'){
								jAlert('Item Deleted','Alert Dialog');
								loadPurchaseOrders(po);
							}
							else{
								jAlert('Error','Error Message');
								event.preventDefault();
							}	
						}
				});
			}
		});	
	}
	
	function editItem(id){
		var po = getUrlVars()["po_no"];
		event.preventDefault();
		var qty = $('#qty'+id).val(),unit_price = $('#unit_cost'+id).val();
		var errormsg="Please complete the following fields: \n";
		var emsg= errormsg.length;
		
		if(qty == ""){
			errormsg+="-Quantity.\n";
		}
		
		if(errormsg.length== emsg){
			$.ajax({
				url: "function2.php",
				data:{"request":"ajax","action":"editPurchaseOrders","qty":qty,"unit_cost":unit_price,"id":id},
				success: function(reply){
					console.log(reply);
						if(reply == 'updated'){
							jAlert('Item Updated','Alert Dialog');
							loadPurchaseOrders(po);
						}
						else{
							jAlert('Error','Error Message');
							event.preventDefault();
						}	
					}
			});
					
		}
		else{
			
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
	}
	</script>
	
</body>
</html>