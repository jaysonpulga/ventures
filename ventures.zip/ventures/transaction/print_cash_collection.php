<html>
<title>COLLECTION</title>
</html>
<style>
.x:nth-child(even) td{
	background:lightgray;
}
</style>
<?php
include('../database.php');  
$db = new Database();  
$db->connect(); 

	$dataArray=array();
	$type="";
	$sortType="DESC";
	$sort="a.id";
	
	$or_no=$_REQUEST['or_no'];
	
	$rows = "a.*, CONCAT(b.last_name,', ',b.first_name,' ',b.middle_name) as customer_name,c.branch_name" ;
	$where = "a.or_no= '$or_no' AND a.customer_id = b.id AND a.branch_code = c.branch_code  group by a.or_no";
	$db->select('collections a, tbl_customer b, tbl_branch c',$rows,$where); 
	$result = $db->getResult();
	

	foreach($result as $key){		

		
		  $or_no=$key["or_no"];
		  $date=$key["date"];
		  $customer_name=$key["customer_name"];
		  $branch_name=$key["branch_name"];
		  $address=$key["address"];
		  $type=$key["type_mode"];
	}
	

	
	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$or_no = $_REQUEST['or_no'];
	
	$where = "or_no='$or_no'";
	$db->select("collection_cash","*",$where);
	$result = $db->getResult();
	
	foreach($result as $key){
		 $category=$key["category"];
		  $dr_no=$key["dr_no"];
		 
		if($category == '1'){
		 
			$row = "a.invoice_no,a.category,a.id as cash_id,a.stock_id,a.type,a.amount,a.qty,b.engine_no,b.frame_no,b.color,c.model,d.brand";
			$table = "collection_cash a,stocks_motors b,tbl_motorcycle c,tbl_manufacturer d";
			
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = d.category AND a.or_no = '$or_no'"; 
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray=$result;	
		 }
		 
		 else if($category == '2'){

			$row = "a.invoice_no,a.category,a.id as cash_id,a.stock_id,a.type,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
			$table = "collection_cash a,stocks_parts b,tbl_parts c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.parts_id AND b.brand = d.id AND a.category = d.category AND a.or_no = '$or_no'";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray2=$result;
		   
		 
		 }
		 else if($category == '3'){
			
			
			$row = "a.invoice_no,a.category,a.id as cash_id,a.stock_id,a.type,a.amount,a.qty,b.serial_no,b.color,c.item_code,d.brand";
			$table = "collection_cash a,stocks_promo b,tbl_promo c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.promo_id AND b.brand = d.id AND a.category = d.category AND a.or_no = '$or_no'";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray3=$result;
		  
		 }
		 else if($category == '4'){
			
			
			$row = "a.invoice_no,a.category,a.id as cash_id,a.stock_id,a.type,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
			$table = "collection_cash a,stocks_consumables b,tbl_consumables c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.con_id AND b.brand = d.id AND a.category = d.category AND a.or_no = '$or_no'";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray4=$result;
		   
		 }
		
		$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4);
		
	}

	echo" 
	<div align='center' style='font-family:Calibri'>
	<table border=0 width='1000' cellpadding=2 cellspacing=0>
		<tr><td><b>O.R. No.:</b> $or_no</td><td align='right' colspan=5><b>Date:</b> $date</td></tr>
		<tr><td colspan=2><b>Customer Name:</b> $customer_name</td><td align='right' colspan=4><b>Branch:</b> $branch_name</td></tr>
		<tr><td colspan=6 ><b>Address:</b> $address</td></tr>

		<tr><td colspan=6 align='center' style='padding:20px 0px 10px 0px;border-bottom:2px solid #000'><b>CASH COLLECTIONS</b></td></tr>
		
		
		<tr>
		<td style='border-bottom:2px solid #000' align='center' width='10%'><b>TYPE</b></td>
		<td style='border-bottom:2px solid #000' align='center' width='10%'><b>QTY</b></td>
		<td colspan=2 align='center' style='border-bottom:2px solid #000'><b>PARTICULARS</b></td>
		<td width='15%' align='center' style='border-bottom:2px solid #000'><b>UNIT PRICE</b></td>
		<td width='15%' align='center' style='border-bottom:2px solid #000'><b>AMOUNT</b></td>
		</tr>";
	
	$total_amout = 0;
	$vat = 0;
	$amount_due = 0;
	if(count($output)>0){
		foreach($output as $key){
			
			
			if($key['category'] == '1'){
					
				 $particulars = "MAKE & MODEL:".$key['brand'].",".$key['model']."<br> ENGINE NO: ".$key['engine_no']."<br> FRAME NO:".$key['frame_no']."<br>COLOR:".$key['color'];
				
				}
				
				else if ($key['category'] == '3'){
					
				$particulars = "MAKE & MODEL:".$key['brand'].",".$key['item_code']."<br> SERIAL NO: ".$key['serial_no']."<br>COLOR: ".$key['color'];
				
				}
				
				else{
					
				$particulars = "MAKE & MODEL:".$key['brand'].",".$key['item_code']."<br> SERIAL NO: ".$key['serial_no'];
				
				}
			
			
			$total_sale= $key['qty'] * $key['amount'];
			
				if($key['type'] == "ITEMS"){
					$typex = $key['type'];
				}else if($key['type'] == "INVOICE"){
				
					
				$typex = $key['type'].":".$key['invoice_no'];
				}
			
			echo "<tr align='center' class='x'>";
			echo "<td>".$typex."</td>";
			echo "<td>".$key['qty']."</td>";
			echo "<td colspan=2>".strtoUpper($particulars)."</td>";
			echo "<td>".number_format($key['amount'],2,".",",")."</td>";
			echo "<td>".number_format($total_sale,2,".",",")."</td>";
			echo "</tr>";
			
			$total_amout += $key['amount'] * $key['qty'];
			$vat = $total_amout*0.12;
			$amount_due = $total_amout-$vat;
		
		}
	}
	else{
		echo "<tr align='center'><td colspan=5  style='padding:20px 0px 0px 0px;'>*** NO ITEMS TO DISPLAY ***</td></tr>";
	}
	echo "<tr><td colspan=6 align='center' style='padding:10px 0px 10px 0px;border-bottom:2px solid #000'></td></tr>";
	echo "<tr><td width='25%'></td><td colspan=4  align='right' style='padding:10px 0px 3px 0px;'><b>AMOUNT DUE:</b></td><td width='15%' align='center' >".number_format($total_amout,2,".",",")."</td></tr>";
	echo "<tr><td width='25%'></td><td  colspan=4 align='right' style='padding:3px 0px 3px 0px;'><b>VAT_TAX:</b></td><td width='15%' align='center' >".number_format($vat,2,".",",")."</td></tr>";
	echo "<tr><td width='25%'></td><td colspan=4  align='right' style='padding:3px 0px 3px 0px;'><b>TOTAL SALES:</b></td><td width='15%' align='center' >".number_format($amount_due,2,".",",")."</td></tr>";
	echo "</table></div>";	
?>