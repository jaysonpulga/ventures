<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Collection</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>

<input type="hidden" id="branch_id" value="<?php echo $_SESSION['branch_id']; ?>" >
<input type="hidden" id="branch_name" value="<?php echo $_SESSION['branch_name']; ?>" >
<input type="hidden" id="branch_code" value="<?php echo $_SESSION['branch_code']; ?>" >
<input type="hidden" id="category" value="<?php echo $_REQUEST['category']; ?>" >
	
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:800px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>NEW COLLECTION (<?php echo $_REQUEST['category']; ?>)</h2><hr></label>
							</span>
						</div>
						<div >
							<span>
								<label>TYPE OF PAYMENT:</label>
								<select id="txtpayment" name="payment" onchange = "changeCategory(this.value)" >
								
								</select>
							</span>
						</div>
						
						
						<div style="margin-top:10px">
							<span>
								<label>O.R No.:</label>
								<input type="text" id = "txtor_no" style="margin-left:60px; width:100px" maxlength="6">
							</span>
							<span>
								<label style="margin-left:330px">Date:</label>
								<input type="date" id = "txtdate" style="margin-left:41px">
							</span>
						</div>
						<div style="margin-top:10px" id="div" >
							<span>
								<input type = "hidden" id = "txtcusid">
								<label>Customer Name:</label>
								<input type="text" id = "txtcusname" style = "margin-left:7px; text-align:center; width:250px;">			
							</span>
							
							<span id="button">
							
							</span>
							
							<span style="float:right">
								<label style="margin-right:20px">BRANCH:</label>
								<select id="txtbranch" name="txtbranch" style="margin-right:10px">
								</select>
							</span>
						</div>
						
						
						<div style="margin-top:10px">
							<span>
								<label>Address:</label>
								<input type="text" id = "txtaddress" style=" width:400px; margin-left:55px">
							</span>
						</div>
						
						
						<div align = "center" style = "margin-top: 20px;">
							<span>
								<input type = "button" id = "btnadd" value = "CREATE" onclick = "Add();">
								<input type = "button" id = "btncancel" value = "CANCEL" onclick = "window.location='collections.php?menu=transaction'">
							</span>
						</div>
						
						
						
						<div align = "center" style = "margin-top: 10px;">
							<span>
								<input type = "hidden" id = "monthly" >
								<input type = "hidden" id = "rebate">
								<input type = "hidden" id = "penalty">
								<input type = "hidden" id = "ins_due">
								<input type = "hidden" id = "account_no">
							</span>
						</div>
						
						
						<div id="customer_items" style="display:none;">
							<iframe id="item_dialog" width="954" height="595" style="border:none"></iframe>
						</div>
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		var category = $("#category").val();
		
		load_payment_type(category);
		
	
	});

	var branch_id = $("#branch_id").val();
	var branch_name = $("#branch_name").val();
	var branch_code = $("#branch_code").val();
	
	
	
	
	

	function load_payment_type(category){
	
	

		$("#txtpayment").empty();
		var option1 = ["CASH", "LOAN", "INTERBRANCH"];
	
						
							for (var i=0; i < option1.length; i++){
										
								if(category == option1[i] ){
									$("#txtpayment").append("<option  value='"+option1[i]+"' selected='selected' >"+option1[i]+"</option>");
								}
								
								
								else{
								
							
									$("#txtpayment").append("<option  value='"+option1[i]+"'>"+option1[i]+"</option>");
								}
								
							} 
							
							changeCategory(category);
		
			
	}

				

	
		
	
	function changeCategory(category){
	 $("#button").empty();
			if(category =="LOAN"){
				 $("#button").append('<a href="#"  style="width:30px;" onclick="search_customer_ledger();"><img src="" id="search" valign="bottom"></a>');
			}else{
				 $("#button").append('<a href="#"  style="width:30px;" onclick="search_customer();"><img src="" id="search" valign="bottom"></a><a href="#"  style="width:30px;" onclick="new_customer();"><img src="" id="new" valign="bottom"></a>');
			}
	
	}
	
	function search_customer_ledger(){
			$("#customer_items").attr("title","SEARCH CUSTOMER");
			$("#item_dialog").attr('src','customer_view_ledger.php');
			$("#customer_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	
	function search_customer(){
			$("#customer_items").attr("title","SEARCH CUSTOMER");
			$("#item_dialog").attr('src','customer_name.php?&branch_id='+branch_id);
			$("#customer_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	function new_customer() {
			$("#customer_items").attr("title","NEW CUSTOMER");
			$("#item_dialog").attr('src','newCustomer.php');
			$("#customer_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	function closeIframe(id,name,address,branch_code,monthly_down,penalty_interest,monthly_rebate,ins_due,account_no) {
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
		
		$("#monthly").val(monthly_down);
		$("#rebate").val(monthly_rebate);
		$("#penalty").val(penalty_interest);
		$("#ins_due").val(ins_due);
		$("#account_no").val(account_no);
		
		loadBranch(branch_code);
	}
	
	function closeIframeNew(id,name,address,branch_code) {
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
		loadBranch(branch_code);
	}
	
	function loadBranch(branch_code){
		var count=0, x=0;
		var select = $("#txtbranch");

		$.ajax({
				url:"functions.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					
					
					
					if(reply.length > 0){
						select.empty();
								
							$.each(reply, function(i,res){
							 count++;
							 
							if(res.branch_code == branch_code ){
							select.append("<option  value='"+res.branch_code+"' selected='selected' >"+res.branch_code+"</option>");
							}	else{
							select.append("<option  value='"+res.branch_code+"'>"+res.branch_code+"</option>");
							}	
								
																		
							});
			
					}
				}
			});
	}
	
	
	
	
	
	
	function Add() {
		var txtor_no=$("#txtor_no").val();	
		var date_issued=$("#txtdate").val();	
		var customer_id=$("#txtcusid").val();
		var txtbranch=$("#txtbranch").val();	
		var address=$("#txtaddress").val();
		var txtpayment=$("#txtpayment").val();
		
		var monthly=$("#monthly").val();
		var rebate=$("#rebate").val();
		var penalty=$("#penalty").val();
		var ins_due=$("#ins_due").val();
		var account_no=$("#account_no").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(txtor_no == ""){
			errormsg+="- Input O.R. No.\n";
		}
		if(date_issued == ""){
			errormsg+="- Input Date Issued.\n";
		}
		if(customer_id == ""){
			errormsg+="- Input Customer Name.\n";
		}
		if(txtbranch == ""){
			errormsg+="- Input Branch.\n";
		}
		if(address == ""){
			errormsg+="- Input Address.\n";
		}
		if(txtpayment == ""){
			errormsg+="- Input Type of Payment.\n";
		}
		
		if(errormsg.length==emsg){
			$.ajax({
				url: "function_transaction.php",
				data:{"request":"ajax","action":"saveORnumber","txtor_no":txtor_no,"date_issued":date_issued,"customer_id":customer_id,"txtbranch":txtbranch,"address":address,"txtpayment":txtpayment,"monthly":monthly,"rebate":rebate,"penalty":penalty,"ins_due":ins_due,"account_no":account_no},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Invoice Successfully Added!", "Alert Dialog");
							
							 if(txtpayment =="CASH"){
								window.location = "cash_collection.php?menu=transaction&or_no="+txtor_no;
							}else if(txtpayment =="LOAN"){
								window.location = "loan_collection.php?menu=transaction&or_no="+txtor_no;
							}else if(txtpayment =="INTERBRANCH"){
								window.location = "interbranch_collection.php?menu=transaction&or_no="+txtor_no;
							} 
							
							
						}else if(reply == 'exists'){
							jAlert('Invoice No. Already Exists!', 'Alert Dialog');
						}
						else{
							jAlert('Error');
							event.preventDefault();
						}
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		
	}
	
	</script>