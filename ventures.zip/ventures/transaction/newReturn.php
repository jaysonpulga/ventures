<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:800px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>SALES RETURN</h2><hr></label>
							</span>
						</div>
						<div>
							<span>
								<label>SR No.:</label>
								<input type="text" id = "txtreturn" value = "<?php echo $_REQUEST['sr_no']; ?>" style="margin-left:67px; width:100px" readonly>
							</span>
							<span>
								<label style="margin-left:315px">Date:</label>
								<input type="date" id = "txtdate" style="margin-left:41px">
							</span>
						</div>
						<div>
							<span>
								<input type="hidden" id = "txtcusid">
								<label>Customer Name:</label>
								<input type="text" id = "txtcusname" style = "margin-left:7px; text-align:center; width:300px;">
							</span>
						</div>
						<div>
							<span>
								<label>Address</label>
								<input type="text" id = "txtaddress" style=" width:400px; margin-left:61px">
							</span>
						</div>
						<div>
							<span>
								<label>Search Item</label>
								<select id = 'search_item' name='brand' style="margin-left:38px">
									<option value="motorcycle">Motorcycle</option>
									<option value="parts">Parts</option>
									<option value="consumables">Consumables</option>
									<option value="promo">Promo</option>
								</select>
								<a href="#" style="width:30px;" id = "asearch" onclick="search_stocks();"><img src="" id="search" valign="bottom"></a>
							</span>
						</div>
						<div  class="contents" style="border:0px solid #000; width:800px" cellspacing="0">	
							<h3>ORDER SALES</h3>
							<table id = "return_list">
								<thead align = "center">
								<tr>
									<th>QUANTITY</th><th style="width:55%">PARTICULARS</th><th>UNIT PRICE</th><th>AMOUNT</th><th>ACTION</th>
								</tr>
								</thead>
								<tbody id = "return_data"></tbody>
							</table>
						</div>
						<input type = "hidden" id = "txtid">
						<input type = "hidden" id = "txtqty">
						<input type = "hidden" id = "txtitemid">
						<div align = "right" style = "margin-top:10px; font-weight:bold;">
							<span>
								<label>AMOUNT DUE: </label>
								<input type = "text" id = "txtdue"  style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>VAT: </label>
								<input type = "text" id = "txtvat" style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>TOTAL: </label>
								<input type = "text" id = "txttotal" style = "text-align: right;" disabled>
							</span>
						</div>
						<div align="center" style="margin-top:10px">
							<span>
								<input type="button" value="SAVE" onclick = "Save();">
								<input type="button" value="PRINT" onclick="window.open('printSalesReturn.php?sr_no=<?php echo $_REQUEST['sr_no']; ?>','_blank')">
							</span>
						</div>
						<div id="add_item" title="" style="display:none;">
							<iframe id="add_dialog" width="800" height="500" style="border:none"></iframe>
						</div>
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	var sr = $("#txtreturn").val();
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
		
		var sr = $("#txtreturn").val();
		var address = $("#txtaddress").val();
		var item_id = $("#txtitemid").val();
		if (sr == "") {
			
			$("#asearch").removeAttr("onclick");
			
		}
		else {
			$("#asearch").attr("onclick", "search_stocks()");
		}
		
		loadUpper();
		loadTable(sr);
		
		$("#txtreturn").bind('keyup change',function(){
			$("#asearch").attr("onclick", "search_stocks()");
		});
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
	});
	
	function search_stocks() {
	
		var item = $("#search_item").val();
		var sr = $("#txtreturn").val();
		var address = $("#txtaddress").val();
		var src;
		
		if (item == "motorcycle") {
			src = "searchMotorcycleReturn.php?sr_no="+sr;
		}
		else if (item == "parts") {
			src = "searchPartsReturn.php?sr_no="+sr;
		}
		else if (item == "consumables") {
			src = "searchConsumablesReturn.php?sr_no="+sr;
		}
		else if (item == "promo") {
			src = "searchPromoReturn.php?sr_no="+sr;
		}
		else {
		}
		
		$("#add_item").attr("title","SEARCH STOCKS");
		$("#add_dialog").attr('src',src);
		$("#add_item").dialog({
			width: 800,
			height: 550,
			modal: true,
			resizable:false,
			close: function () {
				$("#add_dialog").attr('src',"about:blank");
				window.location="newReturn.php?menu=transaction&sr_no="+sr;
			}
		});
		return false;
	}
	
	function closeIframeItem(sr_no) {
		$("#add_item").dialog('close');
		loadTable(sr_no);
	}
	
	function loadUpper() {
		var sr = $("#txtreturn").val();
		var url="functions.php?request=ajax&action=loadReturnData&sr_no="+sr;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
			
				$("#txtid").val(res.id);
				$("#txtdate").val(res.date_returned);
				$("#txtcusname").val(res.customer_name);
				$("#txtcusid").val(res.customer_id);
				$("#txtaddress").val(res.address);
			
			});
		});
	}
	
	var total=0;
	var vat=0;
	var amount_due=0;
	var total_qty=0;
	var counter=0;
	
	function loadTable(sr) {
		$("#return_list > tbody").empty();
		var url="functions.php?request=ajax&action=loadReturnItems&sr_no="+sr;
		var item;
		var amount=0;
		var price=0;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				var qty = res.qty;
				
				price=parseFloat(Math.round((res.selling_price)*100)/100).toFixed(2);
				amount=parseFloat(Math.round((price*qty)*100)/100).toFixed(2);
				
				$("#return_list > tbody").append("<tr class = 'x'><td>"+qty+"</td><td>"+res.description+"</td><td><div style = 'text-align:right'>"+price+"</div></td><td><div style = 'text-align:right'>"+amount+"</div></td><td><a href = '#' class = 'delete' onclick=\"deleteItem('"+res.id+"','"+res.item_id+"','"+res.item_type+"')\"></a></td></tr>");
				counter++;
				
				total = total+parseFloat(amount);
				vat = total*0.12;
				amount_due = total-vat;
				
			});
			
			if (counter <= 0){
				$("#return_list > tbody").append("<tr id = 'noItems'><th colspan = '6' align = 'center'> No Items on record! </th></tr>");
			}
			
			$("#txttotal").val(parseFloat(Math.round((total)*100)/100).toFixed(2));
			$("#txtvat").val(parseFloat(Math.round((vat)*100)/100).toFixed(2));
			$("#txtdue").val(parseFloat(Math.round((amount_due)*100)/100).toFixed(2));
			$("#txtqty").val(counter);
			
		});
		
	}
	/*
	function editItem(id) {
	
		var sr = $("#txtreturn").val();
		var price = $("#item"+id).val();
		
		$.ajax({
			url: "functions.php",
			data:{"request":"ajax","action":"updateItem","price":price,"id":id},
			success: function(reply){
				console.log(reply);
					if(reply == 'updated'){
						jAlert('Item Updated','Alert Dialog');
						window.location = "newReturn.php?menu=transaction&sr_no="+sr;
					}
					else{
						jAlert('Error','Error Message');
						event.preventDefault();
					}
				}
		});
	
	}
	*/
	function deleteItem(id,item_id,type) {
	
		var sr = $("#txtreturn").val();
		var address = $("#txtaddress").val();
	
		jConfirm('Do you really want to DELETE this ITEM?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "functions.php",
					data:{"request":"ajax","action":"deleteReturnItem","id":id,"item_id":item_id,"item_type":type},
					success: function(reply){
						console.log(reply);
							if(reply == 'deleted'){
								jAlert('Item Deleted','Alert Dialog');
								window.location="newReturn.php?menu=transaction&sr_no="+sr+"&address="+address;
							}else{
								jAlert('Error','Alert Dialog');
								event.preventDefault();
							}
						
						}
				});
			}
		});
	
	}
	
	function Save() {
		
		var sr = $("#txtreturn").val();
		var id = $("#txtid").val();
		var date_returned = $("#txtdate").val();
		var customer_id = $("#txtcusid").val();
		var address = $("#txtaddress").val();
		
		$.ajax({
			url: "functions.php",
			data:{"request":"ajax","action":"updateReturnDetails","id":id,"sr_no":sr,"date_returned":date_returned,"customer_id":customer_id,"address":address},
			success: function(reply){
				console.log(reply);
					if(reply == 'updated'){
						jAlert("Data was successfully Added!", "Alert Dialog");
						window.location = "sales_return.php?menu=transaction";
						
					}else if(reply == 'exists'){
						jAlert('SR No. Already Exists!', 'Alert Dialog');
					}
					else{
						alert('Error');
						event.preventDefault();
					}
			}
		});
		
	}
	
	</script>
	
</body>
</html>