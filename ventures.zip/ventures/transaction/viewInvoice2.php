<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}


$_SESSION["username"];
$branch_name = $_SESSION["branch_name"];
$branch_id = $_SESSION['branch_id'];
?>
<!DOCTYPE HTML>
<html lang="en">
<title>Sales</title>
<head>
	
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:800px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>SALES INVOICE</h2><hr></label>
								<input type="hidden" id = "branch_id" value = "<?php echo $branch_id; ?>" >
								<input type="hidden" id = "branch_name" value = "<?php echo $branch_name; ?>" >
								
							</span>
						</div>
						<div>
							<span>
								<label>Invoice No.:</label>
								<input type="text" id = "txtinvoice" value = "<?php echo $_REQUEST['invoice_no']; ?>" style="margin-left:37px; width:100px; text-align:center;" readonly>
							</span>
							<span>
								<label style="margin-left:315px">Date:</label>
								<input type="date" id = "txtdate" style="margin-left:41px; width:160px;">
							</span>
						</div>
						<div>
							<span>
								<input type="hidden" id = "txtcusid">
								<label>Customer Name:</label>
								<input type="text" id = "txtcusname" style = "margin-left:7px; text-align:center; width:330px;">
								<a href="#"  style="width:30px;" onclick="search_customer();"><img src="" id="search" valign="bottom"></a>
								<a href="#"  style="width:30px;" onclick="new_customer();"><img src="" id="new" valign="bottom"></a>
							</span>
							<span>
								<label style="margin-left:19px">Terms:</label>
								<select id = "txtterms" style="margin-left:32px; width:163px;">
									<option value = "">- SELECT -</option>
									<option value = "3">3</option>
									<option value = "6">6</option>
									<option value = "9">9</option>
									<option value = "12">12</option>
									<option value = "15">15</option>
									<option value = "18">18</option>
									<option value = "21">21</option>
									<option value = "24">24</option>
								</select>
							</span>
						</div>
						<div>
							<span>
								<label>Address</label>
								<input type="text" id = "txtaddress" style="text-align:center; width:330px; margin-left:61px">
							</span>
						</div>
						<div>
							<span>
								<label>Search Item</label>
								<select id = 'search_item' name='brand' style="margin-left:38px">
									<option value="motorcycle">Motorcycle</option>
									<option value="parts">Parts</option>
									<option value="consumables">Consumables</option>
									<option value="promo item">Promo</option>
									<option value="repo">REPO</option>
								</select>
								<a href="#" style="width:30px;" id = "asearch" onclick="search_stocks();"><img src="" id="search" valign="bottom"></a>
							</span>
						</div>
						<div  class="contents" style="border:0px solid #000; width:800px" cellspacing="0">
							<h3>ORDER DETAILS</h3>
							<table id = "invoice_list">
								<thead align = "center">
								<tr>
									<th>QTY</th><th style="width:45%">PARTICULARS</th><th>UNIT PRICE</th><th>AMOUNT</th><th colspan = "2">ACTION</th>
								</tr>
								</thead>
								<tbody id = "invoice_data"></tbody>
							</table>
						</div>
						<input type = "hidden" id = "txtid" value = "<?php echo $_REQUEST['id']; ?>">
						<input type = "hidden" id = "txtqty">
						<input type = "hidden" id = "txtitemid">
						<div align = "right" style = "margin-top:10px; font-weight:bold;">
							<span>
								<label>AMOUNT DUE: </label>
								<input type = "text" id = "txtdue"  style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>VAT: </label>
								<input type = "text" id = "txtvat" style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>TOTAL: </label>
								<input type = "text" id = "txttotal" style = "text-align: right;" disabled>
							</span>
						</div>
						<div align="center" style="margin-top:10px">
							<span>
								<input type="button" value="UPDATE" onclick = "Update();">
								<input type="button" value="PRINT" onclick="window.open('printSalesInvoice.php?invoice_no=<?php echo $_REQUEST['invoice_no']; ?>','_blank')">
								<input type="button" value="CANCEL" onclick="window.location='sales.php?menu=transaction'">
							</span>
						</div>
						
						<div id="search_item" title="" style="display:none;">
							<iframe id="search_dialog" width="440" height="400" style="border:none"></iframe>
						</div>
						
						<div id="new_items" title="" style="display:none;">
							<iframe align="center" id="new_dialog" width="540" height="400" style="border:none"></iframe>
						</div>
						
						<div id="new_items2" title="" style="display:none;">
							<iframe align="center" id="item_dialog2" width="540" height="400" style="border:none"></iframe>
						</div>
						
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		var invoice = $("#txtinvoice").val();
		var item_id = $("#txtitemid").val();
		
		loadUpper();
		load_sale_invoice();
	});
	
	var invoice = $("#txtinvoice").val();
	var branch_id = $("#branch_id").val();
	var branch_name = $("#branch_name").val();
	var counter=0;
	
	function search_customer(){
			$("#search_items").attr("title","SEARCH CUSTOMER");
			$("#search_dialog").attr('src','customer_name.php');
			$("#search_items").dialog({
				width: 955,
				height: 643,
				modal: true,
				resizable:false,
				close: function () {
					$("#search_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	function new_customer() {
			$("#new_items").attr("title","NEW CUSTOMER");
			$("#new_dialog").attr('src','newCustomer.php');
			$("#new_items").dialog({
				width: 955,
				height: 643,
				modal: true,
				resizable:false,
				close: function () {
					$("#new_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	function search_stocks() {
	var val = $('#search_item').val();

	if(val =="motorcycle"){
	var cat = 1;
	var table = "stocks_motors";
	}
	else if(val =="parts"){
	var cat = 2;
	var table = "stocks_parts";
	}
	else if(val =="promo item"){
	var cat = 3;
	var table = "stocks_promo";
	}
	else if(val =="consumables"){
	var cat = 4;
	var table = "stocks_consumables";
	}
	
	else if(val =="repo"){
	var cat = 5;
	var table = "stock_repo";
	}
	
			$("#new_items2").attr("title",val+"-"+branch_name);
			$("#item_dialog2").attr("src","../transaction/viewInvoice_item.php?table="+table+"&cat="+cat+"&invoice="+invoice+"&branch_id="+branch_id);
			$("#new_items2").dialog({
				width:540,
				height:450,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog2").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false; 
	
	}
	
	function closeIframe(id,name,address) {
		$("#search_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
	}
	
	function closeIframeNew(id,name,address) {
		$("#new_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
	}
	
	function closeIframeItem(invoice_no) {
		$("#new_items2").dialog('close');
		load_sale_invoice();
	}
	
	function loadUpper() {
		var invoice = $("#txtinvoice").val();
		var url="functions.php?request=ajax&action=loadInvoiceData&invoice_no="+invoice;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
			
				$("#txtdate").val(res.date_issued);
				$("#txtdate").val(res.date_issued);
				$("#txtcusid").val(res.customer_id);
				$("#txtcusname").val(res.customer_name);
				$("#txtterms").val(res.terms);
				$("#txtaddress").val(res.address);
			
			});
		});
		
	}
	
	var total=0;
	var vat=0;
	var amount_due=0;
	var total_qty=0;
	
	
	function load_sale_invoice(){
	
	var url="function_transaction.php?request=ajax&action=load_sale_invoice&invoice_no="+invoice ;
	var counter=1;
	var x = 1,total_sale =0,vat=0,amount_due=0;

		$.getJSON(url,function(data){
		
			$("#invoice_list > tbody").empty();
					$.each(data.members, function(i,res){
				
				if(res.category == '1'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.model+"<br> ENGINE NO: "+res.engine_no+"<br> FRAME NO:"+res.frame_no+"<br>COLOR:"+res.color;
				
				}
				
				
				else if(res.category == '5'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.model+"<br> ENGINE NO: "+res.engine_no+"<br> FRAME NO:"+res.frame_no+"<br>COLOR:"+res.color;
				
				}
				
				
				else if (res.category == '3'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no+"<br>COLOR: "+res.color;
				
				}
				
				else{
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no;
				
				}
				
				var cate = res.qty;
				
				var total_amount = parseFloat(cate) * parseFloat(res.amount);
				
				total_sale += parseFloat(res.amount) *  parseFloat(cate);
				vat = total_sale*0.12;
				amount_due = total_sale-vat;
			
				$("#txtvat").val(FormatNumberBy3((Math.round(vat)).toFixed(2)));
				$("#txtdue").val(FormatNumberBy3((Math.round(total_sale)).toFixed(2))); 
				$("#txttotal").val(FormatNumberBy3((Math.round(amount_due)).toFixed(2))); 
			
				if( cate > 0){
				$("#invoice_list > tbody").append("<tr class='x' id='record"+res.invoice_id+"'><td align='center'>"+cate+"</td><td align='center'>"+particulars+"</td><td><input type = 'text' style = 'width:100px; text-align:right;' id = 'amount"+res.invoice_id+"' value = "+FormatNumberBy3((Math.round(res.amount)).toFixed(2))+" onkeyup=javascript:this.value = this.value.replace(/[^0-9]/, '')></td><td style='text-align:right'>"+FormatNumberBy3((Math.round(total_amount)).toFixed(2))+"</td><td id='edi' align='center'><a href='#' alt='Update' title='edit' class='edit' onclick=\"edit_item('"+res.invoice_id+"')\"></a></td><td  id='del' align='center'><a href='#' alt='Update' title='delete' class='delete' onclick=\"delete_item('"+res.invoice_id+" ','"+res.stock_id+" ','"+res.category+"','"+res.qty+"');\"></a></td></tr>");
				}
				
				else{
				
				$("#invoice_list > tbody").append("<tr class='x' id='record"+res.invoice_id+"'><td align='center'>"+cate+"</td><td align='center'>"+particulars+"</td><td><input type = 'text' style = 'width:100px; text-align:right;' id = 'amount"+res.invoice_id+"' value = "+FormatNumberBy3((Math.round(res.amount)).toFixed(2))+" onkeyup=javascript:this.value = this.value.replace(/[^0-9]/, '')></td><td style='text-align:right'>"+FormatNumberBy3((Math.round(total_amount)).toFixed(2))+"</td><td id='edi' colspan=2 align='center'>SALES RETURNED</td></tr>");
				}
								
				
				
						 counter++;
						 
			});	
			
		
			if (counter <= 1){
				$("#invoice_list > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Items on record! </th></tr>");
			}
					
					
		});
	

	}
	
	
	function delete_item(invoice_id,stock_id,category,qty){
	
			if(category == 1){
			var tablex = "stocks_motors";
			}
			else if(category == 2 ){
			var tablex = "stocks_parts";
			}
			else if(category == 3 ){
			var tablex = "stocks_promo";
			}
			else if(category == 4){
			var tablex = "stocks_consumables";
			}
			
			else if(category == 5){
			var tablex = "stock_repo";
			}
			
		
	
		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
		if(e){
		
			
			$.ajax({
				url: "function_transaction.php",
				data:{"request":"ajax","action":"delete_sale_invoice","invoice_id":invoice_id,"stock_id":stock_id,"tablex":tablex,"quantity":qty},
				success: function(reply){
						jAlert("successfully Deleted");
						load_sale_invoice();
				}
			});
				
		
		
	
  		}
		
		});
	
	
	}
	
	
	
	
	function editItem(id) {
	
		var invoice = $("#txtinvoice").val();
		var vals = $("#item"+id).val();
		var price = parseFloat(vals.replace(/,/g, ''));
		
		$.ajax({
			url: "functions.php",
			data:{"request":"ajax","action":"updateItem","price":price,"id":id},
			success: function(reply){
				console.log(reply);
					if(reply == 'updated'){
						jAlert('Item Updated','Alert Dialog');
						window.location = "viewInvoice.php?menu=transaction&invoice_no="+invoice+"&id="+id;
					}
					else{
						jAlert('Error','Error Message');
						event.preventDefault();
					}
				}
		});
	
	}
	
	function deleteItem(id,item_id,type) {
	
		var invoice = $("#txtinvoice").val();
	
		jConfirm('Do you really want to DELETE this ITEM?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "functions.php",
					data:{"request":"ajax","action":"deleteItem","id":id,"item_id":item_id,"item_type":type},
					success: function(reply){
						console.log(reply);
							if(reply == 'deleted'){
								jAlert('Item Deleted','Alert Dialog');
								window.location="viewInvoice.php?menu=transaction&invoice_no="+invoice+"&id="+id;
							}else{
								jAlert('Error','Alert Dialog');
								event.preventDefault();
							}
						}
				});
			}
		});
	
	}
	
	function Update() {
		
		var invoice = $("#txtinvoice").val();
		var invoice_id = $("#txtid").val();
		var date_issued = $("#txtdate").val();
		var customer_id = $("#txtcusid").val();
		var terms = $("#txtterms").val();
		var address = $("#txtaddress").val();
		
		jConfirm('Do you really want to UPDATE this INVOICE?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "functions.php",
					data:{"request":"ajax","action":"updateDetails","id":invoice_id,"invoice_no":invoice,"date_issued":date_issued,"customer_id":customer_id,"terms":terms,"address":address},
					success: function(reply){
						console.log(reply);
							if(reply == 'updated'){
								jAlert("Invoice was successfully Updated!", "Alert Dialog");
								window.location = "sales.php?menu=transaction";
								
							}else if(reply == 'exists'){
								jAlert('Invoice No. Already Exists!', 'Alert Dialog');
							}
							else{
								jAlert('An Error Occured');
								event.preventDefault();
							}
					}
				});
			}
		});
	}
	
	function closeIframe2(actions){
		if(actions=="add"){
			jAlert("Successfully Added");
		}
		else if(actions=="edit"){
			jAlert("Successfully Updated");
		}
		else if(actions=="cancel"){
			$('#new_items2').dialog('close');
		}
		$('#new_items2').dialog('close');
		loadUpper();
		load_sale_invoice();
		return false;
	}
	
	function edit_item(id){
	event.preventDefault();

		var	amount = parseFloat($("#amount"+id).val().replace(/,/g, ''));

		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length;
		
		if($("#amount"+id).val==""){
			errormsg+="- Amount \n";
		}
		if(errormsg.length==emsg){
			 $.ajax({
				url: "function_transaction.php",
				data:{"request":"ajax","action":"edit_amount_invoice","amount":amount,"id":id},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Successfully Updated!", "Alert Dialog");
							load_sale_invoice();
						}
						else{
							alert('Sorry Error');
							event.preventDefault();
						}
				}
			}); 
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		

	}
	
	</script>
</body>
</html>