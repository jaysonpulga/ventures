<!DOCTYPE HTML>
<html lang="en">
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px; margin-left:15px;" >
				<table class="contents" cellspacing="0" cellpadding="5" width="400px">
					<tr>
						<td style="text-align:center !important;">
							<select id = 'txtbrand' name='brand'>
								<option value="">- BRAND -</option>
							</select>
						</td>
					</tr>
					<tr>
						<td style="text-align:center !important;">
						<select id = 'txtcode' name='brand'>
							<option value="">- ITEM CODE -</option>
						</select>
						</td>
					</tr>
				</table>
				<input type = "hidden" id = "txtinvoice" value = "<?php echo $_REQUEST['invoice_no']; ?>">
				<table id = "promo_list" class="contents" width="400px" style="margin-top:10px;">
					<thead align="center">
					<tr>
						<th></th><th>SERIAL<BR>NO.</th><th>COLOR</th>
					</tr>
					</thead>
						<tbody id = "promo_data"></tbody>
				</table>
				<div align="center" style="margin-top:15px">
					<span>
					<input type="button" value="ADD" id = "btnadd">
					<input type="button" value="CANCEL"  onclick = "window.parent.closeIframeItem();">
					</span>
				</div>
			</div>
		</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadBrand();
		loadTable();
		
		$('#txtcode')
		.prop('disabled', true)
		.empty()
		.append('<option value="">- ITEM CODE -</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$( "#txtbrand" ).change(function() {
			$('#txtcode')
			.prop('disabled', false)
			.empty()
			.append('<option value="">- ITEM CODE -</option>')
			.find('option:first')
			.attr("selected","selected")
			;
			
			brand_id=$("#txtbrand :selected").val();
			brand_name=$("#txtbrand :selected").text();
			
			loadTable();
			loadModel(brand_id);
			
		});
		
		$( "#txtcode" ).change(function() {
			
			con_id=$("#txtcode :selected").val();
			con_name=$("#txtcode :selected").text();
			
			loadTable(con_id);
			
		});
		
	});
	
	function loadBrand() {
		
		var url="functions.php?request=ajax&action=loadBrand&category=3";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){

				$("#txtbrand").append("<option value="+ res.id+">" + res.brand + "</option>");

			});
		});
		
	}
	
	function loadModel(id){
		
		var url="functions.php?request=ajax&action=loadPromo&brand_id="+id;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtcode").append("<option value="+ res.promo_id+">" + res.item_code + "</option>");

			});
		});
	}
	
	function loadTable(id) {
		$("#promo_list > tbody").empty();
	
		var url="functions.php?request=ajax&action=loadStockPromo&item_code="+id;
		var counter=0;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				$("#promo_list > tbody").append("<tr class = 'x'><td><input type = 'checkbox' id = 'txtcheck' value = "+res.id+"></td><td>"+res.serial_no+"<input type = 'hidden' id = 'txtprice' value = "+res.selling_price+"></td><td>"+res.color+"</td></tr>");
				counter++;
			});
			if (counter <= 0){
				$("#promo_list > tbody").append("<tr id = 'noItems'><th colspan = '3' align = 'center'> No Selected Items! </th></tr>");
			}
		});
		
	}
	
	$(function() {
		$('#btnadd').click(Add);
	});
	
	function Add() {
		var invoice_no=$("#txtinvoice").val();
		var count=0;
		var item_type="promo";
		var item_id;
		var selling_price = $("#txtprice").val();
		var qty = 1;
		
		$("#txtcheck:checked").each(function(){ 
			item_id=$(this).val();
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"saveInvoiceData","invoice_no":invoice_no,"item_type":item_type,"item_id":item_id,"qty":qty,"selling_price":selling_price,},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Data was Successfully Saved!", "Alert Dialog");
							window.parent.closeIframeItem(invoice_no);
						}
						else if(reply == 'exists'){
							jAlert('Item Already Exists!', 'Alert Dialog');
						}
						else{
							alert('Error');
							event.preventDefault();
						}
				}
			});
		});
			
	}
	
	</script>
	
</body>
</html>