<?php
	session_start();
	include('../database.php');
	$db = new Database();  
	$db->connect();
	
	$action = $_REQUEST["action"];
	
	if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){
		
		switch($action){
		
		
		case 'viewCustomerLists_sales_return';
				$customer = array();
				$arr = array();
				
			
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$category=$_REQUEST['category'];
				$branch_id=$_REQUEST['branch_id'];
				
				$trimmed=trim($_REQUEST['inputsearch']);
				
				if($sort == "customer_name") {
					$sort1 = "CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name)";
				}
				else {
					$sort1 = $sort;
				}
				
				if($category == "customer_name") {
				
				
					$rows ="x.invoice_no,a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code";
					
					if($branch_id != 1){
						$where = "x.customer_id = a.id AND  a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%'";
						
					}else{
						$where = "x.customer_id = a.id AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%'";
						
					}
					
					$order = "$sort1 $sortType";
					$res = $db->select("sales_invoice x, tbl_customer a, tbl_province b, tbl_city c, tbl_branch d",$rows,$where,$order);
					$res = $db->getResult();
					
				}
				if($category == "branch") {
					
					$rows ="x.invoice_no,a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code";
					
					if($branch_id != 1){
						$where = "x.customer_id = a.id AND a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND d.branch_name LIKE '%".$trimmed."%'";
						
					}else{
						$where = "x.customer_id = a.id AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND d.branch_name LIKE '%".$trimmed."%'";
					
					}
					
					$order = "$sort1 $sortType";
					$db->select("sales_invoice x,tbl_customer a, tbl_province b, tbl_city c, tbl_branch d",$rows,$where,$order);
					
					
					$res = $db->getResult();
				}
				
				$i = 0;
				
				 foreach($res as $info){
			
					 $new_arr[$i] =  array(
							'invoice_no' =>$info['invoice_no'],
							 'id' =>$info['id'],
							 'customer_name' =>$info['customer_name'],
							 'brgy' =>$info['brgy'],
							 'street' =>$info['street'],
							 'province' =>$info['province'],
							 'city' =>$info['city'],
							 'branch_name' =>$info['branch_name'],
							 'branch_id' =>$info['branch_id'],
							 'branch_code' =>$info['branch_code'],
							 'table' => 'SALES INVOICE'
							
							 );
				
							array_push($arr,$new_arr[$i]);
						 $i++;
					
				 }
				
				
				if($category == "customer_name") {
				
				
					$rowy ="x.or_no as invoice_no,a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code";
					
					if($branch_id != 1){
						$wherey = "x.customer_id = a.id AND  a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%' AND x.type = 'CASH' ";
						
					}else{
						$wherey = "x.customer_id = a.id AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%' AND x.type = 'CASH'";
						
					}
					
					$order = "$sort1 $sortType";
					$db->select("collections x, tbl_customer a, tbl_province b, tbl_city c, tbl_branch d",$rowy,$wherey,$ordery);
					$result = $db->getResult();
					

					
				}
				if($category == "branch") {
					
				
					$rowy ="x.or_no as invoice_no,a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code";
					
					if($branch_id != 1){
						$wherey = "x.customer_id = a.id AND a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND d.branch_name LIKE '%".$trimmed."%' AND x.type = 'CASH' ";
						
					}else{
						$wherey = "x.customer_id = a.id AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND d.branch_name LIKE '%".$trimmed."%' AND x.type = 'CASH' ";
					
					}
					
					$order = "$sort1 $sortType";
					$db->select("collections x,tbl_customer a, tbl_province b, tbl_city c, tbl_branch d",$rows,$where,$order);
					$result = $db->getResult();
					
				}
				
				
				
				$i = 0;
				
				 foreach($result as $info){
			
					 $new_arr[$i] =  array(
							'invoice_no' =>$info['invoice_no'],
							 'id' =>$info['id'],
							 'customer_name' =>$info['customer_name'],
							 'brgy' =>$info['brgy'],
							 'street' =>$info['street'],
							 'province' =>$info['province'],
							 'city' =>$info['city'],
							 'branch_name' =>$info['branch_name'],
							 'branch_id' =>$info['branch_id'],
							 'branch_code' =>$info['branch_code'],
							 'table' => 'CASH'
							
							 );
				
							array_push($arr,$new_arr[$i]);
						 $i++;
					
				 }
				
				print '{"members":'.json_encode($arr).'}';
				break;
				
				
	case 'load_invoice_cash';
	
	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$dataArray5=array();
		
	 
	 $table = $_REQUEST['table'];
	  $customer = $_REQUEST['customer'];

	if($table == "collections"){
		
	$where = "customer_id='$customer' and a.or_no = b.or_no";
	$db->select("collections a,collection_cash b","a.*,b.or_no,b.category",$where);
	$result = $db->getResult();
	$tab = "collection_cash";
	
	}else if($table == "sales_invoice"){
	
		$where = "customer_id='$customer' and a.invoice_no = b.invoice_no";
		$db->select("sales_invoice a,sale_invoice_details b","a.*,b.invoice_no,b.category",$where);
		$result = $db->getResult();
		$tab = "sale_invoice_details";	
	}

			foreach($result as $key){
							
				if($table == "collections"){
					$invoice_no=$key["or_no"];
					$id = "a.or_no";
			
				}else if($table == "sales_invoice"){
					$invoice_no=$key["invoice_no"];
					$id = "a.invoice_no";
				}
				$category=$key["category"];
							 
						 
						 if($category == '1'){
						 
							$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.engine_no,b.frame_no,b.color,c.model,d.brand";
							$table = "$tab a,stocks_motors b,tbl_motorcycle c,tbl_manufacturer d";
							
							$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = d.category AND $id  = '$invoice_no' and a.category = 1  AND a.qty != 0  "; 
							$db->select($table,$row,$where);
							$result = $db->getResult();
							$dataArray=$result;	
												
							
						 }else if($category == '5'){
							
							$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.engine as engine_no ,b.frame as frame_no,b.color,c.model,d.brand";
							
							$table = "$tab a,stock_repo b,tbl_motorcycle c,tbl_manufacturer d";
							
							$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = 5 AND $id  = '$invoice_no' AND a.qty != 0  "; 
							$db->select($table,$row,$where);
							$result = $db->getResult();
							$dataArray5=$result;


							
						 }
						 
						 else if($category == '2'){

							$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
							
							$table = "$tab a,stocks_parts b,tbl_parts c,tbl_manufacturer d";
							
							$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.parts_id AND b.brand = d.id AND a.category = d.category AND $id = '$invoice_no' and a.category = 2 AND a.qty != 0 ";
							$db->select($table,$row,$where);
							$result = $db->getResult();
							$dataArray2=$result;
						   
						 
						 }
						 else if($category == '3'){
							
							
							$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,b.color,c.item_code,d.brand";
							$table = "$tab a,stocks_promo b,tbl_promo c,tbl_manufacturer d";
							$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.promo_id AND b.brand = d.id AND a.category = d.category AND $id  = '$invoice_no' and a.category =  3 AND a.qty != 0";
							$db->select($table,$row,$where);
							$result = $db->getResult();
							$dataArray3=$result;
						  
						 }
						 else if($category == '4'){
							
							
							$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
							
							$table = "$tab a,stocks_consumables b,tbl_consumables c,tbl_manufacturer d";
							
							$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.con_id AND b.brand = d.id AND a.category = d.category AND $id = '$invoice_no' and a.category = 4 AND a.qty != 0 ";
							$db->select($table,$row,$where);
							$result = $db->getResult();
							$dataArray4=$result;
						   
						 }
						
							
						
						$output = array_merge($dataArray,$dataArray2,$dataArray3,$dataArray4,$dataArray5); 
	}


	 
		if(empty($output)){
		
			echo '{"members":'.json_encode($result).'}';
			
		}else{

			echo '{"members":'.json_encode($output).'}';
		}		
					
		break;
		
		
		case 'Add_cash_invoice';
		
		$array = $_REQUEST["array"];
		 $or_no = $_REQUEST["or_no"];
		
		
		foreach( $array as $key => $value) { 
		 
		$val =  $value['invoice_id'];
						
		$where = "id = '$val'";
		$db->select("sale_invoice_details b","*",$where);
		$resultx = $db->getResult();			
						
		
				foreach($resultx as $info){
				
					 $id = $info['id'];
					 $invoice_no = $info['invoice_no'];
					 $serial_no = $info['serial_no'];
					 $stock_id = $info['stock_id'];
					 $category = $info['category'];
					 $amount = $info['amount'];
					 $qty = $info['qty'];
					 
						$rows1 = "*";
						$where1 = "invoice_no= '$invoice_no'  AND stock_id = '$stock_id'";
						if($db->recordExist('collection_cash',$rows1,$where1) > 0){
							echo "exists";
						}else{
							
							$rows ='or_no,invoice_no,stock_id,category,type,amount,qty';
							$values = array($or_no,$invoice_no,$stock_id,$category,'INVOICE',$amount,$qty);
							$db->insert('collection_cash',$values,$rows);
							
							echo "uhryt";
						}	 
					 
				
				}

		
	
		} 
			
		break;
		
		
		
		
		case 'load_invoice2';
	
	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$dataArray5=array();
		
	 
	$txtcusid = $_REQUEST['txtcusid'];
	  $inv_number = $_REQUEST['inv_number'];

	
	
		$where = "a.invoice_no = '$inv_number' AND customer_id='$txtcusid' and a.invoice_no = b.invoice_no";
		$db->select("sales_invoice a,sale_invoice_details b","a.*,b.invoice_no,b.category",$where);
		$result = $db->getResult();
		


			foreach($result as $key){
							
				
					$invoice_no=$key["invoice_no"];
					$id = "a.invoice_no";
		
					$category=$key["category"];
					$tab = "sale_invoice_details";		 
						 
						 if($category == '1'){
						 
							$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.engine_no,b.frame_no,b.color,c.model,d.brand";
							$table = "$tab a,stocks_motors b,tbl_motorcycle c,tbl_manufacturer d";
							
							$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = d.category AND $id  = '$invoice_no' and a.category = 1  AND a.qty != 0  "; 
							$db->select($table,$row,$where);
							$result = $db->getResult();
							$dataArray=$result;	
												
							
						 }else if($category == '5'){
							
							$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.engine as engine_no ,b.frame as frame_no,b.color,c.model,d.brand";
							
							$table = "$tab a,stock_repo b,tbl_motorcycle c,tbl_manufacturer d";
							
							$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = 5 AND $id  = '$invoice_no' AND a.qty != 0  "; 
							$db->select($table,$row,$where);
							$result = $db->getResult();
							$dataArray5=$result;


							
						 }
						 
						 else if($category == '2'){

							$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
							
							$table = "$tab a,stocks_parts b,tbl_parts c,tbl_manufacturer d";
							
							$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.parts_id AND b.brand = d.id AND a.category = d.category AND $id = '$invoice_no' and a.category = 2 AND a.qty != 0 ";
							$db->select($table,$row,$where);
							$result = $db->getResult();
							$dataArray2=$result;
						   
						 
						 }
						 else if($category == '3'){
							
							
							$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,b.color,c.item_code,d.brand";
							$table = "$tab a,stocks_promo b,tbl_promo c,tbl_manufacturer d";
							$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.promo_id AND b.brand = d.id AND a.category = d.category AND $id  = '$invoice_no' and a.category =  3 AND a.qty != 0";
							$db->select($table,$row,$where);
							$result = $db->getResult();
							$dataArray3=$result;
						  
						 }
						 else if($category == '4'){
							
							
							$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
							
							$table = "$tab a,stocks_consumables b,tbl_consumables c,tbl_manufacturer d";
							
							$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.con_id AND b.brand = d.id AND a.category = d.category AND $id = '$invoice_no' and a.category = 4 AND a.qty != 0 ";
							$db->select($table,$row,$where);
							$result = $db->getResult();
							$dataArray4=$result;
						   
						 }
						
							
						
						$output = array_merge($dataArray,$dataArray2,$dataArray3,$dataArray4,$dataArray5); 
	}


	 
		if(empty($output)){
		
			echo '{"members":'.json_encode($result).'}';
			
		}else{

			echo '{"members":'.json_encode($output).'}';
		}		
					
		break;
		
		
		
		
		
		
		}
	}