<?php
session_start();
?>
<html>
<title>Purchase</title>
<head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
.ui-dialog-title{
	text-align:left;
}
</style>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link rel="stylesheet" href="../css/jPages.css" type="text/css" media="screen">
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript" ></script>
	<script type="text/javascript" src=""></script>
	<script src="../js/FormatNUmberBy3.js" type="text/javascript"></script>
</head>

<style>
.contents td a{
	color:#3d3d45;
}
.contents td a:hover{
	text-decoration:underline;
}
</style>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<table width="780px" >
						<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2 style="margin-top:10px;">PURCHASE ORDER</h2>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
							<form name="search" action="" method="POST">
							<select id = 'category' name='category'>
								<option value="a.po_num">P.O. # </option>
								<option value="b.supplier_name">Supplier</option>
							
							</select>
								<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Report">
								<input type="button" value="NEW P.O" id='input' style="width:110px;" onClick="create_po();">
								</form>
							</td>
						</tr>
					</table>
				</div>
					
				<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:780px" cellspacing="0">
					<table id="table">
						<thead>
							<tr><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'a.po_num')">P.O NO.</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'a.date')">DATE</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'b.supplier_name')">SUPPLIER</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'a.terms')">TERMS</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'total_amount')">TOTAL AMT</a></th><th colspan="2">ACTION</th></tr>
						</thead>
						<tbody id="alldata">
						</tbody>
					</table>
				</div>
				<div id="new_items" title="VIEW REQUEST" style="display:none;">
					<iframe id="item_dialog" width="750" height="290" style="border:none"></iframe>
				</div>	

					<div id="pagination" style="margin-top:50px;"> 
						<div class="holder" ></div>
						<div style='font-size:11px;margin-top:5px;' align='center'><i>Pages</i></div>
				</div>	
			</div>
	</div>
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		if(menu=="transaction#"){
			menu="transaction";
		}
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		loadPurchaseOrders("a.id","DESC");
	});	
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
				
	var sortType = "ASC";
	
	function filter_list(index,cVar){
		sort = cVar;
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadPurchaseOrders(sort,sortType);
	}
	
	function closeIframe(link)
	{
		$('#new_items').dialog('close');
		jAlert("Purchase Order Created","Alert Dialog");
		
		window.location=link;
		
		return false;
	}
	
	function loadPurchaseOrders(sort,sortType){
				
					
		$("#table > tbody").empty();
		
		var url="function2.php?request=ajax&action=loadAllPO&sort="+sort+"&sortType="+sortType;
		
	
		$.getJSON(url,function(data){
			var counter=0;
		
			$.each(data.members, function(i,res){
				 var amount=FormatNumberBy3((parseFloat(res.total_amount)).toFixed(2));
				 $("#table > tbody").append("<tr class='x' onmouseover='clickSearch()' ><td><a href='newPO.php?menu=transaction&po_no="+res.po_num+"'>"+res.po_num+"</a></td><td>"+res.date+"</td><td>"+res.supplier+"</td><td>"+res.terms+"</td><td><div align='right'>"+amount+"</div></td><td><a href='newPO.php?menu=transaction&po_no="+res.po_num+"'><img src='../images/edit.png' /></a></td><td><a href='#' onclick='deleteItem("+res.id+");' alt='Delete' title='Delete'><img src='../images/delete.png' /></a></td></tr>");
				 counter++;
			});
			jpages();	
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
			}

		});
		
		
		
	}
	function create_po(){
	
		$("#new_items").attr("title","NEW PURCHASE ORDER");
		$("#item_dialog").attr({
			height:340,
			width:400,
		});
			
		$("#item_dialog").attr('src','createPO.php');
		$("#new_items").dialog({
			width: 401,
			height: 385,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src',"about:blank");
				window.location.reload();
			}
		});
		return false;

	}
	
	$("#txtsearch").blur(function(){
		$(this).val("");
	});

	$("#txtsearch").bind('keyup change',function(){
		var url ="function2.php?request=ajax&action=searchPO&inputsearch="+$(this).val()+"&category="+$('#category').val();
		var counter=0;
		
		if($(this).val().trim() != ""){
		
			$("#table > tbody").empty();

			$.getJSON(url,function(data){
				var counter=0;
			
				$.each(data.members, function(i,res){
					 var amount=(parseFloat(res.total_amount)).toFixed(2);
					 $("#table > tbody").append("<tr class='x' onmouseover='clickSearch()' ><td><a href='newPO.php?menu=transaction&po_no="+res.po_num+"'>"+res.po_num+"</a></td><td>"+res.date+"</td><td>"+res.supplier+"</td><td>"+res.terms+"</td><td><div align='right'>"+amount+"</div></td><td><a href='newPO.php?menu=transaction&po_no="+res.po_num+"'><img src='../images/edit.png' /></a></td><td><a href='#' onclick='deleteItem("+res.id+");' alt='Delete' title='Delete'><img src='../images/delete.png' /></a></td></tr>");
					 counter++;
				});
				jpages();	
				
				if (counter <= 0){
					$("#table > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
				}

			});
		
			
		}	
		else{
			$("#table > tbody").empty();
			loadPurchaseOrders("a.id","DESC");
		}				
	});
	
	function deleteItem(id){
		jConfirm('Do you really want to DELETE this PO?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "function2.php",
					data:{"request":"ajax","action":"deleteAllPO","id":id},
					success: function(reply){
						console.log(reply);
							if(reply == 'deleted'){
								jAlert('Purchase Order Deleted','Alert Dialog');
								loadPurchaseOrders("a.id","DESC");
							}
							else{
								jAlert('Error','Error Message');
								event.preventDefault();
							}	
						}
				});
			}
		});	
	}
	
	function jpages(){
			$("div.holder").jPages({
			  containerID : "alldata",
			   previous : "←",
				next : "→",
			  perPage : 10,
			  delay :10,
			  startPage    : 1,
			  startRange   : 1,
			  midRange     : 5,
			  endRange     : 1
			});
	}
	
	function clickSearch() {
	
	$("#txtsearch").blur();	
	
	}
	
	
	
	</script>
	
</body>
</html>