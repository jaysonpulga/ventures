<html>
<title>COLLECTION</title>
</html>
<style>
.x:nth-child(even) td{
	background:lightgray;
}
</style>
<?php
include('../database.php');  
$db = new Database();  
$db->connect(); 

	$dataArray=array();
	$type="1";
	$sortType="DESC";
	$sort="a.id";
	
	$invoice_no=$_REQUEST['invoice_no'];
	
	$rows = "a.*, CONCAT(b.last_name,', ',b.first_name,' ',b.middle_name) as customer_name" ;
	$where = "a.invoice_no= '$invoice_no' AND a.customer_id = b.id   group by a.invoice_no";
	$db->select('sales_invoice a, tbl_customer b',$rows,$where); 
	$result = $db->getResult();
	
	
	foreach($result as $key){		

		
		  $invoice_no=$key["invoice_no"];
		  $date_issued=$key["date_issued"];
		  $customer_name=$key["customer_name"];
		  $terms=$key["terms"];
		  $address=$key["address"];

	}
	
	
	
	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$invoice_no = $_REQUEST['invoice_no'];
	
	$where = "invoice_no='$invoice_no'";
	$db->select("sale_invoice_details","*",$where);
	$result = $db->getResult();
	
	foreach($result as $key){
		 $category=$key["category"];
		  $invoice_no=$key["invoice_no"];
		 
		if($category == '1'){
		 
			$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.engine_no,b.frame_no,b.color,c.model,d.brand";
			$table = "sale_invoice_details a,stocks_motors b,tbl_motorcycle c,tbl_manufacturer d";
			
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = d.category AND a.invoice_no = '$invoice_no'"; 
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray=$result;	
		 }
		 
		 else if($category == '2'){

			$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
			$table = "sale_invoice_details a,stocks_parts b,tbl_parts c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.parts_id AND b.brand = d.id AND a.category = d.category AND a.invoice_no = '$invoice_no'";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray2=$result;
		   
		 
		 }
		 else if($category == '3'){
			
			
			$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,b.color,c.item_code,d.brand";
			$table = "sale_invoice_details a,stocks_promo b,tbl_promo c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.promo_id AND b.brand = d.id AND a.category = d.category AND a.invoice_no = '$invoice_no'";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray3=$result;
		  
		 }
		 else if($category == '4'){
			
			
			$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
			$table = "sale_invoice_details a,stocks_consumables b,tbl_consumables c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.con_id AND b.brand = d.id AND a.category = d.category AND a.invoice_no = '$invoice_no'";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray4=$result;
		   
		 }
		
		$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4);
		
	}

	echo" 
	<div align='center' style='font-family:Calibri'>
	<table border=0 width='1000' cellpadding=2 cellspacing=0>
		<tr><td><b>Invoice No.:</b> $invoice_no</td><td align='right' colspan=4><b>Date:</b> $date_issued</td></tr>
		<tr><td colspan=2><b>Customer Name:</b> $customer_name</td><td align='right' colspan=4><b>Terms:</b> $terms</td></tr>
		<tr><td colspan=3 ><b>Address:</b> $address</td></tr>
		<tr><td colspan=5 align='center' style='padding:20px 0px 10px 0px;border-bottom:2px solid #000'><b>SALES INVOICE</b></td></tr>
		
		
		<tr>
		<td style='border-bottom:2px solid #000' align='center' width='10%'><b>QTY</b></td>
		<td colspan=2 align='center' style='border-bottom:2px solid #000'><b>PARTICULARS</b></td>
		<td width='15%' align='center' style='border-bottom:2px solid #000'><b>UNIT PRICE</b></td>
		<td width='15%' align='center' style='border-bottom:2px solid #000'><b>AMOUNT</b></td>
		</tr>";
	
	$total_amout = 0;
	$vat = 0;
	$amount_due = 0;
	if(count($output)>0){
		foreach($output as $key){
			
			
			if($key['category'] == '1'){
					
				 $particulars = "MAKE & MODEL:".$key['brand'].",".$key['model']."<br> ENGINE NO: ".$key['engine_no']."<br> FRAME NO:".$key['frame_no']."<br>COLOR:".$key['color'];
				
				}
				
				else if ($key['category'] == '3'){
					
				$particulars = "MAKE & MODEL:".$key['brand'].",".$key['item_code']."<br> SERIAL NO: ".$key['serial_no']."<br>COLOR: ".$key['color'];
				
				}
				
				else{
					
				$particulars = "MAKE & MODEL:".$key['brand'].",".$key['item_code']."<br> SERIAL NO: ".$key['serial_no'];
				
				}
			
			
			$total_sale= $key['qty'] * $key['amount'];
			
			echo "<tr align='center' class='x'>";
			echo "<td>".$key['qty']."</td>";
			echo "<td colspan=2>".strtoUpper($particulars)."</td>";
			echo "<td>".number_format($key['amount'],2,".",",")."</td>";
			echo "<td>".number_format($total_sale,2,".",",")."</td>";
			echo "</tr>";
			
			$total_amout += $key['amount'] * $key['qty'];
			$vat = $total_amout*0.12;
			$amount_due = $total_amout-$vat;
		
		}
	}
	else{
		echo "<tr align='center'><td colspan=5  style='padding:20px 0px 0px 0px;'>*** NO ITEMS TO DISPLAY ***</td></tr>";
	}
	echo "<tr><td colspan=5 align='center' style='padding:10px 0px 10px 0px;border-bottom:2px solid #000'></td></tr>";
	echo "<tr><td width='25%'></td><td colspan=3  align='right' style='padding:10px 0px 3px 0px;'><b>AMOUNT DUE:</b></td><td width='15%' align='center' >".number_format($total_amout,2,".",",")."</td></tr>";
	echo "<tr><td width='25%'></td><td  colspan=3 align='right' style='padding:3px 0px 3px 0px;'><b>VAT_TAX:</b></td><td width='15%' align='center' >".number_format($vat,2,".",",")."</td></tr>";
	echo "<tr><td width='25%'></td><td colspan=3  align='right' style='padding:3px 0px 3px 0px;'><b>TOTAL SALES:</b></td><td width='15%' align='center' >".number_format($amount_due,2,".",",")."</td></tr>";
	echo "</table></div>";	
?>