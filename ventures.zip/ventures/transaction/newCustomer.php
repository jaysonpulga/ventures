<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px; margin-left:15px;" >
				<div>
					<span>
						<label><h3>CUSTOMER NAME</h3></label>
					</span>
				</div>
				<div>
					<span>
						<input type="text" id = "txtlast" placeholder="Last Name" style="text-align:center">
						<input type="text" id = "txtfirst" placeholder="First Name" style="text-align:center">
						<input type="text" id = "txtmiddle" placeholder="Middle Name" style="text-align:center">
					</span>
				</div>
				<div>
					<span>
						<label>Birthday:</label>
						<input type="date" id = "txtbirth">
						<label>Telephone No.:</label>
						<input type="text" id = "txttel" onkeyup="javascript:this.value = this.value.replace(/[^0-9,-]/, '')">
						<label>Cellphone No.:</label>
						<input type="text" id = "txtcell" onkeyup="javascript:this.value = this.value.replace(/[^0-9,-]/, '')">
					</span>
				</div>
				<div>
					<span>
						<label>Branch:</label>
						<?php
						if($_SESSION['branch_id'] == 1){
							echo '<select id = "txtbranch">
								<option value = "">-- SELECT --</option>
							</select>;';
						}else{
						echo '<input readonly type="text" value="'.$_SESSION['branch_name'].'" />';
						echo '<input type="hidden" value="'.$_SESSION['branch_id'].'" id="txtbranch" />';
						}
						
						
						?>
					</span>
				</div>
				<div>
					<span>
						<label><h3>CUSTOMER ADDRESS</h3></label>
					</span>
				</div>
				<div>
					<span>
						<label>Region</label>
						<label style="margin-left:125px">Province</label>
						<label style="margin-left:102px">City/Town</label>
						<label style="margin-left:97px">Subd/Brgy</label>
						<label style="margin-left:107px">Street/Num</label>
					</span>
				</div>
				<div>
					<span>
						<select id = "txtcusregion" name='brand'>
						<option value="">Select</option>
						</select>
						<select id = "txtcusprovince" name='brand'>
						<option value="">Select</option>
						</select>
						<select id = "txtcuscity" name='brand'>
						<option value="">Select</option>
						</select>
						<input type="text" id = "txtcussubd">
						<input type="text" id = "txtcusstreet">
					</span>
				</div>
				<div>
					<span>
						<label><h3>SHIPPING ADDRESS</h3></label>
					</span>
				</div>
				<div>
					<span>
						<input type="checkbox" id = "txtsame">
						<label>Same as above</label>
					</span>
				</div>
				<div>
					<span>
						<label>Region</label>
						<label style="margin-left:125px">Province</label>
						<label style="margin-left:102px">City/Town</label>
						<label style="margin-left:97px">Subd/Brgy</label>
						<label style="margin-left:107px">Street/Num</label>
					</span>
				</div>
				<div>
					<span>
						<select id = "txtshipregion" name='brand'>
						<option value="">Select</option>
						</select>
						<select id = "txtshipprovince" name='brand'>
						<option value="">Select</option>
						</select>
						<select id = "txtshipcity" name='brand'>
						<option value="">Select</option>
						</select>
						<input type="text" id = "txtshipsubd">
						<input type="text" id = "txtshipstreet">
					</span>
				</div>
				<div align="center" style="margin-top:15px">
					<span>
						<input type="button" value="SAVE" onclick = "Add();">
						<input type="button" value="CANCEL"  onclick = "window.parent.closeIframeNew();">
					</span>
				</div>
			</div>
		<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		var cus_region_id;
		var cus_region_name;
		var cus_province_id;
		var cus_province_name;
		var cus_city_id;
		var cus_city_name;
		
		loadBranch();
		loadRegion();
		loadRegion2();
		
		$('#txtbranch')
		.prop('disabled', false)
		.empty()
		.append('<option value="">-- SELECT  --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$('#txtsame').prop('disabled', true);
		
		//customer address
		$('#txtcusregion')
		.prop('disabled', false)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$('#txtcusprovince')
		.prop('disabled', true)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$('#txtcuscity')
		.prop('disabled', true)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
			
		$( "#txtcusregion" ).change(function() {
			if($(this).val() == "") {
				$('#txtcusprovince')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
				$('#txtcuscity')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
			}
			
			else {
				
				$('#txtcusprovince')
				.prop('disabled', false)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
				$('#txtcuscity')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
			}
			
			cus_region_id=$("#txtcusregion :selected").val();
			cus_region_name=$("#txtcusregion :selected").text();
			
			loadProvince(cus_region_id);
			
		});
		
		$( "#txtcusprovince" ).change(function() {
			if($(this).val() == "") {
				$('#txtcuscity')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
			}
			else {
			
				$('#txtcuscity')
				.prop('disabled', false)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
			}
			
			cus_province_id=$("#txtcusprovince :selected").val();
			cus_province_name=$("#txtcusprovince :selected").text();
			
			loadCity(cus_province_id);
			
		});
		
		$( "#txtcuscity" ).change(function() {
			
			cus_city_id=$("#txtcuscity :selected").val();
			cus_city_name=$("#txtcuscity :selected").text();
			
			var city=$('#txtcuscity').val();
			
			if(!city == "") {
				$('#txtsame').prop('disabled', false);
			}else {
				$('#txtsame').prop('disabled', true);
			}
			
		});
		
		//shipping address
		
		$('#txtshipregion')
		.prop('disabled', false)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$('#txtshipprovince')
		.prop('disabled', true)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$('#txtshipcity')
		.prop('disabled', true)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$('#txtsame').click(function(event) {
			if(this.checked) {
				loadShippingRegion(cus_region_id,cus_region_name);
				loadShippingProvince(cus_province_id,cus_province_name);
				loadShippingCity(cus_city_id,cus_city_name);
				
				var cus_subd = $('#txtcussubd').val();
				var cus_street = $('#txtcusstreet').val();
				
				$('#txtshipsubd').prop('disabled', true).val(cus_subd);
				$('#txtshipstreet').prop('disabled', true).val(cus_street);
				
			}else{
				loadRegion2();
				$('#txtshipregion')
				.prop('disabled', false)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
				$('#txtshipprovince')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
				$('#txtshipcity')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
				$('#txtshipsubd').prop('disabled', false).val('');
				
				$('#txtshipstreet').prop('disabled', false).val('');
				
			}
		});
		
		$( "#txtshipregion" ).change(function() {
			if($(this).val() == "") {
				$('#txtshipprovince')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
				$('#txtshipcity')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
			}
			else {
				$('#txtshipprovince')
				.prop('disabled', false)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
				$('#txtshipcity')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
			}
			
			var ship_region_id=$("#txtshipregion :selected").val();
			var ship_region_name=$("#txtshipregion :selected").text();
			
			loadProvince2(ship_region_id);
		});
		
		$( "#txtshipprovince" ).change(function() {
			if($(this).val() == "") {
				$('#txtshipcity')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
			}
			else {
				$('#txtshipcity')
				.prop('disabled', false)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
			}
			
			var ship_province_id=$("#txtshipprovince :selected").val();
			var ship_province_name=$("#txtshipprovince :selected").text();
			
			loadCity2(ship_province_id);
		});

	});

	function loadBranch(){
		
		var url="functions.php?request=ajax&action=loadCustomerBranch";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){

				$("#txtbranch").append("<option value="+ res.id+">" + res.branch_name + "</option>");

			});
		});
	}

	function loadRegion(){
		
		var url="functions.php?request=ajax&action=loadCustomerRegion";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){

				$("#txtcusregion").append("<option value="+ res.id+">" + res.region_name + "</option>");
				
			});
		});
	}

	function loadProvince(pid){
		
		var url="functions.php?request=ajax&action=loadCustomerProvince&region_id="+pid;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
			
				$("#txtcusprovince").append("<option value="+ res.id+">" + res.province_name + "</option>");
				
			});
		});
	}

	function loadCity(cid){
		
		var url="functions.php?request=ajax&action=loadCustomerCity&province_id="+cid;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtcuscity").append("<option value="+ res.id+">" + res.city_name + "</option>");

			});
		});
	}

	//functions for shipping address

	function loadRegion2(){
		
		var url="functions.php?request=ajax&action=loadCustomerRegion";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
			
				$("#txtshipregion").append("<option value="+ res.id+">" + res.region_name + "</option>");

			});
		});
	}

	function loadProvince2(cus_region_id){
		
		var url="functions.php?request=ajax&action=loadCustomerProvince&region_id="+cus_region_id;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
			
				$("#txtshipprovince").append("<option value="+ res.id+">" + res.province_name + "</option>");
				
			});
		});
	}

	function loadCity2(cus_province_id){
		
		var url="functions.php?request=ajax&action=loadCustomerCity&province_id="+cus_province_id;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtshipcity").append("<option value="+ res.id+">" + res.city_name + "</option>");

			});
		});
	}

	function loadShippingRegion(region_id,region_name) {
		$('#txtshipregion')
		.prop('disabled', true)
		.empty()
		.append('<option value='+region_id+'>'+region_name+'</option>')
		;
	}

	function loadShippingProvince(province_id,province_name) {
		$('#txtshipprovince')
		.prop('disabled', true)
		.empty()
		.append('<option value='+province_id+'>'+province_name+'</option>')
		;
	}

	function loadShippingCity(city_id,city_name) {
		$('#txtshipcity')
		.prop('disabled', true)
		.empty()
		.append('<option value='+city_id+'>'+city_name+'</option>')
		;
	}

	function Add(){

		var last_name=$("#txtlast").val();
		var first_name=$("#txtfirst").val();	
		var middle_name=$("#txtmiddle").val();	
		var birthday=$("#txtbirth").val();	
		var telno=$("#txttel").val();
		var cellno=$("#txtcell").val();
		var branch_id=$("#txtbranch").val();
		var cus_region_id=$("#txtcusregion").val();
		var cus_province_id=$("#txtcusprovince").val();
		var cus_province_name=$("#txtcusprovince :selected").text();
		var cus_city_id=$("#txtcuscity").val();
		var cus_city_name=$("#txtcuscity :selected").text();
		var cus_subd=$("#txtcussubd").val();
		var cus_street=$("#txtcusstreet").val();
		var ship_region_id=$("#txtshipregion").val();
		var ship_province_id=$("#txtshipprovince").val();
		var ship_city_id=$("#txtshipcity").val();
		var ship_subd=$("#txtshipsubd").val();
		var ship_street=$("#txtshipstreet").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(last_name == ""){
			errormsg+="- Input Last Name.\n";
		}
		if(first_name == ""){
			errormsg+="- Input First Name.\n";
		}
		if(middle_name == ""){
			errormsg+="- Input Middle Name.\n";
		}
		if(birthday == ""){
			errormsg+="- Input Birthday.\n";
		}
		if(branch_id == ""){
			errormsg+="- Input Branch.\n";
		}
		if(cus_region_id == ""){
			errormsg+="- Input Customer Address Region.\n";
		}
		if(cus_province_id == ""){
			errormsg+="- Input Customer Address Province.\n";
		}
		if(cus_city_id == ""){
			errormsg+="- Input Customer Address City/Town.\n";
		}
		if(ship_region_id == ""){
			errormsg+="- Input Shipping Address Region.\n";
		}
		if(ship_province_id == ""){
			errormsg+="- Input Shipping Address Province.\n";
		}
		if(ship_city_id == ""){
			errormsg+="- Input Shipping Address City/Town.\n";
		}
		
		if(errormsg.length==emsg){
		
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"saveCustomerData","last_name":last_name,"first_name":first_name,"middle_name":middle_name,"birthday":birthday,"telno":telno,"cellno":cellno,"branch_id":branch_id,"cus_region_id":cus_region_id,"cus_province_id":cus_province_id,"cus_city_id":cus_city_id,"cus_subd":cus_subd,"cus_street":cus_street,"ship_region_id":ship_region_id,"ship_province_id":ship_province_id,"ship_city_id":ship_city_id,"ship_subd":ship_subd,"ship_street":ship_street},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							
							var url="functions.php?request=ajax&action=loadCustomerId&last_name="+last_name+"&first_name="+first_name+"&middle_name="+middle_name;
							
							$.getJSON(url,function(data){
								$.each(data.members, function(i,res){
									var name = res.last_name+", "+res.first_name+" "+res.middle_name;
									var address;
									var street = res.street;
									var brgy = res.brgy;
									if(street == "" && brgy == "") {
										address = res.city_name+", "+res.province_name;
									}
									else {
										address = street+" "+brgy+", "+res.city_name+", "+res.province_name;
									}
									window.parent.closeIframeNew(res.id,name,address,res.branch_code);
								});
							});
							
							
						}
						else{
							jAlert('Error');
							event.preventDefault();
						}
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
	}
	
	</script>
	
</body>
</html>