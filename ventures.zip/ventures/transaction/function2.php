<?php
include('../database.php');  
$db = new Database();  
$db->connect(); 
$action = $_REQUEST["action"];




if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){

	switch($action){
	
	
	
	case 'loadSupplier';
	
		$row = "*";
		
		$db->select('tbl_supplier',$row);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadBranches';
	
		$row = "branch_code,branch_name";
		$db->select('tbl_branch',$row);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadBrand';
		$category=$_REQUEST["category"];
		$row = "*";
		$where="category=$category";
		$db->select('tbl_manufacturer',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadModel';
		$brandID=$_REQUEST["brandID"];
		$row = "*";
		$where="brand=$brandID";
		$db->select('tbl_motorcycle',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	
	case 'loadPurchaseOrders';
		$new_arr=array();
		$dataArray=array();
		$po_num=$_REQUEST["po_no"];
		$row = "*";
		$where="po_num=$po_num";
		$db->select('purchase_order_details',$row,$where);

		$result = $db->getResult();

		
		$i=0;
		foreach($result as $key){
			
			if($key["category"]==1){
				$item=$key["item"];
				$where_item="a.motor_id=$item and a.brand=b.id";
				$db->select('tbl_motorcycle a,tbl_manufacturer b','a.model,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["model"];
				}
				
				
			}
			else if($key["category"]==2){
				$item=$key["item"];
				$where_item="a.parts_id=$item and a.brand=b.id";
				$db->select('tbl_parts a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
				}
				
				
			}
			else if($key["category"]==3){
				$item=$key["item"];
				$where_item="a.promo_id=$item and a.brand=b.id";
				$db->select('tbl_promo a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
				}
				
				
			}
			else if($key["category"]==4){
				$item=$key["item"];
				$where_item="a.con_id=$item and a.brand=b.id";
				$db->select('tbl_consumables a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
				}
				
				
			}
			
			$new_arr[$i]=array(
			'id'=> $key["id"],	
			'branch'=> $key["branch"],
			'particulars'=> $brand." ".$item." ".$key["color"],
			'qty'=> $key["qty"],
			'unit_cost'=> $key["unit_cost"],
			);
			array_push($dataArray,$new_arr[$i]);
			
			
			$i++;	
			
		}
		
		echo '{"members":'.json_encode($dataArray).'}';
					
	break;
	
	case 'loadAllPO';
		$new_arr=array();
		$dataArray=array();
		$sort=$_REQUEST["sort"];
		$sortType=$_REQUEST["sortType"];
		
		if($sort=="total_amount"){
			$sort="a.id";
		}
		else {
			$sort = $_REQUEST['sort'];
		}
				
		$row = "a.*,b.supplier_name";
		$where="a.supplier=b.id";
		
		$order="$sort $sortType";
		$db->select('purchase_order a,tbl_supplier b',$row,$where,$order);

		$result = $db->getResult();

		
		$i=0;
		foreach($result as $key){
				$total_amount=0;
				$po_no=$key["po_num"];
				$where_item="po_num=$po_no";
				$db->select('purchase_order_details','*',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$amount=$key_item["unit_cost"]*$key_item["qty"];
					$total_amount=$total_amount+$amount;
				}
				
				
			
			
			$new_arr[$i]=array(
			'id'=> $key["id"],
			'po_num'=> $key["po_num"],	
			'supplier'=> $key["supplier_name"],
			'date'=> $key["date"],
			'terms'=> $key["terms"],
			'total_amount'=> $total_amount,
			);
			array_push($dataArray,$new_arr[$i]);
			
			
			$i++;	
			
		}
		
		if ($_REQUEST["sort"] == "total_amount") {
					
			$sortArray = array(); 

			foreach($dataArray as $total){ 
				foreach($total as $key=>$value){
					if(!isset($sortArray[$key])){
						$sortArray[$key] = array(); 
					} 
					$sortArray[$key][] = $value;
				} 
			}

			$orderby = "total_amount";
			if($_REQUEST["sortType"]=="ASC"){
				array_multisort($sortArray[$orderby],SORT_ASC,$dataArray);
			}
			else{
				array_multisort($sortArray[$orderby],SORT_DESC,$dataArray);
			}	
			
			
			
		}
		
		echo '{"members":'.json_encode($dataArray).'}';
					
	break;
	
	
	case 'searchPO';
		$new_arr=array();
		$dataArray=array();	
		$category=$_REQUEST["category"];
		$trimmed=trim($_REQUEST['inputsearch']);
		$where = "$category LIKE '%".$trimmed."%' and a.supplier=b.id ";		
		$row = "a.*,b.supplier_name";

		$db->select('purchase_order a,tbl_supplier b',$row,$where);

		$result = $db->getResult();

		
		$i=0;
		foreach($result as $key){
			$total_amount=0;
			$po_no=$key["po_num"];
			$where_item="po_num=$po_no";
			$db->select('purchase_order_details','*',$where_item);
			
			$result_items = $db->getResult();
			
			foreach($result_items as $key_item){
				$amount=$key_item["unit_cost"]*$key_item["qty"];
				$total_amount=$total_amount+$amount;
			}
				
			$new_arr[$i]=array(
			'id'=> $key["id"],
			'po_num'=> $key["po_num"],	
			'supplier'=> $key["supplier_name"],
			'date'=> $key["date"],
			'terms'=> $key["terms"],
			'total_amount'=> $total_amount,
			);
			array_push($dataArray,$new_arr[$i]);
			
			
			$i++;		
		}
		
		echo '{"members":'.json_encode($dataArray).'}';
	break;
	
	case 'loadPODetails';
		$new_arr=array();
		$dataArray=array();
		$po_num=$_REQUEST["po_no"];
		$row = "*";
		$where="po_num=$po_num";
		$db->select('purchase_order',$row,$where);

		$result = $db->getResult();
		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'deletePurchaseOrders';
		$val=$_REQUEST['id'];
		
		$db->delete("purchase_order_details","id='$val'");
		
		print 'deleted';
			
	break;
	
	case 'editPurchaseOrders';
		$val=$_REQUEST['id'];
		
		$items_array=array(
			'qty'=> $_REQUEST['qty'],
			'unit_cost'=> $_REQUEST['unit_cost'],
		);
				
		$where="id='$val'";
			
		$db->update("purchase_order_details",$items_array,$where);
		
		print "updated";
			
	break;
	
	case 'loadItemsPromo';
		$brandID=$_REQUEST["brandID"];
		$row = "*";
		$where="brand=$brandID";
		$db->select('tbl_promo',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadItemsConsumables';
		$brandID=$_REQUEST["brandID"];
		$row = "*";
		$where="brand=$brandID";
		$db->select('tbl_consumables',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'savePO';
	
		$po_no=$_REQUEST["po_no"];
		$date_created=$_REQUEST["date_created"];
		$terms=$_REQUEST["terms"];
		$supplier=$_REQUEST["supplier"];
		
		$where="po_num='".$po_no."'";
		$values = array('',$po_no,$supplier,$date_created,$terms);
		
	
		$db->select('purchase_order','*',$where);
		$result = $db->getResult();
		
		if(count($result) > 0){
			print("exist");
		}
		else{
			$db->insert("purchase_order",$values);
			print 'saved';
		}
					
	break;
	
	case 'loadPO';
	
		$po_no=$_REQUEST["po_no"];
		$row = "*";
		$where="po_no=$po_no";
		$db->select('purchase_order',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	
	
	case 'addPurchaseOrder';
		$brand=$_REQUEST["brand"];
		$item=$_REQUEST["item"];
		$serial_no=strtoupper($_REQUEST["serial_no"]);
		$color=strtoupper($_REQUEST["color"]);
		$dr_no=$_REQUEST["dr_no"];
		$status="ON HAND";
		
		$values = array('',$dr_no,$brand,$item,$serial_no,$color,$status);
		
		$where="item=$item and serial_no='".$serial_no."'";
		$db->select('stocks_promo','*',$where);
		$result = $db->getResult();
		
		if(count($result) > 0){
			print("exist");
		}
		else{
			$db->insert("stocks_promo",$values);
			print 'saved';
		}
	break;

	case 'deletePurchaseOrder';
		$val=$_REQUEST['id'];
		
		$db->delete("purchase_order_details","id='$val'");
		
		print 'deleted';
			
	break;
	
	case 'deleteAllPO';
		$val=$_REQUEST['id'];
		
		$row = "*";
		$where="id=$val";
		$db->select('purchase_order',$row,$where);

		$result = $db->getResult();

		foreach($result as $key){
			$po_no=$key["po_num"];
			
			$db->delete("purchase_order_details","po_num=$po_no");
			
		}
		
		$db->delete("purchase_order","id=$val");
		
		
		print 'deleted';
			
	break;
	
	
	
	case 'load_select_model';	
		$id = $_REQUEST['id'];
		$table = $_REQUEST['table'];
		$where="brand = ".$id;
		$db->select($table,"*",$where,"model ASC");
		
		$result = $db->getResult();
		
		echo '{"members":'.json_encode($result).'}';
	break;
	
	case 'load_select_ItemCode';	
		$id = $_REQUEST['id'];
		$table = $_REQUEST['table'];
		$where="brand = ".$id;
		$db->select($table,"*",$where,"item_code ASC");
		
		$result = $db->getResult();
		
		echo '{"members":'.json_encode($result).'}';
	break;
	
	case 'load_select_ItemCode';	
		$id = $_REQUEST['id'];
		 $table = $_REQUEST['table'];
		$where="brand = ".$id;
		$db->select($table,"*",$where,"item_code ASC");
		
		$result = $db->getResult();
		
		echo '{"members":'.json_encode($result).'}';
	break;
	
	case 'loadBrand';
		$category=$_REQUEST["category"];
		$row = "*";
		$where="category=$category";
		$db->select('tbl_manufacturer',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'select_unit_cost';	
		$id = $_REQUEST['id'];
		$table = $_REQUEST['table'];
		
			if($table =="tbl_motorcycle" ){
				$where="motor_id = ".$id;
			}else if($table =="tbl_parts"){
				$where="parts_id = ".$id;
			}else if($table =="tbl_promo"){
				$where="promo_id = ".$id;
			}else if($table =="tbl_consumables"){
				$where="con_id = ".$id;
			}
		$db->select($table,"*",$where);
	
	$result = $db->getResult();
	echo '{"members":'.json_encode($result).'}';
	break;
	
	case 'add_stock';
	
		$po_no = $_REQUEST['po_no'];
		$category = $_REQUEST['category'];
		$brand = $_REQUEST['brand'];
		$branch = $_REQUEST['branch'];
		$item_code = $_REQUEST['item_code'];
		$model = $_REQUEST['model'];
		$color = $_REQUEST['color'];
		
		$qty = $_REQUEST['qty'];
		$unit_cost = $_REQUEST['unit_cost'];
		
		
		if($category == '1'){
			
			$where2 ="po_num = '$po_no' and category = '$category' and brand = '$brand' and item = '$model' and branch = '$branch' ";
		
		}else if ($category != '1'){
			
			$where2 ="po_num = '$po_no' and category = '$category' and brand = '$brand' and item = '$item_code' and branch = '$branch' ";
		}
		
		$rows2 = '*';
		
		if($db->recordExist('purchase_order_details',$rows2,$where2) > 0){
		 
			$where_x ="category = '$category' and brand = '$brand' and item = '$model' or item = '$item_code' and branch = '$branch' ";
			$db->select("purchase_order_details","*",$where_x);
			$result = $db->getResult();
			
				foreach($result as $info){
				$qty2 = $info['qty'];
				$unit2 = $info['unit_cost'];
				}
			
			$qty = $qty + $qty2 ;
			$unit_cost = $unit_cost + $unit2;
			
			
			$where_y ="category = '$category' and brand = '$brand' and item = '$model' or item = '$item_code' and branch = '$branch'";
			
			$rows_y = array('unit_cost' => $unit_cost ,'qty' => $qty);
			
			$db->update('purchase_order_details',$rows_y,$where_y); 
			print "saved"; 
		
		}else{
		
			 if($category == '1'){
				$rows ='po_num,category,brand,item,color,qty,unit_cost,branch';	
				$values = array($po_no,$category,$brand,$model,$color,$qty,$unit_cost,$branch);
			
			}else if ($category != '1'){
		
				$rows ='po_num,category,brand,item,qty,unit_cost,branch';	
				$values = array($po_no,$category,$brand,$item_code,$qty,$unit_cost,$branch);
			
			}
	
			$db->insert('purchase_order_details',$values,$rows);
			
		print 'saved'; 
	}
	break;
	
	
	
	case 'loadRequisitions';
		$new_arr=array();
		$dataArray=array();
		$sort=$_REQUEST["sort"];
		$sortType=$_REQUEST["sortType"];
		$row = "a.sr_no,a.branch_code,a.date,b.*";
		$where="a.sr_no=b.sr_no";
		$order="$sort $sortType";
		$db->select('tbl_requisition a,tbl_stock_requisition b',$row,$where,$order);

		$result = $db->getResult();

		
		$i=0;
		foreach($result as $key){
			
			if($key["category"]==1){
				$item=$key["item"];
				$where_item="a.motor_id=$item and a.brand=b.id";
				$db->select('tbl_motorcycle a,tbl_manufacturer b','a.model,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["model"];
					
				}
				
				
			}
			else if($key["category"]==2){
				$item=$key["item"];
				$where_item="a.parts_id=$item and a.brand=b.id";
				$db->select('tbl_parts a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
						
				}
				
				
			}
			else if($key["category"]==3){
				$item=$key["item"];
				$where_item="a.promo_id=$item and a.brand=b.id";
				$db->select('tbl_promo a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
					
				}
				
				
			}
			else if($key["category"]==4){
				$item=$key["item"];
				$where_item="a.con_id=$item and a.brand=b.id";
				$db->select('tbl_consumables a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
					
				}
				
				
			}
			
			$stock_id=$key["stock_id"];
			$where_stock="stock_id=$stock_id";
			$db->select('purchase_order_details','*',$where_stock);
				
			$result_stocks = $db->getResult();	
				
			if(count($result_stocks) > 0){
				$status="ON PROCESS";
			}
			else{
				$status="PENDING";
			}
		
			$new_arr[$i]=array(
			'stock_id'=>$key["stock_id"],
			'sr_no'=> $key["sr_no"],
			'date'=> $key["date"],				
			'branch'=> $key["branch_code"],
			'particulars'=> $brand." ".$item." ".$key["color"],
			'qty'=> $key["quantity"],
			'unit_cost'=> $key["unit_cost"],
			'status'=> $status,
			);
			
			array_push($dataArray,$new_arr[$i]);
			
			
			$i++;	
			
		}
		
		echo '{"members":'.json_encode($dataArray).'}';
					
	break;
	
	case 'addRequest';
		$array = $_REQUEST["array"];
		$po_no=$_REQUEST["po_no"];
		
		foreach($array as $key => $val){	
			$row = "a.sr_no,a.branch_code,b.*";
			$where="a.sr_no=b.sr_no and b.stock_id=$val";
			$db->select('tbl_requisition a,tbl_stock_requisition b',$row,$where);
			
			$result = $db->getResult();
			
			foreach($result as $key_item){
				$category=$key_item["category"];
				$item=$key_item["item"];
				$brand=$key_item["brand"];
				$qty=$key_item["quantity"];
				$unit_cost=$key_item["unit_cost"];				
				$sr_num=$key_item["sr_no"];	
				$color=$key_item["color"];	
				$branch=$key_item["branch_code"];
				$stock_id=$key_item["stock_id"];				
				
				$where2 ="po_num = '$po_no' and category = '$category' and brand = '$brand' and item = '$item'";
				
				
				$rows2 = '*';
				
				if($db->recordExist('purchase_order_details',$rows2,$where2) > 0){
					$where_x ="category = '$category' and brand = '$brand' and item = '$item'";
					$db->select("purchase_order_details","*",$where_x);
					$result = $db->getResult();
					
					
					$where_y ="category = '$category' and brand = '$brand' and item = '$item'";
					$rows_y = array('unit_cost' => $unit_cost ,'qty' => $qty,'sr_num' => $sr_num,'stock_id' => $stock_id);
					$db->update('purchase_order_details',$rows_y,$where_y); 
					
				
				}
				else{
					$rows ='po_num,category,brand,item,color,qty,unit_cost,branch,sr_num,stock_id';	
					$values = array($po_no,$category,$brand,$item,$color,$qty,$unit_cost,$branch,$sr_num,$stock_id);
					$db->insert('purchase_order_details',$values,$rows);
					
					
				}
				
				
			}		
				
			
		}
	
		print 'saved';		
	break;
	
	/* PURCHASE RETURN */
	
	case 'loadPurchaseReturns';
		$new_arr=array();
		$dataArray=array();
		$pr_num=$_REQUEST["pr_no"];
		$row = "*";
		$where="pr_num=$pr_num";
		$db->select('purchase_return_details',$row,$where);

		$result = $db->getResult();

		
		$i=0;
		foreach($result as $key){
			
			if($key["category"]==1){
				$item=$key["item"];
				$where_item="a.motor_id=$item and a.brand=b.id";
				$db->select('tbl_motorcycle a,tbl_manufacturer b','a.model,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["model"];
				}
				
				
			}
			else if($key["category"]==2){
				$item=$key["item"];
				$where_item="a.parts_id=$item and a.brand=b.id";
				$db->select('tbl_parts a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
				}
				
				
			}
			else if($key["category"]==3){
				$item=$key["item"];
				$where_item="a.promo_id=$item and a.brand=b.id";
				$db->select('tbl_promo a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
				}
				
				
			}
			else if($key["category"]==4){
				$item=$key["item"];
				$where_item="a.con_id=$item and a.brand=b.id";
				$db->select('tbl_consumables a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
				}
				
				
			}
			
			$new_arr[$i]=array(
			'id'=> $key["id"],	
			'branch'=> $key["branch"],
			'particulars'=> $brand." ".$item." ".$key["color"],
			'qty'=> $key["qty"],
			'unit_cost'=> $key["unit_cost"],
			);
			array_push($dataArray,$new_arr[$i]);
			
			
			$i++;	
			
		}
		
		echo '{"members":'.json_encode($dataArray).'}';
					
	break;
	
	case 'loadAllPR';
		$new_arr=array();
		$dataArray=array();
		$sort=$_REQUEST["sort"];
		$sortType=$_REQUEST["sortType"];
		
		if($sort=="total_amount"){
			$sort="a.id";
		}
		else {
			$sort = $_REQUEST['sort'];
		}
				
		$row = "a.*,b.supplier_name";
		$where="a.supplier=b.id";
		
		$order="$sort $sortType";
		$db->select('purchase_return a,tbl_supplier b',$row,$where,$order);

		$result = $db->getResult();

		
		$i=0;
		foreach($result as $key){
				$total_amount=0;
				$pr_no=$key["pr_num"];
				$where_item="pr_num=$pr_no";
				$db->select('purchase_return_details','*',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$amount=$key_item["unit_cost"]*$key_item["qty"];
					$total_amount=$total_amount+$amount;
				}
				
				
			
			
			$new_arr[$i]=array(
			'id'=> $key["id"],
			'pr_num'=> $key["pr_num"],	
			'supplier'=> $key["supplier_name"],
			'date'=> $key["date"],
			'terms'=> $key["terms"],
			'total_amount'=> $total_amount,
			);
			array_push($dataArray,$new_arr[$i]);
			
			
			$i++;	
			
		}
		
		if ($_REQUEST["sort"] == "total_amount") {
					
			$sortArray = array(); 

			foreach($dataArray as $total){ 
				foreach($total as $key=>$value){
					if(!isset($sortArray[$key])){
						$sortArray[$key] = array(); 
					} 
					$sortArray[$key][] = $value;
				} 
			}

			$orderby = "total_amount";
			if($_REQUEST["sortType"]=="ASC"){
				array_multisort($sortArray[$orderby],SORT_ASC,$dataArray);
			}
			else{
				array_multisort($sortArray[$orderby],SORT_DESC,$dataArray);
			}	
			
			
			
		}
		
		echo '{"members":'.json_encode($dataArray).'}';
					
	break;
	
	
	case 'searchPR';
		$new_arr=array();
		$dataArray=array();	
		$category=$_REQUEST["category"];
		$trimmed=trim($_REQUEST['inputsearch']);
		$where = "$category LIKE '%".$trimmed."%' and a.supplier=b.id ";		
		$row = "a.*,b.supplier_name";

		$db->select('purchase_return a,tbl_supplier b',$row,$where);

		$result = $db->getResult();

		
		$i=0;
		foreach($result as $key){
			$total_amount=0;
			$pr_no=$key["pr_num"];
			$where_item="pr_num=$po_no";
			$db->select('purchase_return_details','*',$where_item);
			
			$result_items = $db->getResult();
			
			foreach($result_items as $key_item){
				$amount=$key_item["unit_cost"]*$key_item["qty"];
				$total_amount=$total_amount+$amount;
			}
				
			$new_arr[$i]=array(
			'id'=> $key["id"],
			'pr_num'=> $key["pr
			
			_num"],	
			'supplier'=> $key["supplier_name"],
			'date'=> $key["date"],
			'terms'=> $key["terms"],
			'total_amount'=> $total_amount,
			);
			array_push($dataArray,$new_arr[$i]);
			
			
			$i++;		
		}
		
		echo '{"members":'.json_encode($dataArray).'}';
	break;
	
	case 'loadPRDetails';
		$new_arr=array();
		$dataArray=array();
		$pr_num=$_REQUEST["pr_no"];
		$row = "*";
		$where="pr_num=$pr_num";
		$db->select('purchase_return',$row,$where);

		$result = $db->getResult();
		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'deletePurchaseReturns';
		$val=$_REQUEST['id'];
		
		$db->delete("purchase_return_details","id='$val'");
		
		print 'deleted';
			
	break;
	
	case 'editPurchaseReturns';
		$val=$_REQUEST['id'];
		
		$items_array=array(
			'qty'=> $_REQUEST['qty'],
			'unit_cost'=> $_REQUEST['unit_cost'],
		);
				
		$where="id='$val'";
			
		$db->update("purchase_order_details",$items_array,$where);
		
		print "updated";
			
	break;
	
	case 'savePR';
	
		$pr_no=$_REQUEST["pr_no"];
		$date_created=$_REQUEST["date_created"];
		$remarks=$_REQUEST["remarks"];
		$supplier=$_REQUEST["supplier"];
		$branch_code=$_REQUEST["branch_code"];
		
		$where="pr_num='".$pr_no."'";
		$values = array('',$pr_no,$supplier,$date_created,$remarks,$branch_code);
		
	
		$db->select('purchase_return','*',$where);
		$result = $db->getResult();
		
		if(count($result) > 0){
			print("exist");
		}
		else{
			$db->insert("purchase_return",$values);
			print 'saved';
		}
					
	break;
	
	case 'loadPR';
	
		$pr_no=$_REQUEST["pr_no"];
		$row = "*";
		$where="pr_no=$pr_no";
		$db->select('purchase_return',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	
	
	case 'addPurchaseReturn';
		$brand=$_REQUEST["brand"];
		$item=$_REQUEST["item"];
		$serial_no=strtoupper($_REQUEST["serial_no"]);
		$color=strtoupper($_REQUEST["color"]);
		$dr_no=$_REQUEST["dr_no"];
		$status="ON HAND";
		
		$values = array('',$dr_no,$brand,$item,$serial_no,$color,$status);
		
		$where="item=$item and serial_no='".$serial_no."'";
		$db->select('stocks_promo','*',$where);
		$result = $db->getResult();
		
		if(count($result) > 0){
			print("exist");
		}
		else{
			$db->insert("stocks_promo",$values);
			print 'saved';
		}
	break;

	case 'deletePurchaseReturn';
		$val=$_REQUEST['id'];
		
		$db->delete("purchase_order_details","id='$val'");
		
		print 'deleted';
			
	break;
	
	case 'deleteAllPR';
		$val=$_REQUEST['id'];
		
		$row = "*";
		$where="id=$val";
		$db->select('purchase_order',$row,$where);

		$result = $db->getResult();

		foreach($result as $key){
			$po_no=$key["po_num"];
			
			$db->delete("purchase_order_details","po_num=$po_no");
			
		}
		
		$db->delete("purchase_order","id=$val");
		
		
		print 'deleted';
			
	break;
	
	
	}
}


?>