<html>
<title>MOTORCYCLE STOCKS</title>
</html>
<style>
.x:nth-child(odd) td{
	background:lightgray;
}

</style>

<?php
include('../database.php');  
$db = new Database();  
$db->connect(); 

	$dataArray=array();
	$pr_no=$_REQUEST["pr_no"];
	$row = "a.pr_num,a.date,a.remarks,b.supplier_name";
	$where="a.pr_num= '$pr_no' and a.supplier = b.id";

	$db->select('purchase_return a, tbl_supplier b',$row,$where);

	$result = $db->getResult();
	
	foreach($result as $key){		

		
		  $pr_no=$key["pr_num"];
		  $date=$key["date"];
		  $remarks=$key["remarks"];
		  $supplier_name=$key["supplier_name"];
	}
	
	
	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$pr_no = $_REQUEST['pr_no'];
	
	$where = "pr_num='$pr_no'";
	$db->select("purchase_return_details","*",$where);
	$result = $db->getResult();
	
	foreach($result as $key){
		 $category=$key["category"];
		  $pr_no=$key["pr_num"];
		 
		if($category == '1'){
		 
			
			$row = "a.category,a.id_return,a.color,b.brand,c.model,d.engine_no,d.frame_no,d.id,e.branch_name";
			$table = "purchase_return_details a,tbl_manufacturer b, tbl_motorcycle c, stocks_motors d,tbl_branch e";
			
			$where = "a.brand = b.id and a.item = c.motor_id and a.stock_id = d.id and  a.branch = e.branch_code and a.category = '$category' and a.pr_num = '$pr_no'  ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray=$result;
			
			
		 }
		 
		 else if($category == '2'){

			$row = "a.category,a.id_return,a.color,b.brand,c.item_code,d.serial_no,d.id,e.branch_name";
			$table = "purchase_return_details a,tbl_manufacturer b, tbl_parts c, stocks_parts d,tbl_branch e";
			
			$where = "a.brand = b.id and a.item = c.parts_id and a.stock_id = d.id and  a.branch = e.branch_code  and a.category = '$category' and a.pr_num = '$pr_no'  ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray2=$result;
		   
		 
		 }
		 else if($category == '3'){
			
			
			$row = "a.category,a.id_return,a.color,b.brand,c.item_code,d.serial_no,d.id,e.branch_name";
			$table = "purchase_return_details a,tbl_manufacturer b, tbl_promo c, stocks_promo d,tbl_branch e";
			
			$where = "a.brand = b.id and a.item = c.promo_id and a.stock_id = d.id and  a.branch = e.branch_code and a.category = '$category' and a.pr_num = '$pr_no'  ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray3=$result;
		  
		 }
		 else if($category == '4'){
			
			
			$row = "a.category,a.id_return,a.color,b.brand,c.item_code,d.serial_no,d.id,e.branch_name";
			$table = "purchase_return_details a,tbl_manufacturer b, tbl_promo c,stocks_consumables d,tbl_branch e";
			
			$where = "a.brand = b.id and a.item = c.promo_id and a.stock_id = d.id and  a.branch = e.branch_code and a.category = '$category' and a.pr_num = '$pr_no'  ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray4=$result;
		   
		 }
		
		$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4);
		
	}
	
	
	if(!empty($output)){
	
	
		$i=0;
		foreach($output as $key2){
			
			
			 if($key2['category'] =='1'){	
			 
			 $particulars = $key2["brand"]." - ".$key2["model"]." - ".$key2["color"];
			
			 $particulars = "MAKE & MODEL:".$key2["brand"].",".$key2["model"]."<br> ENGINE NO: ".$key2["engine_no"]."<br> FRAME NO:".$key2["frame_no"]."<br>COLOR:".$key2["color"];
			 
			 
			 
			 }else if ($key2['category'] =='3'){
			 
			 $particulars = "MAKE & MODEL:".$key2["brand"].",".$key2["item"]."<br> SERIAL NO: ".$key2["serial_no"]."<br>COLOR: ".$key2["color"];
			  
			 }else{
			 
			 $particulars = "MAKE & MODEL:".$key2["brand"].",".$key2["item"]."<br> SERIAL NO: ".$key2["serial_no"];
			 
			 }
			 
			$branch = $key2["branch_name"];
			
			
			$item_details_arr[$i]=array(
				'particulars'=> $particulars,
				'branch'=> $branch ,
			);
			$i++;
		}
	}
	
	


echo" 
	<div align='center' style='font-family:Calibri'>
	<table border=0 width='1000' cellpadding=2 cellspacing=0>
		
		<tr>
		<td><b>P.R. No. :</b> $pr_no</td>
		<td align='right' colspan=4><b>Date:</b> $date</td>
		</tr>
		
		<tr>
		<td><b>Supplier:</b> $supplier_name</td>
		</tr>
		
		<tr>
		<td colspan=5 align='center' style='padding:25px 0px 10px 0px;border-bottom:2px solid #000'>
		<b>PURCHASE RETURN DETAILS</b></td>
		</tr>
		
		<tr style='padding:20px 0px 10px 0px;border-bottom:2px solid #000'>
		<td align='center' width='20%' ><b>BRANCH</b></td>
		<td align='center' width='60%' ><b>PARTICULARS</b></td>
		</tr>
		
		<tr>
		<td colspan=5 style='padding:0px 0px 5px 0px;border-bottom:2px solid #000'>
		</tr>";
		
		
		if(count($item_details_arr)>0){
		

		 foreach($item_details_arr as $keyx){
			
			echo "<tr class='x' >
			<td align='center' valign='top' >".$keyx['branch']."</td>
			<td align='center'  >".strtoUpper($keyx['particulars'])."</td>
			</tr>";	
			
			
			
		
			
		 }
	}
	else{
		echo "<tr align='center'><td colspan=5  style='padding:20px 0px 5px 0px;'>*** NO ITEMS TO DISPLAY ***</td></tr>";
	}
	echo "<tr><td colspan=5 align='center' style='padding:0px 0px 5px 0px;border-bottom:2px solid #000'></td></tr>";
	
	
	
		echo "<tr><td colspan=4 align='left'  ><b>*REMARKS:</b> &nbsp;" .$remarks."</td></tr>";
		
	
	echo "</table></div>";		
?>