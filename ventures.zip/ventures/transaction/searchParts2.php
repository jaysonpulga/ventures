<html>
<title>Sales</title>
<head>
<?php
include('../database.php');  
$db = new Database();  
$db->connect();
?>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
				
			<div id="sample" style="text-align:left;padding:10px; margin-left:15px;" >
			
				
					<div  class="contents" style="border:0px solid #000; width:460px" cellspacing="0">	
					<input type="hidden" id="table" name="table" value="<?php echo $_REQUEST['table']; ?>" />
					<input type="hidden" id="cat" name="cat" value="<?php echo $_REQUEST['cat']; ?>" />
					<input type="hidden" id="dr_no" name="dr_no" value="<?php echo $_REQUEST['dr_no']; ?>" />
					
								<div align="center" style="padding-bottom:10px;" >
									<span>
										<select class="select_to" style="width:250px;" id = "model" name="model" onchange = "changeCategory(this.value)">

										</select>
									</span>
								</div>
								
								<div align="center" style="padding-bottom:20px;" >
									<span>
								<select class="select_to" style="width:250px"  id ="item" name="item" onchange = "change(this.value)" >
										</select>
									</span>
								</div>
					
							<table  align="center" id="table">
							<thead></thead>	
							<tbody id="alldata"></tbody>
							</table>
					</div>
					<div align="center" style="margin-top:50px">
						<span>
							<input type="button" value="ADD" onclick="checkbox()">
							<input type="button" value="CANCEL" onclick="Cancel()">
						</span>
					</div>
			</div>
		<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		select_brand();
		header();
	});
	
	
	var cat = $('#cat').val();
	var table = $('#table').val();
	var dr_no = $('#dr_no').val();
	
	function add_item(){
	
			$("#new_items").attr("title",val );
			$("#item_dialog").attr('src','../transaction/newTransfer.php?ref_no=');
			$("#new_items").dialog({
				width:510,
				height:450,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
		
			
	}
	
	
	function select_brand(){
	event.preventDefault();

	var url="function_transaction.php?request=ajax&action=load_stock&table="+table;
	var counter=1;

		$.getJSON(url,function(data){
	
		$("#model").empty();
		
			$("#model").append("<option  value=''>--Select Brand--</option>");
			$.each(data.members, function(i,res){
						
			$("#model").append("<option value='"+res.id+"' >"+res.brand+"</option>");
			
			counter++;
				
			});
			if (counter <= 1){
			$("#model").append("<option>NO RECORD</option>");
			}
		});	
	
	}
	
	
	function changeCategory(brand){
		select_model(brand);		
	}
	
	
	function select_model(brand){

	event.preventDefault();
	
	if(table == "stocks_motors"){
	var table2 = "tbl_motorcycle";
	}
	else if(table == "stocks_parts"){
	var table2 = "tbl_parts";
	}
	else if(table == "stocks_promo"){
	var table2 = "tbl_promo";
	}
	else if(table == "stocks_consumables"){
	var table2 = "tbl_consumables";
	}
	

	var url="function_transaction.php?request=ajax&action=load_select_model&id="+brand+"&table="+table+"&table2="+table2;
	var counter=1;

		$.getJSON(url,function(data){
	
		$("#item").empty();
		
			$.each(data.members, function(i,res){
				
					if(res.parts_id){
						var id = res.parts_id;
						$("#item").append("<option value='"+id+"' >"+res.item_code+"</option>");
					}
					else if(res.promo_id){
						var id = res.promo_id;
						$("#item").append("<option value='"+id+"' >"+res.item_code+"</option>");
					}
					else if(res.con_id){
						var id = res.con_id;
						$("#item").append("<option value='"+id+"' >"+res.item_code+"</option>");
					}
					else if(res.motor_id){
						var id = res.motor_id;
						$("#item").append("<option value='"+id+"' >"+res.model+"</option>");
					}
					counter++;
				
			});
				var item = $("#item").val();
				load_item(item);
			
			
			if (counter <= 1){
			$("#item").append("<option>NO RECORD</option>");
			}
		});	
				
	}
	
	function change(item){
	load_item(item)
	}
	
	function header(){
		var container2=$("#table > thead");
		
		if(table == "stocks_motors"){
	
			container2.append("<tr><th></th><th>ENGINE#</th><th>FRAME#</th><th>COLOR</th></tr>");
		}
		
		else if(table == "stocks_parts"){
		
			container2.append("<tr><th></th><th>SERIAL NUMBER</th><th>TOTAL ON HAND</th><th>QTY</th></tr>");
						
		}
						
		else if(table == "stocks_promo"){
		
			container2.append("<tr><th></th><th>SERIAL NUMBER</th><th>COLOR</th></tr>");
						
		}
						
		else if(table == "stocks_consumables"){
						
			container2.append("<tr><th></th><th>SERIAL NUMBER</th><th>TOTAL ON HAND</th><th>QTY</th></tr>");
		}
	
	}
	
	
	function load_item(item){
	event.preventDefault();
	
	var url="function_transaction.php?request=ajax&action=load_item&id="+item+"&table="+table;
	var counter=1;
	var container=$("#table > tbody");
	

		$.getJSON(url,function(data){
	
		container.empty();
		
			$.each(data.members, function(i,res){
				
				
						if(table == "stocks_motors"){
						
						
						container.append("<tr class='x' id='record"+res.id+"' ><td><input type='checkbox' name='chk[]' class='checkboxrecord' value='"+res.id+"'  /></td><td align='center'>"+res.engine_no+"</td><td align='center'>"+res.frame_no+"</td><td align='center'>"+res.color+"</td></tr>");
						
						}
						
						else if(table == "stocks_parts"){
						
								if(res.remaining == 0){
										container.append("<tr class='x' id='record"+res.id+"' ><td></td><td align='center'>"+res.serial_no+"</td><td align='center'>"+res.remaining+"</td><td align='center'><input type='text' id='quantity"+res.serial_no+"' name='quantity"+res.serial_no+"'style='width:60px;margin-left:1px;text-align:center;' disabled='disabled' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\"></td></tr>");
								}else{
							
									container.append("<tr class='x' id='record"+res.id+"' ><td><input type='checkbox'  id='checkmo"+res.id+"' name='chk[]' class='checkboxrecord' value='"+res.serial_no+"' onclick='checkmo("+res.id+")'   /></td><td align='center'>"+res.serial_no+"</td><td align='center'>"+res.remaining+"</td><td align='center'><input type='text' disabled id='quantity"+res.serial_no+"' class='textbox"+res.id+"' name='quantity"+res.serial_no+"'style='width:60px;margin-left:1px;text-align:center;' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, ''),myFunction("+res.id+")\" ></td></tr>");
								}
						
						
						
						}
						
						else if(table == "stocks_promo"){
						
						container.append("<tr class='x' id='record"+res.id+"' ><td><input type='checkbox' name='chk[]' class='checkboxrecord' value='"+res.id+"' /></td><td align='center'>"+res.serial_no+"</td><td align='center'>"+res.color+"</td></tr>");
						
						}
						
						else if(table == "stocks_consumables"){
								if(res.remaining == 0){
						
								container.append("<tr class='x' id='record"+res.id+"' ><td></td><td align='center'>"+res.serial_no+"</td><td align='center'>"+res.remaining+"</td><td align='center'><input type='text' disabled='disabled' id='quantity"+res.serial_no+"' name='quantity"+res.serial_no+"'style='width:60px;margin-left:1px;text-align:center;' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\"></td></tr>");
								
								
								}else{
								
								container.append("<tr class='x' id='record"+res.id+"' ><td><input type='checkbox' name='chk[]' class='checkboxrecord' value='"+res.serial_no+"' /></td><td align='center'>"+res.serial_no+"</td><td align='center'>"+res.remaining+"</td><td align='center'><input type='text' id='quantity"+res.serial_no+"' name='quantity"+res.serial_no+"'style='width:60px;margin-left:1px;text-align:center;' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\"></td></tr>");
								
								
								
								}
						
						
						}
					counter++;
				
			});
				
			
			
			if (counter <= 1){
			container.append("<tr id = 'noItems'><th colspan = '13' align = 'center'> No Items on record! </th></tr>");
			}
		});
	

	}
	
	function checkmo(id) {
			
				var checked = $("#checkmo"+id).is(":checked");
				
				if(checked == true){
					$('.textbox'+id).attr("disabled", false);
					$('.textbox'+id).focus();
				}else{
					$('.textbox'+id).attr("value", "");
					$('.textbox'+id).attr("disabled", true);
				} 
	} 


	
	
	function checkbox(){
	
	var Checkarray =[];
	  
	 var checkbox = $(".checkboxrecord");
	  $.each(checkbox, function(key,val){
	  
	  if($(this).prop("checked")){
	    Checkarray.push($(this).attr('value'));
	  }
	  
	  });
	  
	  var quantity = $('#quantity'+Checkarray).val();
	  var errormsg="Please complete the following fields: \n";
	var emsg= errormsg.length;
	  
	  if(quantity == ""){
				errormsg+="-Quantity \n";
			}
	  
		if(errormsg.length== emsg){
		  if(Checkarray.length > 0){
		  
			$.ajax({
				url: 'function_transaction.php',
				data: {'request' : 'ajax', 'action' : 'add_item' , 'array' : Checkarray,'table':table,'dr_no':dr_no,'quantity':quantity},
				
				beforeSend: function(){
													
						}, success : function(returnData){
															
							if(returnData == "uhryt"){
							
								var actions="add";
								window.parent.closeIframe(actions);
	
								
							}
															
						}, error: function(){}
				});
		  
		  
		  }else {
				jAlert("Please make a selection","Alert Dialog");
			}
		}else{
			jAlert(errormsg);
			event.preventDefault();
		}
	
	}
	
	function myFunction(id){
	
		
		
		  var Checkarray =[];
		  
		 var checkbox = $(".checkboxrecord");
		  $.each(checkbox, function(key,val){
		  
		  if($(this).prop("checked")){
			Checkarray.push($(this).attr('value'));
		  }
	  
		});
		var quantity = $('#quantity'+Checkarray).val();
	  if(Checkarray !="" && id !=""){
				var qty = parseInt(quantity);
				
				var url="function_transaction.php?request=ajax&action=check_data&table="+table+"&array="+Checkarray;
				
					$.getJSON(url,function(data){
						$.each(data.members, function(i,res){
							var val = res.remaining;
							var val2 = parseInt(val);
							
								if(qty > val2){
									jAlert("Remaning Balance:"+ val);
									$('#quantity'+Checkarray).val(val);
									return false;
								}
							
						});	
					});
	}else{
		jAlert("Please make a selection","Alert Dialog");
	}
		
				
	}
	
	function Cancel(){
		var action = "cancel";
	window.parent.closeIframe(action);
	}
	
	</script>
	
</body>
</html>