<html>
<title>COLLECTION</title>
</html>

<?php
include('../database.php');  
$db = new Database();  
$db->connect(); 

	$dataArray=array();
	$type="1";
	$sortType="DESC";
	$sort="a.id";
	
	$or_no=$_REQUEST['or_no'];
	
	$rows = "a.*, CONCAT(b.last_name,', ',b.first_name,' ',b.middle_name) as customer_name,c.branch_name" ;
	$where = "or_no= '$or_no' AND a.customer_id = b.id AND a.branch_code = c.branch_code";
	$db->select('collections a, tbl_customer b, tbl_branch c',$rows,$where); 
	$result = $db->getResult();
	
	
	foreach($result as $key){		

		
		  $or_no=$key["or_no"];
		  $date=$key["date"];
		  $customer_name=$key["customer_name"];
		  $branch_name=$key["branch_name"];
		  $address=$key["address"];
	}
	
	
	
	$where2 = "a.or_no= '$or_no' AND a.customer_id = b.customer_name AND b.loan_type_id = c.id ";
	$db->select('collection_loan a,tbl_ledger b,tbl_loan c',"a.*,b.terms,b.amount_loan",$where2); 
	$result = $db->getResult();
	
	foreach($result as $key2){
			$item_details_arr[$i]=array(
				'dues'=> $key2["dues"],
				'penalty'=> $key2["penalty_discount"],
				'rebate'=> $key2["rebate"],
				'discount'=> $key2["discount"],
				'amount_loan'=> $key2["amount_loan"],
				'terms'=> $key2["terms"],
			);
			array_push($dataArray,$item_details_arr[$i]);
			$i++;
	}

	echo" 
	<div align='center' style='font-family:Calibri'>
	<table border=0 width='1000' cellpadding=2 cellspacing=0>
		<tr><td><b>O.R. No.:</b> $or_no</td><td align='right' colspan=3><b>Date:</b> $date</td></tr>
		<tr><td colspan=2><b>Customer Name:</b> $customer_name</td><td align='right' colspan=2><b>Branch:</b> $branch_name</td></tr>
		<tr><td colspan=3 ><b>Address:</b> $address</td></tr>
		<tr><td colspan=5 align='center' style='padding:20px 0px 10px 0px;border-bottom:2px solid #000'><b>LOAN COLLECTIONS</b></td></tr>
		<tr><td style='border-bottom:2px solid #000' align='center' width='25%'><b>UNIT</b></td><td colspan=2 align='center' style='border-bottom:2px solid #000'><b>PARTICULARS</b></td><td width='15%' align='center' style='border-bottom:2px solid #000'><b>AMOUNT</b></td></tr>";
	
	$total_amout = 0;
	$vat = 0;
	$amount_due = 0;
	if(count($dataArray)>0){
	
								
	
	
	
		foreach($dataArray as $key){
		
								$principal = $key['amount_loan'] / $key['terms'];
								
								$interest = $key['dues'] - $principal;
		
				
			echo "<tr align='center' class='x'><td>1</td><td colspan=2>MONTHLY DUES:</td><td>".number_format($key['dues'],2,".",",")."</td></tr>";
			echo "<tr align='center' class='x'><td></td><td  colspan=2> <p style='padding-left:150px'>PRINCIPAL:</p></td><td>".number_format($principal,2,".",",")."</td></tr>";
			echo "<tr align='center' class='x'><td></td><td   colspan=2><p style='padding-left:150px'>INTEREST:</p></td><td>".number_format($interest,2,".",",")."</td></tr>";
			
			echo "<tr align='center' class='x'><td></td><td colspan=2>PENALTY:</td><td>".number_format($key['penalty'],2,".",",")."</td></tr>";
			echo "<tr align='center' class='x'><td></td><td colspan=2>REBATE:</td><td>".number_format($key['rebate'],2,".",",")."</td></tr>";
			echo "<tr align='center' class='x'><td></td><td colspan=2>DISCOUNT:</td><td>".number_format($key['discount'],2,".",",")."</td></tr>";
			
			if($key['penalty'] > 0){
					$total_amout += $key['dues'] + $key['penalty'] - $key['discount'] ;
			}else{
					$total_amout += $key['dues'] + $key['rebate'] - $key['discount'];
			}
			
			
			
			
								
			$vat = $total_amout*0.12;
			$amount_due = $total_amout-$vat;
		
		}
	}
	else{
		echo "<tr align='center'><td colspan=4  style='padding:20px 0px 0px 0px;'>*** NO ITEMS TO DISPLAY ***</td></tr>";
	}
	echo "<tr><td colspan=5 align='center' style='padding:10px 0px 10px 0px;border-bottom:2px solid #000'></td></tr>";
	echo "<tr><td width='25%'></td><td colspan=2  align='right' style='padding:10px 0px 3px 0px;'><b>AMOUNT DUE:</b></td><td width='15%' align='center' >".number_format($total_amout,2,".",",")."</td></tr>";
	echo "<tr><td width='25%'></td><td  colspan=2 align='right' style='padding:3px 0px 3px 0px;'><b>VAT_TAX:</b></td><td width='15%' align='center' >".number_format($vat,2,".",",")."</td></tr>";
	echo "<tr><td width='25%'></td><td colspan=2  align='right' style='padding:3px 0px 3px 0px;'><b>TOTAL SALES:</b></td><td width='15%' align='center' >".number_format($amount_due,2,".",",")."</td></tr>";
	echo "</table></div>";	
?>