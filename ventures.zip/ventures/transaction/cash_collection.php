<?php
session_start();

if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION["username"];
$branch_name = $_SESSION["branch_name"];
$branch_id = $_SESSION['branch_id'];
?>
<html>
<title>Collection</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
	<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:800px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>CASH PAYMENTS</h2><hr></label>
								<input type="hidden" id = "branch_id" value = "<?php echo $branch_id; ?>" >
								<input type="hidden" id = "branch_name" value = "<?php echo $branch_name; ?>" >
							</span>
						</div>
						<div>
							<span>
							
							<input type="hidden" id = "or_no" name="or_no" value="<?php echo $_REQUEST['or_no'] ?>">
								<label>O.R No.:</label>
								<input type="text" id = "txtor_no" readonly style="margin-left:60px; width:100px">
							</span>
							<span>
								<label style="margin-left:330px">Date:</label>
								<input type="date" id = "txtdate" style="margin-left:41px">
							</span>
						</div>
						<div style="margin-top:10px">
							<span>
								<input type = "hidden" id = "txtcusid">
								<input type="hidden" id = "address" style = "margin-left:7px; text-align:center; width:250px;">
								
								<label>Customer Name:</label>
								<input type="text" id = "txtcusname" style = "margin-left:7px; text-align:center; width:250px;">
								<a href="#"  style="width:30px;" onclick="search_customer();"><img src="" id="search" valign="bottom"></a>
								<a href="#"  style="width:30px;" onclick="new_customer();"><img src="" id="new" valign="bottom"></a>
								
							</span>
							<span>
								<label style="margin-left:110px">BRANCH:</label>
								<select id="txtbranch" name="txtbranch" style="margin-left:20px">
								</select>
							</span>
						</div>
						
						
						
						
						<div style="margin-top:10px">
							<span>
								<label>TYPE OF PAYMENT:</label>
										<span>
												<select id="txtpayment" name="txtpayment" style="margin-left:20px">
												<option value="">-- SELECT --</option>
												<option value='invoice'>INVOICE</option>
												<option value='items'>ITEMS</option>
												<option value='others'>OTHERS</option>
												</select>
										</span>
							</span>
							
						</div>
						
						
						<div style="margin-top:10px">
									<span>
										<label><h3>Search Item</h3></label>
									</span>
						</div>
						
						<div style="margin-bottom:15px" >
									<span id="append">
										
									</span>
									
						</div>
						
						
						
						<div  class="contents" style="border:0px solid #000; width:800px;margin-top:10px" cellspacing="0">
							<h3>CASH COLLECTION</h3>
							<table id = "collection_list">
								<thead align = "center">
								<tr>
								<th>TYPE</th><th>QTY</th><th style="width:45%">PARTICULARS</th><th>UNIT PRICE</th><th>AMOUNT</th><th colspan = "2">ACTION</th>
								</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
						
						
						<div align = "right" style = "margin-top:10px; font-weight:bold;">
							<span>
								<label>AMOUNT DUE: </label>
								<input type = "text" id = "txtdue"  style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>VAT: </label>
								<input type = "text" id = "txtvat" style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>TOTAL: </label>
								<input type = "text" id = "txttotal" style = "text-align: right;" disabled>
							</span>
						</div>
						
						
						
						
						<div align = "center" style = "margin-top: 20px;">
							<span>
								<input type = "button" id = "btnadd" value = "UPDATE" onclick = "update();">
								<input type = "button" id = "btncancel" value = "PRINT" onclick="window.open('print_cash_collection.php?or_no=<?php echo $_REQUEST['or_no']; ?>','_blank')">
								<input type = "button" id = "btncancel" value = "CANCEL" onclick = "window.location='collections.php?menu=transaction'">
							</span>
						</div>
						
						<div id="customer_items" style="display:none;">
							<iframe id="item_dialog" width="954" height="595" style="border:none"></iframe>
						</div>
						
						 <div id="new_items2" title="" style="display:none;">
								<iframe align="center" id="item_dialog2" width="540" height="400" style="border:none"></iframe>
						</div> 
						
						<div id="new_items3" title="" style="display:none;">
								<iframe align="center" id="item_dialog3" width="750" height="385" style="border:none"></iframe>
						</div>
						
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		loadData();
		load_cash_collection();
		//load_payment_terms();
		
	
	
	});
	
	var or_no = $("#or_no").val();
	var branch_id = $("#branch_id").val();
	var branch_name = $("#branch_name").val();
	var txtcusid = $("#txtcusid").val();
	
	
	$("#txtpayment").change(function() {
			var txtpayment=$("#txtpayment").val();
			var txtcusid = $("#txtcusid").val();
			
			$("#append").empty();
			load_append(txtpayment);
			
			loadinvoice_number(txtcusid)
			
	});
	
	
	function  load_append(txtpayment){
	
		if(txtpayment == "items"){
			$("#append").append("<select id = 'category' name='category' onchange = 'changeCategory(this.value)'><option value='motorcycle'>MOTORCYCLE</option><option value='parts'>PARTS</option><option value='promo item'>PROMO ITEM</option><option value='consumables'>CONSUMABLES</option></select><input type='button' value='SEARCH' onclick='add_item();'>");
		}else if(txtpayment == "invoice"){
			
				$("#append").append("<select id = 'inv_number' name='inv_number' ></select><input type='button' value='SEARCH' onclick='add_cash_invoice();'>");
		
		}
		
	}
	
	
	function load_cash_collection(){
	
	var url="function_transaction.php?request=ajax&action=load_cash_collection&or_no="+or_no ;
	var counter=1;
	var x = 1,total_sale =0,vat=0,amount_due=0;

		$.getJSON(url,function(data){
		
			$("#collection_list > tbody").empty();
					$.each(data.members, function(i,res){
				
				if(res.category == '1'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.model+"<br> ENGINE NO: "+res.engine_no+"<br> FRAME NO:"+res.frame_no+"<br>COLOR:"+res.color;
				
				}
				
				else if (res.category == '3'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no+"<br>COLOR: "+res.color;
				
				}
				
				else{
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no;
				
				}
				
				var cate = res.qty;
				
				var total_amount = parseFloat(cate) * parseFloat(res.amount);
				
				 total_sale += parseFloat(res.amount) *  parseFloat(cate);
				  vat = total_sale*0.12;
				  amount_due = total_sale-vat;
			
								$("#txtvat").val(FormatNumberBy3((Math.round(vat)).toFixed(2)));
								 $("#txtdue").val(FormatNumberBy3((Math.round(total_sale)).toFixed(2))); 
								 $("#txttotal").val(FormatNumberBy3((Math.round(amount_due)).toFixed(2))); 
			
							if(res.type == 'ITEMS'){
							
							var typex = res.type ;
							
							}else if (res.type == 'INVOICE'){
								
								var typex = res.type+":"+res.invoice_no;
							}
							
							
				$("#collection_list > tbody").append("<tr class='x' id='record"+res.cash_id+"'><td align='center'>"+typex+"</td><td align='center'>"+cate+"</td><td align='center'>"+particulars+"</td><td><input type = 'text' style = 'width:100px; text-align:right;' id = 'amount"+res.cash_id+"' value = "+FormatNumberBy3((Math.round(res.amount)).toFixed(2))+" onkeyup=javascript:this.value = this.value.replace(/[^0-9]/, '')></td><td style='text-align:right'>"+FormatNumberBy3((Math.round(total_amount)).toFixed(2))+"</td><td align='center'><a href='#' alt='Update' title='edit' class='edit' onclick=\"edit_item('"+res.cash_id+"')\"></a></td><td align='center'><a href='#' alt='Update' title='delete' class='delete' onclick=\"delete_item('"+res.cash_id+" ','"+res.stock_id+" ','"+res.category+"','"+res.qty+"');\"></a></td></tr>");
									
						 counter++;
						 
			});	
		
			if (counter <= 1){
				$("#collection_list > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Items on record! </th></tr>");
			}
					
					
		});
	

	}
	
	
	
	function loadinvoice_number(txtcusid){

			
			 var url="function_transaction.php?request=ajax&action=loadinvoice_number&txtcusid="+txtcusid;
			var counter=1;
		
			$.getJSON(url,function(data){
					
					$("#inv_number").append("<option value=''>--Select Invoice--</option>");
					
				$.each(data.members, function(i,res){
					
					$("#inv_number").append("<option value='"+res.invoice_no+"'>"+res.invoice_no+"</option>");
				counter++;
				
				});	
				
				if (counter <= 1){
				$("#inv_number").append("<option value=''>NO RECORD</option>");
			}
				
			});
			
	}
	
	
	
	function loadData(){

			
			  var url="function_transaction.php?request=ajax&action=view_or_collection&or_no="+or_no;
			var counter=1;
		
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){
					var name = res.last_name+", "+res.first_name+" "+res.middle_name;
					$('#txtor_no').val(res.or_no);
					$('#txtdate').val(res.date);
					$('#txtcusname').val(name);
					$('#address').val(res.address);
					$('#txtcusid').val(res.customer_id);
					loadBranch(res.branch_code);
				
				});	
			});
			
	}
	
	
	function search_customer(){
			$("#customer_items").attr("title","SEARCH CUSTOMER");
			$("#item_dialog").attr('src','customer_name.php');
			$("#customer_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	function new_customer() {
			$("#customer_items").attr("title","NEW CUSTOMER");
			$("#item_dialog").attr('src','newCustomer.php');
			$("#customer_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	function closeIframe(id,name,address,branch_code) {
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#address").val(address);
		loadBranch(branch_code);
		saveChanges(id,address,branch_code)
	}
	
	function closeIframeNew(id,name,address,branch_code) {
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#address").val(address);
		loadBranch(branch_code);
		saveChanges(id,address,branch_code)
	}
	
	
	function closeIframe2(actions)
	{
		if(actions=="add"){
			jAlert("Item Added","Alert Dialog");
		}
		if(actions=="cancel"){
		}
		$('#new_items2').dialog('close');
		
		return false;
	}
	
	function loadBranch(branch_code){
		var count=0, x=0;
		var select = $("#txtbranch");

		$.ajax({
				url:"functions.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					
					
					
					if(reply.length > 0){
						select.empty();
								
							$.each(reply, function(i,res){
							 count++;
							 
							if(res.branch_code == branch_code ){
							select.append("<option  value='"+res.branch_code+"' selected='selected' >"+res.branch_code+"</option>");
							}	else{
							select.append("<option  value='"+res.branch_code+"'>"+res.branch_code+"</option>");
							}	
								
																		
							});
			
					}
				}
			});
	}
	

	
	function saveChanges(id,address,branch_code){
	
		jConfirm('Do you want to save this Changes?','Confirmation Dialog',function(e){	
			
		if(e){
			
			
			
			$.ajax({
				url: "function_transaction.php",
				data:{"request":"ajax","action":"updateORnumber","id":id,"address":address,"branch_code":branch_code,"or_no":or_no},
				success: function(reply){
					if(reply =="saved"){
						jAlert("Successfully Saved");
						loadData();
						load_cash_collection();
						
					}
				}
			});
			
	
  		}
		
		});
	
	}
	
	
	function update() {
		var txtor_no=$("#txtor_no").val();	
		var date_issued=$("#txtdate").val();	
		var customer_id=$("#txtcusid").val();
		var txtbranch=$("#txtbranch").val();	
		var address=$("#address").val();
		var txtpayment=$("#txtpayment").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(txtor_no == ""){
			errormsg+="- Input O.R. No.\n";
		}
		if(date_issued == ""){
			errormsg+="- Input Date Issued.\n";
		}
		if(customer_id == ""){
			errormsg+="- Input Customer Name.\n";
		}
		if(txtbranch == ""){
			errormsg+="- Input Branch.\n";
		}
		
		if(errormsg.length==emsg){
			$.ajax({
				url: "function_transaction.php",
				data:{"request":"ajax","action":"UPDATE_CASH_RECORD","txtor_no":txtor_no,"date_issued":date_issued,"customer_id":customer_id,"txtbranch":txtbranch,"address":address,"txtpayment":txtpayment},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Successfully Updated!", "Alert Dialog");
								loadData();
								load_cash_collection();
								//load_payment_terms()
								
						}else{
							alert('Error');
							event.preventDefault();
						}
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		
	}
	
	function add_item(){
	
	var val = $('#category').val();
	
	if(val =="motorcycle"){
	var cat = 1;
	var table = "stocks_motors";
	}
	else if(val =="parts"){
	var cat = 2;
	var table = "stocks_parts";
	}
	else if(val =="promo item"){
	var cat = 3;
	var table = "stocks_promo";
	}
	else if(val =="consumables"){
	var cat = 4;
	var table = "stocks_consumables";
	}
	
	
			$("#new_items2").attr("title",val+"-"+branch_name);
			$("#item_dialog2").attr('src','../transaction/add_cash_collection.php?table='+table+"&cat="+cat+"&or_no="+or_no+"&branch_id="+branch_id);
			$("#new_items2").dialog({
				width:540,
				height:450,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
		
			
	}
	
	
	
	
	
	function add_cash_invoice(){
	
	var txtcusid = $("#txtcusid").val();
	var inv_number = $("#inv_number").val();
	var or_no = $("#or_no").val();
	

			$("#new_items3").attr("title","INVOICE -"+branch_name);
			$("#item_dialog3").attr('src','../transaction/cash_invoice.php?txtcusid='+txtcusid+'&inv_number='+inv_number+'&or_no='+or_no);
			$("#new_items3").dialog({
				width: 760,
				height: 420,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
		
			
	}
	
	
	
	
	
	
	
	function edit_item(id){
	event.preventDefault();

	var	amount = parseFloat($("#amount"+id).val().replace(/,/g, ''));


		var errormsg="Please complete the following fields: \n",emsg= errormsg.length;
		
		if($("#amount"+id).val==""){
			errormsg+="- Amount \n";
		}
		if(errormsg.length==emsg){
			 $.ajax({
				url: "function_transaction.php",
				data:{"request":"ajax","action":"edit_amount","amount":amount,"id":id},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Successfully Updated!", "Alert Dialog");
							load_cash_collection();
						}
						else{
							alert('Sorry Error');
							event.preventDefault();
						}
				}
			}); 
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		

	}
	
	
	function delete_item(cash_id,stock_id,category,qty){
	
			if(category == 1){
			var tablex = "stocks_motors";
			}
			else if(category == 2 ){
			var tablex = "stocks_parts";
			}
			else if(category == 3 ){
			var tablex = "stocks_promo";
			}
			else if(category == 4){
			var tablex = "stocks_consumables";
			}
			
		
	
		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
		if(e){
			$.ajax({
				url: "function_transaction.php",
				data:{"request":"ajax","action":"delete_cash","cash_id":cash_id,"stock_id":stock_id,"tablex":tablex,"quantity":qty},
				success: function(reply){
						jAlert("successfully Deleted");
						load_cash_collection();
						//load_payment_terms();
				}
			});
				
		
		
	
  		}
		
		});
	
	
	}
	
	
		function closeIframe3(actions){
		if(actions=="add"){
			jAlert("Successfully Added");
			load_cash_collection();
		}
		else if(actions=="edit"){
			jAlert("Successfully Updated");
		}
		else if(actions=="cancel"){
			$('#new_items3').dialog('close');
		}
		$('#new_items3').dialog('close');
		
		
		return false;
	}
	

	</script>