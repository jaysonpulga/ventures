<?php
session_start();
?>
<html>
<title>Collection</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
	<script src="../js/FormatNUmberBy3.js" type="text/javascript"></script>
	<script src="../js/Format.js" type="text/javascript"></script>

</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:800px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>LOAN COLLECTION</h2><hr></label>
							</span>
						</div>
						<div>
							<span>
							<input type="hidden" id = "or_no" name="or_no" value="<?php echo $_REQUEST['or_no'] ?>">
								<label>O.R No.:</label>
								<input type="text" id = "txtor_no" readonly style="margin-left:60px; width:100px" maxlength = "3">
							</span>
							<span>
								<label style="margin-left:330px">Date:</label>
								<input type="date" id = "txtdate" style="margin-left:41px">
								<input type="hidden" id = "compare_date" style=" width:100px; margin-left:20px;text-align:center;" readonly>
								
							</span>
						</div>
						
						<div style="margin-top:10px">
						
							<span>
								<input type = "hidden" id = "txtcusid">
								<label>Account Number:</label>
								<input type="text" readonly id = "txtaccount" style = "margin-left:7px; text-align:center; width:130px;">
							</span>
							<span>
								<label style="margin-left:25px">Terms:</label>
								<input type="text" readonly id = "txtterms" style = "margin-left:7px; text-align:center; width:70px;">
							</span>
							
							<span>
								<label style="margin-left:137px">Date Due:</label>
								<input type="hidden" id = "penalty_interest" name="penalty_interest">
								<input type="text" id = "datedue" style=" width:100px; margin-left:20px;text-align:center;" readonly>
								
								
							</span>
							
							
						</div>
						
						
						
						
						
						<div style="margin-top:10px">
						
							<span>
								<input type = "hidden" id = "txtcusid">
								<label>Customer Name:</label>
								<input type="text" readonly id = "txtcusname" style = "margin-left:7px; text-align:center; width:285px;">
								<!--<a href="#"  style="width:30px;" onclick="search_customer();"><img src="" id="search" valign="bottom"></a>-->
								
							</span>
							<span>
								<label style="margin-left:147px">BRANCH:</label>
								<select disabled id="txtbranch" name="txtbranch" style="margin-left:20px">
								</select>
							</span>
						</div>
						
						
						<div style="margin-top:10px">
							<span>
								<label>Address:</label>
								<input type="text" readonly id = "txtaddress" style=" width:380px; margin-left:55px">
							</span>
							
							
							
						</div>
						
						<div style="margin-top:10px">
							<span>
								<label>TYPE OF LOAN:</label>
								<input type="text" id = "typeofloan" style=" width:150px; margin-left:19px" readonly>
							</span>
							
						</div>
						
						<div style="margin-top:10px">
							<span>
								<input type = "button" id = "btnadd" value = "ADD DISCOUNT" style=" width:150px;" onclick = "discount_add();">
								<input type = "button" id = "btnadd" value = "WAIVED PENALTY"  style=" width:150px;" onclick = "penalty_add();">
								
							</span>
							
						</div>
						
						<div  class="contents" style="border:0px solid #000; width:800px;margin-top:10px" cellspacing="0">
							<h3>LOAN COLLECTION</h3>
							<table id='loan_collection_list'>
								<thead align = "center">
									<tr>
										<th>UNIT</th><th style="width:45%">PARTICULARS</th><th>AMOUNT</th><th>ACTION</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
						
						
						<div align = "right" style = "margin-top:10px; font-weight:bold;">
							<span>
								<label>AMOUNT DUE: </label>
								<input type = "text" id = "txtdue"  style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>VAT_TAX: </label>
								<input type = "text" id = "txtvat" style = "text-align:right;" disabled>
							</span>
						</div>
						<div align = "right" style = "font-weight:bold;">
							<span>
								<label>TOTAL SALES: </label>
								<input type = "text" id = "total_sales" style = "text-align: right;" disabled>
							</span>
						</div>
						
						
						
						
						<div align = "center" style = "margin-top: 20px;">
							<span>
								<input type = "button" id = "btnadd" value = "UPDATE" onclick = "SAME_UPDATE();">
								<input type = "button" id = "btncancel" value = "PRINT" onclick="window.open('print_loan_Collection.php?or_no=<?php echo $_REQUEST['or_no']; ?>','_blank')">
								<input type = "button" id = "btncancel" value = "CANCEL" onclick = "window.location='collections.php?menu=transaction'">
							</span>
						</div>
						
						
							<div align = "center" style = "margin-top: 10px;">
							<span>
								<input type = "hidden" id = "monthly">
								<input type = "hidden" id = "rebate">
								<input type = "hidden" id = "penalty">
								<input type = "hidden" id = "ins_due">
								<input type = "hidden" id = "account_no">
							</span>
						</div>
						
						
						<div id="customer_items" style="display:none;">
							<iframe id="item_dialog" width="954" height="595" style="border:none"></iframe>
						</div>
						
						
						<div id="new_items3" title="ADD DISCOUNT " style="display:none;">
							<iframe id="item_dialog3" width="380" height="90" style="border:none"></iframe>
						</div>
						
						
						<div id="new_items_discount" title="" style="display:none;">
							<iframe align="center" id="item_dialog_discount" width="370" height="305" style="border:none"></iframe>
						</div>
						
						<div id="new_items_penalty" title="" style="display:none;">
							<iframe align="center" id="item_dialog_penalty" width="370" height="305" style="border:none"></iframe>
						</div>
						
						
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
	
		loadData();
		load_loan();

	});
	
	var or_no = $("#or_no").val();
	
	
	function loadData(){

			
			var url="function_transaction.php?request=ajax&action=viewLoanCollection&or_no="+or_no;
			var counter=1;
		
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){
					var name = res.last_name+", "+res.first_name+" "+res.middle_name;
					$('#txtor_no').val(res.or_no);
					$('#txtdate').val(res.date);
					$('#compare_date').val(res.date);
					$('#txtcusname').val(name);
					$('#txtaddress').val(res.address);
					$('#txtcusid').val(res.customer_id);
					$('#account_no').val(res.account_no);
					loadBranch(res.branch_code);
					loadledger(res.customer_id)
				
				});	
			});
			
	}
	
	function load_loan(){

			var container=$("#loan_collection_list > tbody");
			var count=0,x=0,total_amout = 0,vat=0,amount_due=0;	
			$.ajax({
					url:"function_transaction.php",
					
					
					data:{"request":"ajax","action":"load_collection_loan","or_no":or_no},
					
				
					dataType:'json',
					beforeSend: function(){
						
					},
			success: function(reply){
							//console.log(reply.length);
				if(reply.length > 0){
					container.empty();
							$.each(reply, function(i,res){
								count++;
								
								if(res.penalty > 0){
									total_amout += parseFloat(res.dues) + parseFloat(res.penalty) - parseFloat(res.discount);
								}else{
									total_amout += parseFloat(res.dues) - parseFloat(res.rebate) - parseFloat(res.discount);
								}
								
								
								var amount_loan = parseFloat(res.amount_loan);
								var terms = parseFloat(res.terms);

								if(res.status == "1st loan"){
									var principal = parseFloat(res.principal_amt_1);
									var interest = parseFloat(res.int_income_1);
								}else{
									
									var principal = ((parseFloat(res.amount_loan) - parseFloat(res.principal_amt_1)) / (terms - 1));
									var interest = ((parseFloat(res.interest_income) - parseFloat(res.int_income_1)) / (terms - 1));
								
								}
								
								
								 vat = total_amout*0.12;
								 amount_due = total_amout-vat;
								 
								 $("#txtvat").val(FormatNumberBy3((Math.round(vat)).toFixed(2)));
								 $("#total_sales").val(FormatNumberBy3((Math.round(amount_due)).toFixed(2)));
								 $("#txtdue").val(FormatNumberBy3((Math.round(total_amout)).toFixed(2)));  
								
								container.append("<tr><td>"+res.or_no+"</td><td style='text-align:left;text-indent:130px;'>MONTHLY DUES:</td><td><input type='text' id='dues"+res.or_no+"' style='width:100px;margin-left:23px;text-align:right;' value = '"+FormatNumberBy3((Math.round(res.dues)).toFixed(2))+"' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9]/,'')\"></td><td align='center'><a href='#' alt='Update' title='Update' class='edit' onclick=\"edit_item('DUES');\"></a></td></tr><tr><td></td><td style='text-align:left;text-indent:200px;' readonly>PRINCIPAL:</td><td><input type='text' id='dues"+res.or_no+"' style='width:100px;margin-left:23px;text-align:right;' value = '"+FormatNumberBy3((Math.round(principal)).toFixed(2))+"' readonly onkeyup=\"javascript:this.value = this.value.replace(/[^0-9]/,'')\"></td><td align='center'></td></tr><tr><td></td><td style='text-align:left;text-indent:200px;'>INTEREST:</td><td><input readonly type='text' id='dues"+res.or_no+"' style='width:100px;margin-left:23px;text-align:right;' value = '"+FormatNumberBy3((Math.round(interest)).toFixed(2))+"' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9]/,'')\"></td><td align='center'></td></tr><tr><td rowspan='1'></td><td style='text-align:left;text-indent:130px;'>PENALTY:</td><td><input type='text' id='penalty"+res.or_no+"' style='width:100px;margin-left:23px;text-align:right;' value = '"+FormatNumberBy3((Math.round(res.penalty_discount)).toFixed(2))+"' readonly ></td><td align='center'></td></tr><tr><td colspan='5' style='text-align:left;text-indent:120px;'><strong>LESS:</strong></td></tr><tr><td></td><td style='text-align:left;text-indent:130px;'>REBATE:</td><td><input type='text'  id='rebate"+res.or_no+"' style='width:100px;margin-left:23px;text-align:right;' value = '"+FormatNumberBy3((Math.round(res.rebate)).toFixed(2))+"' readonly></td><td align='center'></td></tr><tr><td></td><td style='text-align:left;text-indent:130px;'>DISCOUNT:</td><td><input type='text' id='discount"+res.or_no+"' style='width:100px;margin-left:23px;text-align:right;' value = '"+FormatNumberBy3((Math.round(res.discount)).toFixed(2))+"' readonly ></td><td align='center'><a href='#' alt='Update' title='Update' class='delete' onclick='remove_discount();'></a></td><input type='hidden' id='amount' value='"+res.dues+"' /></tr>");
								
								$("#monthly").val(res.dues);
								$("#rebate").val(res.monthly_rebate);
								$("#penalty").val(res.penalty_interest);
								$("#ins_due").val(res.ins_due);
								
								$("#txtaccount").val(res.account_no);
								$("#txtterms").val(res.terms);
						
																
				});
				}
				
			}
		});
			
			
			
	}
		
	function loadledger(customer_id){
		$('#datedue').val("");
		$('#typeofloan').val("");
		
		var url="function_transaction.php?request=ajax&action=viewLOan_collection&customer_id="+customer_id;
		var counter=1;
			
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				$('#datedue').val(res.installment_due);
				$('#typeofloan').val(res.loan_type);
				$('#penalty_interest').val(res.penalty_interest);
			});	
			
		});
		
	}
		
	
	function search_customer(){
	$("#customer_items").attr("title","SEARCH CUSTOMER");
			$("#item_dialog").attr('src','customer_view_ledger.php');
			$("#customer_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	//function closeIframe(id,name,address,branch_code) {
	function closeIframe(id,name,address,branch_code,monthly_down,penalty_interest,monthly_rebate,ins_due,account_no){
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
		
		$("#monthly").val(monthly_down);
		$("#rebate").val(monthly_rebate);
		$("#penalty").val(penalty_interest);
		$("#ins_due").val(ins_due);
		$("#account_no").val(account_no);
		
		loadBranch(branch_code);
		loadledger(id)
		
		UPDATE_LOAN();

	}
		
	
	function loadBranch(branch_code){
		var count=0, x=0;
		var select = $("#txtbranch");

		$.ajax({
				url:"functions.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					
					
					
					if(reply.length > 0){
						select.empty();
								
							$.each(reply, function(i,res){
							 count++;
							 
							if(res.branch_code == branch_code ){
							select.append("<option  value='"+res.branch_code+"' selected='selected' >"+res.branch_code+"</option>");
							}	else{
							select.append("<option  value='"+res.branch_code+"'>"+res.branch_code+"</option>");
							}	
								
																		
							});
			
					}
				}
			});
	}
	
	
	
	
	
	function Add() {
		var txtor_no=$("#txtor_no").val();	
		var date_issued=$("#txtdate").val();	
		var customer_id=$("#txtcusid").val();
		var txtbranch=$("#txtbranch").val();	
		var address=$("#txtaddress").val();
		var txtpayment=$("#txtpayment").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(txtor_no == ""){
			errormsg+="- Input O.R. No.\n";
		}
		if(date_issued == ""){
			errormsg+="- Input Date Issued.\n";
		}
		if(customer_id == ""){
			errormsg+="- Input Customer Name.\n";
		}
		if(txtbranch == ""){
			errormsg+="- Input Branch.\n";
		}
		if(address == ""){
			errormsg+="- Input Address.\n";
		}
		if(txtpayment == ""){
			errormsg+="- Input Type of Payment.\n";
		}
		
		if(errormsg.length==emsg){
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"saveORnumber","txtor_no":txtor_no,"date_issued":date_issued,"customer_id":customer_id,"txtbranch":txtbranch,"address":address,"txtpayment":txtpayment},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Invoice Successfully Added!", "Alert Dialog");
							//window.location = "newInvoice.php?menu=transaction&invoice_no="+invoice_no+"&address="+address;
							
						}else if(reply == 'exists'){
							jAlert('Invoice No. Already Exists!', 'Alert Dialog');
						}
						else{
							alert('Error');
							event.preventDefault();
						}
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		
	}
	
	function add_discount(){
		
			$("#item_dialog3").attr('src','add_discount.php?or_no='+or_no);
			$("#new_items3").dialog({
				width:381,
				height: 135,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
	}
	
	
	function closeIframe2(actions){
			if(actions=="add"){
				jAlert("successfully Added");
			}
			$('#new_items3').dialog('close');
			load_loan();
			return false;
	}
	
	function popup(m){
	
		jAlert(m,"Alert Dialog");
	
	}
	
	
	function remove_discount(){
		
		var discount =parseInt($("#discount"+or_no).val().replace(/,/g, '')) ;
			
			if(discount != "" || discount != '0'){
				 jConfirm('Are you sure you Remove Discount?','Confirmation Dialog',function(e){	
							
						if(e){
							
							
						
							  $.ajax({
								url: "function_transaction.php",
								data:{"request":"ajax","action":"remove_discount","or_no":or_no},
								success: function(reply){
									if(reply =="saved"){
										jAlert("Successfully Remove Discount");
										load_loan();
									}
								}
							}); 
						
					
						}
						
				});
			}	

	}
	
	
	function UPDATE_LOAN() {
		var txtor_no=$("#txtor_no").val();	
		var date_issued=$("#txtdate").val();	
		var customer_id=$("#txtcusid").val();
		var txtbranch=$("#txtbranch").val();	
		var address=$("#txtaddress").val();
		
		
		var monthly=$("#monthly").val();
		var rebate=$("#rebate").val();
		var penalty=$("#penalty").val();
		var ins_due=$("#ins_due").val();
		var account_no=$("#account_no").val();
		
		jConfirm('Do you want to save this Changes?','Confirmation Dialog',function(e){	
			
			if(e){
			
						var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
						
						if(txtor_no == ""){
							errormsg+="- Input O.R. No.\n";
						}
						if(date_issued == ""){
							errormsg+="- Input Date Issued.\n";
						}
						if(customer_id == ""){
							errormsg+="- Input Customer Name.\n";
						}
						if(txtbranch == ""){
							errormsg+="- Input Branch.\n";
						}
						
						if(errormsg.length==emsg){
							$.ajax({
								url: "function_transaction.php",
								data:{"request":"ajax","action":"SetUpdate_loan","txtor_no":txtor_no,"date_issued":date_issued,"customer_id":customer_id,"txtbranch":txtbranch,"address":address,"monthly":monthly,"rebate":rebate,"penalty":penalty,"ins_due":ins_due,"account_no":account_no},
								success: function(reply){
									console.log(reply);
										if(reply == 'saved'){
											jAlert("Successfully Updated!", "Alert Dialog");
											$("#interbranch_collection_list > tbody").empty();
													load_loan();
													loadData();
										}else{
											jAlert('Error');
											event.preventDefault();
										}
								}
							});
						}
						else{
							jAlert(errormsg,"Alert Dialog");
							event.preventDefault();
						}
			
			}
		
		});	
		
	}
	
	
	function SAME_UPDATE() {
		var txtor_no=$("#txtor_no").val();	
		var date_issued=$("#txtdate").val();	
		var customer_id=$("#txtcusid").val();
		var txtbranch=$("#txtbranch").val();	
		var address=$("#txtaddress").val();
		
		var compare_date=$("#compare_date").val();
		
		
		var monthly=$("#monthly").val();
		var rebate=$("#rebate").val();
		var penalty=$("#penalty").val();
		var ins_due=$("#ins_due").val();
		var account_no=$("#account_no").val();
					
			var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
			
			if(txtor_no == ""){
				errormsg+="- Input O.R. No.\n";
			}
			if(date_issued == ""){
				errormsg+="- Input Date Issued.\n";
			}
			if(customer_id == ""){
				errormsg+="- Input Customer Name.\n";
			}
			if(txtbranch == ""){
				errormsg+="- Input Branch.\n";
			}
			
			if(errormsg.length==emsg){
				$.ajax({
					url: "function_transaction.php",
					data:{"request":"ajax","action":"Set_loan_update","txtor_no":txtor_no,"date_issued":date_issued,"customer_id":customer_id,"txtbranch":txtbranch,"address":address,"rebate":rebate,"penalty":penalty,"ins_due":ins_due,"account_no":account_no,"monthly":monthly,"compare_date":compare_date},
					success: function(reply){
						console.log(reply);
							if(reply == 'saved'){
								jAlert("Successfully Updated!", "Alert Dialog");
								$("#interbranch_collection_list > tbody").empty();
										load_loan();
										loadData();
							}else if(reply == 'no changes'){
								jAlert("Kidly Update Your Date to make Changes", "Alert Dialog");
								$("#interbranch_collection_list > tbody").empty();
										load_loan();
										loadData();
							}else{
								jAlert('Error');
								event.preventDefault();
							}
					}
				});
			}
			else{
				jAlert(errormsg,"Alert Dialog");
				event.preventDefault();
			}
	
		
	}
	
	

	
	
	function edit_item(value){
	event.preventDefault();
	
 	if(value == "DUES"){
		var col = "dues";
		var	amount = parseFloat($("#dues"+or_no).val().replace(/,/g, ''));
		
	}else if(value == "DISCOUNT"){
		var col = "discount";
		var	amount = parseFloat($("#discount"+or_no).val().replace(/,/g, ''));
	}
	else if(value == "REBATE"){
		var col = "rebate";
		var	amount = parseFloat($("#rebate"+or_no).val().replace(/,/g, ''));
	}
	else if(value == "PENALTY"){
		var col = "penalty";
		var	amount = parseFloat($("#penalty"+or_no).val().replace(/,/g, ''));
	} 
	



		 var errormsg="Please complete the following fields: \n",emsg= errormsg.length;
		
		if($("#amount"+or_no).val==""){
			errormsg+="- Amount \n";
		}
		if(errormsg.length==emsg){
			 $.ajax({
				url: "function_transaction.php",
				data:{"request":"ajax","action":"edit_amount_loan","amount":amount,"or_no":or_no,"col":col},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Successfully Updated!", "Alert Dialog");
							load_loan();
						}
						else{
							alert('Sorry Error');
							event.preventDefault();
						}
				}
			}); 
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		} 
		 

	}
	
	
	function discount_add(){
	var or_no = $("#or_no").val();
	var acct = $("#txtaccount").val();
	
	$("#new_items_discount").attr("title","DEBIT/CREDIT MEMO - DISCOUNT");
			$("#item_dialog_discount").attr("src","discount_add.php?acct="+acct+"&or_no="+or_no);
			$("#new_items_discount").dialog({
				width:370,
				height: 350,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog2").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
	
	}
	
	function penalty_add(){
	
	var acct = $("#txtaccount").val();
	var or_no = $("#or_no").val();
	
	$("#new_items_penalty").attr("title","DEBIT/CREDIT MEMO - PENALTY");
			$("#item_dialog_penalty").attr("src","penalty_add.php?acct="+acct+"&or_no="+or_no);
			$("#new_items_penalty").dialog({
				width:370,
				height: 350,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog2").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
	
	}
	
	
	function closeIframe(actions){
		if(actions=="add"){
			jAlert("Successfully Added");
		}
		else if(actions=="edit"){
			jAlert("Successfully Updated");
		}
		else if(actions=="cancel"){
			$('#new_items_discount').dialog('close');
		}
		$('#new_items_discount').dialog('close');

		return false;
	}
	
	function closeIframe2(actions){
		if(actions=="add"){
			jAlert("Successfully Added");
		}
		else if(actions=="edit"){
			jAlert("Successfully Updated");
		}
		else if(actions=="cancel"){
			$('#new_items_penalty').dialog('close');
		}
		$('#new_items_penalty').dialog('close');

		return false;
	}
	
	
	</script>