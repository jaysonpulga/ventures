<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<!DOCTYPE HTML>
<html lang="en">
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center" >
				<div id="options-top" align="center" style="width:870px;">
					<div>
					<table width="870px">
						<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2 style="margin-top:10px;">SALES INVOICE</h2>
							
								<input type="hidden" id="branch_id" value="<?php echo $_SESSION['branch_id']; ?>" >
								<input type="hidden" id="branch_name" value="<?php echo $_SESSION['branch_name']; ?>" >
								<input type="hidden" id="branch_code" value="<?php echo $_SESSION['branch_code']; ?>" >
							
							
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
							<form name="search" action="" method="POST">
									<select id = 'category' name='category'>
										<option value="invoice_no">Invoice No.</option>
									</select>
										<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Report">
										<a href = "addInvoice.php?menu=transaction"><input type="button" value="NEW INVOICE" id='input' style="width:130px;top:1px;"></a>
							</form>
							</td>
						</tr>
					</table>
					</div>
					
										
					<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:870px" cellspacing="0">
						<table id = "invoice_list">
							<thead align = "center">
								<tr>
									<th style="width:10px;"><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'invoice_no')">INVOICE NUMBER</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'date_issued')">DATE</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'name')">CUSTOMER NAME</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'total_qty')">TOTAL<br>QTY</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'total_amount')">TOTAL<br>AMOUNT</a></th><th colspan = "2" style="width:10px;">ACTION</th>
								</tr>
							</thead>
							<tbody id = "invoice_data"></tbody>
						</table>
					</div>
					
					<div id="pagination" style = "margin-top:50px;"> 
						<div class="holder" ></div>
						<i>Pages</i>
					</div>
					
					<div id="invoice_items" style="display:none;">
						<iframe id="item_dialog" width="504" height="312" style="border:none"></iframe>
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	
	function jpages(){
		$("div.holder").jPages({
		  containerID : "invoice_data",
		  previous : "←",
		  next : "→",
		  perPage : 15,
		  delay :10,
		  startPage    : 1,
		  startRange   : 1,
		  midRange     : 5,
		  endRange     : 1
		});
	}
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
				
	var sortType = "ASC";
	
	function filter_list(index,cVar){
		sort = cVar;
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadBody(sort,sortType);
	}

	
	$(document).ready(function(){
	
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadBody("date_issued","DESC");
		
	});
	
	var branch_id = $("#branch_id").val();
	var branch_name = $("#branch_name").val();
	var branch_code = $("#branch_code").val();
	
	function add_invoice() {
		$("#invoice_items").attr("title","NEW INVOICE");
		$("#item_dialog").attr('src','addInvoice.php');
		$("#invoice_items").dialog({
			width: 505,
			height: 360,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src',"about:blank");
			}
		});
		return false;
	}
	
	$("#txtsearch").live("keyup change",function(){
		$("#invoice_list > tbody").empty();
		loadBody("date_issued","DESC");				
	});
	
	function loadBody(sort,sortType) {
		$("#invoice_list > tbody").empty();
		
		var url="functions.php?request=ajax&action=loadSalesInvoice&sort="+sort+"&sortType="+sortType+"&inputsearch="+$("#txtsearch").val()+"&category="+$("#category").val()+"&branch_id="+branch_id;
		var counter=0;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				var total_amount = parseFloat(Math.round((res.total_amount)*100)/100).toFixed(2);
				
				$("#invoice_list > tbody").append("<tr class = 'x' onmouseover='clickSearch();'><td>"+res.invoice_no+"</td><td>"+res.date_issued+"</td><td><div style = 'text-align:left;'>"+res.name+"</div></td><td><div style = 'text-align:right'>"+res.total_qty+"</div></td><td><div style = 'text-align:right'>"+FormatNumberBy3(total_amount)+"</div></td><td><a href = '#' class = 'view' onclick = \"view_data("+res.invoice_no+","+res.id+");\"></a></td><td><a href = '#' class = 'delete' onclick=\"delete_item('"+res.invoice_no+"');\"></td></tr>");
				counter++;
				
			});
			if (counter <= 0){
				$("#invoice_list > tbody").append("<tr id = 'noItems'><th colspan = '6' align = 'center'> No Items on record! </th></tr>");
			}
			jpages();
		});
		
	}
	
	
	function delete_item(id){
	
		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){
			
			if(e){
			
				var table1 =  "sale_invoice_details";
				var table2 =  "sales_invoice";
				$.ajax({
					url: "function_transaction.php",
					data:{"request":"ajax","action":"deleteTwotable","id":id,"table1":table1,"table2":table2,"table_id":"invoice_no"},
					success: function(reply){

					}
				});
				
				$('#record'+id).animate({ backgroundColor: '#fbc7c7' }, 'fast')
				.animate({ opacity: "hide" }, "slow");
					
				jAlert("successfully Deleted");
				loadBody("date_issued","DESC");
			}
		
		});
	}
	
	function view_data(invoice_no,id) {
		
		window.location = "viewInvoice2.php?menu=transaction&invoice_no="+invoice_no+"&id="+id;
	}
	
	
	function clickSearch() {
	
		$("#txtsearch").blur();
	
	}
	
	</script>
	
</body>
</html>