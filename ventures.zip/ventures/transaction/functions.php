<?php
	session_start();
	include('../database.php');
	$db = new Database();  
	$db->connect();
	
	$action = $_REQUEST["action"];
	
	if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){
		
		switch($action){
			
			// SALES INVOICE
			
			case 'viewCustomerLists';
				$customer = array();
			
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$category=$_REQUEST['category'];
				$branch_id=$_REQUEST['branch_id'];
				
				$trimmed=trim($_REQUEST['inputsearch']);
				
				if($sort == "customer_name") {
					$sort1 = "CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name)";
				}
				else {
					$sort1 = $sort;
				}
				
				if($category == "customer_name") {
					$rows ="a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code";
					
					if($branch_id != 1){
						$where = "a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%'";
						
					}else{
						$where = "a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%'";
						
					}
					
					$order = "$sort1 $sortType";
					$db->select("tbl_customer a, tbl_province b, tbl_city c, tbl_branch d",$rows,$where,$order);
				}
				if($category == "branch") {
					$rows ="a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code";
					
					if($branch_id != 1){
						$where = "a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND d.branch_name LIKE '%".$trimmed."%'";
						
					}else{
						$where = "a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND d.branch_name LIKE '%".$trimmed."%'";
					
					}
					
					$order = "$sort1 $sortType";
					$db->select("tbl_customer a, tbl_province b, tbl_city c, tbl_branch d",$rows,$where,$order);
				}
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}'; 
				
			break;
			
			case 'viewCustomer_with_ledger';
				$customer = array();
			
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$category=$_REQUEST['category'];
				$trimmed=trim($_REQUEST['inputsearch']);
				
				if($sort == "customer_name") {
					$sort1 = "CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name)";
				}
				else {
					$sort1 = $sort;
				}
				
				if($category == "customer_name") {
					$rows ="a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code";
					$where = "e.customer_name = a.id AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',
					',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%'";
					$order = "$sort1 $sortType";
					$db->select("tbl_customer a, tbl_province b, tbl_city c, tbl_branch d,tbl_ledger e",$rows,$where,$order);
				}
				if($category == "branch") {
					$rows ="a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code";
					$where = "e.customer_name = a.id AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND d.branch_name LIKE '%".$trimmed."%'";
					$order = "$sort1 $sortType";
					$db->select("tbl_customer a, tbl_province b, tbl_city c, tbl_branch d,tbl_ledger e",$rows,$where,$order);
				}
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}'; 
				
			break;
			
			case 'loadCustomerBranch';
			
				$rows="id,branch_name,branch_code";
				$db->select('tbl_branch',$rows);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'select_branch';
				$db->select("tbl_branch","*");
				$result = $db->getResult();
		
				print json_encode($result);
			break;
			
			case 'loadCustomerRegion';
			
				$rows="id,region_name";
				$db->select('tbl_region',$rows);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'loadCustomerProvince';
				
				$region_id=$_REQUEST["region_id"];
				$where='region_id='.$region_id;
				$rows="*";
				$order = "province_name ASC";
				$db->select('tbl_province',$rows,$where,$order);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'loadCustomerCity';
				
				$province_id=$_REQUEST["province_id"];
				$where='province_id='.$province_id;
				$rows="*";
				$order = "city_name ASC";
				$db->select('tbl_city',$rows,$where,$order);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'saveCustomerData';
			
				$last_name=$_REQUEST["last_name"];
				$first_name=$_REQUEST["first_name"];
				$middle_name=$_REQUEST["middle_name"];
				$birthday=$_REQUEST["birthday"];
				$telno=$_REQUEST["telno"];
				$cellno=$_REQUEST["cellno"];
				$branch_id=$_REQUEST["branch_id"];
				$cus_region_id=$_REQUEST["cus_region_id"];
				$cus_province_id=$_REQUEST["cus_province_id"];
				$cus_city_id=$_REQUEST["cus_city_id"];
				$cus_subd_brgy=$_REQUEST["cus_subd"];
				$cus_street_num=$_REQUEST["cus_street"];
				$ship_region_id=$_REQUEST["ship_region_id"];
				$ship_province_id=$_REQUEST["ship_province_id"];
				$ship_city_id=$_REQUEST["ship_city_id"];
				$ship_subd_brgy=$_REQUEST["ship_subd"];
				$ship_street_num=$_REQUEST["ship_street"];
				
				$rows1 = "*";
				$where1 = "last_name='$last_name' AND first_name='$first_name' AND middle_name='$middle_name'";
				
				$db->select("tbl_customer", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
				
					$rows ='last_name,first_name,middle_name,birthday,telephone_no,cellphone_no,branch_id,customer_region_id,customer_province_id,customer_city_town_id,customer_subd_brgy,customer_street_num,shipping_region_id,shipping_province_id,shipping_city_town_id,shipping_subd_brgy,shipping_street_num';
					$values = array($last_name,$first_name,$middle_name,$birthday,$telno,$cellno,$branch_id,$cus_region_id,$cus_province_id,$cus_city_id,$cus_subd_brgy,$cus_street_num,$ship_region_id,$ship_province_id,$ship_city_id,$ship_subd_brgy,$ship_street_num);
					
					$db->insert('tbl_customer',$values,$rows);
					
					echo "saved";
					
				}
				
			break;
			
			case "loadBrand";
				
				$category = $_REQUEST["category"];
				
				if($category == "1") {
					$where="category=1 AND a.id=b.brand AND b.status='ON HAND'";
					$rows="DISTINCT(a.brand) as brand, a.id as id";
					$db->select('tbl_manufacturer a, stocks_motors b',$rows,$where);
				}
				
				else if($category == "2") {
					$where="category=2 AND a.id=b.brand";
					$rows="DISTINCT(a.brand) as brand, a.id as id";
					$db->select('tbl_manufacturer a, stocks_parts b',$rows,$where);
				}
				else if($category == "3") {
					$where="category=3 AND a.id=b.brand AND b.status='ON HAND'";
					$rows="DISTINCT(a.brand) as brand, a.id as id";
					$db->select('tbl_manufacturer a, stocks_promo b',$rows,$where);
				}
				else if($category == "4") {
					$where="category=4 AND a.id=b.brand";
					$rows="DISTINCT(a.brand) as brand, a.id as id";
					$db->select('tbl_manufacturer a, stocks_consumables b',$rows,$where);
				}
				else {
				}
				
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadModel";
			
				$brand = $_REQUEST["brand_id"];
				
				$where="a.brand='$brand' AND b.model=a.motor_id AND b.status='ON HAND'";
				$rows="DISTINCT(a.model) as model,a.motor_id as motor_id";
				$db->select('tbl_motorcycle a, stocks_motors b',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadInvoiceData";
			
				$invoice_no = $_REQUEST["invoice_no"];
				
				$where = "a.invoice_no=$invoice_no AND a.customer_id=b.id";
				$rows = "a.*,a.id as id,b.id as cid,CONCAT(b.last_name,', ',b.first_name,' ',b.middle_name) as customer_name";
				$db->select("sales_invoice a,tbl_customer b",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadMotor";
			
				$id = $_REQUEST["id"];
				
				$where="a.id='$id' AND a.model=b.motor_id";
				$rows="a.*, b.selling_price as selling_price";
				$db->select('stocks_motors a, tbl_motorcycle b',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadCode";
			
				$brand = $_REQUEST["brand_id"];
				
				$where="a.brand='$brand' AND b.item=a.parts_id";
				$rows="DISTINCT(a.item_code) as item_code, a.parts_id as parts_id";
				$db->select('tbl_parts a, stocks_parts b',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadConsumables";
			
				$brand = $_REQUEST["brand_id"];
				
				$where="a.brand='$brand' AND b.item=a.con_id";
				$rows="DISTINCT(a.item_code) as item_code,a.con_id as con_id";
				$db->select('tbl_consumables a, stocks_consumables b',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadPromo";
			
				$brand = $_REQUEST["brand_id"];
				
				$where="a.brand='$brand' AND b.item=a.promo_id AND b.status='ON HAND'";
				$rows="a.item_code as item_code, a.promo_id as promo_id";
				$db->select('tbl_promo a, stocks_promo b',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadStockMotor";
			
				$result=array();
				$motor = array();
				$status = "ON HAND";
			
				$model = $_REQUEST["model"];
				
				$where="a.model=b.motor_id AND a.status='$status' AND a.model='$model'";
				$rows='a.*,a.model as model, a.status as status';
				$db->select('stocks_motors a, tbl_motorcycle b',$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $data){
				
					$where="a.model=b.motor_id AND a.model=".$data['model']." AND a.status='$status'";
					$rows='a.id,a.dr_no,a.brand,a.model,a.engine_no,a.frame_no,a.color,b.selling_price';
					
					$db->select('stocks_motors a, tbl_motorcycle b',$rows,$where);
					$result = $db->getResult();
				
				}
			
				for($i=0;$i<count($result);$i++){
					array_push($motor,$result[$i]);
				}
					
				print '{"members":'.json_encode($motor).'}';
			
			break;
			
			case "loadStockParts";
			
				$item = $_REQUEST["item_code"];
				$row = "a.id,a.dr_no,a.brand,a.item,serial_no,sum(a.quantity) as quantity,sum(a.remaining) as remain, b.selling_price ";
				$where="a.item = '$item' and a.brand = b.brand group by a.serial_no ";
				
				$db->select("stocks_parts a,tbl_parts b",$row,$where);
				$result = $db->getResult();
				
				print '{"members":'.json_encode($result).'}';
			
			break;
			
			case "loadStockConsumables";
				$result = array();
				$cons = array();
				$item = $_REQUEST["item_code"];
				$status = "ON HAND";
				
				$where = "a.item='$item' AND a.item=b.con_id";
				$rows = "a.*,a.item as item";
				$db->select('stocks_consumables a, tbl_consumables b',$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $data){
				
					$where="a.item=b.con_id AND a.item=".$data['item'];
					$rows='DISTINCT(a.serial_no),a.id,a.dr_no,a.brand,SUM(a.remaining) as remain,b.item_code,b.selling_price';
					
					$db->select('stocks_consumables a, tbl_consumables b',$rows,$where);
					$result = $db->getResult();
				
				}
				
				for($i=0;$i<count($result);$i++){
					array_push($cons,$result[$i]);
				}
				
				print '{"members":'.json_encode($cons).'}';
			
			break;
			
			case "loadStockPromo";
				$result = array();
				$promo = array();
				$item = $_REQUEST["item_code"];
				$status = "ON HAND";
				
				$where = "a.item='$item' AND a.status='$status' AND a.item=b.promo_id";
				$rows = "a.*,a.item as item";
				$db->select('stocks_promo a, tbl_promo b',$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $data){
				
					$where="a.item=b.promo_id AND a.item=".$data['item']." AND a.status='$status'";
					$rows='a.id,a.dr_no,a.brand,b.item_code,a.serial_no,a.color,b.selling_price';
					
					$db->select('stocks_promo a, tbl_promo b',$rows,$where);
					$result = $db->getResult();
				
				}
				
				for($i=0;$i<count($result);$i++){
					array_push($promo,$result[$i]);
				}
				
				print '{"members":'.json_encode($promo).'}';
			
			break;
			
			case "loadItems";
				
				$dataArray_motors=array();
				$dataArray_parts=array();
				$dataArray_consumables=array();
				$dataArray_promo=array();
				$dataArray=array();
				
				$invoice = $_REQUEST["invoice_no"];
				$i=0;
				
				$where = "invoice_no=".$invoice;
				$rows = "*";
				$db->select("sale_invoice_details",$rows,$where);
				$res = $db->getResult();
				
				foreach($res as $data) {
					
					$invoice = $data["invoice_no"];
					$item_id = $data["stock_id"];
					$qty=$data["qty"];
					$selling_price=$data["amount"];
					
					if($item_type == "motorcycle") {
						$where1 = "a.id=c.stock_id AND a.model=b.motor_id AND a.brand=d.id AND c.stock_id=".$item_id." AND c.category=1 AND c.invoice_no=".$invoice;
						$rows1 = "DISTINCT(c.stock_id),d.brand,b.model as item,CONCAT('MAKE&TYPE: ',d.brand,' ',b.model,'<br> MOTOR NO.: ',a.engine_no,'<br> FRAME NO.: ',a.frame_no,'<br> COLOR: ',a.color) as description,c.id as id,b.motor_id as itemid,c.invoice_no as invoice_no";
						$db->select("stocks_motors a, tbl_motorcycle b, sale_invoice_details c, tbl_manufacturer d",$rows1,$where1);
						$result_motors = $db->getResult();
						
						foreach($result_motors as $data_motors) {
							
							$new_array[$i]=array(
								'id' => $data_motors["id"],
								'invoice_no' => $data_motors["invoice_no"],
								'stock_id' => $data_motors["stock_id"],
								'item' => $data_motors["item"],
								'brand' => $data_motors["brand"],
								'description' => $data_motors["description"],
								'itemid' => $data_motors["itemid"],
								'qty' => $qty,
								'selling_price' => $selling_price
							);
							array_push($dataArray_motors,$new_array[$i]);
						}
						
					}
					else if($item_type == "parts"){
						$where1="c.item_id=a.id AND a.item=b.parts_id AND c.category=2 AND a.brand=d.id AND c.stock_id=".$item_id." AND c.invoice_no=".$invoice;
						$rows1="DISTINCT(c.stock_id),a.*,d.brand,b.item_code as item,CONCAT('MAKE & TYPE: ',d.brand,' ',b.item_code,'<br> SERIAL NO.: ',a.serial_no,'<br> DESCRIPTION: ',b.description) as description,c.id as id,b.parts_id as itemid,c.invoice_no as invoice_no";
						$db->select('stocks_parts a, tbl_parts b, sale_invoice_details c, tbl_manufacturer d',$rows1,$where1);
						$result_parts= $db->getResult();
						
						foreach($result_parts as $data_parts){
							$new_array[$i]=array(
								'id' => $data_parts["id"],
								'invoice_no' => $data_parts["invoice_no"],
								'stock_id' => $data_parts["stock_id"],
								'item' => $data_parts["item"],
								'brand' => $data_parts["brand"],
								'itemid' => $data_parts["itemid"],
								'description' => $data_parts["description"],
								'qty' => $qty,
								'selling_price' => $selling_price
								
							);
							array_push($dataArray_parts,$new_array[$i]);
						}
						
					}
					else if($item_type == "consumables"){
						$where1="c.stock_id=a.id AND a.item=b.con_id AND c.category=4 AND a.brand=d.id AND c.stock_id=".$item_id." AND c.invoice_no=".$invoice;
						$rows1="DISTINCT(c.stock_id),a.*,d.brand,b.item_code as item,CONCAT('MAKE & TYPE: ',d.brand,' ',b.item_code,'<br> SERIAL NO.: ',a.serial_no,'<br> DESCRIPTION: ',b.description) as description,c.id as id,b.con_id as itemid,c.invoice_no as invoice_no";
						$db->select('stocks_consumables a, tbl_consumables b, sale_invoice_details c, tbl_manufacturer d',$rows1,$where1);
						$result_consumables= $db->getResult();
						
						foreach($result_consumables as $data_consumables){
							$new_array[$i]=array(
								'id' => $data_consumables["id"],
								'invoice_no' => $data_consumables["invoice_no"],
								'item_id' => $data_consumables["item_id"],
								'item' => $data_consumables["item"],
								'brand' => $data_consumables["brand"],
								'itemid' => $data_consumables["itemid"],
								'description' => $data_consumables["description"],
								'qty' => $qty,
								'selling_price' => $selling_price
								
							);
							array_push($dataArray_consumables,$new_array[$i]);
						}
						
					}
					else if($item_type == "promo"){
						$where1="c.stock_id=a.id AND a.item=b.promo_id AND a.brand=d.id AND c.category=3 AND c.stock_id=".$item_id." AND c.invoice_no=".$invoice;
						$rows1="DISTINCT(c.stock_id),a.*,d.brand,b.item_code as item,CONCAT('MAKE & TYPE: ',d.brand,' ',b.item_code,'<br> SERIAL NO.: ',a.serial_no,'<br> COLOR: ',a.color,'<br> DESCRIPTION: ',b.description) as description,c.id as id,b.promo_id as itemid,c.invoice_no as invoice_no";
						$db->select('stocks_promo a, tbl_promo b, sale_invoice_details c, tbl_manufacturer d',$rows1,$where1);
						$result_promo= $db->getResult();
						
						foreach($result_promo as $data_promo){
							$new_array[$i]=array(
								'id' => $data_promo["id"],
								'invoice_no' => $data_promo["invoice_no"],
								'item_id' => $data_promo["item_id"],
								'item' => $data_promo["item"],
								'brand' => $data_promo["brand"],
								'itemid' => $data_promo["itemid"],
								'description' => $data_promo["description"],
								'qty' => $qty,
								'selling_price' => $selling_price
								
							);
							array_push($dataArray_promo,$new_array[$i]);
						}
					}
					$i++;
				}
				
				$dataArray=array_merge($dataArray_motors,$dataArray_parts,$dataArray_consumables,$dataArray_promo);
				
				print '{"members":'.json_encode($dataArray).'}';
			
			break;
			
			case "loadMotorcycle";
			
				$invoice = $_REQUEST["invoice_no"];
			
				$where="c.invoice_no='$invoice' AND c.item_type='motorcycle' AND a.id=c.item_id AND a.model=b.motor_id AND b.brand=d.id";
				$rows="b.model as model, a.engine_no as engine_no, a.frame_no as frame_no, a.color as color, c.item_id as item_id, b.motor_id as motor_id, c.id as id, c.item_type as item_type, c.selling_price as selling_price, d.brand as brand";
				$db->select('stocks_motors a, tbl_motorcycle b, invoice_details c, tbl_manufacturer d',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadParts";
			
				$invoice = $_REQUEST["invoice_no"];
			
				$where="c.invoice_no='$invoice' AND c.item_type='parts' AND a.id=c.item_id AND a.item=b.parts_id AND b.brand=d.id";
				$rows="b.parts as parts, a.serial_no as serial_no, b.description as description, b.item_code as item_code, b.parts_id as parts_id,c.selling_price as selling_price, c.item_id as item_id, c.item_type as item_type, c.id as id, d.brand as brand";
				$db->select('stocks_parts a, tbl_parts b, invoice_details c, tbl_manufacturer d',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "saveInvoice";
			
				$invoice_no=$_REQUEST["invoice_no"];
				$date_issued=$_REQUEST["date_issued"];
				$customer_id=$_REQUEST["customer_id"];
				$terms=$_REQUEST["terms"];
				$address=$_REQUEST["address"];
				
				$rows1 = "*";
				$where1 = "invoice_no=".$invoice_no;
				
				$db->select("sales_invoice",$rows1,$where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
				
					$rows ='invoice_no,date_issued,customer_id,terms,address';
					$values = array($invoice_no,$date_issued,$customer_id,$terms,$address);
					
					$db->insert('sales_invoice',$values,$rows);
					
					echo "saved";
					
				}
			break;
			
			case "saveInvoiceParts";
			
				$array = $_REQUEST["array"];
				$selling_price = $_REQUEST["selling_price"];
				$invoice_no = $_REQUEST["invoice_no"];
				$item_type = $_REQUEST["item_type"];
				$quantity = $_REQUEST["quantity"];
				$var = $quantity;
					
				foreach($array as $key => $val){
				
					$where = "serial_no = '$val' ";
					$order = "id desc";		
					$db->select("stocks_parts",'*',$where,$order);
					$result = $db->getResult();
				
						foreach($result as $info){
						
									 $id = $info['id'];
									 $brand = $info['brand'];
									 $item = $info['item'];
									 $serial_no = $info['serial_no'];
									 $remaining = $info['remaining'];
																			  
								
									$c = $var;
									$answer = ($var - $remaining);
									$var = $answer;

									if($var < 0) $var = 0; 
									if($var > 0){

									$rowsx = array('remaining' => '0');
									$wherex ="id = '$id'";
									$db->update("stocks_parts",$rowsx,$wherex);

									$rows ='invoice_no,item_type,item_id,qty,selling_price';
									$values = array($invoice_no,$item_type,$id,$remaining,$selling_price);
									$db->insert("invoice_details",$values,$rows); 
                  
									}else{
 
									$answer = abs($answer); 
									$rowsx = array('remaining' => $answer);
									$wherex ="id = '$id'";
									$db->update("stocks_parts",$rowsx,$wherex); 
									
									$rows ='invoice_no,item_type,item_id,qty,selling_price';
									$values = array($invoice_no,$item_type,$id,$c,$selling_price);
									$db->insert("invoice_details",$values,$rows);
									
									break; 
									}
						}
				
				}
				print "uhryt";
				
			break;
			
			case "saveInvoiceConsumables";
			
				$array = $_REQUEST["array"];
				$selling_price = $_REQUEST["selling_price"];
				$invoice_no = $_REQUEST["invoice_no"];
				$item_type = $_REQUEST["item_type"];
				$quantity = $_REQUEST["quantity"];
				$var = $quantity;
					
				foreach($array as $key => $val){
				
					$where = "serial_no = '$val' ";
					$order = "id desc";		
					$db->select("stocks_consumables",'*',$where,$order);
					$result = $db->getResult();
				
						foreach($result as $info){
						
									$id = $info['id'];
									$brand = $info['brand'];
									$item = $info['item'];
									$serial_no = $info['serial_no'];
									$remaining = $info['remaining'];
								
									$c = $var;
									$answer = ($var - $remaining);
									$var = $answer;

									if($var < 0) $var = 0; 
									if($var > 0){

									$rowsx = array('remaining' => '0');
									$wherex ="id = '$id'";
									$db->update("stocks_consumables",$rowsx,$wherex);

									$rows ='invoice_no,item_type,item_id,qty,selling_price';
									$values = array($invoice_no,$item_type,$id,$remaining,$selling_price);
									$db->insert("invoice_details",$values,$rows); 
                  
									}else{
 
									$answer = abs($answer); 
									$rowsx = array('remaining' => $answer);
									$wherex ="id = '$id'";
									$db->update("stocks_consumables",$rowsx,$wherex); 
									
									$rows ='invoice_no,item_type,item_id,qty,selling_price';
									$values = array($invoice_no,$item_type,$id,$c,$selling_price);
									$db->insert("invoice_details",$values,$rows);
									
									break; 
									}
						}
				
				}
				print "uhryt";
			
				/* $array = $_REQUEST["array"];
				$selling_price = $_REQUEST["selling_price"];
				$invoice_no = $_REQUEST["invoice_no"];
				$item_type = $_REQUEST["item_type"];
				$quantity = $_REQUEST["quantity"];
				$var = $quantity;
					
				foreach($array as $key => $val){
				
					$where = "serial_no = '$val' ";
					$order = "id desc";		
					$db->select("stocks_consumables",'*',$where,$order);
					$result = $db->getResult();
				
					foreach($result as $info){
						
						 $id = $info['id'];
						 $brand = $info['brand'];
						 $item = $info['item'];
						 $serial_no = $info['serial_no'];
						 $remaining = $info['remaining'];
						 	
						$c = $var;
						$answer = ($var - $remaining);
						$var = $answer;

						if($var < 0) $var = 0; 
						if($var > 0){

						$rowsx = array('remaining' => '0');
						$wherex ="id = '$id'";
						$db->update("stocks_consumables",$rowsx,$wherex);

						$rows ='invoice_no,item_type,item_id,qty,selling_price';
						$values = array($invoice_no,$item_type,$id,$remaining,$selling_price);
						$db->insert("invoice_details",$values,$rows);
	  
						}else{

						$answer = abs($answer); 
						$rowsx = array('remaining' => $answer);
						$wherex ="id = '$id'";
						$db->update("stocks_consumables",$rowsx,$wherex); 
						
						$rows ='invoice_no,item_type,item_id,qty,selling_price';
						$values = array($invoice_no,$item_type,$id,$c,$selling_price);
						$db->insert("invoice_details",$values,$rows); 
						break; 
						}
					}
				
				}
				
				print "uhryt"; */
			
			break;
			
			case "saveInvoiceData";
			
				$invoice_no = $_REQUEST['invoice_no'];
				$item_type = $_REQUEST['item_type'];
				$item_id = $_REQUEST['item_id'];
				$qty = $_REQUEST["qty"];
				$price = $_REQUEST["selling_price"];
				$remain = $_REQUEST["remain"];
				
				if($item_type == "motorcycle") {
					$table_name = "stocks_motors";
				}
				if($item_type == "parts") {
					$table_name = "stocks_parts";
				}
				if($item_type == "consumables") {
					$table_name = "stocks_consumables";
				}
				if($item_type == "promo") {
					$table_name = "stocks_promo";
				}
				
				$rows2 = "*";
				$where2 = "id=".$item_id;
				$db->select($table_name,$rows2,$where2);
				$result1 = $db->getResult();
				
				foreach($result1 as $data) {
				
					$rows1 = "*";
					$where1 = "invoice_no ='$invoice_no' AND item_type='$item_type' AND item_id=".$data['id'];
					
					$db->select("sale_invoice_details", $rows1, $where1);
					$result = $db->getResult();
					
					if(count($result)>0){
						echo "exists";
					}
					
					else {
						$status = "SOLD";
					
						$rows ='invoice_no,item_type,item_id,qty,selling_price';
						$values = array($invoice_no,$item_type,$item_id,$qty,$price);
						
						$db->insert('invoice_details',$values,$rows);
						
						$where_stocks = "id=".$data['id'];
						$rows_stocks = array('status' => $status);
						$db->update($table_name,$rows_stocks,$where_stocks);
						
						echo "saved";
						
					}
				
				}
			
			break;
			
			case "saveDetails";
			
				$invoice = $_REQUEST["invoice_no"];
				$qty = $_REQUEST["total_qty"];
				$amount = $_REQUEST["total_amount"];
				
				$rows1 = "*";
				$where1 = "invoice_no=".$invoice;
				
				$db->select("sales_details", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
				
					$rows ='invoice_no,total_qty,total_amount';
					$values = array($invoice,$qty,$amount);
					
					$db->insert('sales_details',$values,$rows);
					
					echo "saved";
					
				}
			
			break;
			
			case "loadSalesInvoice";
				
				$invoice = array();
				$result = array();
				
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$category=$_REQUEST['category'];
				$branch_id=$_REQUEST['branch_id'];
				$trimmed=trim($_REQUEST['inputsearch']);
				 
						if($branch_id != 1 ){
							$where = "b.branch_id = '$branch_id' and $category LIKE '%".$trimmed."%'";
						}else{
							$where = "$category LIKE '%".$trimmed."%'";
						}
						
					$rows = "a.*,b.first_name,b.last_name,b.middle_name";
					$order = "CONCAT(b.last_name,',',b.first_name,' ',b.middle_name) $sortType";
					$db->select("sales_invoice a LEFT JOIN tbl_customer b ON a.customer_id=b.id",$rows,$where,$order);
				
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $key){
					$total_qty=0;
					$total_amount=0;
					$id=$key["id"];
					$invoice_no=$key["invoice_no"];
					$date=$key["date_issued"];
					$name=$key["last_name"].",".$key["first_name"]." ".$key["middle_name"];
					$customer_name=$key["invoice_no"];
					
					$where1 = "invoice_no= '$invoice_no' and $category LIKE '%".$trimmed."%'";
					$rows1 = "*";
					$db->select("sale_invoice_details",$rows1,$where1);
					$result2 = $db->getResult();
					
					foreach($result2 as $key_details){
						$amount=$key_details["qty"]*$key_details["amount"];	
						$total_amount=$total_amount+$amount;
						$total_qty=$total_qty+$key_details["qty"];	
					}
					$result[$i]=array(
						'id' => $id,
						'invoice_no' => $invoice_no,
						'date_issued' => $date,
						'name' => $name,
						'total_qty' => $total_qty,
						'total_amount' => $total_amount
					);
					
					array_push($invoice,$result[$i]);
					$i++;
				}
				
				//print_r($invoice);
		if(count($invoice) > 0){
				$sortArray = array(); 
				
				foreach($invoice as $total){ 
					foreach($total as $key=>$value){
						if(!isset($sortArray[$key])){
							$sortArray[$key] = array(); 
						}
						$sortArray[$key][] = $value;
					}
				}
				
				$orderby = $sort;
				if($_REQUEST["sortType"]=="ASC"){
					array_multisort($sortArray[$orderby],SORT_ASC,$invoice);
				}
				else{
					array_multisort($sortArray[$orderby],SORT_DESC,$invoice);
				}
				
		}		print '{"members":'.json_encode($invoice).'}';
			
		break;
			
			case "updateItem";
				
				$price = $_REQUEST["price"];
				$id = $_REQUEST["id"];
				
				$where = "id=".$id;
				$rows = array("selling_price" => $price);
				$db->update('invoice_details',$rows, $where);
				
				echo "updated";
			
			break;
			
			case "deleteItem";
				
				$item_id = $_REQUEST["item_id"];
				$type = $_REQUEST["item_type"];
				$status = "ON HAND";
			
				if($type == "motorcycle") {
					$table_name = "stocks_motors";
					$where = "id=".$item_id;
					$rows = array('status' => $status);
					$db->update($table_name,$rows,$where);
				}
				/* if($type == "parts") {
					
				}
				if($type == "consumables") {
					
				} */
				if($type == "promo") {
					$table_name = "stocks_promo";
					$where = "id=".$item_id;
					$rows = array('status' => $status);
					$db->update($table_name,$rows,$where);
				}
				
				$id = $_REQUEST["id"];
				$db->delete("invoice_details","id='$id'");
				
				print "deleted";
			
			break;
			
			case "updateDetails";
				
				$id=$_REQUEST["id"];
				$invoice_no=$_REQUEST["invoice_no"];
				$date_issued=$_REQUEST["date_issued"];
				$customer_id=$_REQUEST['customer_id'];
				$terms=$_REQUEST['terms'];
				$address=$_REQUEST['address'];
				
				$where="id= '$id' ";
				$rows = array('invoice_no' => $invoice_no , 'date_issued' => $date_issued , 'customer_id' => $customer_id , 'terms' => $terms , 'address' => $address);
				$db->update('sales_invoice',$rows,$where);
				
				echo "updated";
			
			break;
			
			case "searchInvoice";
				
				$invoice = array();
			
				$search=trim($_REQUEST['inputsearch']);
				$category=$_REQUEST['category'];
				
				if($category=="invoice_no"){
					$rows ="a.*,b.first_name,b.last_name,b.middle_name";
					$where = " a.invoice_no LIKE '%".$search."%' AND a.customer_id = b.id";
					$db->select('sales_invoice a, tbl_customer b',$rows,$where); 
				}
				
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $key){
					$total_qty=0;
					$total_amount=0;
					$invoice_no=$key["invoice_no"];
					$date=$key["date_issued"];
					$name=$key["last_name"]." , ".$key["first_name"]." ".$key["middle_name"];
					$customer_name=$key["invoice_no"];
					$id=$key["id"];
					
					$where1 = "invoice_no=$invoice_no";
					$rows1 = "*";
					$db->select("invoice_details",$rows1,$where1);
					$result2 = $db->getResult();
					
					foreach($result2 as $key_details){
						$amount=$key_details["qty"]*$key_details["selling_price"];	
						$total_amount=$total_amount+$amount;
						$total_qty=$total_qty+$key_details["qty"];	
					}
					$result[$i]=array(
					'id' => $id,	
					'invoice_no' => $invoice_no,
					'date_issued' => $date,
					'name' => $name,
					'total_qty' => $total_qty,
					'total_amount' => $total_amount
					);
					
					array_push($invoice,$result[$i]);
					$i++;
				}
				
				print '{"members":'.json_encode($invoice).'}';
			
			break;
			
			case "searchCustomer";
			
				$customer = array();
				$result_name = array();
			
				$search=trim($_REQUEST['inputsearch']);
				$category=$_REQUEST['category'];
				
				$where = "a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) LIKE '%".$search."%'";
				$rows = "a.*,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name, b.province_name as province_name, c.city_name as city_name, d.branch_name, a.customer_subd_brgy as brgy, a.customer_street_num as street";
				$db->select("tbl_customer a, tbl_province b, tbl_city c, tbl_branch d",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "deleteInvoice";
			
				$id = $_REQUEST["id"];
				$invoice = $_REQUEST["invoice_no"];
				
				$db->delete("sales_invoice","id='$id'");
				
				$db->delete("invoice_details","invoice_no='$invoice'");
				
				print "deleted";
			
			break;
			
			case "loadCustomerId";
			
				$last_name = $_REQUEST["last_name"];
				$first_name = $_REQUEST["first_name"];
				$middle_name = $_REQUEST["middle_name"];
				
				$where = "a.last_name='$last_name' AND a.first_name='$first_name' AND a.middle_name='$middle_name' AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id = d.id";
				$rows = "a.id, a.last_name, a.first_name, a.middle_name, b.province_name, c.city_name, a.customer_subd_brgy as brgy, a.customer_street_num as street,d.branch_code";
				$db->select("tbl_customer a, tbl_province b, tbl_city c,tbl_branch d",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			// SALES RETURN
			
			case "saveReturn";
				
				$sr_no = $_REQUEST["sr_no"];
				$date_returned = $_REQUEST["date_returned"];
				$customer_id = $_REQUEST["customer_id"];
				$address = $_REQUEST["address"];
				$table = $_REQUEST["table"];
				
				$rows1 = "*";
				$where1 = "sr_no=".$sr_no;
				
				$db->select("sales_return", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
					
					$rows = "sr_no,date_returned,customer_id,address,source";
					$values = array($sr_no,$date_returned,$customer_id,$address,$table);
					
					$db->insert('sales_return',$values,$rows);
					
					echo "saved";
					
				}
			
			break;
			
			case "loadReturnData";
				
				$sr_no = $_REQUEST["sr_no"];
				
				$where = "a.sr_no='$sr_no' AND a.customer_id=b.id";
				$rows = "a.*,a.id as id,b.id as cid,CONCAT(b.last_name,', ',b.first_name,' ',b.middle_name) as customer_name";
				$db->select("sales_return a, tbl_customer b",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadReturnItems";
			
				$dataArray_motors=array();
				$dataArray_parts=array();
				$dataArray_consumables=array();
				$dataArray_promo=array();
				$dataArray=array();
				
				$sr_no = $_REQUEST["sr_no"];
				$i=0;
				
				$where = "sr_no=".$sr_no;
				$rows = "*";
				$db->select("sr_details",$rows,$where);
				$res = $db->getResult();
				
				foreach($res as $data) {
					
					$sr_no = $data["sr_no"];
					$invoice = $data["invoice_no"];
					$item_type = $data["item_type"];
					$item_id = $data["item_id"];
					$qty=$data["qty"];
					$selling_price=$data["selling_price"];
					$reason = $data["reason"];
					
					if($item_type == "motorcycle") {
					
						$where1 = "a.id=c.item_id AND a.model=b.motor_id AND a.brand=d.id AND c.item_type='motorcycle' AND c.item_id=".$item_id." AND c.sr_no=".$sr_no;
						$rows1 = "DISTINCT(c.item_id),d.brand,b.model as item,CONCAT('MAKE & TYPE: ',d.brand,' ',b.model,'<br> MOTOR NO.: ',a.engine_no,'<br> FRAME NO.: ',a.frame_no,'<br> COLOR: ',a.color) as description,c.id as id,b.motor_id as itemid,c.item_type as item_type,c.sr_no as sr_no,c.invoice_no as invoice_no";
						$db->select("stocks_motors a, tbl_motorcycle b, sr_details c, tbl_manufacturer d",$rows1,$where1);
						$result_motors = $db->getResult();
						
						foreach($result_motors as $data_motors) {
							
							$new_array[$i]=array(
								'id' => $data_motors["id"],
								'sr_no' => $data_motors["sr_no"],
								'invoice_no' => $data_motors["invoice_no"],
								'item_id' => $data_motors["item_id"],
								'item' => $data_motors["item"],
								'description' => $data_motors["description"],
								'itemid' => $data_motors["itemid"],
								'item_type' => $data_motors["item_type"],
								'qty' => $qty,
								'selling_price' => $selling_price
							);
							array_push($dataArray_motors,$new_array[$i]);
						}
						
					}
					else if($item_type == "parts"){
					
						$where1 = "c.item_id=a.id AND a.item=b.parts_id AND c.item_type='parts' AND a.brand=d.id AND c.item_id=".$item_id." AND c.sr_no='$sr_no' GROUP BY a.serial_no";
						$rows1 = "DISTINCT(c.item_id),a.*,d.brand,b.item_code as item,d.brand,b.item_code,a.serial_no,b.description,c.id as id,b.parts_id as itemid,c.item_type as item_type,c.sr_no as sr_no,c.invoice_no as invoice_no";
						$db->select("stocks_parts a, tbl_parts b, sr_details c, tbl_manufacturer d",$rows1,$where1);
						$result = $db->getResult();
						
						foreach($result as $data) {
							$serial=$data["serial_no"];
							$where2 = "c.item_id=a.id AND a.item=b.parts_id AND c.item_type='parts' AND a.brand=d.id AND c.item_id=".$item_id." AND c.sr_no='$sr_no' AND a.serial_no='$serial' GROUP BY a.serial_no";
							$rows2 = "DISTINCT(c.item_id),a.*,d.brand,b.item_code as item,CONCAT('MAKE & TYPE: ',d.brand,' ',b.item_code,'<br> SERIAL NO.: ',a.serial_no,'<br> DESCRIPTION: ',b.description) as description,c.id as id,b.parts_id as itemid,c.item_type as item_type,c.sr_no as sr_no,c.invoice_no as invoice_no,SUM(c.qty) as qty";
							$db->select("stocks_parts a, tbl_parts b, sr_details c, tbl_manufacturer d",$rows2,$where2);
							$result_parts = $db->getResult();
						
							foreach($result_parts as $data_parts){
								$new_array[$i]=array(
									'id' => $data_parts["id"],
									'sr_no' => $data_parts["sr_no"],
									'invoice_no' => $data_parts["invoice_no"],
									'item_id' => $data_parts["item_id"],
									'item' => $data_parts["item"],
									'itemid' => $data_parts["itemid"],
									'item_type' => $data_parts["item_type"],
									'description' => $data_parts["description"],
									'qty' => $qty,
									'selling_price' => $selling_price
								);
								array_push($dataArray_parts,$new_array[$i]);
							}
						
						}
					
					}
					else if($item_type == "consumables"){
						$where1 = "c.item_id=a.id AND a.item=b.con_id AND c.item_type='consumables' AND a.brand=d.id AND c.item_id='$item_id' AND c.sr_no='$sr_no' GROUP BY a.serial_no";
						$rows1 = "DISTINCT(c.item_id),a.*,d.brand,b.item_code as item,d.brand,b.item_code,a.serial_no,b.description,c.id as id,b.con_id as itemid,c.item_type as item_type,c.sr_no as sr_no,c.invoice_no as invoice_no";
						$db->select("stocks_consumables a, tbl_consumables b, sr_details c, tbl_manufacturer d",$rows1,$where1);
						$result = $db->getResult();
						
						foreach($result as $data) {
							$serial=$data["serial_no"];
							$where2 = "c.item_id=a.id AND a.item=b.con_id AND c.item_type='consumables' AND a.brand=d.id AND c.item_id='$item_id' AND c.sr_no='$sr_no' AND a.serial_no='$serial' GROUP BY a.serial_no";
							$rows2 = "DISTINCT(c.item_id),a.*,d.brand,b.item_code as item,CONCAT('MAKE & TYPE: ',d.brand,' ',b.item_code,'<br> SERIAL NO.: ',a.serial_no,'<br> DESCRIPTION: ',b.description) as description,c.id as id,b.con_id as itemid,c.item_type as item_type,c.sr_no as sr_no,c.invoice_no as invoice_no,SUM(c.qty) as qty";
							$db->select("stocks_consumables a, tbl_consumables b, sr_details c, tbl_manufacturer d",$rows2,$where2);
							$result_cons = $db->getResult();
						
							foreach($result_cons as $data_cons){
								$new_array[$i]=array(
									'id' => $data_cons["id"],
									'sr_no' => $data_cons["sr_no"],
									'invoice_no' => $data_cons["invoice_no"],
									'item_id' => $data_cons["item_id"],
									'item' => $data_cons["item"],
									'itemid' => $data_cons["itemid"],
									'item_type' => $data_cons["item_type"],
									'description' => $data_cons["description"],
									'qty' => $qty,
									'selling_price' => $selling_price
								);
								array_push($dataArray_consumables,$new_array[$i]);
							}
						}
					}
					else if($item_type == "promo"){
						$where1="c.item_id=a.id AND a.item=b.promo_id AND a.brand=d.id AND c.item_id=".$item_id." AND c.item_type='promo' AND c.sr_no=".$sr_no;
						$rows1="DISTINCT(c.item_id),a.*,d.brand,b.item_code as item,CONCAT('MAKE & TYPE: ',d.brand,' ',b.item_code,'<br> SERIAL NO.: ',a.serial_no,'<br> COLOR: ',a.color,'<br> DESCRIPTION: ',b.description) as description,c.id as id,b.promo_id as itemid,c.item_type as item_type,c.invoice_no as invoice_no,c.sr_no as sr_no";
						$db->select('stocks_promo a, tbl_promo b, sr_details c, tbl_manufacturer d',$rows1,$where1);
						$result_promo= $db->getResult();
						
						foreach($result_promo as $data_promo){
							$new_array[$i]=array(
								'id' => $data_promo["id"],
								'sr_no' => $data_promo["sr_no"],
								'invoice_no' => $data_promo["invoice_no"],
								'item_id' => $data_promo["item_id"],
								'item' => $data_promo["item"],
								'itemid' => $data_promo["itemid"],
								'item_type' => $data_promo["item_type"],
								'description' => $data_promo["description"],
								'qty' => $qty,
								'selling_price' => $selling_price
								
							);
							array_push($dataArray_promo,$new_array[$i]);
						}
						
					}
					$i++;
				}
				
				$dataArray=array_merge($dataArray_motors,$dataArray_parts,$dataArray_consumables,$dataArray_promo);
				
				print '{"members":'.json_encode($dataArray).'}';
				
			break;
			
			case "loadBrandReturn";
			
				$category = $_REQUEST["category"];
				
				if($category == "1") {
					$where="category=1 AND a.id=b.brand AND b.status='SOLD'";
					$rows="DISTINCT(a.brand) as brand, a.id as id";
					$db->select('tbl_manufacturer a, stocks_motors b',$rows,$where);
				}
				
				else if($category == "2") {
					$where="category=2 AND a.id=b.brand AND b.id=c.item_id";
					$rows="DISTINCT(a.brand) as brand, a.id as id";
					$db->select('tbl_manufacturer a, stocks_parts b, invoice_details c',$rows,$where);
				}
				else if($category == "3") {
					$where="category=3 AND a.id=b.brand AND b.status='SOLD'";
					$rows="DISTINCT(a.brand) as brand, a.id as id";
					$db->select('tbl_manufacturer a, stocks_promo b, invoice_details c',$rows,$where);
				}
				else if($category == "4") {
					$where="category=4 AND a.id=b.brand AND b.id=c.item_id";
					$rows="DISTINCT(a.brand) as brand, a.id as id";
					$db->select('tbl_manufacturer a, stocks_consumables b',$rows,$where);
				}
				else {
				}
				
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadModelReturn";
			
				$brand = $_REQUEST["brand_id"];
				
				$where="a.brand='$brand' AND b.model=a.motor_id AND b.status='SOLD'";
				$rows="a.model as model,a.motor_id as motor_id";
				$db->select('tbl_motorcycle a, stocks_motors b',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadCodeReturn";
			
				$brand = $_REQUEST["brand_id"];
				
				$where = "a.brand='$brand' AND b.item=a.parts_id";
				$rows = "DISTINCT(a.item_code) as item_code, a.parts_id as parts_id";
				$db->select("tbl_parts a, stocks_parts b",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadConsumablesReturn";
			
				$brand = $_REQUEST["brand_id"];
				
				$where="a.brand='$brand' AND b.item=a.con_id";
				$rows="DISTINCT(a.item_code) as item_code,a.con_id as con_id";
				$db->select('tbl_consumables a, stocks_consumables b',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadPromoReturn";
			
				$brand = $_REQUEST["brand_id"];
				
				$where = "a.brand='$brand' AND b.item=a.promo_id AND b.status='SOLD'";
				$rows = "a.item_code as item_code,a.promo_id as promo_id";
				$db->select("tbl_promo a, stocks_promo b",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadReturnStockMotor";
			
				$result=array();
				$motor = array();
				$status = "SOLD";
			
				$model = $_REQUEST["model"];
				
				$where = "a.model='$model' AND a.model=b.motor_id AND a.status='$status' AND a.id=c.item_id AND c.item_type='motorcycle'";
				$rows = "a.*,a.model as model, a.status as status, c.qty as qty, c.selling_price";
				$db->select('stocks_motors a, tbl_motorcycle b, invoice_details c',$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $data){
				
					$where="a.model=b.motor_id AND a.model=".$data['model']." AND a.status='$status' AND a.id=c.item_id AND b.brand=d.id AND c.item_type='motorcycle'";
					$rows="a.id,c.invoice_no,CONCAT('MAKE & TYPE: ',d.brand,' ',b.model,'<br> ENGINE NO.: ',a.engine_no,'<br> FRAME NO.: ',a.frame_no,'<br> COLOR: ',a.color) as description,a.status,c.qty,c.selling_price";
					
					$db->select('stocks_motors a, tbl_motorcycle b, invoice_details c, tbl_manufacturer d',$rows,$where);
					$result = $db->getResult();
				
				}
			
				for($i=0;$i<count($result);$i++){
					array_push($motor,$result[$i]);
				}
					
				print '{"members":'.json_encode($motor).'}';
			
			break;
			
			case "loadStockPartsReturn";
				
				$parts = array();
				$result = array();
				$item = $_REQUEST["item_code"];
				
				$where = "a.item='$item' AND a.id=c.item_id AND c.item_type='parts'";
				$rows = "a.id,a.dr_no,a.brand,a.item,a.serial_no,c.qty,c.invoice_no,c.selling_price";
				$db->select("stocks_parts a, invoice_details c",$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $data) {
					$where = "a.item=".$data['item']." AND a.id=c.item_id AND c.item_type='parts' AND c.invoice_no=".$data['invoice_no'];
					$rows = "a.id,a.dr_no,a.brand,a.item,a.serial_no,SUM(c.qty) as remain,c.invoice_no,c.selling_price";
					$db->select("stocks_parts a, invoice_details c",$rows,$where);
					$result = $db->getResult();
				}
				
				for($i=0;$i<count($result);$i++){
					array_push($parts,$result[$i]);
				}
				
				print '{"members":'.json_encode($parts).'}';
			
			break;
			
			case "loadStockConsumablesReturn";
			
				$result = array();
				$cons = array();
				$item = $_REQUEST["item_code"];
				
				$where = "a.item='$item' AND a.id=c.item_id AND c.item_type='consumables'";
				$rows = "a.id,a.dr_no,a.brand,a.item,a.serial_no,c.qty,c.invoice_no,c.selling_price";
				$db->select("stocks_consumables a, invoice_details c",$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $data){
					$data_item = $data['item'];
					$data_invoice = $data['invoice_no'];
					$data_id = $data['id'];
					
					$where = "a.item='$data_item' AND a.id=c.item_id AND c.item_type='consumables'";
					$rows = "a.id,a.dr_no,a.brand,a.item,a.serial_no,SUM(c.qty) as remain,c.invoice_no,c.selling_price";
					$db->select("stocks_consumables a, invoice_details c",$rows,$where);
					$result = $db->getResult();
					
				}
				
				for($i=0;$i<count($result);$i++){
					array_push($cons,$result[$i]);
				}
				
				print '{"members":'.json_encode($cons).'}';
			
			break;
			
			case "loadStockPromoReturn";
			
				$result = array();
				$promo = array();
				$item = $_REQUEST["item_code"];
				$status = "SOLD";
				
				$where = "a.item='$item' AND a.item=b.promo_id AND a.id=c.item_id AND a.status='$status'";
				$rows = "a.*,a.item as item, a.status as status, c.qty as qty, c.selling_price";
				$db->select("stocks_promo a, tbl_promo b, invoice_details c",$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $data){
					
					$where = "a.item=b.promo_id AND a.item=".$data['item']." AND a.id=c.item_id AND b.brand=d.id AND a.status='$status'";
					$rows = "a.id,c.invoice_no,CONCAT('MAKE & TYPE: ',d.brand,' ',b.item_code,'<br> SERIAL NO.: ',a.serial_no,'<br> COLOR: ',a.color,'<br> DESCRIPTION: ',b.description) as description,a.status,c.qty,c.selling_price";
					$db->select("stocks_promo a, tbl_promo b, invoice_details c, tbl_manufacturer d",$rows,$where);
					$result = $db->getResult();
				
				}
				
				for($i=0;$i<count($result);$i++){
					array_push($promo,$result[$i]);
				}
				
				print '{"members":'.json_encode($promo).'}';
			
			break;
			
			case "saveReturnParts";
				
				$array = $_REQUEST["array"];
				$selling_price = $_REQUEST["selling_price"];
				$sr_no = $_REQUEST["sr_no"];
				$invoice_no = $_REQUEST["invoice_no"];
				$item_type = $_REQUEST["item_type"];
				$quantity = $_REQUEST["quantity"];
				$reason = $_REQUEST["reason"];
				$var = $quantity;
				
				foreach($array as $key => $val){
				
					$where = "a.serial_no='$val' AND a.id=b.item_id AND a.dr_no=c.dr_no";
					$rows = "a.id,a.brand,a.item,a.serial_no,b.qty,c.date";
					$order = "c.date desc";
					$db->select("stocks_parts a, invoice_details b, stocks c",$rows,$where,$order);
					$result = $db->getResult();
					
						foreach($result as $info){
						
									$id = $info['id'];
									$brand = $info['brand'];
									$item = $info['item'];
									$serial_no = $info['serial_no'];
									$remaining = $info['qty'];
									
									$c = $var;
									$answer = ($var - $remaining);
									$var = $answer;

									if($var < 0) $var = 0;
									if($var > 0){

									$rowsx = array('qty' => '0');
									$wherex ="item_id = '$id' AND item_type='parts'";
									$db->update("invoice_details",$rowsx,$wherex);

									$rows ="sr_no,invoice_no,item_type,item_id,qty,selling_price,reason";
									$values = array($sr_no,$invoice_no,$item_type,$id,$remaining,$selling_price,$reason);
									$db->insert("sr_details",$values,$rows);
				  
									}else{

									$answer = abs($answer); 
									$rowsx = array('qty' => $answer);
									$wherex ="item_id = '$id' AND item_type='parts'";
									$db->update("invoice_details",$rowsx,$wherex); 
									
									$rows ="sr_no,invoice_no,item_type,item_id,qty,selling_price,reason";
									$values = array($sr_no,$invoice_no,$item_type,$id,$c,$selling_price,$reason);
									$db->insert("sr_details",$values,$rows);
									
									break; 
									}
						}
				
				}
				print "uhryt";
			
			break;
			
			case "saveReturnConsumables";
			
				$array = $_REQUEST["array"];
				$selling_price = $_REQUEST["selling_price"];
				$sr_no = $_REQUEST["sr_no"];
				$invoice_no = $_REQUEST["invoice_no"];
				$item_type = $_REQUEST["item_type"];
				$quantity = $_REQUEST["quantity"];
				$reason = $_REQUEST["reason"];
				$var = $quantity;
					
				foreach($array as $key => $val){
					
					$where = "a.id=b.item_id AND b.item_type='consumables' AND a.serial_no='$val' AND a.dr_no=c.dr_no";
					$rows = "a.id,a.brand,a.item,a.serial_no,b.qty,c.date";
					$order = "c.date DESC";
					$db->select("stocks_consumables a, invoice_details b, stocks c",$rows,$where,$order);
					$result = $db->getResult();
				
					foreach($result as $info){
						
						$id = $info['id'];
						$brand = $info['brand'];
						$item = $info['item'];
						$serial_no = $info['serial_no'];
						$remaining = $info['qty'];
						 	
						$c = $var;
						$answer = ($var - $remaining);
						$var = $answer;

						if($var < 0) $var = 0; 
						if($var > 0){

						$rowsx = array('qty' => '0');
						$wherex ="item_id='$id' AND item_type='consumables'";
						$db->update("invoice_details",$rowsx,$wherex);

						$rows ="sr_no,invoice_no,item_type,item_id,qty,selling_price,reason";
						$values = array($sr_no,$invoice_no,$item_type,$id,$remaining,$selling_price,$reason);
						$db->insert("sr_details",$values,$rows);
	  
						}else{

						$answer = abs($answer);
						$rowsx = array('qty' => $answer);
						$wherex ="item_id = '$id' AND item_type='consumables'";
						$db->update("invoice_details",$rowsx,$wherex); 
						
						$rows ="sr_no,invoice_no,item_type,item_id,qty,selling_price,reason";
						$values = array($sr_no,$invoice_no,$item_type,$id,$c,$selling_price,$reason);
						$db->insert("sr_details",$values,$rows);
						break; 
						}
					}
				
				}
				print "uhryt";
			
			break;
			
			case "saveReturnData";
				
				$sr_no = $_REQUEST["sr_no"];
				$invoice_no = $_REQUEST["invoice_no"];
				$item_type = $_REQUEST["item_type"];
				$item_id = $_REQUEST["item_id"];
				$qty = $_REQUEST["qty"];
				$price = $_REQUEST["selling_price"];
				$reason = $_REQUEST["reason"];
				
				if($item_type == "motorcycle") {
					$table_name = "stocks_motors";
				}
				if($item_type == "parts") {
					$table_name = "stocks_parts";
				}
				if($item_type == "consumables") {
					$table_name = "stocks_consumables";
				}
				if($item_type == "promo") {
					$table_name = "stocks_promo";
				}
				
				$rows2 = "*";
				$where2 = "id=".$item_id;
				$db->select($table_name,$rows2,$where2);
				$result1 = $db->getResult();
				
				foreach($result1 as $data) {
				
					$rows1 = "*";
					$where1 = "sr_no = '$sr_no' AND invoice_no ='$invoice_no' AND item_type='$item_type' AND item_id=".$data['id'];
					
					$db->select("sr_details", $rows1, $where1);
					$result = $db->getResult();
					
					if(count($result)>0){
						echo "exists";
					}
					
					else {
						$status = "SALES RETURNED";
					
						$rows ='sr_no,invoice_no,item_type,item_id,qty,selling_price,reason';
						$values = array($sr_no,$invoice_no,$item_type,$item_id,$qty,$price,$reason);
						
						$db->insert('sr_details',$values,$rows);
						
						$where_stocks = "id=".$data['id'];
						$rows_stocks = array('status' => $status);
						$db->update($table_name,$rows_stocks,$where_stocks);
						
						echo "saved";
						
					}
				
				}
			
			break;
			
			case "loadSalesReturn";
			
				$return = array();
				$result = array();
				
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$category=$_REQUEST['category'];
				$branch_id=$_REQUEST['branch_id'];
				
				$trimmed=trim($_REQUEST['inputsearch']);
				
				if($branch_id != 1){
					$where = "b.branch_id = '$branch_id' AND  a.customer_id=b.id and $category LIKE '%".$trimmed."%'";
				}else{
					$where = " a.customer_id=b.id and $category LIKE '%".$trimmed."%'";
				}
				
				
				$rows = "a.*,b.first_name,b.last_name,b.middle_name";
				$db->select("sales_return a,tbl_customer b",$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $key){
					$total_qty=0;
					$total_amount=0;
					$id=$key["id"];
					$sr_no=$key["sr_no"];
					$date=$key["date_returned"];
					$name=$key["last_name"]." , ".$key["first_name"]." ".$key["middle_name"];
					$customer_id=$key["customer_id"];
					
					$where1 = "sr_no=$sr_no";
					$rows1 = "*";
					$db->select("sr_details",$rows1,$where1);
					$result2 = $db->getResult();
					
					foreach($result2 as $key_details){
						$amount=$key_details["qty"]*$key_details["selling_price"];	
						$total_amount=$total_amount+$amount;
						$total_qty=$total_qty+$key_details["qty"];	
					}
					$result[$i]=array(
						'id' => $id,
						'sr_no' => $sr_no,
						'date_returned' => $date,
						'name' => $name,
						'total_qty' => $total_qty,
						'total_amount' => $total_amount,
						'customer_id' => $customer_id
					);
					
					array_push($return,$result[$i]);
					$i++;
				}
				if(count($return) > 0) {
					$sortArray = array(); 
					
					foreach($return as $total){ 
						foreach($total as $key=>$value){
							if(!isset($sortArray[$key])){
								$sortArray[$key] = array(); 
							}
							$sortArray[$key][] = $value;
						}
					}
					
					$orderby = $sort;
					if($_REQUEST["sortType"]=="ASC"){
						array_multisort($sortArray[$orderby],SORT_ASC,$return);
					}
					else{
						array_multisort($sortArray[$orderby],SORT_DESC,$return);
					}
				}
				
				print '{"members":'.json_encode($return).'}';
			
			break;
			
			case "deleteReturnItem";
			
				$item_id = $_REQUEST["item_id"];
				$type = $_REQUEST["item_type"];
				$status = "SOLD";
			
				if($type == "motorcycle") {
					$table_name = "stocks_motors";
					$where = "id=".$item_id;
					$rows = array('status' => $status);
					$db->update($table_name,$rows,$where);
					
					$id = $_REQUEST["id"];
					$db->delete("sr_details","id='$id'");
				}
				if($type == "parts") {
					$id = $_REQUEST["id"];
					$db->delete("sr_details","id='$id'");
				}
				if($type == "consumables") {
					$id = $_REQUEST["id"];
					$db->delete("sr_details","id='$id'");
				}
				if($type == "promo") {
					$table_name = "stocks_promo";
					$where = "id=".$item_id;
					$rows = array('status' => $status);
					$db->update($table_name,$rows,$where);
					
					$id = $_REQUEST["id"];
					$db->delete("sr_details","id='$id'");
				}
				
				print "deleted";
			
			break;
			
	case "delete_SALESReturn";
			
				 $idx = $_REQUEST["id"];
				 $sr_no = $_REQUEST["sr_no"];
				 
				 
				 $db->select("sr_details","*","sr_no='$sr_no'");
				$result = $db->getResult();
				
		foreach($result as $info){
				
						$id = $info['id'];
						$sr_no = $info['sr_no'];
						$invoice_no = $info['invoice_no'];
						$stock_id = $info['stock_id'];
						$inv_id = $info['inv_id'];
						$category = $info['category'];
						$quantity = $info['qty'];
						$reason = $info['reason'];
						$source = $info['source'];
						
						
						if($source =="invoice"){
						
						$table = "sale_invoice_details";
						$col = "invoice_no";
						
						}else if($source =="cash"){
						
						$table = "collection_cash";
						$col = "or_no";
						}
						
						$where="$col = '$invoice_no' AND stock_id = '$stock_id' AND category = '$category' ";
						$db->select($table,"*",$where);
						$result = $db->getResult();
						
							foreach($result as $infox){
								$idx = $infox['id'];
								 $qty = $infox['qty'];
							}
						 $sum = $qty+$quantity;
						 
						 $wherex="$col = '$invoice_no' AND stock_id = '$stock_id' AND category = '$category' ";
						 $rowsx = array('qty' =>$sum );
						 $db->update($table,$rowsx,$wherex);
						
						if($category == '2'){
										
							$where = "id = '$stock_id'";
							$db->select("stocks_parts",'remaining',$where);
							$resulty = $db->getResult();
								
								 foreach($resulty as $data){
									$remaining = $data['remaining'];
								 }
							$sumy = $remaining - $quantity;
							
							$rowsy = array('remaining' => $sumy);
							$wherey ="id = '$stock_id'";
							$db->update("stocks_parts",$rowsy,$wherey);
										
										
						}else if($category == '4'){
										
										 
							$where = "id = '$stock_id'";
							$db->select("stocks_consumables",'remaining',$where);
							$resulty = $db->getResult();
								
								 foreach($resulty as $data){
								  $remaining = $data['remaining'];
								}
					 
					 
				
						$sumy = $remaining - $quantity;
						$rowsy = array('remaining' => $sumy);
						$wherey ="id = '$stock_id'";
						$db->update("stocks_consumables",$rowsy,$wherey);
					
						}else if($category == '1'){
			
						$rowsy = array('status' => 'SOLD');
						$wherey ="id = '$stock_id'";
						$db->update("stocks_motors",$rowsy,$wherey);
				
				
						}else if($category == '5'){
				
						$rowsy = array('status' => 'SOLD');
						$wherey ="id = '$stock_id'";
						$db->update("stock_repo",$rowsy,$wherey);
				
						}else if($category == '3'){
						
							 $rowsy = array('status' => 'SOLD');
							$wherey ="id = '$stock_id'";
							$db->update("stocks_promo",$rowsy,$wherey);
						}
						
						
						
						
						
						
						
		}
		
		$wherexx="sr_no='$sr_no'";
		$db->delete("sales_return",$wherexx);
		
		$whereyy="sr_no='$sr_no'";
		$db->delete("sr_details",$whereyy);
				
		print "deleted"; 
			
	break;
			
			case "updateReturnDetails";
			
				$id=$_REQUEST["id"];
				$sr_no=$_REQUEST["sr_no"];
				$date_returned=$_REQUEST["date_returned"];
				$customer_id=$_REQUEST['customer_id'];
				$address=$_REQUEST['address'];
				
				$where="id=".$id;
				$rows = array('sr_no' => $sr_no , 'date_returned' => $date_returned , 'customer_id' => $customer_id , 'address' => $address);
				$db->update('sales_return',$rows,$where);
				
				echo "updated";
			
			break;
			
			case "searchReturn";
				
				$return = array();
			
				$search=trim($_REQUEST['inputsearch']);
				$category=$_REQUEST['category'];
				
				if($category=="sr_no"){
					$rows ="a.*,b.first_name,b.last_name,b.middle_name";
					$where = " a.sr_no LIKE '%".$search."%' AND a.customer_id = b.id";
					$db->select('sales_return a, tbl_customer b',$rows,$where); 
				}
				
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $key){
					$total_qty=0;
					$total_amount=0;
					$sr_no=$key["sr_no"];
					$date=$key["date_returned"];
					$name=$key["last_name"]." , ".$key["first_name"]." ".$key["middle_name"];
					$id=$key["id"];
					
					$where1 = "sr_no=$sr_no";
					$rows1 = "*";
					$db->select("sr_details",$rows1,$where1);
					$result2 = $db->getResult();
					
					foreach($result2 as $key_details){
						$amount=$key_details["qty"]*$key_details["selling_price"];	
						$total_amount=$total_amount+$amount;
						$total_qty=$total_qty+$key_details["qty"];	
					}
					$result[$i]=array(
					'id' => $id,	
					'sr_no' => $sr_no,
					'date_returned' => $date,
					'name' => $name,
					'total_qty' => $total_qty,
					'total_amount' => $total_amount
					);
					
					array_push($return,$result[$i]);
					$i++;
				}
				
				print '{"members":'.json_encode($return).'}';
			
			break;
			
			case "updateORnumber";
			
				$id=$_REQUEST["id"];
				$address=$_REQUEST["address"];
				$branch_code=$_REQUEST["branch_code"];
				echo $or_no=$_REQUEST["or_no"];

				$where = "or_no=".$or_no;
				
				$rows = array('customer_id' => $id
				,'address' => $address
				,'branch_code' => $branch_code
				);
			  
			$db->update('collections',$rows,$where); 				
					
			echo "saved";	
			break;
			
			
			
		}
		
	}

?>