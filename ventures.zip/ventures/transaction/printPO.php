<html>
<title>PURCHASE ORDER</title>
</html>

<style>
.x:nth-child(even) td{
	background:lightgray;
}

</style>
<?php
include('../database.php');  
$db = new Database();  
$db->connect(); 

	$dataArray=array();
	$po_no=$_REQUEST["po_no"];
	
	$row = "a.id,a.po_num,b.supplier_name,a.date,a.terms";
	$where="a.supplier=b.id and a.po_num=$po_no";
	
	$db->select('purchase_order a,tbl_supplier b',$row,$where);

	$results = $db->getResult();

	//print_r($results);
	
	foreach($results as $keys){		
		$po_num=$keys["po_num"];
		
		$date=$keys["date"];
		$terms=$keys["terms"];
		$supplier=$keys["supplier_name"];
		
		$row2 = "*";
		$where2="po_num=$po_num";
		$db->select('purchase_order_details',$row2,$where2);

		$result = $db->getResult();
		
		
		$i=0;
		foreach($result as $key){
			
			if($key["category"]==1){
				$item=$key["item"];
				$where_item="a.motor_id=$item and a.brand=b.id";
				$db->select('tbl_motorcycle a,tbl_manufacturer b','a.model,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["model"];
				}
				
				
			}
			else if($key["category"]==2){
				$item=$key["item"];
				$where_item="a.parts_id=$item and a.brand=b.id";
				$db->select('tbl_parts a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
				}
				
				
			}
			else if($key["category"]==3){
				$item=$key["item"];
				$where_item="a.promo_id=$item and a.brand=b.id";
				$db->select('tbl_promo a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
				}
				
				
			}
			else if($key["category"]==4){
				$item=$key["item"];
				$where_item="a.con_id=$item and a.brand=b.id";
				$db->select('tbl_consumables a,tbl_manufacturer b','a.item_code,b.brand',$where_item);
				
				$result_items = $db->getResult();
				
				foreach($result_items as $key_item){
					$brand=$key_item["brand"];
					$item=$key_item["item_code"];
				}
				
				
			}
			
			$new_arr[$i]=array(
			'id'=> $key["id"],	
			'branch'=> $key["branch"],
			'particulars'=> $brand." ".$item." ".$key["color"],
			'qty'=> $key["qty"],
			'unit_cost'=> $key["unit_cost"],
			);
			array_push($dataArray,$new_arr[$i]);
			
			
			$i++;	
			
		}
		
		//echo '{"members":'.json_encode($dataArray).'}';
			
	}		
	
	
	
	

	echo" 
	<div align='center' style='font-family:Calibri'>
	<table border=0 width='1000' cellpadding=2 cellspacing=0>
		<tr><td><b>P.O. No.:</b> $po_num</td><td align='right' colspan=4><b>Date:</b> $date</td></tr>
		<tr><td><b>Supplier:</b> $supplier</td><td align='right' colspan=4><b>Terms:</b> $terms</td></tr>
		<tr><td colspan=5 align='center' style='padding:20px 0px 10px 0px;border-bottom:2px solid #000'><b>PURCHASE ORDER DETAILS</b></td></tr>
		<tr><td style='border-bottom:2px solid #000' align='center' width='25%'><b>BRANCH</b></td><td colspan=2 align='center' style='border-bottom:2px solid #000'><b>ITEM DESCRIPTION</b></td><td width='25%' align='center' style='border-bottom:2px solid #000'><b>QTY</b></td><td width='25%' align='center' style='border-bottom:2px solid #000'><b>UNIT COST</b></td></tr>";
	
	if(count($dataArray)>0){
		$total_qty=0;
		$total_cost=0;
		foreach($dataArray as $key){
			$total_qty=$total_qty+$key['qty'];
			$total_cost=$total_cost+$key['unit_cost'];
			echo "<tr align='center' class='x'><td >".$key['branch']."</td><td colspan=2>".$key['particulars']."</td><td>".$key['qty']."</td><td>".number_format($key['unit_cost'],2)."</td></tr>";
			
		}
		echo "<tr><td colspan=5 align='center' style='padding:10px 0px 0px 0px;border-bottom:2px solid #000'></td></tr>";
		echo "<tr align='center' style='font-weight:bold;'><td colspan=3  style='padding:10px 0px 0px 0px'>TOTAL</td><td style='padding:10px 0px 0px 0px'>".number_format($total_qty,2)."</td><td style='padding:10px 0px 0px 0px'>".number_format($total_cost,2)."</td></tr>";
			
	}
	else{
		echo "<tr align='center'><td colspan=5  style='padding:20px 0px 0px 0px;'>*** NO ITEMS TO DISPLAY ***</td></tr>";
	}
	echo "<tr><td colspan=5 align='center' style='padding:0px 0px 10px 0px;border-bottom:2px solid #000'></td></tr>";
	echo "</table></div>";	
?>