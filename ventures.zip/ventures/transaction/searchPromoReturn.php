<!DOCTYPE HTML>
<html lang="en">
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px; margin-left:15px;" >
				<div align = "center">
					<select id = 'txtbrand' name='brand'>
						<option value="">- BRAND -</option>
					</select>
				</div>
				<div align = "center">				
					<select id = 'txtcode' name='brand'>
						<option value="">- ITEM CODE -</option>
					</select>
				</div>
				<input type = "hidden" id = "txtreturn" value = "<?php echo $_REQUEST['sr_no']; ?>">
				<table id = "promo_list" class="contents" width="750px" align = "center" style="margin-top:10px;">
					<thead align="center">
					<tr>
						<th></th><th>INVOICE<BR>NO.</th><th>PARTICULARS</th><th>UNIT<BR>PRICE</th><th>AMOUNT</th>
					</tr>
					</thead>
						<tbody id = "promo_data"></tbody>
				</table>
				<div>
					<span>
						<label>Reason</label>
						<textarea id = "txtreason"></textarea>
					</span>
				</div>
				<div align="center" style="margin-top:15px">
					<span>
					<input type="button" value="ADD" id = "btnadd">
					<input type="button" value="CANCEL"  onclick = "window.parent.closeIframeItem();">
					</span>
				</div>
			</div>
		</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadBrand();
		loadTable();
		
		$('#txtcode')
		.prop('disabled', true)
		.empty()
		.append('<option value="">- ITEM CODE -</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$( "#txtbrand" ).change(function() {
			$('#txtcode')
			.prop('disabled', false)
			.empty()
			.append('<option value="">- ITEM CODE -</option>')
			.find('option:first')
			.attr("selected","selected")
			;
			
			brand_id=$("#txtbrand :selected").val();
			brand_name=$("#txtbrand :selected").text();
			
			loadTable();
			loadModel(brand_id);
			
		});
		
		$( "#txtcode" ).change(function() {
			
			promo_id=$("#txtcode :selected").val();
			promo_name=$("#txtcode :selected").text();
			
			loadTable(promo_id);
			
		});
		
	});
	
	function loadBrand() {
		
		var url="functions.php?request=ajax&action=loadBrandReturn&category=3";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){

				$("#txtbrand").append("<option value="+ res.id+">" + res.brand + "</option>");

			});
		});
		
	}
	
	function loadModel(id){
		
		var url="functions.php?request=ajax&action=loadPromoReturn&brand_id="+id;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtcode").append("<option value="+ res.promo_id+">" + res.item_code + "</option>");

			});
		});
	}
	
	function loadTable(id) {
		$("#promo_list > tbody").empty();
	
		var url="functions.php?request=ajax&action=loadStockPromoReturn&item_code="+id;
		var counter=0;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				var invoice_no=res.invoice_no;
				price = parseFloat(Math.round((res.selling_price)*100)/100).toFixed(2);
				amount = parseFloat(Math.round((res.selling_price*res.qty)*100)/100).toFixed(2);
				
				$("#promo_list > tbody").append("<tr class = 'x'><td width = 5><input type = 'checkbox' id = 'txtcheck' value = "+res.id+"></td><td>"+invoice_no+"<input type = 'hidden' id = 'txtinvoice' value = '"+invoice_no+"'></td><td>"+res.description+"</td><td>"+price+"<input type = 'hidden' id = 'txtprice' value = '"+price+"'></td><td>"+amount+"</td></tr>");
				counter++;
			});
			if (counter <= 0){
				$("#promo_list > tbody").append("<tr id = 'noItems'><th colspan = '5' align = 'center'> No Selected Items! </th></tr>");
			}
		});
		
	}
	
	$(function() {
		$('#btnadd').click(Add);
	});
	
	function Add() {
		var item_id;
		var sr_no=$("#txtreturn").val();
		var invoice_no=$("#txtinvoice").val();
		var count=0;
		var item_type="promo";
		
		var selling_price = $("#txtprice").val();
		var qty = 1;
		var reason = $("#txtreason").val();
	
		$("#txtcheck:checked").each(function(){
			item_id=$(this).val();
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"saveReturnData","sr_no":sr_no,"invoice_no":invoice_no,"item_type":item_type,"item_id":item_id,"qty":qty,"selling_price":selling_price,"reason":reason},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Data was Successfully Saved!", "Alert Dialog");
							window.parent.closeIframeItem(sr_no);
						}
						else if(reply == 'exists'){
							jAlert('Item Already Exists!', 'Alert Dialog');
						}
						else{
							alert('Error');
							event.preventDefault();
						}
				}
			});
		});
		
	}
	
	</script>
	
</body>
</html>