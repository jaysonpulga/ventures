<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}


$_SESSION["username"];
$branch_name = $_SESSION["branch_name"];
$branch_id = $_SESSION['branch_id'];
?>
<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:700px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>SALES RETURN</h2><hr></label>
							</span>
						</div>
						<div>
							<span>
								<label>SR. No.:</label>
								<input type="text" id = "txtreturn" style="margin-left:67px; width:100px" maxlength = "6">
							</span>
							<span>
								<label style="margin-left:225px">Date:</label>
								<input type="date" id = "txtdate" style="margin-left:48px">
							</span>
						</div>
						<div>
							<span>
								<input type = "hidden" id = "txtcusid">
								
								<input type = "hidden" id = "table">
								<label>Customer Name:</label>
								<input type="text" id = "txtcusname" style = "margin-left:11px; text-align:center; width:300px;">
								<a href="#"  style="width:30px;" onclick="search_customer();"><img src="" id="search" valign="bottom"></a>
								<!--<a href="#"  style="width:30px;" onclick="new_customer();"><img src="" id="new" valign="bottom"></a> -->
							</span>
						</div>
						<div>
							<span>
								<label>Address:</label>
								<input type="text" id = "txtaddress" style=" width:400px; margin-left:61px">
							</span>
						</div>
						<div align = "center" style = "margin-top: 20px;">
							<span>
								<input type = "button" id = "btnadd" value = "CREATE" onclick = "Add();">
								<input type = "button" id = "btncancel" value = "CANCEL" onclick = "window.location='sales_return.php?menu=transaction'">
							</span>
						</div>
						
						<div id="customer_items" style="display:none;">
							<iframe id="item_dialog" width="954" height="595" style="border:none"></iframe>
						</div>
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	});
	
	function search_customer(){
			$("#customer_items").attr("title","SEARCH CUSTOMER");
			$("#item_dialog").attr('src','customer_sales.php');
			$("#customer_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	function new_customer() {
			$("#customer_items").attr("title","NEW CUSTOMER");
			$("#item_dialog").attr('src','newCustomer.php');
			$("#customer_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	function closeIframe(id,name,address,branch_code,table) {
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
		$("#table").val(table);
	}
	
	function closeIframeNew(id,name,address) {
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#txtaddress").val(address);
	}
	
	function Add() {
		var sr_no=$("#txtreturn").val();	
		var date_returned=$("#txtdate").val();	
		var customer_id=$("#txtcusid").val();
		var address=$("#txtaddress").val();
		var source = $("#table").val();
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(sr_no == ""){
			errormsg+="- Input Invoice No.\n";
		}
		if(date_returned == ""){
			errormsg+="- Input Date Returned.\n";
		}
		if(customer_id == ""){
			errormsg+="- Input Customer Name.\n";
		}
		if(address == ""){
			errormsg+="- Input Address.\n";
		}
		
		if(errormsg.length==emsg){
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"saveReturn","sr_no":sr_no,"date_returned":date_returned,"customer_id":customer_id,"address":address,"table":source},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Successfully Added!", "Alert Dialog");
							window.location = "viewReturn.php?menu=transaction&sr_no="+sr_no;
						}else if(reply == 'exists'){
							jAlert('SR No. Already Exists!', 'Alert Dialog');
						}
						else{
							alert('Error');
							event.preventDefault();
						}
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		
	}
	
	</script>