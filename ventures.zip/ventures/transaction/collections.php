<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<!DOCTYPE HTML>
<html lang="en">
<title>Collection</title>
<head>
<?php
error_reporting(E_ALL^E_NOTICE);
?>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	<script src="../js/FormatNUmberBy3.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center" >
				<div id="options-top" align="center" style="width:870px;">
					<div>
					<table width="870px">
						<tr>
							<td colspan="6" style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2>COLLECTIONS</h2>
							
								<input type="hidden" id="branch_id" value="<?php echo $_SESSION['branch_id']; ?>" >
								<input type="hidden" id="branch_name" value="<?php echo $_SESSION['branch_name']; ?>" >
								<input type="hidden" id="branch_code" value="<?php echo $_SESSION['branch_code']; ?>" >
								
							
							</td>
						</tr>
						<tr>
							<td td style="text-align:left;background:#FFF;padding:0px;border:none">	
							
								<font size="3">Category:</font><select id = 'table' name='table'>
												<option value="CASH">CASH</option>
												<option value="LOAN">LOAN</option>
												<option value="INTERBRANCH">INTERBRANCH</option>
										</select>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
								<form name="search" action="" method="POST">
									<select id = 'category' name='category'>
										<option value="or_no">O.R NO</option>
										<option value="last_name">LAST NAME</option>
										<option value="date">DATE</option>
									</select>
										<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Collection">
										<a href = "#"><input type="button" onclick="add_new()" value="ADD NEW" id='input' style="width:130px;top:1px;"></a>
								</form>
							</td>
						</tr>
					</table>
					</div>
					
					<div  class="contents" style="border:0px solid #000; margin-top:12px; width:870px" cellspacing="0">
						<table id = "collection_list">
							<thead align = "center">
								<tr>
									<th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'or_no')">O.R. #</a></th>
									<th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'customer_name')">CUSTOMER NAME</a></th>
									<th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'DATE')">DATE</a></th>
									<th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'type')">TYPE</a></th>
									<th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'amount')">AMOUNT DUE</a></th><th colspan = "2" style="width:10px;">ACTION</th>
								</tr>
							</thead>
							<tbody id = "collection_data"></tbody>
						</table>
					</div>
					
					<div id="pagination" style = "margin-top:50px;"> 
						<div class="holder" ></div>
						<i>Pages</i>
					</div>
					
					<div id="invoice_items" style="display:none;">
						<iframe id="item_dialog" width="504" height="312" style="border:none"></iframe>
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	
	$(document).ready(function(){
	
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
			menu="transaction";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		var table = $('#table').val();	
		
		
		load_collection(table,"or_no","ASC");
		
		
	});
	
	
	
	function add_new(){
	var table = $('#table').val();
	
	window.location="addCollections.php?category="+table+"&menu=transaction";
	}
	
	
	  var branch_id = $("#branch_id").val();
	  var branch_name = $("#branch_name").val();
	  var branch_code = $("#branch_code").val();
	
	
	function jpages(){
		$("div.holder").jPages({
		  containerID : "collection_data",
		   previous : "←",
				next : "→",
		  perPage : 15,
		  delay :10,
		  startPage    : 1,
		  startRange   : 1,
		  midRange     : 5,
		  endRange     : 1
		});
	}
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
				
	var sortType = "ASC";
	
	function filter_list(index,cVar){
	
	var table = $('#table').val();	
		sort = cVar;
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		load_collection(table,sort,sortType)	
	}

	
	
	
	function add_invoice() {
		$("#invoice_items").attr("title","NEW INVOICE");
		$("#item_dialog").attr('src','addInvoice.php');
		$("#invoice_items").dialog({
			width: 505,
			height: 360,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src',"about:blank");
			}
		});
		return false;
	}
	
	$("#txtsearch").live('keyup change',function(){
		$("#collection_list > tbody").empty();
		var table=$("#table").val();
		load_collection(table,"or_no","ASC");				
	})
	
	
	
	$("#table").change(function() {
			var table=$("#table").val();
			load_collection(table,"or_no","ASC");
	});
	
	
	
	function load_collection(table,sort,sortType){
	
	

	var count=0,x=0;	
	var container=$("#collection_list > tbody");
	
		$.ajax({
					url:"function_transaction.php",
					
					
					data:{"request":"ajax","action":"load_collection","type":table,"inputsearch":$("#txtsearch").val(),"category":$("#category").val(),"sort":sort,"sortType":sortType,"branch_code":branch_code},
					
				
					dataType:'json',
					beforeSend: function(){
						
					},
			success: function(reply){
							//console.log(reply.length);
				if(reply.length > 0){
					container.empty();
							$.each(reply, function(i,res){
								count++;
								
								
						var amount=FormatNumberBy3((parseFloat(res.amount)).toFixed(2));
						container.append("<tr class='x' id='record"+res.or_no+"'  onmouseover='clickSearch()' > </td><td align='center'>"+res.or_no+"</td><td align='center'>"+res.customer_name+"</td><td align='center'>"+res.date+"</td><td align='center'>"+res.type+"</td><td align='center'>"+amount+"</td><td align='center'><a href='#' alt='Update' title='Update' class='view' onclick=\"view_collection('"+res.type+"','"+res.or_no+"');\"></a></td><td align='center'><a href='#' alt='Update' title='Update' class='delete'  onclick=\"delete_item('"+res.or_no+"','"+res.type+"');\"></a></td></tr>");
																
				});
				jpages();
				}
				else{
					
				container.append("<tr id = 'noItems'><th colspan = '13' align = 'center'> No Items on record! </th></tr>");
				}
			}
		}); 

	}
	

	
	function clickSearch() {
	
		$("#txtsearch").blur();
	
	}
	
	function deleteInvoice(invoice_no,id) {
	
		jConfirm('Do you really want to DELETE this INVOICE?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "functions.php",
					data:{"request":"ajax","action":"deleteInvoice","id":id,"invoice_no":invoice_no},
					success: function(reply){
						console.log(reply);
							if(reply == 'deleted'){
								jAlert('Item Deleted','Alert Dialog');
								window.location="sales.php?menu=transaction";
							}else{
								jAlert('Error','Alert Dialog');
								event.preventDefault();
							}
						
						}
				});
			}
		});
	
	}
	
	function view_collection(type,or_no) {
		
		if(type =="CASH"){
		window.location = "cash_collection.php?menu=transaction&or_no="+or_no;
		}
		else if(type =="LOAN"){
		window.location = "loan_collection.php?menu=transaction&or_no="+or_no;
		}
		else if(type =="INTERBRANCH"){
		window.location = "interbranch_collection.php?menu=transaction&or_no="+or_no;
		}
		
		
		
	}

	function clickSearch() {
	
		$("#txtsearch").blur();
	
	}
	
	function delete_item(id,type){
	
			 jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
			if(e){
			
				
				var table2 =  "collections";
				
				if(type =="CASH"){
				
					var table1 =  "collection_cash";
					$.ajax({
						url: "function_transaction.php",
						data:{"request":"ajax","action":"deleteTwotable","id":id,"table1":table1,"table2":table2,"table_id":"or_no"},
						success: function(reply){

						}
					});
				
				}else if(type == "INTERBRANCH"){
						var table1 =  "collection_interbranch";
						$.ajax({
						url: "function_transaction.php",
						data:{"request":"ajax","action":"delete2table","id":id,"table1":table1,"table2":table2,"table_id":"or_no"},
						success: function(reply){

						}
					});
				
				} else if (type == "LOAN"){
						var table1 =  "collection_loan";
						$.ajax({
						url: "function_transaction.php",
						data:{"request":"ajax","action":"delete2table","id":id,"table1":table1,"table2":table2,"table_id":"or_no"},
						success: function(reply){

						}
					});
					
				}
				
				$('#record'+id).animate({ backgroundColor: '#fbc7c7' }, 'fast')
			.animate({ opacity: "hide" }, "slow");
				
			jAlert("successfully Deleted");
			load_collection(table,"or_no","ASC");	
			}
		
		});
	}
	
	</script>
	
</body>
</html>