<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Purchase</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<input type="hidden" id="branch_id" value="<?php echo $_SESSION['branch_id']; ?>" >
<input type="hidden" id="branch_name" value="<?php echo $_SESSION['branch_name']; ?>" >
<input type="hidden" id="branch_code" value="<?php echo $_SESSION['branch_code']; ?>" >
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:1000px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>NEW PURCHASE RETURN</h2><hr></label>
								<input type="hidden" style=" width:100px;margin-left:10px;" id="PR" name="PR" value="<?php echo $_REQUEST["pr_num"]; ?>" >
							</span>
						</div>
						<div>
							<span>
							
								<label>P.R. No.:</label>
								
								<input type="text" style=" width:100px;margin-left:10px;" id="PR_num" name="PR_num" readonly="readonly" >
							</span>
							<span>
								<label style="margin-left:600px">Date:</label>
								<input type="date" style="margin-left:10px; text-align:center" id="date" name="date">
								
							</span>
						</div>
						<div>
							<span>
								<label>Supplier:</label>
								<select id = 'supplier' name='supplier' style="margin-left:10px">
								
								</select>	
								<label style="margin-left:515px">Remarks:</label>
								<input type="text" style="margin-left:5px; text-align:center" id="remarks" name="remarks">
							</span>
							
						</div>
						<div>
							<span>
								<label><h3>Search Item</h3></label>
							</span>
						</div>
						<div>
							<span>
								<select id = "cat" name="category" onchange = "changeCategory(this.value)">
								<option value="motorcycle">MOTORCYCLE</option>
								<option value="parts">PARTS</option>
								<option value="promo item">PROMO ITEM</option>
								<option value="consumables">CONSUMABLES</option>
								</select>
								<input type="button" value="SEARCH" onclick="search_item();">
								
							</span>
						</div>
						<div  class="contents" style="border:0px solid #000; width:1000px" cellspacing="0">	
							<table id="table">
								<thead>
									<tr>
									<th style="width:30%">BRANCH</th>
									<th style="width:10%" >QUANTITY</th>
									<th style="width:40%" >PARTICULARS</th>
									<th style="width:20%" colspan=2>ACTIONS</th>
									</tr>
								</thead>
								<tbody>
								</tbody>
							</table>
						</div>
					
						
						<div align="center" style="margin-top:20px">
							<span>
								<input type="button" value="UPDATE" onclick="update()" >
								<input type="button" value="PRINT" onclick="window.open('printPR.php?pr_no=<?php echo $_REQUEST['pr_num']; ?>','_blank')">
								<input type="button" value="CANCEL" onclick="cancel()">
							</span>
						</div>
						<div id="new_items" title="VIEW REQUEST" style="display:none;">
						<iframe align="center" id="item_dialog" width="550" height="400" style="border:none"></iframe>
						</div>
						
						<div id="new_items2" title="" style="display:none;">
								<iframe align="center" id="item_dialog2" width="540" height="400" style="border:none"></iframe>
						</div>
						
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
				menu="transaction";
		}
		
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});

		loadData();
		load_dataitem();
	});
	var pr = $('#PR').val();
	
	function loadData(){
			
			var url="function_transaction.php?request=ajax&action=load_PR&pr_no="+pr;
		
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){
					$('#PR_num').val(res.pr_num);
					$('#date').val(res.date);
					$('#remarks').val(res.remarks);
					var supplier = res.supplier;
					loadSupplier(supplier);
				});	
			});
			
	}
	
	var branch_id = $("#branch_id").val();
	  var branch_name = $("#branch_name").val();
	  var branch_code = $("#branch_code").val();
	
	function search_item(){
	
	var val = $('#cat').val();
	
	if(val =="motorcycle"){
	var cat = 1;
	var table = "stocks_motors";
	}
	else if(val =="parts"){
	var cat = 2;
	var table = "stocks_parts";
	}
	else if(val =="promo item"){
	var cat = 3;
	var table = "stocks_promo";
	}
	else if(val =="consumables"){
	var cat = 4;
	var table = "stocks_consumables";
	}
	
				if(branch_id == 1){
						$("#new_items").attr("title",val+"-"+branch_name);
						$("#item_dialog").attr('src','../transaction/load_stock.php?table='+table+"&cat="+cat+"&pr_no="+pr);
						$("#new_items").dialog({
							width:550,
							height:450,
							modal: true,
							resizable:false,
							close: function () {
								$("#item_dialog").attr('src',"about:blank");
								window.location.reload();
							}
						});
						return false;
				}else{
				
					
						
						$("#new_items2").attr("title",val+"-"+branch_name );
						$("#item_dialog2").attr('src','../transaction/load_stock_branch.php?table='+table+"&cat="+cat+"&pr_no="+pr+"&branch_id="+branch_id);
						$("#new_items2").dialog({
							width:540,
							height:450,
							modal: true,
							resizable:false,
							close: function () {
								$("#item_dialog").attr('src',"about:blank");
								window.location.reload();
							}
						});
						return false;
				}		
			
			
	}
	

	function loadSupplier(supplier){
		
		var count=0, x=0;
		var select = $("#supplier");
		
		var url="function2.php?request=ajax&action=loadSupplier";
		
		$.getJSON(url,function(data){
				select.empty();
			$.each(data.members, function(i,res){
				
				if(res.id == supplier ){
							select.append("<option  value='"+res.id+"' selected='selected' >"+res.supplier_name+"</option>");
							}	else{
							select.append("<option  value='"+res.id+"'>"+res.supplier_name+"</option>");
							}
			});
		});
			
	}
	
	
	function load_dataitem(){
	
			
	var url="function_transaction.php?request=ajax&action=load_datareturn&pr_no="+pr ;
	var counter=1;
	var x = 1;

		$.getJSON(url,function(data){
		
			$("#table > tbody").empty();
					$.each(data.members, function(i,res){
				
				if(res.category == '1'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.model+"<br> ENGINE NO: "+res.engine_no+"<br> FRAME NO:"+res.frame_no+"<br>COLOR:"+res.color;
				
				}
				
				else if (res.category == '3'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no+"<br>COLOR: "+res.color;
				
				}
				
				else{
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no;
				
				}
				
				
						
				$("#table > tbody").append("<tr class='x' id='record"+res.id_return+"'><td align='center'>"+res.branch_name+"</td><td align='center'>"+res.qty+"</td><td align='center'>"+particulars+"</td><td align='center'><a href='#' alt='Update' title='Delete' class='delete' onclick=\"delete_item('"+res.id_return+" ','"+res.id+" ','"+res.category+"','"+res.qty+"');\"></a></td></tr>");
									
						 counter++;
						 
			});	
		
			if (counter <= 1){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Items on record! </th></tr>");
			}
					
					
		});
	

	}
	
	function cancel(){
		window.location="purchase_return.php?menu=transaction";
	}
	
	function delete_item(id_return,id,category,quantity){
	
			if(category == 1){
			var tablex = "stocks_motors";
			}
			else if(category == 2 ){
			var tablex = "stocks_parts";
			}
			else if(category == 3 ){
			var tablex = "stocks_promo";
			}
			else if(category == 4){
			var tablex = "stocks_consumables";
			}
			
		
	
		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
		if(e){
		
			$.ajax({
				url: "function_transaction.php",
				data:{"request":"ajax","action":"deleteReturn","id_x":id_return,"id":id,"tablex":tablex,"quantity":quantity},
				success: function(reply){

				}
			});
			$('#record'+id_return).animate({ backgroundColor: '#fbc7c7' }, 'fast')
			.animate({ opacity: "hide" }, "slow");
				
			jAlert("successfully Deleted");
			load_dataitem();
	
  		}
		
		});
		
	
	
	}
	
	function update(){
	
		event.preventDefault();
		
	
		var date = $('#date').val();
		var supplier = $('#supplier').val();
		var remarks = $('#remarks').val();
		var errormsg="Please complete the following fields: \n";
		var emsg= errormsg.length;

			if(date == ""){
				errormsg+="-Date \n";
				
			}
			if(supplier == ""){
				errormsg+="-Branch \n";
				
			}
			if(errormsg.length== emsg){
			
			
		$.ajax({
			
				  url: "function_transaction.php",
					data:{"request":"ajax","action":"update_return","pr_num":pr,"date":date,"supplier":supplier,"remarks":remarks},
						success: function(reply){
							console.log(reply);
								if(reply == 'updated'){
									
									 jAlert("Successfully Updated","UPDATED");
									$("#table > tbody").empty()
									loadData();
									load_dataitem();
								
								}else{
									jAlert("cannot add information");
								}
							
							}
			
			
			
			});
			
			}else{
				jAlert(errormsg);
				event.preventDefault();
			}
	
	}
	
	function closeIframe(actions)
	{

		$('#new_items').dialog('close');
		if(actions=="add"){
			jAlert("Item Added","Alert Dialog");
		}
		else if(actions=="cancel"){
		
			$('#new_items').dialog('close');
		}
		
		
		return false;
	}
	
	function closeIframe2(actions)
	{

		$('#new_items2').dialog('close');
		if(actions=="add"){
			jAlert("Item Added","Alert Dialog");
		}
		else if(actions=="cancel"){
		
			$('#new_items2').dialog('close');
		}
		
		
		return false;
	}
	

	</script>
	
</body>
</html>