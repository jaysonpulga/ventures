<?php
include('../database.php'); 
 
$db = new Database();  
$db->connect(); 
$action = $_REQUEST["action"];

if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){

	switch($action){

	case 'select_branch';
	$db->select("tbl_branch","*");
	$result = $db->getResult();

	print json_encode($result);
	break;
	
	case 'load_stock_brand';
	$table = $_REQUEST['table'];
	$dr_no2 = explode(",",$_REQUEST['dr_no']);
	$arr = array();

	foreach($dr_no2 as $dr_no){
		$i = 0;

	 	$tables= "$table a,tbl_manufacturer b";
		
		
		if($table =="stocks_parts" || $table =="stocks_consumables" ){
		
			$rows = "a.item,b.id, b.brand,a.dr_no";
			$where = "a.dr_no = '$dr_no'  and a.brand = b.id group by b.brand";
			
			$db->select($tables,$rows,$where);

				$result = $db->getResult();
				 foreach($result as $info){
			
					 $new_arr[$i] =  array(
							'brand' =>$info['brand'],
							 'id' =>$info['id'],
							 'dr_no' =>$info['dr_no'],
							 'item' =>$info['item'],
							
							 );
				
							array_push($arr,$new_arr[$i]);
						 $i++;
					
				 }
			
			
			
		
		}else if($table =="stocks_motors"){
			$rows = "a.model,b.id, b.brand,a.dr_no";
			 $where = "a.dr_no = '$dr_no'  and a.brand = b.id and status = 'ON HAND'";

				$db->select($tables,$rows,$where);

				$result = $db->getResult();
				 foreach($result as $info){
			
					 $new_arr[$i] =  array(
							'brand' =>$info['brand'],
							 'id' =>$info['id'],
							 'dr_no' =>$info['dr_no'],
							 'model' =>$info['model'],
							
							 );
				
							array_push($arr,$new_arr[$i]);
						 $i++;
					
				 }
			 
		}else if($table =="stocks_promo"){
			$rows = "a.item,b.id, b.brand,a.dr_no";
			 $where = "a.dr_no = '$dr_no'  and a.brand = b.id and status = 'ON HAND'";

				$db->select($tables,$rows,$where);

				$result = $db->getResult();
				 foreach($result as $info){
			
					 $new_arr[$i] =  array(
							'brand' =>$info['brand'],
							 'id' =>$info['id'],
							 'dr_no' =>$info['dr_no'],
							 'item' =>$info['item'],
							
							 );
				
							array_push($arr,$new_arr[$i]);
						 $i++;
					
				 }
			 
		} 
		
		
	}
	echo '{"members":'.json_encode($arr).'}'; 
	break;
	
	
	case 'load_stock';
	$table = $_REQUEST['table'];
	$branch_id = $_REQUEST['branch_id'];
	
	$tables= "stocks a,$table b,tbl_manufacturer c";
	$rows = "c.id, c.brand";
	if($table =="stocks_parts"){
		
		if($branch_id !=1){
				$where = "a.type = 2 and a.branch = '$branch_id' AND a.dr_no = b.dr_no AND b.brand = c.id  group by c.brand";
		}else{
				$where = "a.type = 2 AND a.dr_no = b.dr_no AND b.brand = c.id  group by c.brand";
		}
		
	
	}elseif($table =="stocks_consumables"){
	
		if($branch_id !=1){
				$where = "a.type = 4 and a.branch = '$branch_id' AND a.dr_no = b.dr_no AND b.brand = c.id  group by c.brand";
		}else{
				$where = "a.type = 4 AND a.dr_no = b.dr_no AND b.brand = c.id  group by c.brand";
		}
	
	}elseif($table =="stocks_motors"){
		
		if($branch_id !=1){
		
				$where = "a.type = 1 and a.branch = '$branch_id' AND a.dr_no = b.dr_no AND b.brand = c.id and (b.status = 'ON HAND') group by c.brand";
		}else{
				$where = "a.type = 1 AND a.dr_no = b.dr_no AND b.brand = c.id and (b.status = 'ON HAND' or b.status = 'TRANSFERRED' ) group by c.brand";
		}
	}
	elseif($table =="stocks_promo"){
	
		if($branch_id !=1){
			
			$where = "a.type = 3 and a.branch = '$branch_id' AND a.dr_no = b.dr_no AND b.brand = c.id and (b.status = 'ON HAND' ) group by c.brand";
		
		}else{
		
			$where = "a.type = 3 AND a.dr_no = b.dr_no AND b.brand = c.id and (b.status = 'ON HAND') group by c.brand";
		}

	}
	
	elseif($table =="stock_repo"){
	
		if($branch_id !=1){
			
			$where = "a.type = 5 and a.branch = '$branch_id' AND a.dr_no = b.dr_no AND b.brand = c.id and (b.status = 'ON HAND' ) group by c.brand";
		
		}else{
		
			$where = "a.type = 5 AND a.dr_no = b.dr_no AND b.brand = c.id and (b.status = 'ON HAND') group by c.brand";
		}

	}
	
	$db->select($tables,$rows,$where);
	$result = $db->getResult();
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	case 'load_stock_transfer';
	$table = $_REQUEST['table'];
	$branch_id = $_REQUEST['branch_id'];
	
	$tables= "stocks a,$table b,tbl_manufacturer c";
	$rows = "c.id, c.brand";
	if($table =="stocks_parts"){
		$where = "a.type = 2 and a.branch = '$branch_id' AND a.dr_no = b.dr_no AND b.brand = c.id  group by c.brand";
	}elseif($table =="stocks_consumables"){
		$where = "a.type = 4 and a.branch = '$branch_id' AND a.dr_no = b.dr_no AND b.brand = c.id  group by c.brand";
	}elseif($table =="stocks_motors"){
	$where = "a.type = 1 and a.branch = '$branch_id' AND a.dr_no = b.dr_no AND b.brand = c.id and (b.status = 'ON HAND') group by c.brand";
	}
	elseif($table =="stocks_promo"){
	$where = "a.type = 3 and a.branch = '$branch_id' AND a.dr_no = b.dr_no AND b.brand = c.id and (b.status = 'ON HAND') group by c.brand";
	}
	$db->select($tables,$rows,$where);
	$result = $db->getResult();
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	
	/* case 'load_branch';
    $type = $_REQUEST['type'];
	$tables= "tbl_branch a left join stocks b on a.id = b.branch ";
	$rows = "a.branch_name,a.id,a.branch_code,b.dr_no";
	$where = "type = '$type' group by b.branch";
	$db->select($tables,$rows,$where);
	$result = $db->getResult();
	echo '{"members":'.json_encode($result).'}';
	break; */
	
	 case 'load_branch';
    $type = $_REQUEST['type'];
	$tables= "tbl_branch a left join stocks b on a.id = b.branch ";
	$rows = "a.branch_name,a.id,a.branch_code";
	$where = "type = '$type' group by b.branch";
	$db->select($tables,$rows,$where);
	$result = $db->getResult();
	echo '{"members":'.json_encode($result).'}';
	break;
	
	case 'load_dr_no';
    $branch_id = $_REQUEST['branch_id'];
	$type = $_REQUEST['type'];
	$rows = "dr_no";
	$where = "type = '$type' AND branch = '$branch_id'";
	$db->select(" stocks",$rows,$where);
	$result = $db->getResult();
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	case 'load_po_model';	
		
		 $id = $_REQUEST['id'];
		 $table = $_REQUEST['table'];
		 $table2 = $_REQUEST['table2'];
		 $dr_no = $_REQUEST['dr_no'];
	
	if($table == "stocks_motors"){
	
		$where="a.dr_no = '$dr_no' AND a.model = '$id' and  a.model = b.motor_id  and (a.status = 'ON HAND' or a.status = 'TRANSFERRED') group by a.model ";
		$rows = "b.model as model,b.motor_id,a.dr_no,a.model as model_id";
	}
	else if($table == "stocks_parts"){
	
		$where="a.dr_no = '$dr_no' AND a.item = '$id' and a.item = b.parts_id group by a.item";
		$rows = "b.item_code,b.parts_id,a.dr_no,a.item as item_id";
		
	
	}
	
	else if($table == "stocks_promo"){
	
		/* $where="b.item = c.promo_id and b.brand = '$id' and (b.status = 'ON HAND' or b.status = 'TRANSFERRED') group by b.item";
		$rows = "c.item_code,c.promo_id"; */
		
		$where="a.dr_no = '$dr_no' AND a.item = '$id' and  a.item = b.promo_id  and (a.status = 'ON HAND' or a.status = 'TRANSFERRED') group by a.item ";
		$rows = "b.item_code as item_code,b.promo_id,a.dr_no,a.item as item_id";
		
	
	}
	else if($table2 == "tbl_consumables"){
	
		/* $where="b.item = c.con_id and b.brand = '$id'  group by b.item ";
		$rows = "c.item_code,c.con_id"; */
		
		$where="a.dr_no = '$dr_no' AND a.item = '$id' and a.item = b.con_id group by a.item";
		$rows = "b.item_code,b.con_id,a.dr_no,a.item as item_id";
	
	
	}

	$tables = "$table a, $table2 b";
	
	$db->select($tables,$rows,$where);
	
	$result = $db->getResult();
	
	echo '{"members":'.json_encode($result).'}'; 
	break;
	
	
	
	case 'load_select_model';	
		
		$id = $_REQUEST['id'];
		$table = $_REQUEST['table'];
		$table2 = $_REQUEST['table2'];
		$branch_id = $_REQUEST['branch_id'];
	
	if($table2 == "tbl_motorcycle"){
	
		if($branch_id != 1){
			$where="a.type = 1 and a.branch = '$branch_id' and a.dr_no = b.dr_no and b.model = c.motor_id and b.brand = '$id' and (b.status = 'ON HAND') group by b.model ";
		}else{
			$where="a.type = 1 and a.dr_no = b.dr_no and b.model = c.motor_id and b.brand = '$id' and (b.status = 'ON HAND') group by b.model ";
		}
		
		$rows = "c.model,c.motor_id";
		
	
	}else if($table2 == "tbl_parts"){
	
		if($branch_id != 1){
			$where="a.type = 2 and a.branch = '$branch_id' and a.dr_no = b.dr_no and b.item = c.parts_id and b.brand = '$id' group by b.item";
		}else{
			$where="a.type = 2  and a.dr_no = b.dr_no and b.item = c.parts_id and b.brand = '$id' group by b.item";
		}
			
		
			$rows = "c.item_code,c.parts_id";
		
	
	}
	
	else if($table2 == "tbl_promo"){
		
		if($branch_id != 1){
			$where="a.type = 3 and a.branch = '$branch_id' and a.dr_no = b.dr_no and b.item = c.promo_id and b.brand = '$id' and (b.status = 'ON HAND') group by b.item";
		}else{
			$where="a.type = 3 and a.dr_no = b.dr_no and b.item = c.promo_id and b.brand = '$id' and (b.status = 'ON HAND') group by b.item";
		}
	
		
		$rows = "c.item_code,c.promo_id";
		
	
	}
	else if($table2 == "tbl_consumables"){
	
		if($branch_id != 1){
			$where="a.type = 4 and a.branch = '$branch_id' and a.dr_no = b.dr_no and b.item = c.con_id and b.brand = '$id'  group by b.item ";
		}else{
			$where="a.type = 4  and a.dr_no = b.dr_no and b.item = c.con_id and b.brand = '$id'  group by b.item ";
		}
		
		$rows = "c.item_code,c.con_id";
	
	}
	if($table == "stock_repo"){
	
		if($branch_id != 1){
			$where="a.type = 5 and a.branch = '$branch_id' and a.dr_no = b.dr_no and b.model = c.motor_id and b.brand = '$id' and (b.status = 'ON HAND') group by b.model ";
		}else{
			$where="a.type = 5 and a.dr_no = b.dr_no and b.model = c.motor_id and b.brand = '$id' and (b.status = 'ON HAND') group by b.model ";
		}
		
		$rows = "c.model,c.motor_id,b.id as id";

	}
	

	
	$tables = "stocks a,$table b, $table2 c";
	
	$db->select($tables,$rows,$where);
	
	$result = $db->getResult();
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	
	
	
	
	
	case 'load_select_model_transfer';	
		
		$id = $_REQUEST['id'];
		$table = $_REQUEST['table'];
		$table2 = $_REQUEST['table2'];
		$branch_id = $_REQUEST['branch_id'];
	
	if($table2 == "tbl_motorcycle"){
	
		if($branch_id != 1){
			$where="a.type = 1 and a.branch = '$branch_id' and a.dr_no = b.dr_no and b.model = c.motor_id and b.brand = '$id' and (b.status = 'ON HAND') group by b.model ";
		}else{
			$where="a.type = 1 and a.dr_no = b.dr_no and b.model = c.motor_id and b.brand = '$id' and (b.status = 'ON HAND') group by b.model ";
		}
		
		$rows = "c.model,c.motor_id";
		
	
	}else if($table2 == "tbl_parts"){
	
		if($branch_id != 1){
			$where="a.type = 2 and a.branch = '$branch_id' and a.dr_no = b.dr_no and b.item = c.parts_id and b.brand = '$id' group by b.item";
		}else{
			$where="a.type = 2  and a.dr_no = b.dr_no and b.item = c.parts_id and b.brand = '$id' group by b.item";
		}
			
		
			$rows = "c.item_code,c.parts_id";
		
	
	}
	
	else if($table2 == "tbl_promo"){
		
		if($branch_id != 1){
			$where="a.type = 3 and a.branch = '$branch_id' and a.dr_no = b.dr_no and b.item = c.promo_id and b.brand = '$id' and (b.status = 'ON HAND' or b.status = 'TRANSFERRED') group by b.item";
		}else{
			$where="a.type = 3 and a.dr_no = b.dr_no and b.item = c.promo_id and b.brand = '$id' and (b.status = 'ON HAND') group by b.item";
		}
	
		
		$rows = "c.item_code,c.promo_id";
		
	
	}
	else if($table2 == "tbl_consumables"){
	
		if($branch_id != 1){
			$where="a.type = 4 and a.branch = '$branch_id' and a.dr_no = b.dr_no and b.item = c.con_id and b.brand = '$id'  group by b.item ";
		}else{
			$where="a.type = 4  and a.dr_no = b.dr_no and b.item = c.con_id and b.brand = '$id'  group by b.item ";
		}
		
		$rows = "c.item_code,c.con_id";
	
	}
	if($table == "stock_repo"){
	
		if($branch_id != 1){
			$where="a.type = 5 and a.branch = '$branch_id' and a.dr_no = b.dr_no and b.model = c.motor_id and b.brand = '$id' and (b.status = 'ON HAND' or b.status = 'TRANSFERRED') group by b.model ";
		}else{
			$where="a.type = 5 and a.dr_no = b.dr_no and b.model = c.motor_id and b.brand = '$id' and (b.status = 'ON HAND') group by b.model ";
		}
		
		$rows = "c.model,c.motor_id,b.id as id";

	}
	

	
	$tables = "stocks a,$table b, $table2 c";
	
	$db->select($tables,$rows,$where);
	
	$result = $db->getResult();
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	case 'load_select_ItemCode';	
	$id = $_REQUEST['id'];
	 $table = $_REQUEST['table'];
	$where="item = ".$id;
	$db->select($table,"*",$where,"item_code ASC");
	
	$result = $db->getResult();
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	case 'add_DRNO';
	
	  $dr_no = $_REQUEST['dr_no'];
	  $date = $_REQUEST['date'];
	  $branch = $_REQUEST['branch'];
	  $to = $_REQUEST['to'];
	
	$where ="dr_no = '$dr_no' ";
	$rows = '*';
	if($db->recordExist('transfer_item',$rows,$where) > 0){
		print 'duplicate';
	}else{
	
	$rows = "dr_no,branch_code,date,move_to";
	$values = array($dr_no,$branch,$date,$to);
	$db->insert('transfer_item',$values,$rows);
	
	print 'saved';
	}
	break;
	
	
	case 'load_DR';
	$dr_no = $_REQUEST["dr_no"];

	$where = "dr_no = '$dr_no' ";
	
	$db->select("transfer_item","*",$where);
	$result = $db->getResult();
	
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	case 'load_item_stock';	
	 $id = $_REQUEST['id'];
	$table = $_REQUEST['table'];
	$dr_no = $_REQUEST['dr_no'];
	
	if($table  =="stocks_motors"){
		$where="dr_no = '$dr_no' AND model = '$id' and status = 'ON HAND' ";
		$row = "*";
	}else if($table  =="stocks_parts" || $table  =="stocks_consumables" ){
		$row = "id,dr_no,brand,item,serial_no,sum(quantity) as quantity,sum(remaining) as remaining ";
		$where="dr_no = '$dr_no' AND item = '$id' group by serial_no ";	
	}else if($table  =="stocks_promo"){
		$row = "*";
		$where="dr_no = '$dr_no' AND item = '$id' and status = 'ON HAND' ";	
	}
	
	$db->select($table,$row,$where);
		$result = $db->getResult();	
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	case 'add_item';
		$array = $_REQUEST["array"];
		$table = $_REQUEST["table"];
		$dr_no = $_REQUEST["dr_no"];
		
	
	if($table =="stocks_parts" || $table =="stocks_consumables"){
				foreach( $array as $key => $value) { 
				
				 $val =  $value['serial_no'];
				$quantity = $value['quantity'];
				$selling = $value["selling"];
				
				$brand = $value['brand'];
				$item = $value['item'];
				
				$var = $quantity ;
				
				$where = "serial_no = '$val' AND brand = '$brand' AND  item = '$item' ";
				$order = "id desc";		
				$db->select($table,'*',$where,$order);
				$result = $db->getResult();
				
						foreach($result as $info){
						
									 $id = $info['id'];
									 $brand = $info['brand'];
									 $item = $info['item'];
									 $serial_no = $info['serial_no'];
									 $remaining = $info['remaining'];
								 
									 if(empty($color)){
										$color = "";
									}
									if($table =="stocks_parts"){
										$cat = 2;
									} else if($table =="stocks_consumables"){
										$cat = 4;
									}
									
									 
								
									$c = $var;
									$answer = ($var - $remaining);
									$var = $answer;

									if($var < 0) $var = 0; 
									if($var > 0){

									$rowsx = array('remaining' => '0');
									$wherex ="id = '$id' AND brand = '$brand' AND  item = '$item'";
									$db->update($table,$rowsx,$wherex);

									$rows ='stock_id,dr_no,category,brand,item,color,qty';
									$values = array($id,$dr_no,$cat,$brand,$item,$color,$remaining);
									$db->insert("transfer_details",$values,$rows); 
                  
									}else{ 
 
									 $answer = abs($answer); 
									$rowsx = array('remaining' => $answer);
									$wherex ="id = '$id' AND brand = '$brand' AND  item = '$item'";
									$db->update($table,$rowsx,$wherex); 
									
									$rows ='stock_id,dr_no,category,brand,item,color,qty';
									$values = array($id,$dr_no,$cat,$brand,$item,$color,$c);
									$db->insert("transfer_details",$values,$rows);
									break; 
									}
									
									
									
									
						}
				
				}
		
		
		}else{
	
				 foreach( $array as $key => $value) { 
					
					 $val =  $value['serial_no'];
					 $selling = $value["selling"];
				
					$where = "id = '$val' ";
							
					$db->select($table,'*',$where);
					$result = $db->getResult();
					
						foreach($result as $info){
									
									$id = $info['id'];
									$brand = $info['brand'];
									$color = $info['color'];
									$remaining = $info['remaining'];
									
									if(empty($color)){
										$color = "";
									}
									
									if($table =="stocks_motors"){			
									 $item = $info['model'];
									 $cat = 1;
									}
									
									else if($table =="stocks_promo"){
										$item = $info['item'];
										$cat = 3;
									}
									
									
									
									
						}
									
						$rows ='stock_id,dr_no,category,brand,item,color,qty';
						$values = array($id,$dr_no,$cat,$brand,$item,$color,'1');
						$db->insert("transfer_details",$values,$rows);
					
						$rowsx = array('status' => "TRANSFERRED");
						$wherex ="id = '$id'";
						$db->update($table,$rowsx,$wherex);
						
				}
		
	}	 
			print "uhryt";
				
	break;
	
	
	
	case 'load_dataitem';
	
	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$dr_no = $_REQUEST['dr_no'];
	
	$where = "dr_no='$dr_no'";
	$db->select("transfer_details","*",$where);
	$result = $db->getResult();
	
	foreach($result as $key){
		 $category=$key["category"];
		  $dr_no=$key["dr_no"];
		 
		if($category == '1'){
		 
			
			$row = "a.category,a.id_s,a.color,a.qty,b.brand,c.model,d.engine_no,d.frame_no,d.id";
			$table = "transfer_details a,tbl_manufacturer b, tbl_motorcycle c, stocks_motors d";
			
			$where = "a.brand = b.id and a.item = c.motor_id and a.stock_id = d.id and a.category = '$category' and a.dr_no = '$dr_no'  ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray=$result;
			
			
		 }
		 
		 else if($category == '2'){

			$row = "a.category,a.id_s,a.color,a.qty,b.brand,c.item_code,d.serial_no,d.id";
			$table = "transfer_details a,tbl_manufacturer b, tbl_parts c, stocks_parts d";
			
			$where = "a.brand = b.id and a.item = c.parts_id and a.stock_id = d.id and a.category = '$category' and a.dr_no = '$dr_no'  ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray2=$result;
		   
		 
		 }
		 else if($category == '3'){
			
			
			$row = "a.category,a.id_s,a.color,a.qty,b.brand,c.item_code,d.serial_no,d.id";
			$table = "transfer_details a,tbl_manufacturer b, tbl_promo c, stocks_promo d";
			
			$where = "a.brand = b.id and a.item = c.promo_id and a.stock_id = d.id and a.category = '$category' and a.dr_no = '$dr_no'  ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray3=$result;
		  
		 }
		 else if($category == '4'){
			
			
			$row = "a.category,a.id_s,a.color,a.qty,b.brand,c.item_code,d.serial_no,d.id";
			$table = "transfer_details a,tbl_manufacturer b,tbl_consumables c,stocks_consumables d";
			
			$where = "a.brand = b.id and a.item = c.con_id and a.stock_id = d.id and a.category = '$category' and a.dr_no = '$dr_no'";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray4=$result;
		   
		 }
		
		$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4);
		
	}
	
	 

		if(empty($output)){
		
			echo '{"members":'.json_encode($result).'}';
			
		}else{

			echo '{"members":'.json_encode($output).'}';
		}
	break;
	
	case 'deleteItem';
	$id=$_REQUEST['id'];
	$id_x=$_REQUEST['id_x'];
	$tablex=$_REQUEST['tablex'];
	$quantity=$_REQUEST['quantity'];
		if($tablex == "stocks_parts" || $tablex == "stocks_consumables" ){
			
			 $where="id = ".$id;
			$db->select($tablex,"*",$where);
			$result = $db->getResult();
			
				foreach($result as $info){
					$idx = $info['id'];
					$data = $info['remaining'];
				}
			$sum = $data+$quantity;
			
			$wherex="id = '$idx'";
			$rowsx = array('remaining' =>$sum );
			$db->update($tablex,$rowsx,$wherex); 
		
		}else{
			
			$where="id= '$id'";
			$rows = array('status' => "ON HAND");
			$db->update($tablex,$rows,$where);
		}
	
	$wherex="id_s = '$id_x' ";
	$db->delete("transfer_details",$wherex);
	break;
	
	
	case 'load_item_data';
	
	$sort = $_REQUEST['sort'];
	$sortType = $_REQUEST['sortType'];
	$branch_code = $_REQUEST['branch_code'];
	
	$row = "a.transfer_id,a.dr_no,a.branch_code,a.date,a.move_to,COUNT( b.dr_no ) as no_of_item" ;
	$order = "$sort $sortType";
	
	$category=$_REQUEST['category'];
	$trimmed=trim($_REQUEST['inputsearch']);
	
	$table = "transfer_item  a left join transfer_details  b on a.dr_no = b.dr_no";
	if($branch_code != "3SS"){
		$where = "a.branch_code = '$branch_code' AND $category LIKE '%".$trimmed."%' group by a.dr_no";
	}else{
		$where = "$category LIKE '%".$trimmed."%' group by a.dr_no";
	}
		
	
	$db->select($table,$row,$where,$order);
	
	
	$result = $db->getResult();

	print json_encode($result);
		
	break;
	
	
	case 'update_drno';
	$dr_no=$_REQUEST['dr_no'];
	$date=$_REQUEST['date'];	
	$branch=$_REQUEST['branch'];
	$branch_to=$_REQUEST['branch_to'];
	$remarks=$_REQUEST['remarks'];
	
	$where ="dr_no = '$dr_no'";
		
	$rows = array('date' => $date
				,'branch_code' => $branch
				,'move_to' => $branch_to
				,'remarks' => $remarks
			  );
			  
	$db->update('transfer_item',$rows,$where); 	
	print "updated";
	
	break;
	
	
	case 'multiple_delete';
		$array_request=$_REQUEST['array'];
			
	foreach($array_request as $key => $val){
			
			
			$db->select("transfer_details","*","dr_no ='$val'");
			$result = $db->getResult();
				
			foreach($result as $info){
								
				 $category	 = $info['category'];
				 $brand = $info['brand'];
				 $item  = $info['item'];
				 $stock_id  = $info['stock_id'];
				  $qty  = $info['qty'];
				
						if($category == 1){

							$rowsx = array('status' => "ON HAND");
							$wherex ="id = '$stock_id'";
							$db->update("stocks_motors",$rowsx,$wherex);
						
						}
						else if($category == 2){
						 
							$where="id = '$stock_id'";
							$db->select("stocks_parts","*",$where);
							$result = $db->getResult();
						
							foreach($result as $info){
								$idx = $info['id'];
								$data = $info['remaining'];
							}
							$sum = $data+$qty;
							
							$wherex="id = '$idx'";
							$rowsx = array('remaining' =>$sum );
							$db->update("stocks_parts",$rowsx,$wherex); 
						 
						}
						
						else if($category == 3){
						
							$rowsx = array('status' => "ON HAND");
							$wherex ="id = '$stock_id'";
							$db->update("stocks_promo",$rowsx,$wherex);
						}
						
						else if($category == 4){	
						
						
							$where="id = '$stock_id'";
							$db->select("stocks_consumables","*",$where);
							$result = $db->getResult();
						
							foreach($result as $info){
								$idx = $info['id'];
								$data = $info['remaining'];
							}
							$sum = $data+$qty;
							
							$wherex="id = '$idx'";
							$rowsx = array('remaining' =>$sum );
							$db->update(" stocks_consumables",$rowsx,$wherex);
						
						
						}
			}
											
	}
			
			$db->delete("transfer_item","dr_no ='$val'");
			$db->delete("transfer_details","dr_no ='$val'");	
	
	print "deleted";
	
	break;
	
	
	case 'deleteTwotable';
	$id=$_REQUEST['id'];
	$table1=$_REQUEST['table1'];
	$table2=$_REQUEST['table2'];
	$table_id=$_REQUEST['table_id'];
	
	$db->select("$table1","*"," $table_id='$id' ");
	$result = $db->getResult();

	foreach($result as $info){
							
					 $category	 = $info['category'];
					 $brand = $info['brand'];
					 $item  = $info['item'];
					 $stock_id  = $info['stock_id'];
					  $qty  = $info['qty'];
					
					if($category == 1){

						$rowsx = array('status' => "ON HAND");
						$wherex ="id = '$stock_id'";
						$db->update("stocks_motors",$rowsx,$wherex);
					
					}else if($category == 5){

						$rowsx = array('status' => "ON HAND");
						$wherex ="id = '$stock_id'";
						$db->update("stock_repo",$rowsx,$wherex);
					
					}
					else if($category == 2){
					 
						$where="id = '$stock_id'";
						$db->select("stocks_parts","*",$where);
						$result = $db->getResult();
					
						foreach($result as $info){
							$idx = $info['id'];
							$data = $info['remaining'];
						}
						$sum = $data+$qty;
						
						$wherex="id = '$idx'";
						$rowsx = array('remaining' =>$sum );
						$db->update("stocks_parts",$rowsx,$wherex); 
					 
					}
					
					else if($category == 3){
					
						$rowsx = array('status' => "ON HAND");
						$wherex ="id = '$stock_id'";
						$db->update("stocks_promo",$rowsx,$wherex);
					}
					
					else if($category == 4){	
					
						$where="id = '$stock_id'";
						$db->select("stocks_consumables","*",$where);
						$result = $db->getResult();
					
						foreach($result as $info){
							$idx = $info['id'];
							$data = $info['remaining'];
						}
						$sum = $data+$qty;
						
						$wherex="id = '$idx'";
						$rowsx = array('remaining' =>$sum );
						$db->update(" stocks_consumables",$rowsx,$wherex);
					
					
					}
											
	}
	
	$db->delete($table2,"$table_id ='$id'");
	$db->delete($table1,"$table_id ='$id'");	

	break;
	

	
	case 'delete2table';
	$id=$_REQUEST['id'];
	$table1=$_REQUEST['table1'];
	$table2=$_REQUEST['table2'];
	$table_id=$_REQUEST['table_id'];
		
	$db->delete($table2,"$table_id ='$id'");
	$db->delete($table1,"$table_id ='$id'");	

	break;
	
	
	case 'loadAllPR';
	
	$sort = $_REQUEST['sort'];
	$sortType = $_REQUEST['sortType'];
	$branch_code = $_REQUEST['branch_code'];
	
	$row = "a.id_pr,a.pr_num,a.date,COUNT( b.pr_num ) as no_of_item,c.supplier_name" ;
	$order = "$sort $sortType";
	
	$category=$_REQUEST['category'];
	$trimmed=trim($_REQUEST['inputsearch']);
	
	$table = "purchase_return  a left join purchase_return_details  b on a.pr_num = b.pr_num,  tbl_supplier c";
			if($branch_code != "3SS"){
			 $where = "a. branch_code = '$branch_code' AND a.supplier = c.id	 and $category LIKE '%".$trimmed."%' group by a.pr_num";
			}else{
			 $where = "a.supplier = c.id	 and $category LIKE '%".$trimmed."%' group by a.pr_num";
			}
	
	
	
	$db->select($table,$row,$where,$order);
	
	
	$result = $db->getResult();

	print json_encode($result);
		
	break;
	
	
	case 'load_PR';
	$pr_no = $_REQUEST["pr_no"];

	$where = "pr_num = '$pr_no' ";
	
	$db->select("purchase_return","*",$where);
	$result = $db->getResult();
	
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	case 'ADD_PR';
	
		$array = $_REQUEST["array"];
		$table = $_REQUEST["table"];
		$pr_no = $_REQUEST["pr_no"];
		$branch = $_REQUEST["branch"];
		
		$var = $quantity ;
		
		$db->select('tbl_branch','*',"id = '$branch'");
		$result = $db->getResult();
		foreach($result as $info){
			$branch_code = $info['branch_code'];
		}
		
		
		if($table =="stocks_parts" || $table =="stocks_consumables"){
				foreach( $array as $key => $value) { 
				
				 $val =  $value['serial_no'];
				 $quantity = $value['quantity'];
				
				 $brand = $value['brand'];
				 $item = $value['item'];
				 
				 $var = $quantity ;
				
				$where = "serial_no = '$val' and remaining != '0'  AND brand = '$brand' AND  item = '$item'";
				$order = "id desc";		
				$db->select($table,'*',$where,$order);
				$result = $db->getResult();
				
						foreach($result as $info){
						
									 $id = $info['id'];
									 $brand = $info['brand'];
									 $item = $info['item'];
									 $serial_no = $info['serial_no'];
									 $remaining = $info['remaining'];
																			 
									 if(empty($color)){
										$color = "";
									}
									if($table =="stocks_parts"){
										$cat = 2;
									} else if($table =="stocks_consumables"){
										$cat = 4;
									}
									
									if(empty($frame_no )){
									$frame_no  = "";
									}
									 
								
									$c = $var;
									$answer = ($var - $remaining);
									$var = $answer;

									if($var < 0) $var = 0; 
									if($var > 0){

									$rowsx = array('remaining' => '0');
									$wherex ="id = '$id' AND brand = '$brand' AND  item = '$item'";
									$db->update($table,$rowsx,$wherex);

									$rows ='pr_num,stock_id,category,brand,item,serial_no,frame_no,color,branch,qty';
									$values = array($pr_no,$id,$cat,$brand,$item,$serial_no,$frame_no,$color,$branch_code,$remaining);
									$db->insert("purchase_return_details",$values,$rows);
 
                  
									}else{ 
 
									 $answer = abs($answer); 
									$rowsx = array('remaining' => $answer);
									$wherex ="id = '$id' AND brand = '$brand' AND  item = '$item'";
									$db->update($table,$rowsx,$wherex); 
									
									$rows ='pr_num,stock_id,category,brand,item,serial_no,frame_no,color,branch,qty';
									$values = array($pr_no,$id,$cat,$brand,$item,$serial_no,$frame_no,$color,$branch_code,$c);
									$db->insert("purchase_return_details",$values,$rows);
									
									break; 
									}
									
									
									
									
						}
				
				}
		
		
		}else{
	
				 foreach( $array as $key => $value) { 
					
					 $val =  $value['serial_no'];
				
					$where = "id = '$val' ";
							
					$db->select($table,'*',$where);
					$result = $db->getResult();
					
						foreach($result as $info){
									
									$id = $info['id'];
									$brand = $info['brand'];
									$color = $info['color'];
									$engine_no = $info['engine_no'];
									$frame_no = $info['frame_no'];
									
									if(empty($color)){
										$color = "";
									}
									if(empty($engine_no)){
										$engine_no = "";
									}
									if(empty($frame_no )){
										$frame_no  = "";
									}
											
									if($table =="stocks_motors"){
									
									 $serial = $info['engine_no'];
									 $item = $info['model'];
									 $cat = 1;
									
									}
									
									
									else if($table =="stocks_promo"){
										$serial = $info['serial_no'];
										$item = $info['item'];
										$cat = 3;
									}
									
						}
						
								$rows ='pr_num,stock_id,category,brand,item,serial_no,frame_no,color,branch,qty';
								$values = array($pr_no,$id,$cat,$brand,$item,$serial,$frame_no,$color,$branch_code,'1');
								$db->insert("purchase_return_details",$values,$rows);
								
								$rowsx = array('status' => "PO RETURNED");
								$wherex ="id = '$id'";
								$db->update($table,$rowsx,$wherex);
								
								
				

				}
		}

	
	print "uhryt";			
	break;
	
	
	case 'load_datareturn';
	
	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$pr_no = $_REQUEST['pr_no'];
	
	$where = "pr_num='$pr_no'";
	$db->select("purchase_return_details","*",$where);
	$result = $db->getResult();
	
	

	foreach($result as $key){
		 $category=$key["category"];
		  $pr_no=$key["pr_num"];
		 
		if($category == '1'){
		 
			
			$row = "a.qty,a.category,a.id_return,a.color,b.brand,c.model,d.engine_no,d.frame_no,d.id,e.branch_name";
			$table = "purchase_return_details a,tbl_manufacturer b, tbl_motorcycle c, stocks_motors d,tbl_branch e";
			
			$where = "a.brand = b.id and a.item = c.motor_id and a.stock_id = d.id and a.branch = e.branch_code and a.category = '$category' and a.pr_num = '$pr_no'  ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray=$result;
			
		
			
		 }
		 
		 else if($category == '2'){

			$row = "a.qty,a.category,a.id_return,a.color,b.brand,c.item_code,d.serial_no,d.id,e.branch_name";
			$table = "purchase_return_details a,tbl_manufacturer b, tbl_parts c, stocks_parts d,tbl_branch e";
			
			$where = "a.brand = b.id and a.item = c.parts_id and a.stock_id = d.id and  a.branch = e.branch_code  and a.category = '$category' and a.pr_num = '$pr_no'  ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray2=$result;
		   
		 
		 }
		 else if($category == '3'){
			
			
			$row = "a.qty,a.category,a.id_return,a.color,b.brand,c.item_code,d.serial_no,d.id,e.branch_name";
			$table = "purchase_return_details a,tbl_manufacturer b, tbl_promo c, stocks_promo d,tbl_branch e";
			
			$where = "a.brand = b.id and a.item = c.promo_id and a.stock_id = d.id and  a.branch = e.branch_code and a.category = '$category' and a.pr_num = '$pr_no'  ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray3=$result;
		  
		 }
		 else if($category == '4'){
			
			
			$row = "a.qty,a.category,a.id_return,a.color,b.brand,c.item_code,d.serial_no,d.id,e.branch_name";
			$table = "purchase_return_details a,tbl_manufacturer b, tbl_consumables c,stocks_consumables d,tbl_branch e";
			
			$where = "a.brand = b.id and a.item = c.con_id and a.stock_id = d.id and  a.branch = e.branch_code and a.category = '$category' and a.pr_num = '$pr_no'  ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray4=$result;
		   
		 }
		
		$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4);
		
	}
	
	 

		if(empty($output)){
		
			echo '{"members":'.json_encode($result).'}';
			
		}else{

			echo '{"members":'.json_encode($output).'}';
		}
	break;
	
	
	
	case 'deleteReturn';
	$id=$_REQUEST['id'];
	$id_x=$_REQUEST['id_x'];
	$tablex=$_REQUEST['tablex'];
	$quantity=$_REQUEST['quantity'];
		if($tablex == "stocks_parts" || $tablex == "stocks_consumables" ){
			
			 $where="id = ".$id;
			$db->select($tablex,"*",$where);
			$result = $db->getResult();
			
				foreach($result as $info){
					$idx = $info['id'];
					$data = $info['remaining'];
				}
			$sum = $data+$quantity;
			
			$wherex="id = '$idx'";
			$rowsx = array('remaining' =>$sum );
			$db->update($tablex,$rowsx,$wherex); 
		
		}else{
		$where="id= '$id'";
		$rows = array('status' => "ON HAND");
		$db->update($tablex,$rows,$where);
		}
	 
	
	$wherex="id_return = '$id_x' ";
	$db->delete("purchase_return_details",$wherex);
	break;
	
	case 'update_return';
	$pr_num=$_REQUEST['pr_num'];
	$date=$_REQUEST['date'];	
	$supplier=$_REQUEST['supplier'];
	$remarks=$_REQUEST['remarks'];
	
	$where ="pr_num = '$pr_num'";
		
	$rows = array('date' => $date
				,'supplier' => $supplier
				,'remarks' => $remarks
			  );
			  
	$db->update('purchase_return',$rows,$where); 	
	print "updated";
	break;
	
	case 'check_datareturn';
	$table = $_REQUEST["table"];
	$array = $_REQUEST["array"];
	$where = "a.serial_no = '$array' GROUP BY a.serial_no ";	
	$db->select($table,"b.SUM(b.qty) as remaining",$where);
	$result = $db->getResult();

	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	case 'view_or_collection';
				
				$or_no=$_REQUEST['or_no'];
				$rows ='a.customer_id,a.or_no,a.address,a.date,a.branch_code,b.last_name,b.first_name,b.middle_name';
				$where = "a.or_no= '$or_no' AND a.customer_id = b.id";
				$db->select('collections a,tbl_customer b',$rows,$where); 
				$result = $db->getResult();
				
				print '{"members":'.json_encode($result).'}';
				
			
	break;
	
	
	case 'loadinvoice_number';
				
				$txtcusid=$_REQUEST['txtcusid'];
				$rows ='invoice_no,id';
				$where = "customer_id = '$txtcusid'";
				$db->select('sales_invoice',$rows,$where); 
				$result = $db->getResult();
				
				print '{"members":'.json_encode($result).'}';
				
			
	break;
	
	
	
	case 'viewLoanCollection';
				
				$or_no=$_REQUEST['or_no'];
				$rows ='a.customer_id,a.or_no,a.address,a.date,a.branch_code,b.last_name,b.first_name,b.middle_name,c.account_no';
				$where = "a.or_no= '$or_no' AND a.customer_id = b.id AND a.customer_id = c.customer_id";
				$db->select('collections a,tbl_customer b, collection_loan c',$rows,$where); 
				$result = $db->getResult();
				
				print '{"members":'.json_encode($result).'}';
				
			
	break;
	
	
	
	case 'viewLOan_collection';
	
				
				$customer_id=$_REQUEST['customer_id'];	
				$where="a.customer_name = '$customer_id' AND a.loan_type_id=b.id";
				
				$rows ="substr(a.installment_due,9) as installment_due,round((a.installment_amount + a.interest_income) / (a.terms)) as monthly_down , b.loan_type as loan_type,b.penalty_interest,a.monthly_rebate";
				
				$db->select('tbl_ledger a,tbl_loan b',$rows,$where);
				$result = $db->getResult();
				
				print '{"members":'.json_encode($result).'}';
			
			break;
			
	case 'load_collection';
	
	$new_arr = array();
	$arr = array();
	$i = 0;
		
	
	$sort = $_REQUEST['sort'];
	$sortType = $_REQUEST['sortType'];
	$branch_code = $_REQUEST['branch_code'];
	$type = $_REQUEST['type'];
	
	$row = "a.*, CONCAT(b.last_name,', ',b.first_name,' ',b.middle_name) as customer_name" ;
	$order = "$sort $sortType";
	
	$category=$_REQUEST['category'];
	$trimmed=trim($_REQUEST['inputsearch']);
	
	$table = "collections a,tbl_customer b";
		if($branch_code != "3SS"){
			$where = "a.type = '$type' AND  a.branch_code = '$branch_code' AND a.customer_id = b.id AND $category LIKE '%".$trimmed."%'";
		}else{
			$where = "a.type = '$type' AND a.customer_id = b.id AND $category LIKE '%".$trimmed."%'";
		}
			
	$db->select($table,$row,$where);
	
	$result = $db->getResult();
	
	
			foreach($result as $info){
							$total_qty=0;
							$total_amount=0;
							$dues =0;
							$penalty =0;
							$rebate = 0;
							$discount =0;
						
						$id = $info['id'];
						$or_no = $info['or_no'];
						$customer_id = $info['customer_id'];
						$customer_name = $info['customer_name'];
						$type = $info['type'];
						$date = $info['date'];
						
								if($type =="CASH"){
									$row = "*";
									$where = "or_no = '$or_no'";
									$db->select('collection_cash',$row,$where);
									$result2 = $db->getResult();
										
									foreach($result2 as $key_details){
											$amount=$key_details["qty"]*$key_details["amount"];	
											$total_amount=$total_amount+$amount;
											$total_qty=$total_qty+$key_details["qty"];	
									}	
								}elseif($type =="LOAN"){
									$row = "*";
									$where = "or_no = '$or_no'";
									$db->select('collection_loan',$row,$where);
									$result2 = $db->getResult();
										
									foreach($result2 as $key_details){
											$dues=$key_details["dues"];
											$penalty=$key_details["penalty"];
											$rebate=$key_details["rebate"];	
											$discount=$key_details["discount"];	

										if($penalty > 0){
											$total_amount += $dues + $penalty - $discount;
										}else{
											$total_amount += $dues - $rebate - $discount;
										}
											
									
											
									}	
								}elseif($type =="INTERBRANCH"){
									$row = "*";
									$where = "or_no = '$or_no'";
									$db->select('collection_interbranch',$row,$where);
									$result2 = $db->getResult();
										
									foreach($result2 as $key_details){
											$total_amount += $key_details["amount"];	
									}	
								}
							
					$new_arr[$i] =  array(
							'id' =>$id,
							'or_no' =>$or_no,
							'customer_id'=>$customer_id,
							'customer_name'=>$customer_name,
							'date'=>$date,
							'type'=>$type,
							'amount'=>$total_amount,
							);
				
						array_push($arr,$new_arr[$i]);
						$i++;	
			
			}
			
			if(count($arr) > 0){
			$sortArray = array(); 
				
				foreach($arr as $total){ 
					foreach($total as $key=>$value){
						if(!isset($sortArray[$key])){
							$sortArray[$key] = array(); 
						}
						$sortArray[$key][] = $value;
					}
				}
				
			
				 $orderby = $sort;
				if($_REQUEST["sortType"]=="ASC"){
					array_multisort($sortArray[$orderby],SORT_ASC,$arr);
				}
				else{
					array_multisort($sortArray[$orderby],SORT_DESC,$arr);
				}
			}
				
	
	print json_encode($arr);
	
		
	/* $new_arr = array();
	$arr = array();
	$i = 0;
		
	
	$sort = $_REQUEST['sort'];
	$sortType = $_REQUEST['sortType'];
	$branch_code = $_REQUEST['branch_code'];
	$tablex = $_REQUEST['table'];
	
	$row = "a.*, CONCAT(b.last_name,', ',b.first_name,' ',b.middle_name) as customer_name" ;
	$order = "$sort $sortType";
	
	$category=$_REQUEST['category'];
	$trimmed=trim($_REQUEST['inputsearch']);
	
	$table = "collections a,tbl_customer b";
		if($branch_code != "3SS"){
				if($trimmed!=""){
					$where = "a.type = '$table' AND a.branch_code = '$branch_code' AND a.customer_id = b.id AND $category LIKE '%".$trimmed."%'";
				}else{
					$where = "a.type = '$tablex' AND a.branch_code = '$branch_code' AND a.customer_id = b.id";
				}
		}else{
				if($trimmed!=""){
					$where = "a.type = '$table' AND a.customer_id = b.id AND $category LIKE '%".$trimmed."%'";
				}else{
					$where = "a.type = '$tablex' AND a.customer_id = b.id";
				}
		}
			
	$db->select($table,$row,$where);
	
	$result = $db->getResult();
	
	

	
	
			foreach($result as $info){
							$total_qty=0;
							$total_amount=0;
							$dues =0;
							$penalty =0;
							$rebate = 0;
							$discount =0;
						
						$id = $info['id'];
						$or_no = $info['or_no'];
						$customer_id = $info['customer_id'];
						$customer_name = $info['customer_name'];
						$type = $info['type'];
						
								if($type =="CASH"){
									$row = "*";
									$where = "or_no = '$or_no'";
									$db->select('collection_cash',$row,$where);
									$result2 = $db->getResult();
										
									foreach($result2 as $key_details){
											$amount=$key_details["qty"]*$key_details["amount"];	
											$total_amount=$total_amount+$amount;
											$total_qty=$total_qty+$key_details["qty"];	
									}	
								}elseif($type =="LOAN"){
									$row = "*";
									$where = "or_no = '$or_no'";
									$db->select('collection_loan',$row,$where);
									$result2 = $db->getResult();
										
									foreach($result2 as $key_details){
											$dues=$key_details["dues"];
											$penalty=$key_details["penalty"];
											$rebate=$key_details["rebate"];	
											$discount=$key_details["discount"];	

										if($penalty > 0){
											$total_amount += $dues + $penalty - $discount;
										}else{
											$total_amount += $dues - $rebate - $discount;
										}
											
									
											
									}	
								}elseif($type =="INTERBRANCH"){
									$row = "*";
									$where = "or_no = '$or_no'";
									$db->select('collection_interbranch',$row,$where);
									$result2 = $db->getResult();
										
									foreach($result2 as $key_details){
											$total_amount += $key_details["amount"];	
									}	
								}
							
					$new_arr[$i] =  array(
							'id' =>$id,
							'or_no' =>$or_no,
							'customer_id'=>$customer_id,
							'customer_name'=>$customer_name,
							'type'=>$type,
							'amount'=>$total_amount,
							);
				
						array_push($arr,$new_arr[$i]);
						$i++;	
			
			}
			
			if(count($arr) > 0){
			$sortArray = array(); 
				
				foreach($arr as $total){ 
					foreach($total as $key=>$value){
						if(!isset($sortArray[$key])){
							$sortArray[$key] = array(); 
						}
						$sortArray[$key][] = $value;
					}
				}
				
			
				$orderby = $sort;
				if($_REQUEST["sortType"]=="ASC"){
					array_multisort($sortArray[$orderby],SORT_ASC,$arr);
				}
				else{
					array_multisort($sortArray[$orderby],SORT_DESC,$arr);
				}
			}
				
	
	print json_encode($arr); */
		
	break;
	
	
	case 'load_item_collection';	
		$id = $_REQUEST['id'];
		$table = $_REQUEST['table'];
	 $branch_id = $_REQUEST['branch_id'];
	
	if($table  =="stocks_motors"){
		
		if($branch_id != 1){
			
			$where="a.type = 1 and a.branch = '$branch_id' AND a.dr_no = b.dr_no and b.model = '$id' AND b.model = c.motor_id and (b.status = 'ON HAND')";
		}else{
			
			$where="a.type = 1  AND a.dr_no = b.dr_no and b.model = '$id' AND b.model = c.motor_id and (b.status = 'ON HAND')";
		}
			
		$row = "b.*,c.selling_price";
		$tablex = "stocks a,$table b, tbl_motorcycle c";
		
	}else if($table  =="stocks_parts"){
	
		if($branch_id != 1){
			$where="a.type = 2 and a.branch = '$branch_id' AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.parts_id group by b.brand,b.item,b.serial_no ";
		}else{
			$where="a.type = 2  AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.parts_id group by b.brand,b.item,b.serial_no ";
		}
		
		
		$row = "b.id,b.dr_no,b.brand,b.item,b.serial_no,sum(b.quantity) as quantity,sum(b.remaining) as remaining,c.selling_price ";
		$tablex = "stocks a,$table b,  tbl_parts c";		
	}
	
	else if($table  =="stocks_consumables"){
		if($branch_id != 1){
			
		$where="a.type = 4 and a.branch = '$branch_id' AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.con_id group by b.brand,b.item,b.serial_no ";
		}else{
			
		$where="a.type = 4  AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.con_id group by b.brand,b.item,b.serial_no ";
		}
		
		$row = "b.id,b.dr_no,b.brand,b.item,b.serial_no,sum(b.quantity) as quantity,sum(b.remaining) as remaining,c.selling_price ";
		$tablex = "stocks a,$table b,  tbl_consumables c";		
	}
	else if ($table  =="stocks_promo"){
	
		if($branch_id != 1){
			$where="a.type = 3 and a.branch = '$branch_id' AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.promo_id and (b.status = 'ON HAND')";	
		}else{
			$where="a.type = 3 AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.promo_id and (b.status = 'ON HAND')";	
		}
		
		$row = "b.*,c.selling_price";
		$tablex = "stocks a,$table b,  tbl_promo c";
	}
	else if($table  =="stock_repo"){
	

		if($branch_id != 1){
			

			$where = "a.type = 5 AND a.branch = '$branch_id' AND a.dr_no = b.dr_no AND b.model = ".$id." AND b.model = c.motor_id AND b.status = 'ON HAND' ";
		
		}else{
		
			$where = "a.type = 5 AND a.dr_no = b.dr_no AND b.model = ".$id." AND b.model = c.motor_id AND b.status = 'ON HAND' ";
		}
			
		$row = "b.*,c.selling_price";
		$tablex = "stocks a,$table b,tbl_motorcycle c";
		
	}
	
	$db->select($tablex,$row,$where);
		$result = $db->getResult();	
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	
	
	
	
	
	
	
	
	case 'load_item_transfer';	
		$id = $_REQUEST['id'];
		$table = $_REQUEST['table'];
	 $branch_id = $_REQUEST['branch_id'];
	
	if($table  =="stocks_motors"){
		
		if($branch_id != 1){
			
			$where="a.type = 1 and a.branch = '$branch_id' AND a.dr_no = b.dr_no and b.model = '$id' AND b.model = c.motor_id and (b.status = 'ON HAND')";
		}else{
			
			$where="a.type = 1  AND a.dr_no = b.dr_no and b.model = '$id' AND b.model = c.motor_id and (b.status = 'ON HAND')";
		}
			
		$row = "b.*,c.selling_price";
		$tablex = "stocks a,$table b, tbl_motorcycle c";
		
	}else if($table  =="stocks_parts"){
	
		if($branch_id != 1){
			$where="a.type = 2 and a.branch = '$branch_id' AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.parts_id group by b.brand,b.item,b.serial_no ";
		}else{
			$where="a.type = 2  AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.parts_id group by b.brand,b.item,b.serial_no ";
		}
		
		
		$row = "b.id,b.dr_no,b.brand,b.item,b.serial_no,sum(b.quantity) as quantity,sum(b.remaining) as remaining,c.selling_price ";
		$tablex = "stocks a,$table b,  tbl_parts c";		
	}
	
	else if($table  =="stocks_consumables"){
		if($branch_id != 1){
			
		$where="a.type = 4 and a.branch = '$branch_id' AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.con_id group by b.brand,b.item,b.serial_no ";
		}else{
			
		$where="a.type = 4  AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.con_id group by b.brand,b.item,b.serial_no ";
		}
		
		$row = "b.id,b.dr_no,b.brand,b.item,b.serial_no,sum(b.quantity) as quantity,sum(b.remaining) as remaining,c.selling_price ";
		$tablex = "stocks a,$table b,  tbl_consumables c";		
	}
	else if ($table  =="stocks_promo"){
	
		if($branch_id != 1){
			$where="a.type = 3 and a.branch = '$branch_id' AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.promo_id and (b.status = 'ON HAND')";	
		}else{
			$where="a.type = 3 AND a.dr_no = b.dr_no and b.item = '$id' AND b.brand = c.brand AND b.item = c.promo_id and (b.status = 'ON HAND')";	
		}
		
		$row = "b.*,c.selling_price";
		$tablex = "stocks a,$table b,  tbl_promo c";
	}
	else if($table  =="stock_repo"){
	

		if($branch_id != 1){
			

			$where = "a.type = 5 AND a.branch = '$branch_id' AND a.dr_no = b.dr_no AND b.model = ".$id." AND b.model = c.motor_id AND b.status = 'ON HAND' ";
		
		}else{
		
			$where = "a.type = 5 AND a.dr_no = b.dr_no AND b.model = ".$id." AND b.model = c.motor_id AND b.status = 'ON HAND' ";
		}
			
		$row = "b.*,c.selling_price";
		$tablex = "stocks a,$table b,tbl_motorcycle c";
		
	}
	
	$db->select($tablex,$row,$where);
		$result = $db->getResult();	
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	
	
	
	
	
	/* case 'load_item_retun';	
	$id = $_REQUEST['id'];
	$table = $_REQUEST['table'];
	
	if($table  =="stocks_motors"){
		$where="a.stock_id = b.id";
		$row = "a.*,b.engine_no,b.frame_no,b.color";
		$tablex = "sale_invoice_details b,$table a";
	}
	
	else if($table  =="stocks_parts"){
		$where="a.stock_id = b.id";
		$row = "a.*,b.engine_no,b.serial_no";
		$tablex = "sale_invoice_details b,$table a";	
	}
	
	else if($table  =="stocks_consumables"){
		$where="a.stock_id = b.id";
		$row = "a.*,b.engine_no,b.serial_no";
		$tablex = "sale_invoice_details b,$table a";	
	}
	
	else if ($table  =="stocks_promo"){
		$where="a.stock_id = b.id";
		$row = "a.*,b.engine_no,b.serial_no";
		$tablex = "sale_invoice_details b,$table a";
	}
	
	$db->select($tablex,$row,$where);
		$result = $db->getResult();	
	
	echo '{"members":'.json_encode($result).'}';
	break; */
	
	
	case "save_inter_collection";
			
				$txtor_no=$_REQUEST["txtor_no"];
				$amount=$_REQUEST["amount"];
				$ramarks=$_REQUEST["ramarks"];

				
				$rows ='or_no,remarks,amount';
				$values = array($txtor_no,$ramarks,$amount);
				
				$db->insert('collection_interbranch',$values,$rows);
				
				echo "saved";
					
				
	break;
	
	case 'load_collection_interbranch';
	
	$or_no = $_REQUEST['or_no'];
	$row = "*" ;	
	$where = "or_no = '$or_no' ";
	$db->select("collection_interbranch",$row,$where);

	$result = $db->getResult();

	print json_encode($result);
		
	break;
	
	
	case 'load_collection_loan';
	
	$or_no = $_REQUEST['or_no'];
	$row = "a.*,substr(b.installment_due,9) as ins_due,c.penalty_interest,b.monthly_rebate,b.account_no,b.int_income_1,b.principal_amt_1,b.terms,b.amount_loan,b.interest_income" ;
	
	
	$where = "a.or_no = '$or_no' AND a.customer_id = b.customer_name AND b.loan_type_id = c.id AND a.account_no = b.account_no ";
	$db->select("collection_loan a, tbl_ledger b,tbl_loan c",$row,$where);

	$result = $db->getResult();

	print json_encode($result);
		
	break;
	
	case 'remove_discount';
	
	$or_no = $_REQUEST['or_no'];
	
	$rowsx = array('discount' => '0');
	$wherex ="or_no = '$or_no'";
	$db->update("collection_loan",$rowsx,$wherex);
	
	$wherex ="or_no = '$or_no' AND  description = 'DISCOUNT'";
	$db->delete("dr_cr_menu",$wherex);
	
	
	
	print "saved";
		
	break;
	
	
	case 'add_rebate';
	
	$or_no = $_REQUEST['or_no'];
	$rebate = $_REQUEST['rebate'];
	$monthly = $_REQUEST['monthly'];
	$customer = $_REQUEST['customer'];
	$rowsx = array('rebate' => $rebate,
				   'dues' => $monthly,
				   'customer_id'=> $customer,
				    'penalty'=>'0',
				   'discount'=>'0',);
	$wherex ="or_no = '$or_no'";
	$db->update("collection_loan",$rowsx,$wherex);
	print "saved";
		
	break;
	
	
	case 'add_discount';
	
	$or_no = $_REQUEST['or_no'];
	$discount = $_REQUEST['discount'];
	$rowsx = array('discount' => $discount);
	$wherex ="or_no = '$or_no'";
	$db->update("collection_loan",$rowsx,$wherex);
	print "saved";
		
	break;
	
	
	case 'update_loan';
	
	$or_no = $_REQUEST['or_no'];
	$value = $_REQUEST['value'];
	$row = $_REQUEST['row'];
	
	 $rowsx = array($row => $value);
	$wherex ="or_no = '$or_no'";
	$db->update("collection_loan",$rowsx,$wherex);
	print "saved";
		
	break;
	
	
	case 'viewCustomer_Ledger';
				$customer = array();
			
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$category=$_REQUEST['category'];
				$trimmed=trim($_REQUEST['inputsearch']);
				
				if($sort == "customer_name") {
					$sort1 = "CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name)";
				}
				else {
					$sort1 = $sort;
				}
				
				if($category == "customer_name") {
					
					$rows ="a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code,round(e.installment_amount) as monthly_down,e.terms,substr(e.installment_due,9) as ins_due,f.penalty_interest,e.monthly_rebate,e.account_no";
					
					
					$where = "a.id = e.customer_name AND a.id = e.customer_name AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',
					',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%' AND e.loan_type_id = f.id";
					$order = "$sort1 $sortType";
					$db->select("tbl_customer a, tbl_province b, tbl_city c, tbl_branch d,tbl_ledger e, tbl_loan f",$rows,$where,$order);
				}
				if($category == "branch") {
					$rows ="a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code,round(e.installment_amount) as monthly_down,e.terms,substr(e.installment_due,9) as ins_due,f.penalty_interest,e.monthly_rebate,e.account_no";
					$where = "a.id = e.customer_name AND a.id = e.customer_name AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND d.branch_name LIKE '%".$trimmed."%' AND e.loan_type_id = f.id";
					$order = "$sort1 $sortType";
					$db->select("tbl_customer a, tbl_province b, tbl_city c, tbl_branch d, tbl_ledger e,tbl_loan f",$rows,$where,$order);
				}
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}'; 
				
			break;
			
			
			case "saveORnumber";
			
				$txtor_no=$_REQUEST["txtor_no"];
				$date_issued=$_REQUEST["date_issued"];
				$date = substr($_REQUEST['date_issued'],8);
				
				$customer_id=$_REQUEST["customer_id"];
				$txtbranch=$_REQUEST["txtbranch"];
				$address=$_REQUEST["address"];
				$txtpayment=$_REQUEST["txtpayment"];
				
				$monthly=$_REQUEST["monthly"];
				$rebate=$_REQUEST["rebate"];
				$penalty=$_REQUEST["penalty"]/100;
				$ins_due=$_REQUEST["ins_due"];
				$account_no=$_REQUEST["account_no"];
				
				$rows1 = "*";
				$where1 = "or_no=".$txtor_no;
				
				
				if($db->recordExist('collections',$rows1,$where1) > 0){
					echo "exists";
				
				
				}else {
				
							if($txtpayment =="LOAN"){
							
								$where2 = "account_no = '$account_no' AND customer_id = '$customer_id' ";						
								if($db->recordExist('collection_loan',"*",$where2) > 0){
										
											$row='installment_amount,terms,amount_loan,principal_amt_1,interest_income,int_income_1';
											$where= "account_no = '$account_no' AND customer_name = '$customer_id' ";	
											$db->select("tbl_ledger",$row,$where);
											$result = $db->getResult();
											
											
											 foreach($result as $info){
											
												$ins_amount = $info['installment_amount'];
												
												$terms = $info['terms'];
												
												$amount_loan = $info['amount_loan'];
												$principal_amt_1 = $info['principal_amt_1'];
												
												$interest_income = $info['interest_income'];
												$int_income_1 = $info['int_income_1'];
												
												
												$principal = (($amount_loan - $principal_amt_1) / ($terms - 1));
												$int_income = (($interest_income - $int_income_1) / ($terms - 1));
												
												
													$dues_month = $principal + $int_income;
											
						
													if($date > $ins_due){
													
												
										
													$diff = $date - $ins_due;
													$penalty2 = ($diff*$penalty*$ins_amount)/30;
										
													$rows ='or_no,customer_id,account_no,principal,interest,dues,penalty,penalty_discount';
													$values = array($txtor_no,$customer_id,$account_no,$principal,$int_income,$dues_month,$penalty2,$penalty2);
													} 
													else if ($date <= $ins_due ){
													$rows ='or_no,customer_id,account_no,principal,interest,dues';
													$values = array($txtor_no,$customer_id,$account_no,$principal,$int_income,$dues_month);
													}
								
													 $db->insert('collection_loan',$values,$rows);
											
											
											}
											
											
											
			
								
								}else{
								
								
											$rowx="installment_amount,int_income_1,principal_amt_1";
											$wherex= "account_no = '$account_no' AND customer_name = '$customer_id' ";	
											$db->select("tbl_ledger",$rowx,$wherex);
											$result = $db->getResult();
											
											
											
											  foreach($result as $info){
											
												$ins_amount = $info['installment_amount'];
												$principal = $info['principal_amt_1'];
												$int_income = $info['int_income_1'];
												$dues_month = $principal + $int_income;
											
						
													if($date > $ins_due){
										
													$diff = $date - $ins_due;
													$penalty2 = ($diff*$penalty*$ins_amount)/30;
										
													$rows ='or_no,customer_id,account_no,principal,interest,dues,penalty,penalty_discount,status';
													$values = array($txtor_no,$customer_id,$account_no,$dues_month,$penalty2,$penalty2,'1st loan');
													}
													else if ($date <= $ins_due ){
													$rows ='or_no,customer_id,account_no,principal,interest,dues,status';
													$values = array($txtor_no,$customer_id,$account_no,$principal,$int_income,$dues_month,'1st loan');
													}
								
													$db->insert('collection_loan',$values,$rows);
											
											}  
											
											
									
											
								
								}
							
							
									
									
											
							}
							
								$rows ='or_no,customer_id,address,date,branch_code,type';
								$values = array($txtor_no,$customer_id,$address,$date_issued,$txtbranch,$txtpayment);
								$db->insert('collections',$values,$rows);
								echo "saved";
							
						
				
					
					
				}
			break;
			
			
		case 'ADD_CASH';
		$array = $_REQUEST["array"];
		$table = $_REQUEST["table"];
		$or_no = $_REQUEST["or_no"];
		
		
		$var = $quantity ;
		
		if($table =="stocks_parts" || $table =="stocks_consumables"){
		
				foreach( $array as $key => $value) { 
				 $val =  $value['serial_no'];
				$quantity = $value['quantity'];
				$selling = $value["selling"];
				
				$brand = $value['brand'];
				$item = $value['item'];
				
				$where = "serial_no = '$val' AND brand = '$brand' AND  item = '$item'  ";
				$order = "id desc";		
				$db->select($table,'*',$where,$order);
				$result = $db->getResult();
				
						foreach($result as $info){
						
									 $id = $info['id'];
									 $brand = $info['brand'];
									 $item = $info['item'];
									 $serial_no = $info['serial_no'];
									 $remaining = $info['remaining'];
									 
									 $var = $quantity ;
																			 
									 if(empty($color)){
										$color = "";
									}
									if($table =="stocks_parts"){
										$cat = 2;
									} else if($table =="stocks_consumables"){
										$cat = 4;
									}
									
									 
								
									$c = $var;
									$answer = ($var - $remaining);
									$var = $answer;

									if($var < 0) $var = 0; 
									if($var > 0){

									 $rowsx = array('remaining' => '0');
									$wherex ="id = '$id' AND brand = '$brand' AND  item = '$item' ";
									$db->update($table,$rowsx,$wherex);

									$rows ='or_no,stock_id,category,type,amount,qty';
									$values = array($or_no,$id,$cat,'ITEMS',$selling,$remaining);
									$db->insert("collection_cash",$values,$rows); 
                  
									}else{ 
 
									 $answer = abs($answer); 
									$rowsx = array('remaining' => $answer);
									$wherex ="id = '$id' AND brand = '$brand' AND  item = '$item' ";
									$db->update($table,$rowsx,$wherex); 
									
									$rows ='or_no,stock_id,category,type,amount,qty';
									$values = array($or_no,$id,$cat,'ITEMS',$selling,$c);
									$db->insert("collection_cash",$values,$rows);
									break; 
									}
									
									
									
									
						}
				
				}
		
		
		}else{
	
				 foreach( $array as $key => $value) { 
					
					 $val =  $value['serial_no'];
					 $selling = $value["selling"];
				
					$where = "id = '$val' ";
							
					$db->select($table,'*',$where);
					$result = $db->getResult();
					
						foreach($result as $info){
									
									$id = $info['id'];
									$brand = $info['brand'];
									$color = $info['color'];
									$remaining = $info['remaining'];
									
									if(empty($color)){
										$color = "";
									}
									
									if($table =="stocks_motors"){			
									 $item = $info['model'];
									 $cat = 1;
									}
									
									else if($table =="stocks_promo"){
										$item = $info['item'];
										$cat = 3;
									}
									
									
									
									
						}
									
					
						
						
						$rows ='or_no,stock_id,category,type,amount,qty';
						$values = array($or_no,$id,$cat,'ITEMS',$selling,'1');
						$db->insert("collection_cash",$values,$rows);
					
						$rowsx = array('status' => "SOLD");
						$wherex ="id = '$id'";
						$db->update($table,$rowsx,$wherex);
						
				}
		
	}		
			print "uhryt";
		
				
	break;
	

	
	case 'load_cash_collection';
	
	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$or_no = $_REQUEST['or_no'];
	
	$where = "or_no='$or_no'";
	$db->select("collection_cash","*",$where);
	$result = $db->getResult();
	
	foreach($result as $key){
		 $category=$key["category"];
		  $dr_no=$key["dr_no"];
		 
		if($category == '1'){
		 
			$row = "a.type,a.invoice_no,a.category,a.id as cash_id,a.stock_id,a.type,a.amount,a.qty,b.engine_no,b.frame_no,b.color,c.model,d.brand";
			$table = "collection_cash a,stocks_motors b,tbl_motorcycle c,tbl_manufacturer d";
			
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = d.category AND a.or_no = '$or_no'"; 
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray=$result;	
		 }
		 
		 else if($category == '2'){

			$row = "a.type,a.invoice_no,a.category,a.id as cash_id,a.stock_id,a.type,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
			$table = "collection_cash a,stocks_parts b,tbl_parts c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.parts_id AND b.brand = d.id AND a.category = d.category AND a.or_no = '$or_no'";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray2=$result;
		   
		 
		 }
		 else if($category == '3'){
			
			
			$row = "a.type,a.invoice_no,a.category,a.id as cash_id,a.stock_id,a.type,a.amount,a.qty,b.serial_no,b.color,c.item_code,d.brand";
			$table = "collection_cash a,stocks_promo b,tbl_promo c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.promo_id AND b.brand = d.id AND a.category = d.category AND a.or_no = '$or_no'";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray3=$result;
		  
		 }
		 else if($category == '4'){
			
			
			$row = "a.type,a.invoice_no,a.category,a.id as cash_id,a.stock_id,a.type,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
			$table = "collection_cash a,stocks_consumables b,tbl_consumables c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.con_id AND b.brand = d.id AND a.category = d.category AND a.or_no = '$or_no'";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray4=$result;
		   
		 }
		
		$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4);
		
	}
	
	 

		if(empty($output)){
		
			echo '{"members":'.json_encode($result).'}';
			
		}else{

			echo '{"members":'.json_encode($output).'}';
		}
	break;
	
	case 'edit_amount';
	$id = $_REQUEST['id'];
	$amount = $_REQUEST['amount'];
	
	$rowsx = array('amount' => $amount);
	$wherex ="id = '$id'";
	$db->update("collection_cash",$rowsx,$wherex);
	print "saved";	
	break;
	
	
	
	case 'edit_amount_loan';
	$or_no = $_REQUEST['or_no'];
	$amount = $_REQUEST['amount'];
	$col = $_REQUEST['col'];
	
	$rowsx = array($col => $amount);
	$wherex ="or_no = '$or_no'";
	$db->update("collection_loan",$rowsx,$wherex);
	print "saved";	
	break;
	
	
	
	case 'edit_amount_invoice';
	$id = $_REQUEST['id'];
	$amount = $_REQUEST['amount'];
	
	$rowsx = array('amount' => $amount);
	$wherex ="id = '$id'";
	$db->update("sale_invoice_details",$rowsx,$wherex);
	print "saved";	
	break;
	
	
	
	case 'delete_cash';
	$cash_id=$_REQUEST['cash_id'];
	$stock_id=$_REQUEST['stock_id'];
	$tablex=$_REQUEST['tablex'];
	$quantity=$_REQUEST['quantity'];
		if($tablex == "stocks_parts" || $tablex == "stocks_consumables" ){
			
			 $where="id = ".$stock_id;
			$db->select($tablex,"*",$where);
			$result = $db->getResult();
			
				foreach($result as $info){
					$idx = $info['id'];
					$data = $info['remaining'];
				}
			$sum = $data+$quantity;
			
			$wherex="id = '$idx'";
			$rowsx = array('remaining' =>$sum );
			$db->update($tablex,$rowsx,$wherex); 
		
		}else{
			
			$where="id= '$stock_id'";
			$rows = array('status' => "ON HAND");
			$db->update($tablex,$rows,$where);
		}
	
	$wherex="id = '$cash_id' ";
	$db->delete("collection_cash",$wherex);
	break;
	
			
	case "updateORnumber";
			
				$id=$_REQUEST["id"];
				$address=$_REQUEST["address"];
				$branch_code=$_REQUEST["branch_code"];
				$or_no=$_REQUEST["or_no"];

				$where = "or_no= '$or_no' ";
				
				$rows = array('customer_id' => $id
				,'address' => $address
				,'branch_code' => $branch_code
				);
			  
			$db->update('collections',$rows,$where); 				
					
			echo "saved";	
	break;
	
	case 'select_payment';
	
 	 $or_no = $_REQUEST['or_no'];
				$where = "or_no = '$or_no' group by or_no ";
				$db->select("collection_cash","type",$where);
				$result = $db->getResult();
		
				print '{"members":'.json_encode($result).'}';
	break;
	
	case'UPDATE_CASH_RECORD';
	
	$txtor_no = $_REQUEST['txtor_no'];
	$date_issued = $_REQUEST['date_issued'];
	$customer_id = $_REQUEST['customer_id'];
	$txtbranch = $_REQUEST['txtbranch'];
	$address = $_REQUEST['address'];
	$txtpayment = $_REQUEST['txtpayment'];
	
	$rows = array('customer_id' => $customer_id,
					'address' => $address,
					'date' => $date_issued,
					'branch_code' => $txtbranch,);
	
	$where ="or_no = '$txtor_no'";
	$db->update('collections',$rows,$where);
	
	
	$rowsx = array('type' =>$txtpayment,);
	
	$wherex ="or_no = '$txtor_no'";
	$db->update('collection_cash',$rowsx,$wherex);
	
	print "saved";
	break;
	
	
	case'UPDATE_INTERBRANCH';
	
	$txtor_no = $_REQUEST['txtor_no'];
	$date_issued = $_REQUEST['date_issued'];
	$customer_id = $_REQUEST['customer_id'];
	$txtbranch = $_REQUEST['txtbranch'];
	$address = $_REQUEST['address'];
	
	$rows = array('customer_id' => $customer_id,
					'address' => $address,
					'date' => $date_issued,
					'branch_code' => $txtbranch,);
	
	$where ="or_no = '$txtor_no'";
	$db->update('collections',$rows,$where);

	
	print "saved";
	break;
	
	
	
	case'SetUpdate_loan';
	
	$txtor_no = $_REQUEST['txtor_no'];
	$date = substr($_REQUEST['date_issued'],8);
	$date_issued = $_REQUEST['date_issued'];
	$customer_id = $_REQUEST['customer_id'];
	$txtbranch = $_REQUEST['txtbranch'];
	$address = $_REQUEST['address'];
	
				$monthly=$_REQUEST["monthly"];
				$rebate=$_REQUEST["rebate"];
				$penalty=$_REQUEST["penalty"]/100;
				$ins_due=$_REQUEST["ins_due"];
				$account_no=$_REQUEST["account_no"];
	
	 $rows = array('customer_id' => $customer_id,
					'address' => $address,
					'date' => $date_issued,
					'branch_code' => $txtbranch,);
	
	$where ="or_no = '$txtor_no'";
	$db->update('collections',$rows,$where);
	
	
			if($date > $ins_due   ){
			$diff = $date-$ins_due;
			echo $diff;
			$row_ledger = "installment_amount";
			$where_ledger = "customer_name=$customer_id";
			$db->selectSingle("tbl_ledger",$row_ledger,$where_ledger);
			$ins_amount = $db->getSingleResult();
			
			$penalty2 = ($diff*$penalty*$ins_amount)/30;
			//$penalty = $monthly * $penalty / 100;
			$rowsx = array('customer_id' => $customer_id,
							'account_no' => $account_no,
							'dues' => $monthly,
							'penalty' => $penalty2,
							'rebate' => '0',
							'discount' => '0',
						);
			}
			else if ($date <= $ins_due ){
					$rowsx = array('customer_id' => $customer_id,
									'account_no' => $account_no,
									'dues' => $monthly,
									'rebate' => $rebate,
									'penalty' => '0',
									'discount' => '0',
									);
			
			}
			$wherex ="or_no = '$txtor_no'";			
			$db->update('collection_loan',$rowsx,$wherex);
	
	print "saved"; 
	break;
	
	
		case'Set_loan_update';
	
	$txtor_no = $_REQUEST['txtor_no'];
	$date = substr($_REQUEST['date_issued'],8);
	$date_issued = $_REQUEST['date_issued'];
	$customer_id = $_REQUEST['customer_id'];
	$txtbranch = $_REQUEST['txtbranch'];
	$address = $_REQUEST['address'];
	
	$compare_date = $_REQUEST['compare_date'];
	
	
	if($compare_date != $date_issued ){
	
				
							$monthly=$_REQUEST["monthly"];
							$rebate=$_REQUEST["rebate"];
							$penalty=$_REQUEST["penalty"]/100;
							$ins_due=$_REQUEST["ins_due"];
							$account_no=$_REQUEST["account_no"];
				
				$rows = array('customer_id' => $customer_id,
								'address' => $address,
								'date' => $date_issued,
								'branch_code' => $txtbranch,);
				
				$where ="or_no = '$txtor_no'";
				$db->update('collections',$rows,$where);
				
				
						if($date > $ins_due ){
						
						$diff = $date-$ins_due;
						
						//echo $diff;
						
						$row_ledger = "installment_amount";
						$where_ledger = "customer_name=$customer_id";
						$db->selectSingle("tbl_ledger",$row_ledger,$where_ledger);
						$ins_amount = $db->getSingleResult();
						
						$penalty2 = ($diff*$penalty*$ins_amount)/30;
						//$penalty = $monthly * $penalty / 100;
						$rowsx = array('customer_id' => $customer_id,
										'account_no' => $account_no,
										'penalty_discount' => $penalty2,
										'penalty' => $penalty2,
										'rebate' => '0',
										'discount' => '0'
									);
						}
						else if ($date <= $ins_due ){
								$rowsx = array('customer_id' => $customer_id,
												'account_no' => $account_no,
												'rebate' => $rebate,
												'penalty_discount' => '0',
												);
						
						}
						$wherex ="or_no = '$txtor_no'";			
						$db->update('collection_loan',$rowsx,$wherex);
						
						$wherey ="or_no = '$txtor_no'";	
						$db->delete("dr_cr_menu",$wherey);
				
				print "saved"; 
	}else{
	
		print "no changes";
	}
	
	
	break;
	
	
	
	
	case 'Add_saleinvoice';
		$array = $_REQUEST["array"];
		
		$table = $_REQUEST["table"];
		$invoice_no = $_REQUEST["invoice"];
		
				

	if($table =="stocks_parts" || $table =="stocks_consumables"){
		
		foreach( $array as $key => $value) { 
				
				 $val =  $value['serial_no'];
				$quantity = $value['quantity'];
				$selling = $value["selling"];
				
				$brand = $value['brand'];
				$item = $value['item'];
				$branch = $value['branch'];
				
				$var = $quantity ;
				
				$where = "serial_no = '$val' AND brand = '$brand' AND  item = '$item' ";
				$order = "id desc";		
				$db->select($table,'*',$where,$order);
				$result = $db->getResult();
				
						foreach($result as $info){
						
									 $id = $info['id'];
									 $brand = $info['brand'];
									 $item = $info['item'];
									 $serial_no = $info['serial_no'];
									 $remaining = $info['remaining'];
																			 
									 if(empty($color)){
										$color = "";
									}
									if($table =="stocks_parts"){
										$cat = 2;
									} else if($table =="stocks_consumables"){
										$cat = 4;
									}
									
									 
							
									$c = $var;
									
									
									$answer = ($var - $remaining);
									$var = $answer;

									if($var < 0) $var = 0; 
									if($var > 0){

									 $rowsx = array('remaining' => '0');
									$wherex ="id = '$id' AND brand = '$brand' AND  item = '$item'";
									$db->update($table,$rowsx,$wherex);

									$rows ='invoice_no,serial_no,stock_id,category,amount,qty,branch';
									$values = array($invoice_no,$serial_no,$id,$cat,$selling,$remaining,$branch);
									$db->insert("sale_invoice_details",$values,$rows); 
                  
									}else{ 
 
									 $answer = abs($answer); 
									$rowsx = array('remaining' => $answer);
									$wherex ="id = '$id' AND brand = '$brand' AND  item = '$item'";
									$db->update($table,$rowsx,$wherex); 
									
									$rows ='invoice_no,serial_no,stock_id,category,amount,qty,branch';
									$values = array($invoice_no,$serial_no,$id,$cat,$selling,$c,$branch);
									$db->insert("sale_invoice_details",$values,$rows);
									break; 
									}				
							
						}
				
			}
		
		
		}else{
	
				foreach( $array as $key => $value) { 
					
					 $val =  $value['serial_no'];
					 $selling = $value["selling"];
					 $branch = $value["branch"];
				
					 $where = "id = '$val' ";
							
					$db->select($table,'*',$where);
					$result = $db->getResult();
					
						foreach($result as $info){
									
									$id = $info['id'];
									$brand = $info['brand'];
									$color = $info['color'];
									 
									//$remaining = $info['remaining'];
									
									if(empty($color)){
										$color = "";
									}
									
									if($table =="stocks_motors"){			
									$serial_no = $info['engine_no'];
									 $cat = 1;
									}
									
									else if($table =="stocks_promo"){
										$serial_no = $info['serial_no'];
										$cat = 3;
									}
									
									else if($table =="stock_repo"){
										$serial_no = $info['engine'];
										$cat = 5;
									}
									
								$rows ='invoice_no,serial_no,stock_id,category,amount,qty,branch';
								$values = array($invoice_no,$serial_no,$id,$cat,$selling,'1',$branch);
								$db->insert("sale_invoice_details",$values,$rows);
							
								$rowsx = array('status' => "SOLD");
								$wherex ="id = '$id'";
								$db->update($table,$rowsx,$wherex);	
									
									
						} 
									
						
				} 
		
	}
			print "uhryt";
	
				
	break;
	
	case 'load_sale_invoice';
	
	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$invoice_no = $_REQUEST['invoice_no'];
	
	$where = "invoice_no='$invoice_no'";
	$db->select("sale_invoice_details","*",$where);
	$result = $db->getResult();
	
	foreach($result as $key){
		 $category=$key["category"];
		  $invoice_no=$key["invoice_no"];
		 
		if($category == '1'){
		 
			$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.engine_no,b.frame_no,b.color,c.model,d.brand";
			$table = "sale_invoice_details a,stocks_motors b,tbl_motorcycle c,tbl_manufacturer d";
			
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = d.category AND a.invoice_no = '$invoice_no' and a.category = 1 "; 
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray=$result;	
			
		 }else if($category == '5'){
			
			$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.engine as engine_no ,b.frame as frame_no,b.color,c.model,d.brand";
			
			$table = "sale_invoice_details a,stock_repo b,tbl_motorcycle c,tbl_manufacturer d";
			
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = 5 AND a.invoice_no = '$invoice_no'  "; 
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray=$result;	
		 }
		 
		 else if($category == '2'){

			$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
			$table = "sale_invoice_details a,stocks_parts b,tbl_parts c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.parts_id AND b.brand = d.id AND a.category = d.category AND a.invoice_no = '$invoice_no' and a.category = 2 ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray2=$result;
		   
		 
		 }
		 else if($category == '3'){
			
			
			$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,b.color,c.item_code,d.brand";
			$table = "sale_invoice_details a,stocks_promo b,tbl_promo c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.promo_id AND b.brand = d.id AND a.category = d.category AND a.invoice_no = '$invoice_no' and a.category =  3";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray3=$result;
		  
		 }
		 else if($category == '4'){
			
			
			$row = "a.category,a.id as invoice_id,a.stock_id,a.amount,a.qty,b.serial_no,c.item_code,d.brand";
			$table = "sale_invoice_details a,stocks_consumables b,tbl_consumables c,tbl_manufacturer d";
			$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.con_id AND b.brand = d.id AND a.category = d.category AND a.invoice_no = '$invoice_no' and a.category = 4 ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray4=$result;
		   
		 }
		
		$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4);
		
	}
	
	 

		if(empty($output)){
		
			echo '{"members":'.json_encode($result).'}';
			
		}else{

			echo '{"members":'.json_encode($output).'}';
		}
	break;
	
	case 'delete_sale_invoice';
	$invoice_id=$_REQUEST['invoice_id'];
	$stock_id=$_REQUEST['stock_id'];
	$tablex=$_REQUEST['tablex'];
	$quantity=$_REQUEST['quantity'];
		if($tablex == "stocks_parts" || $tablex == "stocks_consumables" ){
			
			 $where="id = ".$stock_id;
			$db->select($tablex,"*",$where);
			$result = $db->getResult();
			
				foreach($result as $info){
					$idx = $info['id'];
					$data = $info['remaining'];
				}
			$sum = $data+$quantity;
			
			$wherex="id = '$idx'";
			$rowsx = array('remaining' =>$sum );
			$db->update($tablex,$rowsx,$wherex); 
		
		}else{
			
			$where="id= '$stock_id'";
			$rows = array('status' => "ON HAND");
			$db->update($tablex,$rows,$where);
		}
	
	$wherex="id = '$invoice_id' ";
	$db->delete("sale_invoice_details",$wherex);
	break;
	
	
	
	case 'delete_sale_return';
	
	$invoice_no=$_REQUEST['invoice_no'];
	$stock_id=$_REQUEST['stock_id'];
	$category=$_REQUEST['category'];
	$sr_id=$_REQUEST['sr_id'];
	$source=$_REQUEST['source'];
	$quantity=$_REQUEST['quantity'];
	
	
		if($source =="invoice"){
			 $table = "sale_invoice_details";
			$col = "invoice_no";
		}else if($source =="cash"){
			$table = "collection_cash";
			$col = "or_no";
		}
	
			
			$where="$col = '$invoice_no' AND stock_id = '$stock_id' AND category = '$category' ";
			$db->select($table,"*",$where);
			$result = $db->getResult();
			
				foreach($result as $info){
					$idx = $info['id'];
					 $qty = $info['qty'];
				}
			 $sum = $qty+$quantity;
			 
			 $wherex="$col = '$invoice_no' AND stock_id = '$stock_id' AND category = '$category' ";
			 $rowsx = array('qty' =>$sum );
			 $db->update($table,$rowsx,$wherex);
			 
			 
			if($category == '2'){
										
				$where = "id = '$stock_id'";
				$db->select("stocks_parts",'remaining',$where);
				$resulty = $db->getResult();
					
					 foreach($resulty as $data){
						$remaining = $data['remaining'];
					 }
				$sumy = $remaining - $quantity;
				
				$rowsy = array('remaining' => $sumy);
				$wherey ="id = '$stock_id'";
				$db->update("stocks_parts",$rowsy,$wherey);
										
										
			}else if($category == '4'){
										
										 
				$where = "id = '$stock_id'";
				$db->select("stocks_consumables",'remaining',$where);
				$resulty = $db->getResult();
					
					 foreach($resulty as $data){
					  $remaining = $data['remaining'];
					 }
					 
					 
					$sumy = $remaining - $quantity;
				
				$rowsy = array('remaining' => $sumy);
				$wherey ="id = '$stock_id'";
				$db->update("stocks_consumables",$rowsy,$wherey);
			
				}else if($category == '1'){
			
					$rowsy = array('status' => 'SOLD');
					$wherey ="id = '$stock_id'";
					$db->update("stocks_motors",$rowsy,$wherey);
				
				
				}else if($category == '5'){
				
					 $rowsy = array('status' => 'SOLD');
					$wherey ="id = '$stock_id'";
					$db->update("stock_repo",$rowsy,$wherey);
				
				}else if($category == '3'){
				
					 $rowsy = array('status' => 'SOLD');
					$wherey ="id = '$stock_id'";
					$db->update("stocks_promo",$rowsy,$wherey);
				
				
				}
			 
	$wherex="id = '$sr_id' ";
	$db->delete("sr_details",$wherex);
	break;
	
	
	
	case 'load_return_brand';
	$table = $_REQUEST['table'];
	$branch_id = $_REQUEST['branch_id'];
	
	if($table=="stocks_motors"){
		$rows = "c.id, c.brand";
		$where = "a.branch = '$branch_id' AND a.stock_id = b.id AND b.brand = c.id AND a.qty != 0 AND a.category = 1 group by c.brand ";
		$tables ="sale_invoice_details a,$table b,tbl_manufacturer c";
	
	}
	else if($table=="stocks_parts"){
		$rows = "c.id, c.brand";
		$where = "a.branch = '$branch_id' AND a.stock_id = b.id AND b.brand = c.id AND a.qty != 0 AND a.category = 2  group by c.brand";
		$tables ="sale_invoice_details a,$table b,tbl_manufacturer c";
	
	}
	else if($table=="stocks_promo"){
		$rows = "c.id, c.brand";
		$where = "a.branch = '$branch_id' AND a.stock_id = b.id AND b.brand = c.id AND a.qty != 0 AND a.category = 3  group by c.brand";
		$tables ="sale_invoice_details a,$table b,tbl_manufacturer c";
	
	}
	else if($table=="stocks_consumables"){
		$rows = "c.id, c.brand";
		$where = "a.branch = '$branch_id' AND a.stock_id = b.id AND b.brand = c.id AND a.qty != 0 AND a.category = 4  group by c.brand";
		$tables ="sale_invoice_details a,$table b,tbl_manufacturer c";
	
	}
	
	$db->select($tables,$rows,$where);
	$result = $db->getResult();
	echo '{"members":'.json_encode($result).'}';
	break;
	
	case 'load_invoice_model';	
		
		$id = $_REQUEST['id'];
		$table = $_REQUEST['table'];
		$table2 = $_REQUEST['table2'];
	
	if($table2 == "tbl_motorcycle"){
	
		$where="b.model = c.motor_id and b.brand = '$id' AND a.stock_id = b.id and a.category = 1 ";
		$rows = "c.model,c.motor_id";
		
	
	}else if($table2 == "tbl_parts"){
	
		$where="b.item = c.parts_id and b.brand = '$id' AND a.stock_id = b.id and a.category = 2";
		$rows = "c.item_code,c.parts_id";
		
	
	}
	
	else if($table2 == "tbl_promo"){
	
		$where="b.item = c.promo_id and b.brand = '$id' AND a.stock_id = b.id and a.category = 3";
		$rows = "c.item_code,c.promo_id";
		
	
	}
	else if($table2 == "tbl_consumables"){
	
		$where="b.item = c.con_id and b.brand = '$id'  AND a.stock_id = b.id and a.category = 4";
		$rows = "c.item_code,c.con_id";
	
	
	}
	
	$tables = "sale_invoice_details a, $table b, $table2 c";
	
	$db->select($tables,$rows,$where);
	
	$result = $db->getResult();
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	case 'load_invoice_return';	
	$id = $_REQUEST['id'];
	$table = $_REQUEST['table'];
	
	if($table  =="stocks_motors"){
		$where="a.model = '$id' AND a.id = b.stock_id AND b.category = 1 group by b.invoice_no,b.stock_id,b.category";
		$row = "a.id as stock_id,a.engine_no,a.frame_no,a.color,b.amount,sum(b.qty) as qty,b.invoice_no,b.category,b.id";
		$tablex = "$table a,sale_invoice_details b ";
		
	}else if($table  =="stocks_parts"){
		$row = "a.id as stock_id,a.serial_no,b.amount,a.brand,a.item,sum(b.qty) as qty,b.invoice_no,b.category,b.id";
		$where="item = '$id' AND a.id = b.stock_id AND b.category = 2 group by b.invoice_no,a.serial_no,b.category";
		$tablex = "$table a,sale_invoice_details b";		
	}
	
	else if($table  =="stocks_consumables"){
		$row = "a.id as stock_id,a.serial_no,b.amount,a.brand,a.item,sum(b.qty) as qty,b.invoice_no,b.category,b.id";
		$where="item = '$id' AND a.id = b.stock_id AND b.category = 4 group by b.invoice_no,a.serial_no,b.category";
		$tablex = "$table a,sale_invoice_details b";		
	}
	else if ($table  =="stocks_promo"){
		$row = "a.id as stock_id,a.color,a.serial_no,b.amount,sum(b.qty) as qty,b.invoice_no,b.category,b.id";
		$where="item = '$id' AND a.id = b.stock_id AND b.category = 3 group by b.invoice_no,b.stock_id,b.category";
		$tablex = "$table a,sale_invoice_details b";
	}
	
	$db->select($tablex,$row,$where);
		$result = $db->getResult();	
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	
	
		
	print "uhryt";
		
	break;
	
	
	case 'load_return';
	
	$dataArray=array();
	$dataArray6=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$sr = $_REQUEST['sr'];
	
	$where = "sr_no='$sr'";
	$db->select("sr_details","*",$where);
	$result = $db->getResult();

	foreach($result as $key){
	
		  $category=$key["category"];
		   $sr_no=$key["sr_no"];
		   $source=$key["source"];
		 
		 if($source == "invoice"){
			
			$tablex = "sale_invoice_details";
		 }else if($source == "cash"){
			
			$tablex = "collection_cash";
		 }
					if($category == '1'){
					 
						$row = "a.source,a.inv_id,a.category,a.id as sr_id,a.stock_id,a.qty,b.engine_no,b.frame_no,b.color,c.model,d.brand,e.amount,a.invoice_no";
						$table = "sr_details a,stocks_motors b,tbl_motorcycle c,tbl_manufacturer d,$tablex e";
						$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = d.category AND a.sr_no = '$sr' AND a.inv_id = e.id AND a.qty != 0"; 
						$db->select($table,$row,$where);
						$result = $db->getResult();
						$dataArray=$result;	
					 }
					 
					else if($category == '5'){
					
					 
						$row = "a.source,a.inv_id,a.category,a.id as sr_id,a.stock_id,a.qty,b.engine engine_no,b.frame frame_no,b.color,c.model,d.brand,e.amount,a.invoice_no";
						
						$table = "sr_details a,stock_repo b,tbl_motorcycle c,tbl_manufacturer d,$tablex e";
						
						$where ="a.stock_id = b.id AND b.brand = c.brand AND b.model = c.motor_id AND b.brand = d.id AND a.category = 5 AND a.sr_no = '$sr_no' AND a.inv_id = e.id AND a.qty != 0"; 
						$db->select($table,$row,$where);
						$result = $db->getResult();
						$dataArray6=$result;	
					 }
					 
					  else if($category == '2'){

						$row = "a.source,a.inv_id,a.category,a.id as sr_id,a.stock_id,a.qty as qty,b.serial_no,c.item_code,d.brand,e.amount,a.invoice_no";
						
						$table = "sr_details a, stocks_parts b,tbl_parts c, tbl_manufacturer d,$tablex e";
						
						$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.parts_id AND b.brand = d.id AND a.category = d.category AND a.sr_no = '$sr' AND a.inv_id = e.id AND a.qty != 0" ;
						$db->select($table,$row,$where);
						$result = $db->getResult();
						$dataArray2=$result;
					   
					 
					 }
					 else if($category == '3'){
						
						
						$row = "a.source,a.inv_id,a.category,a.id as sr_id,a.stock_id,a.qty,b.serial_no,b.color,c.item_code,d.brand,e.amount,a.invoice_no";
						
						$table = "sr_details a, stocks_promo b,tbl_promo c,tbl_manufacturer d,$tablex e";
						
						$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.promo_id AND b.brand = d.id AND a.category = d.category AND a.sr_no = '$sr' AND a.inv_id = e.id AND a.qty != 0";
						$db->select($table,$row,$where);
						$result = $db->getResult();
						$dataArray3=$result;
					  
					 }
					 else if($category == '4'){
						
						
						$row = "a.source,a.inv_id,a.category,a.id as sr_id,a.stock_id,a.qty,b.serial_no,c.item_code,d.brand,e.amount,a.invoice_no";
						
						$table = "sr_details a,stocks_consumables b,tbl_consumables c,tbl_manufacturer d,$tablex e";
						
						$where ="a.stock_id = b.id AND b.brand = c.brand AND b.item = c.con_id AND b.brand = d.id AND a.category = d.category AND a.sr_no = '$sr' AND a.inv_id = e.id AND a.qty != 0";
						
						/*$table = "sr_details a LEFT JOIN stocks_consumables b ON a.stock_id = b.id LEFT JOIN tbl_consumables c ON  b.brand = c.brand  LEFT JOIN tbl_manufacturer d ON b.brand = d.id  LEFT JOIN  sale_invoice_details e ON a.inv_id = e.id";
						$where ="b.item = c.con_id  AND a.category = d.category AND a.sr_no = '$sr' AND a.qty != 0";*/
						
						$db->select($table,$row,$where);
						$result = $db->getResult();
						$dataArray4=$result;
					   
					 } 
					
					$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4,$dataArray6);
		
	}
	
	 

		if(empty($output)){
		
			echo '{"members":'.json_encode($result).'}';
			
		}else{

			echo '{"members":'.json_encode($output).'}';
		} 
	break;
	
	
	case 'select_invoice_or';
				 $table=$_REQUEST["table"];
				 $date=$_REQUEST["date"];
		if($table == "sales_invoice"){
				$row = "invoice_no as invoice";
				$where ="date_issued = '$date'";
				
		}else if($table == "collections"){
				$row = "or_no as invoice ";
				$where ="date = '$date' and type = 'CASH' ";
		}
				
				$db->select($table,$row,$where);
				$result = $db->getResult();
		
				print json_encode($result); 
	break;
	
	case 'delete_sale_invoice';
	$invoice_id=$_REQUEST['invoice_id'];
	$stock_id=$_REQUEST['stock_id'];
	$tablex=$_REQUEST['tablex'];
	$quantity=$_REQUEST['quantity'];
		if($tablex == "stocks_parts" || $tablex == "stocks_consumables" ){
			
			 $where="id = ".$stock_id;
			$db->select($tablex,"*",$where);
			$result = $db->getResult();
			
				foreach($result as $info){
					$idx = $info['id'];
					$data = $info['remaining'];
				}
			$sum = $data+$quantity;
			
			$wherex="id = '$idx'";
			$rowsx = array('remaining' =>$sum );
			$db->update($tablex,$rowsx,$wherex); 
		
		}else{
			
			$where="id= '$stock_id'";
			$rows = array('status' => "ON HAND");
			$db->update($tablex,$rows,$where);
		}
	
	$wherex="id = '$invoice_id' ";
	$db->delete("sale_invoice_details",$wherex);
	break;
	
	
	case 'load_return_brand';
	$table = $_REQUEST['table'];
	$branch_id = $_REQUEST['branch_id'];
	
	if($table=="stocks_motors"){
		$rows = "c.id, c.brand";
		$where = "a.branch = '$branch_id' AND a.stock_id = b.id AND b.brand = c.id AND a.qty != 0 AND a.category = 1 group by c.brand ";
		$tables ="sale_invoice_details a,$table b,tbl_manufacturer c";
	
	}
	else if($table=="stocks_parts"){
		$rows = "c.id, c.brand";
		$where = "a.branch = '$branch_id' AND a.stock_id = b.id AND b.brand = c.id AND a.qty != 0 AND a.category = 2  group by c.brand";
		$tables ="sale_invoice_details a,$table b,tbl_manufacturer c";
	
	}
	else if($table=="stocks_promo"){
		$rows = "c.id, c.brand";
		$where = "a.branch = '$branch_id' AND a.stock_id = b.id AND b.brand = c.id AND a.qty != 0 AND a.category = 3  group by c.brand";
		$tables ="sale_invoice_details a,$table b,tbl_manufacturer c";
	
	}
	else if($table=="stocks_consumables"){
		$rows = "c.id, c.brand";
		$where = "a.branch = '$branch_id' AND a.stock_id = b.id AND b.brand = c.id AND a.qty != 0 AND a.category = 4  group by c.brand";
		$tables ="sale_invoice_details a,$table b,tbl_manufacturer c";
	
	}
	
	$db->select($tables,$rows,$where);
	$result = $db->getResult();
	echo '{"members":'.json_encode($result).'}';
	break;
	
	case 'load_invoice_model';	
		
		$id = $_REQUEST['id'];
		$table = $_REQUEST['table'];
		$table2 = $_REQUEST['table2'];
	
	if($table2 == "tbl_motorcycle"){
	
		$where="b.model = c.motor_id and b.brand = '$id' AND a.stock_id = b.id and a.category = 1 ";
		$rows = "c.model,c.motor_id";
		
	
	}else if($table2 == "tbl_parts"){
	
		$where="b.item = c.parts_id and b.brand = '$id' AND a.stock_id = b.id and a.category = 2";
		$rows = "c.item_code,c.parts_id";
		
	
	}
	
	else if($table2 == "tbl_promo"){
	
		$where="b.item = c.promo_id and b.brand = '$id' AND a.stock_id = b.id and a.category = 3";
		$rows = "c.item_code,c.promo_id";
		
	
	}
	else if($table2 == "tbl_consumables"){
	
		$where="b.item = c.con_id and b.brand = '$id'  AND a.stock_id = b.id and a.category = 4";
		$rows = "c.item_code,c.con_id";
	
	
	}
	
	$tables = "sale_invoice_details a, $table b, $table2 c";
	
	$db->select($tables,$rows,$where);
	
	$result = $db->getResult();
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	case 'load_invoice_return';	
	$id = $_REQUEST['id'];
	$table = $_REQUEST['table'];
	
	if($table  =="stocks_motors"){
		$where="a.model = '$id' AND a.id = b.stock_id AND b.category = 1 group by b.invoice_no,b.stock_id,b.category";
		$row = "a.id as stock_id,a.engine_no,a.frame_no,a.color,b.amount,sum(b.qty) as qty,b.invoice_no,b.category,b.id";
		$tablex = "$table a,sale_invoice_details b ";
		
	}else if($table  =="stocks_parts"){
		$row = "a.id as stock_id,a.serial_no,b.amount,a.brand,a.item,sum(b.qty) as qty,b.invoice_no,b.category,b.id";
		$where="item = '$id' AND a.id = b.stock_id AND b.category = 2 group by b.invoice_no,a.serial_no,b.category";
		$tablex = "$table a,sale_invoice_details b";		
	}
	
	else if($table  =="stocks_consumables"){
		$row = "a.id as stock_id,a.serial_no,b.amount,a.brand,a.item,sum(b.qty) as qty,b.invoice_no,b.category,b.id";
		$where="item = '$id' AND a.id = b.stock_id AND b.category = 4 group by b.invoice_no,a.serial_no,b.category";
		$tablex = "$table a,sale_invoice_details b";		
	}
	else if ($table  =="stocks_promo"){
		$row = "a.id as stock_id,a.color,a.serial_no,b.amount,sum(b.qty) as qty,b.invoice_no,b.category,b.id";
		$where="item = '$id' AND a.id = b.stock_id AND b.category = 3 group by b.invoice_no,b.stock_id,b.category";
		$tablex = "$table a,sale_invoice_details b";
	}
	
	$db->select($tablex,$row,$where);
		$result = $db->getResult();	
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	
/* 	case 'Add_invoice_return';
	 $array = $_REQUEST["array"];
		
		 $table = $_REQUEST["table"];
		 $sr = $_REQUEST["sr"];
		 $reason = $_REQUEST["reason"];
		
		
	if($table =="stocks_parts" || $table =="stocks_consumables"){
	
				foreach( $array as $key => $value) { 
									
						 $val =  $value['serial_no'];
						$quantity = $value['quantity'];
						$category = $value['category'];
						
						
						 $var = $quantity;
						
						$where = "serial_no = '$val' AND qty != 0 ";
						$order = "serial_no";		
						$db->select('sale_invoice_details','*',$where,$order);
						$result = $db->getResult();
						
						 foreach($result as $info){
						
									 $id = $info['id'];
									 $invoice_no = $info['invoice_no'];
									 $stock_id = $info['stock_id'];
									 $category = $info['category'];
									 $qty = $info['qty'];
																			 
									$c = $var;
									
									
									$answer = ($var - $qty);
									$var = $answer;

									if($var < 0) $var = 0; 
									if($var > 0){

									 $rowsx = array('qty' => '0');
									$wherex ="id = '$id'";
									$db->update('sale_invoice_details',$rowsx,$wherex);

									$rows ='sr_no,invoice_no,stock_id,inv_id,category,qty,reason';
									$values = array($sr,$invoice_no,$stock_id,$id,$category,$qty,$reason);
									$db->insert("sr_details",$values,$rows); 
                  
									}else{ 
 
									 $answer = abs($answer); 
									 $rowsx = array('qty' => $answer);
									$wherex ="id = '$id'";
									$db->update('sale_invoice_details',$rowsx,$wherex); 
									
									$rows ='sr_no,invoice_no,stock_id,inv_id,category,qty,reason';
									$values = array($sr,$invoice_no,$stock_id,$id,$category,$c,$reason);
									$db->insert("sr_details",$values,$rows);
									
									break; 
									} 				
							
							}
						
								
													 
				}
	}else{
	
					foreach( $array as $key => $value) { 
					
					 $val =  $value['serial_no'];
				
					$where = "id = '$val'";
							
					$db->select('sale_invoice_details','*',$where);
					$result = $db->getResult();
					
						foreach($result as $info){
									
									 $id = $info['id'];
									 $invoice_no = $info['invoice_no'];
									 $stock_id = $info['stock_id'];
									 $category = $info['category'];
									 $qty = $info['qty'];
									
									
									$rowsx = array('qty' => '0');
									$wherex ="id = '$id'";
									$db->update('sale_invoice_details',$rowsx,$wherex);

									$rows ='sr_no,invoice_no,stock_id,inv_id,category,qty,reason';
									$values = array($sr,$invoice_no,$stock_id,$id,$category,$qty,$reason);
									$db->insert("sr_details",$values,$rows);

									
									
									
									
						}
									
						
				} 
	
	}
	
	print "uhryt";	
	
	break; */
	
	case 'select_max_id';
				
				$rows ='MAX(JV) + 1 as JV';
				$db->select('dr_cr_menu',$rows); 
				$result = $db->getResult();
				
				print '{"members":'.json_encode($result).'}';
				
			
	break;
	
	
	case 'select_penalty';
				$or_no =  $_REQUEST['or_no'];
				$acct =  $_REQUEST['acct'];
				
				$rows ='penalty_discount';
				$where = "or_no = '$or_no' AND account_no = '$acct' ";
				$db->select('collection_loan',$rows,$where); 
				$result = $db->getResult();
				
				print '{"members":'.json_encode($result).'}';
				
			
	break;
	
	
	
	case 'discount_add';
	
	  $amount = $_REQUEST['amount'];
	  $type = $_REQUEST['type'];
	  $or_no = $_REQUEST['or_no'];
	  $acct = $_REQUEST['acct'];
	  $desc = $_REQUEST['desc'];
	
	$where ="acct_no = '$acct' AND or_no ='$or_no' AND description = '$desc' ";
	$rows = '*';
	if($db->recordExist('dr_cr_menu',$rows,$where) > 0){
		print 'duplicate';
	}else{
	
	$date = date("Y-m-d");
	$rowsx = 'date,acct_no,or_no,type,description,amount';
	$values = array($date,$acct,$or_no,$type,$desc,$amount);
	$db->insert("dr_cr_menu",$values,$rowsx);
	
	$rowsx = array('discount' =>$amount);
	$wherex = "or_no = '$or_no' AND account_no = '$acct' ";
	$db->update('collection_loan',$rowsx,$wherex);
	
	
	
	print 'saved';
	}
	break;
	
	
	case 'update_penalty_discount';
	
	   $amount = $_REQUEST['amount'];

	   $type = $_REQUEST['type'];

	   $or_no = $_REQUEST['or_no'];

	   $acct = $_REQUEST['acct'];

	   $desc = $_REQUEST['desc'];

	
	$date = date("Y-m-d");
	$rowsx = 'date,acct_no,or_no,type,description,amount';
	$values = array($date,$acct,$or_no,$type,$desc,$amount);
	$db->insert("dr_cr_menu",$values,$rowsx);
	
	
	$rows ='penalty_discount';
	$where = "or_no = '$or_no' AND account_no = '$acct' ";
	$db->select('collection_loan',$rows,$where); 
	$result = $db->getResult();
	
	foreach($result as $info){
	
		$penalty = $info['penalty_discount'];
	}
	
	$sum = $penalty -  $amount;
	
	$rowsx = array('penalty_discount' => $sum);
	$wherex = "or_no = '$or_no' AND account_no = '$acct' ";
	$db->update('collection_loan',$rowsx,$wherex);
	
	
	print 'saved'; 

	break;
	
	

		
	}
	

}	

?>