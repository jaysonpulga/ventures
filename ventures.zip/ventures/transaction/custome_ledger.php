<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
<body>
	<div id="main" align="center">
		<div style="width:100%;position:relative;">	
			<div  class="contents" style="border:0px solid #000; margin-top:-110px; width:900px" cellspacing="0">
				<div id="options-top" align="center" style="width:870px;">
				<form name="frm" method="POST" id = "item_form">
					<div style = "margin-left:370px;">
						<select id = 'category' name='category'>
							<option value="customer_name">Customer Name</option>
							<option value="branch">Branch</option>
						</select>
						<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Report">
					</div>
					<br>
					<table id="customer_list" align = "center" style = "width:700px">

						<thead align="center">
						<tr>
							<th></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'customer_name')">NAME</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'branch_name')">BRANCH</a></th><th>ADDRESS</th>
						</tr>
						</thead>
						
						<tbody id="customer_data"></tbody>
						
					</table>
				</form>
			</div>
			</div>
			<div id="pagination"> 
				<div class="holder" style = "margin-top: 30px;"></div>
				<i>Pages</i>
			</div>
		</div>
	</div>
	<script src='../js/dropdowntabs.js'></script>
	<script>
	
		function jpages(){
			$("div.holder").jPages({
			  containerID : "customer_data",
			  previous : "?",
			  next : "?",
			  perPage : 10,
			  delay :5,
			  startPage    : 1,
			  startRange   : 1,
			  midRange     : 5,
			  endRange     : 1
			});
		}
		
		var filter = 1;
		var display_result = [0,0,0,0,0];
					
		var sortType = "ASC";
		
		function filter_list(index,cVar){
			sort = cVar;
			display_result[index] = display_result[index] == 0 ? 1 : 0;
			sortType = display_result[index] == 0 ? "ASC" : "DESC";
			loadData(sort,sortType);
		}
		
		$(document).ready(function(){
			var menu = getUrlVars()["menu"];
		
			$("."+menu).attr("class",menu+"-active");
			
			$("."+menu+"-active a").css({
			"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
			"padding":"30px 12px 0px 12px",
			"border-bottom":"4px solid #c95447"
			});
			
			loadData("id","DESC");
			
		});
		
		$("#txtsearch").live("keyup change",function(){
			$("#customer_list > tbody").empty();
			loadData("id","DESC");				
		})
		
		function loadData(sort,sortType){
			$("#customer_list > tbody").empty();
			
			var url="functions.php?request=ajax&action=viewCustomer_with_ledger&sort="+sort+"&sortType="+sortType+"&inputsearch="+$("#txtsearch").val()+"&category="+$("#category").val();
			var counter=0;
			
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){
					var address;
					var street = res.street;
					var brgy = res.brgy;
					
					if(street == "" && brgy == "") {
						address = res.city+", "+res.province;
					}
					else {
						address = res.street+" "+res.brgy+", "+res.city+", "+res.province;
					}
					$("#customer_list > tbody").append("<tr class = 'x' onmouseover = 'clickSearch();'><td><input type = 'checkbox' value = '"+res.id+"' onclick = \"window.parent.closeIframe("+res.id+",'"+res.customer_name+"','"+address+"','"+res.branch_code+"')\"></td><td>"+res.customer_name+"</td><td>"+res.branch_name+"</td><td>"+address+"</td></tr>");
					counter++;
				});
				if (counter <= 0){
					$("#customer_list > tbody").append("<tr id = 'noItems'><th colspan = '4' align = 'center'> No Items on record! </th></tr>");
				}
				jpages();
			});
		}
		
		function clickSearch() {
		
			$("#txtsearch").blur();
		
		}
		
		function getData(id,name,address) {
	
			window.parent.closeIframe(id,name,address);

		}
		
	</script>
	
</body>
</html>