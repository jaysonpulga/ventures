<?php
session_start();

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
?>
<html>
<title>Sales</title>
<head>
<?php
include('../database.php');  
$db = new Database();  
$db->connect();
?>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
<form  name="frm"  method="POST">
<input type="hidden" id="promo_id" value="<?php echo $_REQUEST['promo_id']; ?>" name="promo_id" >
<input type="hidden" id="branch_id" value="<?php echo $_SESSION['branch_id']; ?>" >
<input type="hidden" id="branch_name" value="<?php echo $_SESSION['branch_name']; ?>" >

<input type="hidden" id="id_p"  name="id_p" >
<input type="hidden" id="item_code_a"  name="item_code_a" >
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px;">
				<div  align="center" style="margin-top:15px;">
					<span>
						<label>D.R NO:</label>
						<input type="text"id="dr_no" name="dr_no"  style="margin-left:10px" >
					</span>
				</div>
				<div align="center" style="margin-top:5px;">
					<span>
						<label>Date:</label>
						<input type="date" id="date" name="date" style="margin-left:15px">
					</span>
				</div>
				<div align="center" style="margin-top:5px;">
					<span>
						<label >From:</label>
					</span>
					
					<?php
					
						if($_SESSION['branch_id'] == 1){
						
							echo "<select id ='branch' name='branch' style='margin-left:20px'></select>";
						}else{
						
							echo "<input type='text' id ='branch' name='branchx' readonly style='margin-left:20px' />";
						}
					?>
					
				</div>
				<div align="center" style="margin-top:5px;">
					<span>
						<label style="margin-left:0px">Move To:</label>
						<select id ='branch_to' name='branch_to' style="margin-left:0px" >		
						
						</select>
					</span>
				</div>
			
				<div align="center">
					<span><br>
						<input type="button" value="ADD" onClick="save_transfer(this)" >
						<input type="button" value="CANCEL" onClick="Cancel();">
					
					</span>
				</div>
			</div>
		</div>
	</div>

	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		load_select();
		load_branch_to();

	});	
	
  var branch_id = $("#branch_id").val()
  var branch_name = $("#branch_name").val()


	function save_transfer(obj){
		event.preventDefault();
		
		var dr_no = $('#dr_no').val();
		var date = $('#date').val();
		var branch = $('#branch').val();
		var branch_to = $('#branch_to').val();
		var errormsg="Please complete the following fields: \n";
		var emsg= errormsg.length;

			if(dr_no == ""){
				errormsg+="-D.R NO:\n";
				
			}
			if(date == ""){
				errormsg+="-Date \n";
				
			}
			if(branch == ""){
				errormsg+="-Branch \n";
				
			}
			if(branch_to == ""){
				errormsg+="-Move To ";
				
			}
			if(errormsg.length== emsg){
			
			
		$.ajax({
			
				  url: "function_transaction.php",
					data:{"request":"ajax","action":"add_DRNO","dr_no":dr_no,"date":date,"branch":branch,"to":branch_to},
						success: function(reply){
							console.log(reply);
								if(reply == 'saved'){
									var actions="add";
									var link ="transfer.php?dr_no="+dr_no+"&menu=management";
									window.parent.Nexturl(actions,link);
									
								
								}else if(reply == 'duplicate'){
								 jAlert("The D.R NO:"+dr_no+ " is already exist in database!");
								
								}else{
									jAlert("cannot add information");
								}
							
							}
			
			
			
			});
			
			}else{
				jAlert(errormsg);
				event.preventDefault();
			}
			
	}
	
			
	function Cancel(){
		var action = "cancel";
	window.parent.closeIframe(action);
	}
	
	
	function load_select(){
	
	

		var count=0, x=0;
		var select = $("#branch");

		$.ajax({
				url:"../managements/function_items.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					
					if(reply.length > 0){
						
								if(branch_id == 1){
						
									select.empty();
									select.append("<option  value=''>-Select Branch--</option>");
										$.each(reply, function(i,res){
										 count++;
												
											select.append("<option  value='"+res.branch_code+"' >"+res.branch_name+"</option>");
																					
									});
								
								}else{
								
									$("#branch").val("");
									$.each(reply, function(i,res){
										 count++;
												if(branch_id == res.id ){
													$("#branch").val(res.branch_code);
											
												}									
									});
								
								}
						
					}
				}
			});
	}
	
	
	function load_branch_to(){

		var count=0, x=0;
		var select = $("#branch_to");

		$.ajax({
				url:"../managements/function_items.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					
					if(reply.length > 0){
						select.empty();
						select.append("<option  value=''>-Select Branch--</option>");
							$.each(reply, function(i,res){
							 count++;
									
								select.append("<option  value='"+res.branch_code+"' >"+res.branch_name+"</option>");
																		
							});
			
					}
				}
			});
	}
	

	
	</script>
	
</body>
</html>