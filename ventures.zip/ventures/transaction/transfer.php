<?php
session_start();
$_SESSION["username"];
$branch_name = $_SESSION["branch_name"];
$branch_id = $_SESSION['branch_id'];
?>
<html>
<title>Transfer Item</title>
<head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
.ui-dialog-title{
	text-align:left;
}
</style>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<style>
</style>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
		<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:628px; margin-left:15px; border:0px solid #000" >
						<div>
							<span>
								<label><h2>TRANSFER ITEM</h2><hr></label>
								<input type="hidden" id="dr_no" value="<?php echo $_REQUEST['dr_no']; ?>"  name="dr_no"   />
								
								<input type="hidden" id = "branch_id" value = "<?php echo $branch_id; ?>" >
								<input type="hidden" id = "branch_name" value = "<?php echo $branch_name; ?>" >
							</span>
						</div>
						<div style="margin-top:10px">
							<span>
								<label>D.R. No:</label>
								<input type="text" id="dr" name="dr" style="text-align:center;" style="color:black" readonly="readonly" style="margin-left:10px">
							</span>
							<span>
								<label style="margin-left:110px">Date Transferd:</label>
								<input type="date" id="date" name="date">
							</span>
						</div>
						<div style="margin-top:5px;margin-bottom:10px" >
							<span>
								<label>From:</label>
								<select id ='branch' name='branch' style="margin-left:13px;">
								</select>
							</span>
							<span>
								<label  style="margin-left:120px">Move to:</label>
								<select id ='branch_to' name='branch_to' style="margin-left:50px;"></select>
							</span>
						</div>
						<div style="margin-top:10px">
									<span>
										<label><h3>Search Item</h3></label>
									</span>
						</div>
						
						<div style="margin-bottom:25px" >
									<span >
										<input type="hidden" name="cat" id="cat" />
										<select id = "category" name="category" onchange = "changeCategory(this.value)">
										<option value="motorcycle">MOTORCYCLE</option>
										<option value="parts">PARTS</option>
										<option value="promo item">PROMO ITEM</option>
										<option value="consumables">CONSUMABLES</option>
										</select>
										<input type="button" value="SEARCH" onclick="add_item();">
									</span>
									<span>
											<label style="margin-left:70px">Remarks:</label>
											<input type="text" id="remarks" name="remarks" style="margin-left:46px">
									</span>
						</div>
						<div  class="contents" align="center">
							<table  align="center" id="table">
								<br>
									<thead>
									<tr>
									<th>QUANTITY</th>
									<th>PARTICULARS</th>
									<th>ACTION</th>
									</tr>
									<thead>
									<tbody id="alldata"></tbody>
							</table>
						</div>
						
						<div id="new_items" title="" style="display:none;">
								<iframe align="center" id="item_dialog" width="540" height="400" style="border:none"></iframe>
						</div>
						
						<div align="center" style="margin-top:20px">
							<span>
								<input type="button" value="UPDATE" onclick="update_item()" style="width:100px;top:1px;">
								<input type="button" value="CANCEL" onclick="cancel()" style="width:100px;top:1px;">
							</span>
						</div>
				</div>
			<div>
		</div>
	</div>
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="transaction#"){
				menu="transaction";
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadData();
		load_dataitem();
		
		var category = $('#category').val();		
		$('#cat').val(category);
	});	
	
	var dr_no = $('#dr_no').val();	

	var branch_id = $("#branch_id").val();
	var branch_name = $("#branch_name").val();
	
	function changeCategory(category){
		$('#cat').val(category);
	}
	
	function loadData(){
			
			var url="function_transaction.php?request=ajax&action=load_DR&dr_no="+dr_no;
		
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){
					$('#dr').val(res.dr_no);
					$('#date').val(res.date);
					$('#remarks').val(res.remarks);
					var branch_code = res.branch_code;
					var branch_code_to= res.move_to;
					load_select(branch_code);
					load_move_to(branch_code_to);
				});	
			});
			
	}
	
	
	function load_select(branch_code){
		var count=0, x=0;
		var select = $("#branch");

		$.ajax({
				url:"../managements/function_items.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					if(reply.length > 0){
						select.empty();
							$.each(reply, function(i,res){
							 count++;
							if(res.branch_code == branch_code ){
							select.append("<option  value='"+res.branch_code+"' selected='selected' >"+res.branch_code+"</option>");
							}	else{
							select.append("<option  value='"+res.branch_code+"'>"+res.branch_code+"</option>");
							}	
								
																		
							});
			
					}
				}
			});
	}
	
	function load_move_to(branch_code_to){
		var count=0, x=0;
		var select = $("#branch_to");

		$.ajax({
				url:"../managements/function_items.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					if(reply.length > 0){
						select.empty();
							$.each(reply, function(i,res){
							 count++;
							if(res.branch_code == branch_code_to ){
							select.append("<option  value='"+res.branch_code+"' selected='selected' >"+res.branch_code+"</option>");
							}	else{
							select.append("<option  value='"+res.branch_code+"'>"+res.branch_code+"</option>");
							}	
								
																		
							});
			
					}
				}
			});
	}
	
	
	
	function add_item(){
	
	var val = $('#cat').val();
	
	if(val =="motorcycle"){
	var cat = 1;
	var table = "stocks_motors";
	}
	else if(val =="parts"){
	var cat = 2;
	var table = "stocks_parts";
	}
	else if(val =="promo item"){
	var cat = 3;
	var table = "stocks_promo";
	}
	else if(val =="consumables"){
	var cat = 4;
	var table = "stocks_consumables";
	}
	
	
			$("#new_items").attr("title",val+"-"+branch_name );
			$("#item_dialog").attr('src','../transaction/newTransfer.php?table='+table+"&cat="+cat+"&dr_no="+dr_no+"&branch_id="+branch_id);
			$("#new_items").dialog({
				width:540,
				height:450,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
		
			
	}

	
	
	function cancel(){
			window.location = "transferItem.php?menu=transaction";
	}
	
	function closeIframe(actions){
		if(actions=="add"){
			jAlert("Successfully Added");
		}
		else if(actions=="edit"){
			jAlert("Successfully Updated");
		}
		else if(actions=="cancel"){
			$('#new_items').dialog('close');
		}
		$('#new_items').dialog('close');
		 loadData();
		return false;
	}
	
	function cancel(){
			window.location = "transferItem.php?menu=transaction";
	}
	
	function load_dataitem(){
	
			
	var url="function_transaction.php?request=ajax&action=load_dataitem&dr_no="+dr_no ;
	var counter=1;
	var x = 1;

		$.getJSON(url,function(data){
		
			$("#table > tbody").empty();
					$.each(data.members, function(i,res){
				
				if(res.category == '1'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.model+"<br> ENGINE NO: "+res.engine_no+"<br> FRAME NO:"+res.frame_no+"<br>COLOR:"+res.color;
				
				}
				
				else if (res.category == '3'){
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no+"<br>COLOR: "+res.color;
				
				}
				
				else{
					
				var particulars = "MAKE & MODEL:"+res.brand+","+res.item_code+"<br> SERIAL NO: "+res.serial_no;
				
				}
				
				var cate = res.qty;
							
				$("#table > tbody").append("<tr class='x' id='record"+res.id_s+"'><td align='center'>"+cate+"</td><td align='center'>"+particulars+"</td><td align='center'><a href='#' alt='Update' title='Delete' class='delete' onclick=\"delete_item('"+res.id_s+" ','"+res.id+" ','"+res.category+"','"+res.qty+"');\"></a></td></tr>");
									
						 counter++;
						 
			});	
		
			if (counter <= 1){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Items on record! </th></tr>");
			}
					
					
		});
	

	}
	
	function delete_item(id_s,id,category,qty){
	
			if(category == 1){
			var tablex = "stocks_motors";
			}
			else if(category == 2 ){
			var tablex = "stocks_parts";
			}
			else if(category == 3 ){
			var tablex = "stocks_promo";
			}
			else if(category == 4){
			var tablex = "stocks_consumables";
			}
			
		
	
		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
				if(e){
				
						var table =  "tbl_stock_requisition";
						$.ajax({
							url: "function_transaction.php",
							data:{"request":"ajax","action":"deleteItem","id_x":id_s,"id":id,"tablex":tablex,"quantity":qty},
							success: function(reply){
								jAlert("successfully Deleted");
									loadData();
									load_dataitem();
							}
						});
					
				}
		
		});
	
	
	}
	
	function update_item(){
		event.preventDefault();
		
	
		var date = $('#date').val();
		var branch = $('#branch').val();
		var branch_to = $('#branch_to').val();
		var remarks = $('#remarks').val();
		var errormsg="Please complete the following fields: \n";
		var emsg= errormsg.length;

			if(date == ""){
				errormsg+="-Date \n";
				
			}
			if(branch == ""){
				errormsg+="-Branch \n";
				
			}
			if(branch_to == ""){
				errormsg+="-Move To ";
				
			}
			if(errormsg.length== emsg){
			
			
		$.ajax({
			
				  url: "function_transaction.php",
					data:{"request":"ajax","action":"update_drno","dr_no":dr_no,"date":date,"branch":branch,"branch_to":branch_to,"remarks":remarks},
						success: function(reply){
							console.log(reply);
								if(reply == 'updated'){
									
									 jAlert("Successfully Updated","UPDATED");
									$("#table > tbody").empty()
									loadData();
									load_dataitem();
								
								}else{
									jAlert("cannot add information");
								}
							
							}
			
			
			
			});
			
			}else{
				jAlert(errormsg);
				event.preventDefault();
			}
	
	}
	
	
	</script>
	
</body>
</html>