<?php
	session_start();
	include('../database.php');
	$db = new Database();  
	$db->connect();
	
	$action = $_REQUEST["action"];
	
	if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){
		
		switch($action){
			case "viewSecurityData";
				
				$sort1=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$category1=$_REQUEST["category"];
				$trimmed=trim($_REQUEST["inputsearch"]);
				
				if($category1 == "emp_name") {
					$category = "CONCAT(last_name,', ',first_name,' ',middle_name)";
				}
				else {
					$category = $category1;
				}
				
				if($sort1 == "emp_name") {
					$sort = "CONCAT(last_name,', ',first_name,' ',middle_name)";
				}
				else {
					$sort = $sort1;
				}
				
				$rows = "*,CONCAT(last_name,', ',first_name,' ',middle_name) as emp_name";
				$where = "$category LIKE '%".$trimmed."%'";
				$order="$sort $sortType";
				$db->select("tbl_security",$rows,$where,$order);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			break;
			
			case "loadSecurityData";
				$id = $_REQUEST["id"];
			
				$rows = "a.*,b.*";
				$where = "a.id='$id' AND a.id=b.emp_id";
				$db->select("tbl_security a, tbl_priviledges b",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadSecurityBranch";
			
				$rows = "id,branch_name";
				$where = "";
				$db->select("tbl_branch",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "saveSecurityData";
			
				$username = $_REQUEST["username"];
				$password = $_REQUEST["password"];
				$position = $_REQUEST["position"];
				$branch_id = $_REQUEST["branch_id"];
				$last_name = $_REQUEST["last_name"];
				$first_name = $_REQUEST["first_name"];
				$middle_name = $_REQUEST["middle_name"];
				$contact_no = $_REQUEST["contact_no"];
				$email = $_REQUEST["email"];
				$department = $_REQUEST["department"];
				$access_level = $_REQUEST["access_level"];
				$sales = $_REQUEST["sales"];
				$purchase = $_REQUEST["purchase"];
				$process_payment = $_REQUEST["process_payment"];
				$reports = $_REQUEST["reports"];
				$add_stocks = $_REQUEST["add_stocks"];
				$process_loan = $_REQUEST["process_loan"];
				$update_pricelist = $_REQUEST["update_pricelist"];
				$settings = $_REQUEST["settings"];
				$branch = $_REQUEST["branch"];
				$supplier = $_REQUEST["supplier"];
				$stock_requisition = $_REQUEST["stock_requisition"];
				$items = $_REQUEST["items"];
				
				$where1 = "username='$username'";
				$rows1 = "*";
				$db->select("tbl_security",$rows1,$where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
					$rows = "username,password,position,branch_id,last_name,first_name,middle_name,contact_no,email,department,access_level";
					$values = array($username,$password,$position,$branch_id,$last_name,$first_name,$middle_name,$contact_no,$email,$department,$access_level);
					$db->insert("tbl_security",$values,$rows);
					
					$emp_id = mysql_insert_id();
					
					$rows = "emp_id,sales,purchase,process_payment,reports,add_stocks,process_loan,update_pricelist,settings,branch,supplier,stock_requisition,items";
					$values = array($emp_id,$sales,$purchase,$process_payment,$reports,$add_stocks,$process_loan,$update_pricelist,$settings,$branch,$supplier,$stock_requisition,$items);
					$db->insert("tbl_priviledges",$values,$rows);
					
					echo "saved";
					
				}
				
			break;
			
			case "updateSecurityData1";
				
				$id=$_REQUEST["id"];
				$username=$_REQUEST["username"];
				$password=$_REQUEST["password"];
				$position=$_REQUEST["position"];
				$branch_id=$_REQUEST["branch_id"];
				$last_name=$_REQUEST["last_name"];
				$first_name=$_REQUEST["first_name"];
				$middle_name=$_REQUEST["middle_name"];
				$contact_no=$_REQUEST["contact_no"];
				$email=$_REQUEST["email"];
				$department=$_REQUEST["department"];
				$access_level=$_REQUEST["access_level"];
				
				$sales=$_REQUEST["sales"];
				$purchase=$_REQUEST["purchase"];
				$process_payment=$_REQUEST["process_payment"];
				$reports=$_REQUEST["reports"];
				$add_stocks=$_REQUEST["add_stocks"];
				$process_loan=$_REQUEST["process_loan"];
				$update_pricelist=$_REQUEST["update_pricelist"];
				$settings=$_REQUEST["settings"];
				$branch=$_REQUEST["branch"];
				$supplier=$_REQUEST["supplier"];
				$stock_requisition=$_REQUEST["stock_requisition"];
				$items=$_REQUEST["items"];
				
				$where="a.id='$id' AND a.id=b.emp_id";
	
				$rows = array('a.username' => $username , 'a.password' => $password , 'a.position' => $position , 'branch_id' => $branch_id , 'a.last_name' => $last_name , 'a.first_name' => $first_name , 'a.middle_name' => $middle_name , 'a.contact_no' => $contact_no , 'a.email' => $email , 'a.department' => $department , 'a.access_level' => $access_level , 'b.sales' => $sales , 'b.purchase' => $purchase , 'b.process_payment' => $process_payment , 'b.reports' => $reports , 'b.add_stocks' => $add_stocks , 'b.process_loan' => $process_loan , 'b.update_pricelist' => $update_pricelist , 'b.settings' => $settings , 'b.branch' => $branch , 'b.supplier' => $supplier , 'b.stock_requisition' => $stock_requisition , 'b.items' => $items);
				$db->update("tbl_security a, tbl_priviledges b",$rows, $where);
				
				echo "updated";
				
			break;
			
			case 'updateSecurityData2';
				
				$id=$_REQUEST["id"];
				$uname=$_REQUEST["uname"];
				$username=$_REQUEST["username"];
				$password=$_REQUEST["password"];
				$position=$_REQUEST["position"];
				$branch_id=$_REQUEST["branch_id"];
				$last_name=$_REQUEST["last_name"];
				$first_name=$_REQUEST["first_name"];
				$middle_name=$_REQUEST["middle_name"];
				$contact_no=$_REQUEST["contact_no"];
				$email=$_REQUEST["email"];
				$department=$_REQUEST["department"];
				$access_level=$_REQUEST["access_level"];
				
				$sales=$_REQUEST["sales"];
				$purchase=$_REQUEST["purchase"];
				$process_payment=$_REQUEST["process_payment"];
				$reports=$_REQUEST["reports"];
				$add_stocks=$_REQUEST["add_stocks"];
				$process_loan=$_REQUEST["process_loan"];
				$update_pricelist=$_REQUEST["update_pricelist"];
				$settings=$_REQUEST["settings"];
				$branch=$_REQUEST["branch"];
				$supplier=$_REQUEST["supplier"];
				$stock_requisition=$_REQUEST["stock_requisition"];
				$items=$_REQUEST["items"];
				
				$rows1 = "*";
				$where1 = "username='$uname'";
				
				$db->select("tbl_security", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
					$where="a.id='$id' AND a.id=b.emp_id";
	
					$rows = array('a.username' => $uname , 'a.password' => $password , 'a.position' => $position , 'branch_id' => $branch_id , 'a.last_name' => $last_name , 'a.first_name' => $first_name , 'a.middle_name' => $middle_name , 'a.contact_no' => $contact_no , 'a.email' => $email , 'a.department' => $department , 'a.access_level' => $access_level , 'b.sales' => $sales , 'b.purchase' => $purchase , 'b.process_payment' => $process_payment , 'b.reports' => $reports , 'b.add_stocks' => $add_stocks , 'b.process_loan' => $process_loan , 'b.update_pricelist' => $update_pricelist , 'b.settings' => $settings , 'b.branch' => $branch , 'b.supplier' => $supplier , 'b.stock_requisition' => $stock_requisition , 'b.items' => $items);
					$db->update("tbl_security a, tbl_priviledges b",$rows, $where);
					
					echo "updated";
				}
			
			break;
			
			case "deleteSecurityData";
			
				$id=$_REQUEST["id"];
				
				$db->delete("tbl_security","id='$id'"); 
				$db->delete("tbl_priviledges","emp_id='$id'");
				
				print "deleted";
			
			break;
			
		}
		
	}

?>