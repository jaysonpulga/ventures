<!DOCTYPE HTML>
<html lang="en">
<title>Security</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<table width="900px">
						<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2 style="margin-top:10px;">SECURITY</h2>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
							<form name="search" action="" method="POST">
							<select id = 'category' name='category'>
								<option value="emp_name">Employee Name</option>
								<option value="username">Username</option>
								<option value="access_level">Access Type</option>
								<option value="department">Department</option>
							</select>
								<input type="search" name="txtsearch" id="txtsearch" placeholder="Search">
								<input type="button" value="ADD USER" id='input' style="width:120px;" onclick="add_item();">
								</form>
							</td>
						</tr>
					</table>
				</div>
					
				<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:900px" cellspacing="0">
					
					<table id="security_list" border=1 align = "center">

						<thead align="center">
						<tr>
							<th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'emp_name')">EMP NAME</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'username')">USERNAME</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'access_level')">ACCESS TYPE</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'department')">DEPARTMENT</a></th><th colspan="2">ACTION</th>
						</tr>
						</thead>
						
						<tbody id="security_data"></tbody>
						
					</table>
				</div>
				
				<div id="pagination">
					<div class="holder" style = "margin-top:30px;"></div>
					<i>Pages</i>
				</div>
				
				<div id="new_items" title="USER ACCOUNT" style="display:none;">
					<iframe id="item_dialog" width="630" height="570" style="border:none"></iframe>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	function jpages(){
		$("div.holder").jPages({
		  containerID : "security_data",
		  previous : "←",
		  next : "→",
		  perPage : 15,
		  delay :10,
		  startPage    : 1,
		  startRange   : 1,
		  midRange     : 5,
		  endRange     : 1
		});
	}
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
				
	var sortType = "ASC";
	
	function filter_list(index,cVar){
		sort = cVar;
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadBody(sort,sortType);
	}
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="settings#"){
			menu="settings";
		}
		else{
			menu = getUrlVars()["menu"];	
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -325px 5px no-repeat",
		"padding":"30px 30px 0px 30px",
		"border-bottom":"4px solid #c95447"
		});
		loadBody("emp_name","DESC");
	});
	
	function add_item(){
		
		$("#item_dialog").attr('src','userAccount.php');
		$("#new_items").dialog({
			width:631,
			height:620,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src',"about:blank");
				window.location.reload();
			}
		});
		return false;
	}
	
	function edit_item(id){
		
		$("#item_dialog").attr('src','editAccount.php?id='+id);
		$("#new_items").dialog({
			width:631,
			height:620,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src',"about:blank");
				window.location.reload();
			}
		});
		return false;
		
	}
	
	function closeIframe(action) {
		if (action=="add") {
			jAlert('Data Saved!','Alert Dialog');
		}
		if (action=="edit") {
			jAlert('Data Updated!','Alert Dialog');
		}
		else {
		}
		$("#new_items").dialog("close");
		loadBody();
	}
	
	$("#txtsearch").live("keyup change",function(){
		$("#security_list > tbody").empty();
		loadBody("emp_name","DESC");				
	});
	
	function clickSearch() {
		$("#txtsearch").blur();
	}
	
	function loadBody(sort,sortType) {
	
		$("#security_list > tbody").empty();
	
		var url="functions.php?request=ajax&action=viewSecurityData&sort="+sort+"&sortType="+sortType+"&inputsearch="+$("#txtsearch").val()+"&category="+$("#category").val();
		var counter=0;
			
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				 
				$("#security_list > tbody").append("<tr class='x' onmouseover='clickSearch()'><td><div style = 'text-align:left;'>"+res.emp_name+"</div></td><td>"+res.username+"</td><td>"+res.access_level+"</td><td>"+res.department+"</td><td><a href='#' class='edit' title='EDIT link' onclick = 'edit_item("+res.id+")'></a></td><td><a href='#' class='delete' title='DELETE link' onclick = 'delete_item("+res.id+")'></a></td></tr>");
				counter++;
			});
			if (counter <= 0){
				$("#security_list > tbody").append("<tr id = 'noItems'><th colspan = '6' align = 'center'> No Items on record! </th></tr>");
			}
			jpages();
		});
	
	}
	
	function delete_item(id) {
		
		jConfirm('Do you really want to DELETE this DATA?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "functions.php",
					data:{"request":"ajax","action":"deleteSecurityData","id":id},
					success: function(reply){
						console.log(reply);
							if(reply == 'deleted'){
								jAlert('Data Deleted','Alert Dialog');
								window.location.reload();
							}else{
								jAlert('Error','Alert Dialog');
								event.preventDefault();
							}
						
						}
				});
			}
		});
		
	}
	
	</script>
	
</body>
</html>