<html>
<title>Settings</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px;">
					<div style="margin-top:10px">
						<span>
							<label>NAME</label>
						</span>
					</div>
					<div>
						<span>
							<input type="text" id = "txtlast" placeholder="last name" style="text-align:center; margin-left:20px;">
							<input type="text" id = "txtfirst" placeholder="first name" style="text-align:center; margin-left:20px;">
							<input type="text" id = "txtmiddle" placeholder="middle name" style="text-align:center; margin-left:20px;">
						</span>
					</div>
					<div style = "margin-top:5px;">
						<span>
							<label>Username</label>
							<input type="text" id = "txtuser" style="margin-left:18px">
						</span>
						<span>
							<label style="margin-left:90px">Contact No.:</label>
							<input type="text" id = "txtcontact" onkeyup="javascript:this.value = this.value.replace(/[^0-9,-]/, '')">
						</span>
					</div>
					<div style = "margin-top:5px;">
						<span>
							<label>Password:</label>
							<input type="password" id = "txtpass" style="margin-left:18px">
						</span>
						<span>
							<label style="margin-left:90px">Email:</label>
							<input type="email" id = "txtemail" name = "myemail" style="margin-left:38px" onchange="return checkmail(this.value)">
						</span>
					</div>
					<div style = "margin-top:5px;">
						<span>
							<label>Position:</label>
							<input type="text" id = "txtposition" style="margin-left:26px">
						</span>
						<span>
							<label style = "margin-left:90px;">Branch:</label>
							<select id = 'txtbranch' name='category' style="margin-left:30px">
								<option value="">- SELECT -</option>
							</select>
						</span>
					</div>
					<div style = "margin-top:5px;">
						<span>
							<label>Department:</label>
							<select id = 'txtdepartment' name='category' style="margin-left:2px">
								<option value="">- SELECT -</option>
								<option value="Sales">Sales</option>
								<option value="Accounting">Accounting</option>
								<option value="Cashier">Cashier</option>
								<option value="Stocks">Stocks</option>
								<option value="Admin">Admin</option>
							</select>
						</span>
					</div>
					<div style = "margin-top:5px;">
						<span>
							<label>Access Level:</label>
							<select id = 'txtaccess' name='category'>
								<option value="">- SELECT -</option>
								<option value="Administrator">Administrator</option>
								<option value="Supervisor">Supervisor</option>
								<option value="Standard User">Standard User</option>
							</select>
						</span>
					</div>
					<div  class="contents2" style="border:0px solid #000;margin-top:10px" align="center">
						<table>
							<tr><th colspan="3">PRIVILEGES</th></tr>
							<tbody>
								<tr>
									<td><input type="checkbox" id = "sales" value ="">Sales</td>
									<td><input type="checkbox" id = "add_stocks">Add Stocks</td>
									<td><input type="checkbox" id = "branch">Branch</td>
								</tr>
								<tr>
									<td><input type="checkbox" id = "purchase">Purchase</td>
									<td><input type="checkbox" id = "process_loan">Process Loan</td>
									<td><input type="checkbox" id = "supplier">Supplier</td>
								</tr>							
								<tr>
									<td><input type="checkbox" id = "process_payment">Process Payment</td>
									<td><input type="checkbox" id = "update_pricelist">Update Pricelist</td>
									<td><input type="checkbox" id = "stock_requisition">Stock Requisition</td>
								</tr>
								<tr>
									<td><input type="checkbox" id = "reports">Reports</td>
									<td><input type="checkbox" id = "settings">Settings</td>
									<td><input type="checkbox" id = "items">Items</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div align="center" style="margin-top:10px">
						<span>
							<input type="button" id = "btnSave" value="SAVE" onclick = "Save();" style="width:100px;top:1px;">
							<input type="button" id = "btnCancel" value="CANCEL" style="width:100px;top:1px;" onclick = "window.parent.closeIframe('cancel');">
						</span>
					</div>
			</div>
		<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		checkboxes();
		loadBranch();
		
	});
	
	$("#txtaccess").change(function(){
		
		if($(this).val() == "Administrator") {
			$("#sales").prop("checked",true);
			$("#add_stocks").prop("checked",true);
			$("#branch").prop("checked",true);
			$("#purchase").prop("checked",true);
			$("#process_loan").prop("checked",true);
			$("#supplier").prop("checked",true);
			$("#process_payment").prop("checked",true);
			$("#update_pricelist").prop("checked",true);
			$("#stock_requisition").prop("checked",true);
			$("#reports").prop("checked",true);
			$("#settings").prop("checked",true);
			$("#settings").prop("disabled",false);
			$("#items").prop("checked",true);
			
		}
		
		else if($(this).val() == "Supervisor") {
			$("#sales").prop("checked",true);
			$("#add_stocks").prop("checked",true);
			$("#branch").prop("checked",true);
			$("#purchase").prop("checked",true);
			$("#process_loan").prop("checked",true);
			$("#supplier").prop("checked",true);
			$("#process_payment").prop("checked",true);
			$("#update_pricelist").prop("checked",true);
			$("#stock_requisition").prop("checked",true);
			$("#reports").prop("checked",true);
			$("#settings").prop("checked",false);
			$("#settings").prop("disabled",true);
			$("#items").prop("checked",true);
		}
		
		else {
			$("#sales").prop("checked",false);
			$("#add_stocks").prop("checked",false);
			$("#branch").prop("checked",false);
			$("#purchase").prop("checked",false);
			$("#process_loan").prop("checked",false);
			$("#supplier").prop("checked",false);
			$("#process_payment").prop("checked",false);
			$("#update_pricelist").prop("checked",false);
			$("#stock_requisition").prop("checked",false);
			$("#reports").prop("checked",false);
			$("#settings").prop("checked",false);
			$("#settings").prop("disabled",false);
			$("#items").prop("checked",false);
		}
		
		checkboxes();
	
	});
	
	var emailfilter=/^\w+[\+\.\w-]*@([\w-]+\.)*\w+[\w-]*\.([a-z]{2,4}|\d+)$/i

	function checkmail(e){
	
		var returnval=emailfilter.test(e);
			if (returnval==false){
				if (e == "") {
				}
				
				else {
					jAlert("Please enter a valid email address.", "Alert Dialog");
					e.select();
				}
			}
			else {
				
			}
		
		return returnval
	}
	
	function loadBranch() {
		
		var url="functions.php?request=ajax&action=loadSecurityBranch";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
			
				$("#txtbranch").append("<option value="+res.id+">" + res.branch_name + "</option>");
			
			});
		});
		
	}
	
	function checkboxes() {
		
		var sales;
		var add_stocks;
		var branch;
		var purchase;
		var process_loan;
		var supplier;
		var process_payment;
		var update_pricelist;
		var stock_requisition;
		var report;
		var settings;
		var items;
		
		if ($("#sales").is(":checked")) {
			sales = "Y";
		}else {
			sales = "N";
		}
		if ($("#add_stocks").is(":checked")) {
			add_stocks = "Y";
		}else {
			add_stocks = "N";
		}
		if ($("#branch").is(":checked")) {
			branch = "Y";
		}else {
			branch = "N";
		}
		if ($("#purchase").is(":checked")) {
			purchase = "Y";
		}else {
			purchase = "N";
		}
		if ($("#process_loan").is(":checked")) {
			process_loan = "Y";
		}else {
			process_loan = "N";
		}
		if ($("#supplier").is(":checked")) {
			supplier = "Y";
		}else {
			supplier = "N";
		}
		if ($("#process_payment").is(":checked")) {
			process_payment = "Y";
		}else {
			process_payment = "N";
		}
		if ($("#update_pricelist").is(":checked")) {
			update_pricelist = "Y";
		}else {
			update_pricelist = "N";
		}
		if ($("#stock_requisition").is(":checked")) {
			stock_requisition = "Y";
		}else {
			stock_requisition = "N";
		}
		if ($("#reports").is(":checked")) {
			reports = "Y";
		}else {
			reports = "N";
		}
		if ($("#settings").is(":checked")) {
			settings = "Y";
		}else {
			settings = "N";
		}
		if ($("#items").is(":checked")) {
			items = "Y";
		}else {
			items = "N";
		}
		
		$("#sales").val(sales);
		$("#add_stocks").val(add_stocks);
		$("#branch").val(branch);
		$("#purchase").val(purchase);
		$("#process_loan").val(process_loan);
		$("#supplier").val(supplier);
		$("#process_payment").val(process_payment);
		$("#update_pricelist").val(update_pricelist);
		$("#stock_requisition").val(stock_requisition);
		$("#reports").val(reports);
		$("#settings").val(settings);
		$("#items").val(items);
		
	}
	
	function Save() {
		checkboxes();
		
		// security inputs
		var username=$("#txtuser").val();
		var password=$("#txtpass").val();
		var position=$("#txtposition").val();
		var branch_id=$("#txtbranch").val();
		var last_name=$("#txtlast").val();
		var first_name=$("#txtfirst").val();
		var middle_name=$("#txtmiddle").val();
		var contact_no=$("#txtcontact").val();
		var email=$("#txtemail").val();
		var department=$("#txtdepartment").val();
		var access_level=$("#txtaccess").val();
		
		// priviledges inputs
		var sales=$("#sales").val();
		var add_stocks=$("#add_stocks").val();
		var branch=$("#branch").val();
		var purchase=$("#purchase").val();
		var process_loan=$("#process_loan").val();
		var supplier=$("#supplier").val();
		var process_payment=$("#process_payment").val();
		var update_pricelist=$("#update_pricelist").val();
		var stock_requisition=$("#stock_requisition").val();
		var reports=$("#reports").val();
		var settings=$("#settings").val();
		var items=$("#items").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(username == ""){
			errormsg+="- Input Username.\n";
		}
		if(password == ""){
			errormsg+="- Input Password.\n";
		}
		if(position == ""){
			errormsg+="- Input Position.\n";
		}
		if(branch_id == ""){
			errormsg+="- Input Branch.\n";
		}
		if(last_name == ""){
			errormsg+="- Input Last Name.\n";
		}
		if(first_name == ""){
			errormsg+="- Input First Name.\n";
		}
		if(middle_name == ""){
			errormsg+="- Input Middle Name.\n";
		}
		if(contact_no == ""){
			errormsg+="- Input Contact No.\n";
		}
		if(email == ""){
			errormsg+="- Input Email.\n";
		}
		if(department == ""){
			errormsg+="- Select Department.\n";
		}
		if(access_level == ""){
			errormsg+="- Select Access Level.\n";
		}
		
		if(errormsg.length==emsg){
		
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"saveSecurityData","username":username,"password":password,"position":position,"branch_id":branch_id,"last_name":last_name,"first_name":first_name,"middle_name":middle_name,"contact_no":contact_no,"email":email,"department":department,"access_level":access_level,"sales":sales,"purchase":purchase,"process_payment":process_payment,"reports":reports,"add_stocks":add_stocks,"process_loan":process_loan,"update_pricelist":update_pricelist,"settings":settings,"branch":branch,"supplier":supplier,"stock_requisition":stock_requisition,"items":items},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							window.parent.closeIframe('add');
							
						}else if(reply == 'exists'){
							jAlert('Username Already Exists!', 'Alert Dialog');
						}
						else{
							jAlert('Error');
							event.preventDefault();
						}
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		
	}
	
	</script>
</body>
</html>