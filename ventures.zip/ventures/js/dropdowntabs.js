$( "li" ).hover(
  function() {
	var rel = $(this).attr('rel');
	$("#"+rel).css("display","block");
  }, function() {
	var rel = $(this).attr('rel');
	$("#"+rel).css("display","none");	
  }
);

$( "#dropmenu" ).hover(
  function() {
		$(".transaction a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		$("#dropmenu").css("display","block");
	
  }, function() {
		$("#dropmenu").css("display","none");
		$(".transaction a").css({
		"background":"",
		"padding":"",
		"border-bottom":""
		});
	
  }
);

$( "#dropmenu2" ).hover(
  function() {
		$(".stocks a").css({
		"background":"#4b4c51 url('../images/icons.png') -25px 5px no-repeat",
		"padding":"30px 36px 0px 36px",
		"border-bottom":"4px solid #c95447"
		});
		$("#dropmenu2").css("display","block");
  }, function() {
		$("#dropmenu2").css("display","none");				
		$(".stocks a").css({
		"background":"",
		"padding":"",
		"border-bottom":""
		});
  }
);
$( "#dropmenu3" ).hover(
  function() {
	  $(".customers a").css({
		"background":"#4b4c51 url('../images/icons.png') -100px 5px no-repeat",
		"padding":"30px 20px 0px 20px",
		"border-bottom":"4px solid #c95447"
		});
		$("#dropmenu3").css("display","block");
  }, function() {
		$("#dropmenu3").css("display","none");
		$(".customers a").css({
		"background":"",
		"padding":"",
		"border-bottom":""
		});
  }
);
$( "#dropmenu4" ).hover(
  function() {
		$(".reports a").css({
		"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
		"padding":"30px 31px 0px 31px",
		"border-bottom":"4px solid #c95447"
		});
		$("#dropmenu4").css("display","block");
  }, function() {
		$("#dropmenu4").css("display","none");
		$(".reports a").css({
		"background":"",
		"padding":"",
		"border-bottom":""
		});
  }
);
$( "#dropmenu5" ).hover(
  function() {
		$(".management a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});
		$("#dropmenu5").css("display","block");
  }, function() {
		$("#dropmenu5").css("display","none");
		$(".management a").css({
		"background":"",
		"padding":"",
		"border-bottom":""
		});
  }
);
$( "#dropmenu6" ).hover(
  function() {
		$(".settings a").css({
		"background":"#4b4c51 url('../images/icons.png') -325px 5px no-repeat",
		"padding":"30px 30px 0px 30px",
		"border-bottom":"4px solid #c95447"
		});
		$("#dropmenu6").css("display","block");
  }, function() {
		$("#dropmenu6").css("display","none");
		$(".settings a").css({
		"background":"",
		"padding":"",
		"border-bottom":""
		});
  }
);

function readURL(input) {
	if (input.files && input.files[0]) {
	var reader = new FileReader();
	reader.onload = function (e) {
	$('#imgholder')
	.attr('src', e.target.result)
	};
	reader.readAsDataURL(input.files[0]);
	}
}
function getUrlVars() {

	var vars = [], hash;
	var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
	for(var i = 0; i < hashes.length; i++)
	{
		hash = hashes[i].split('=');
		vars.push(hash[0]);
		vars[hash[0]] = hash[1];
	}		
	return vars;
}