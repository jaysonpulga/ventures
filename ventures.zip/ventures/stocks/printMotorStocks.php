<html>

<title>MOTORCYCLE STOCKS</title>
</html>
<style>
.x:nth-child(even) td{
	background:lightgray;
}
</style>
<?php
include('../database.php');  
$db = new Database();  
$db->connect(); 

	$dataArray=array();
	$type="1";
	$sortType="DESC";
	$sort="a.id";
	$dr_no=$_REQUEST["dr_no"];
	
	$row = "a.remarks,a.dr_no,b.supplier_name,a.date,c.branch_name";
	$where="a.type=$type and a.supplier=b.id and a.branch=c.id and a.dr_no=$dr_no";
	
	$order="$sort $sortType";
	$db->select('stocks a,tbl_supplier b,tbl_branch c',$row,$where,$order);

	$result = $db->getResult();
	
	foreach($result as $key){		
		$dr_no=$key["dr_no"];
		$row = "a.*,b.model as item";
		$where2="a.dr_no=$dr_no and a.model=b.motor_id";
		$db->select('stocks_motors a,tbl_motorcycle b',$row,$where2);
		$result2 = $db->getResult();
		
		$dr_no=$key["dr_no"];
		$supplier=$key["supplier_name"];
		$date_received=$key["date"];
		$branch=$key["branch_name"];
		$remarks=$key["remarks"];
		
		$i=0;
		foreach($result2 as $key2){
			$item_desc="ENG.# ".$key2["frame_no"]." FR.# ".$key2["engine_no"]." ".$key2["color"];
			$item_details_arr[$i]=array(
				'model'=> $key2["item"],
				'description'=> $item_desc,
				'status'=> $key2["status"],
			);
			array_push($dataArray,$item_details_arr[$i]);
			$i++;
		}
			
	}		
	
	
	

	echo" 
	<div align='center' style='font-family:Calibri'>
	<table border=0 width='1000' cellpadding=2 cellspacing=0>
		<tr><td><b>D.R. No.:</b> $dr_no</td><td align='right' colspan=3><b>Date Received:</b> $date_received</td></tr>
		<tr><td><b>Supplier:</b> $supplier</td><td align='right' colspan=3><b>Branch:</b> $branch</td></tr>
		<tr><td colspan=4 align='center' style='padding:20px 0px 10px 0px;border-bottom:2px solid #000'><b>STOCKS DETAILS</b></td></tr>
		<tr><td style='border-bottom:2px solid #000' align='center' width='25%'><b>MODEL</b></td><td colspan=2 align='center' style='border-bottom:2px solid #000'><b>ITEM DESCRIPTION</b></td><td width='25%' align='center' style='border-bottom:2px solid #000'><b>STATUS</b></td></tr>";
	
	if(count($dataArray)>0){
		foreach($dataArray as $key){
			echo "<tr align='center' class='x'><td >".$key['model']."</td><td colspan=2>".$key['description']."</td><td>".$key['status']."</td></tr>";
		
		}
	}
	else{
		echo "<tr align='center'><td colspan=4  style='padding:20px 0px 0px 0px;'>*** NO ITEMS TO DISPLAY ***</td></tr>";
	}
	echo "<tr><td colspan=5 align='center' style='padding:10px 0px 10px 0px;border-bottom:2px solid #000'></td></tr>";
	echo "<tr><td colspan=5 align='left' style='padding:10px 0px 10px 0px;'><b>REMARKS:</b><br />$remarks</td></tr>";
	echo "</table></div>";	
?>