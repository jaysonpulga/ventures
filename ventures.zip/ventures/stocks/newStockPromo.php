<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
		<div id="main" align="center">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="padding:10px;">
				<div style="margin:0px auto;width:1000px;" >
					<div style="margin-top:10px">
						<span>
							<label>D.R. No.:<label>
							<input type="text" style="margin-left:14px" id="dr" readonly="read_only" value="<?php echo $_REQUEST['dr_no']; ?>">
						</span>
						
						<span style="margin-left:15px;">
							<label>Supplier:</label>
							<select id='supplier' name='category'>
								<option value="">- Select -</option>
							</select>
						</span>
						<span style="margin-left:15px;">
							<label>Branch:</label>
							<select id='branch_id' name='branch'>
								<option value="">- Select -</option>
							</select>
						</span>
						<span style="margin-left:15px;">
							<label>Date:</label>
							<input type="date" style="margin-left:13px;text-align:center" id="date_created">
						</span>
					</div>
				</div>	
					<div style="text-align:left;width:980px;margin-bottom:10px;">
						<span>
							<label><h3>ADD ITEM:</h3></label>
						</span>
					</div>
					
					<div style="text-align:left;width:980px;margin-bottom:10px;">
						<form name='item_form' id='item_form' method='POST'>
						<span>
							<select id = 'brand' name='category'>
								<option value="">BRAND</option>
							</select>
							<select id = 'item' name='category'>
								<option value="">ITEM CODE</option>
							</select>
							<input type="text" style="text-align:center;text-transform:uppercase" id="serial_no" placeholder="SERIAL NO">
							<input type="text" style="text-align:center;width:95px;text-transform:uppercase" id="color" placeholder="COLOR">
							<input type="button" value="ADD" style="width:100px;top:1px;" onclick="add_item();">
							<input type="button" value="RESET" style="width:100px;top:1px;" onclick="reset();">
						</span>
						</form>
					</div>
					<div  class="contents">
						<table style="width:980px" id="table">
							<thead>
								<tr><th>ITEM CODE</th><th>SERIAL NO.</th><th>COLOR</th><th>STATUS</th><th colspan="2">ACTION</th></tr>
							</thead>
							<tbody></tbody>
						</table>
					</div>
					<div style="width:980px;">	
						<div style="margin-top:10px;text-align:right">
							<span>
								<label style="margin-bottom:10px; margin-left:320px">Total Qty:<span id="qty"></span></label>
							</span>
						</div>
						<div align="center">
							<span>
								<input type="button" value="SAVE" style="width:100px;top:1px;" onclick="updateDR();">
									
								<input type="button" value="PRINT" style="width:100px;top:1px;" onclick="window.open('printPromoStocks.php?dr_no=<?php echo $_REQUEST['dr_no']; ?>','_blank')" >
							</span>
						</div>
					</div>

			</div>
	</div>
	</div>
	</div>
	<script src='../js/dropdowntabs.js'></script>
	<script>
	loadBranches();
	loadSupplier();
	$(document).ready(function(){
		
		
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -25px 5px no-repeat",
		"padding":"30px 36px 0px 36px",
		"border-bottom":"4px solid #c95447"
		});
		
		
		
		
		
		loadBrand();
		
		$('#item').prop('disabled', true);
			
		$( "#brand" ).change(function() {
			$('#item')
			.prop('disabled', false)
			.empty()
			.append('<option value="">ITEM CODE</option>')
			.find('option:first')
			.attr("selected","selected")
			;
			loadItemsPromo();
		});	
		
		var dr = getUrlVars()["dr_no"];
		loadDR(dr);
	});
	
	function loadDR(dr){
		var url="function.php?request=ajax&action=loadDR&type=3&dr_no="+dr;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				//alert(res.branch);
				$("#branch_id option[value='"+res.branch+"']").attr('selected', 'selected');
				$('#supplier option[value='+res.supplier+']').attr('selected', 'selected');
				$('#date_created').val(res.date);
			});
		});
		loadPromoStocks(dr);	
	}	
	function loadBranches(){
		var url="function.php?request=ajax&action=loadBranches";
	
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				 $("#branch_id").append("<option value='"+ res.id +"' id='"+res.id+"'>" + res.branch_name + "</option>"); 
			});
		});
			
		
	}	
	function loadSupplier(){
					
			
		var url="function.php?request=ajax&action=loadSupplier";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				 $("#supplier").append("<option value="+ res.id +">" + res.supplier_name + "</option>"); 
			});
		});	
					
	}
	function loadBrand(){
					
			
		var url="function.php?request=ajax&action=loadBrand&category=3";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				 $("#brand").append("<option value="+ res.id +">" + res.brand + "</option>"); 
			});
		});	
			
	}
	function loadItemsPromo(){
					
		var brandID=$('#brand').val();
		
		var url="function.php?request=ajax&action=loadItemsPromo&brandID="+brandID;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				 $("#item").append("<option value="+ res.promo_id +">" + res.item_code + "</option>"); 
			});
		});	
					
	}		
	function add_item(){
			var dr = getUrlVars()["dr_no"];
			var item=$('#item').val(),brand=$('#brand').val(),serial_no=$('#serial_no').val(),color=$('#color').val(),errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");;

			if(item == ""){
				errormsg+="-Item Code\n";
			}
			if(serial_no == ""){
				errormsg+="-Serial No.\n";
			}
			
			if(errormsg.length== emsg){
			
			$.ajax({
					url: "function.php",
					data:{"request":"ajax","action":"addPromoStocks","item":item,"serial_no":serial_no,"brand":brand,"color":color,"dr_no":dr},
					success: function(reply){
						console.log(reply);
							if(reply == 'saved'){
								loadPromoStocks(dr);
								reset();
							}
							else if(reply == 'exist'){
								jAlert('Item already exists!','Alert Dialog');
							}
							else{
								jAlert('Error','Error Message');
								event.preventDefault();
							}	
						}
				});
					
			}else{
				
				jAlert(errormsg,"Alert Dialog");
				event.preventDefault();
			}
	}
	
	function deleteItem(id){
		var dr = getUrlVars()["dr_no"];
		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "function.php",
					data:{"request":"ajax","action":"deletePromoStocks","id":id},
					success: function(reply){
						console.log(reply);
							if(reply == 'deleted'){
								jAlert('Item Deleted','Alert Dialog');
								loadPromoStocks(dr);
							}
							else{
								jAlert('Error','Error Message');
								event.preventDefault();
							}	
						}
				});
			}
		});	
	}
	function updateDR(){
		var dr = getUrlVars()["dr_no"];
		event.preventDefault();
		var date_created=$('#date_created').val(),supplier=$('#supplier').val(),branch=$('#branch_id').val();
		var errormsg="Please complete the following fields: \n";
		var emsg= errormsg.length;
		
		if(date_created == ""){
			errormsg+="-Set Date Created.\n";
		}
		if(supplier== ""){
			errormsg+="-Add Supplier.\n";
		}
		if(branch== ""){
			errormsg+="-Select Branch .\n";
		}
		if(errormsg.length== emsg){
			$.ajax({
				url: "function.php",
				data:{"request":"ajax","action":"updateMotorStocks","date":date_created,"dr_no":dr,"supplier":supplier,"branch":branch,"type":"3"},
				success: function(reply){
					console.log(reply);
						if(reply == 'updated'){
							jAlert('D.R. was Updated Successfully','Alert Dialog');
							loadDR(dr);
						}
						else{
							jAlert('Error','Error Message');
							event.preventDefault();
						}	
					}
			});
					
		}
		else{
			
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
	}
	function editItem(id){
		var dr = getUrlVars()["dr_no"];
		event.preventDefault();
		var serial_no = $('#serial_no'+id).val(),color = $('#color'+id).val();
		var errormsg="Please complete the following fields: \n";
		var emsg= errormsg.length;
		
		if(serial_no == ""){
			errormsg+="-Serial No.\n";
		}
		if(errormsg.length== emsg){
			$.ajax({
				url: "function.php",
				data:{"request":"ajax","action":"editPromoStocks","serial_no":serial_no,"color":color,"id":id},
				success: function(reply){
					console.log(reply);
						if(reply == 'updated'){
							jAlert('Item Updated','Alert Dialog');
							loadMotorStocks(dr);
						}
						else{
							jAlert('Error','Error Message');
							event.preventDefault();
						}	
					}
			});
					
		}
		else{
			
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
	}	
	function loadPromoStocks(dr){
					
		$("#table > tbody").empty();
		
		var url="function.php?request=ajax&action=loadPromoStocks&dr_no="+dr;
		
	
		$.getJSON(url,function(data){
			var counter=0;
			$.each(data.members, function(i,res){
				 $("#table > tbody").append("<tr><td>"+res.item+"</td><td><input type='text' id='serial_no"+res.id+"' style='text-align:center;text-transform:uppercase' value='"+res.serial_no+"'></td><td><input type='text' id='color"+res.id+"' style='text-align:center;width:100px;text-transform:uppercase' value='"+res.color+"'></td><td>"+res.status+"</td><td><a href='#' alt='Update' title='Update' class='edit_item' onclick='editItem("+res.id+");'><img src='../images/edit.png' /></a></td><td><a href='#' onclick='deleteItem("+res.id+");' alt='Delete' title='Delete'><img src='../images/delete.png' /></a></td></tr>");
				 counter++;
				$( "#qty" ).html("<label style='font-weight:bold'> "+counter+" </label>");	
			});
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
				$( "#qty" ).html("<label style='font-weight:bold'> "+counter+" </label>");	
			}

		});
		
		
	}
	function reset(){
		$('#item')
		.prop('disabled', false)
		.empty()
		.append('<option value="">ITEM CODE</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$('#serial_no').val('');
		$('#color').val('');
	}
	</script>
	
</body>
</html>