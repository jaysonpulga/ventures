<?php
	session_start();
	include('../database.php');
	$db = new Database();  
	$db->connect();
	
	$action = $_REQUEST["action"];
	
	if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){
		
		switch($action){
					
			case 'viewCustomerLists';
				 $customer = array();
			
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$category=$_REQUEST['category'];
				$branch_id=$_REQUEST['branch_id'];
				
				$trimmed=trim($_REQUEST['inputsearch']);
				
				if($sort == "customer_name") {
					$sort1 = "CONCAT(c.last_name,', ',c.first_name,' ',c.middle_name)";
				}
				else {
					$sort1 = $sort;
				} 
				
				if($category == "customer_name") {
				
					/* $rows ="e.dr_no,a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code";
					
						if($branch_id != 1){
							$where = "e.dr_no = f.dr_no  AND f.status = 'SOLD' AND  e.type = 1  AND e.branch = a.branch_id AND a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',
					',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%' group by a.branch_id";
						
						}else{
							$where = "e.dr_no = f.dr_no  AND f.status = 'SOLD' AND  e.type = 1  AND e.branch = a.branch_id AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',
					',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%' AND e.type = 1 AND  e.branch = a.branch_id AND e.dr_no = f.dr_no AND f.status = 'SOLD' group by a.branch_id ";
						
						}
					
					
					
					$order = "$sort1 $sortType";
					$db->select("tbl_customer a, tbl_province b, tbl_city c, tbl_branch d, stocks e,stocks_motors f",$rows,$where,$order); */
					
					
					$row = "c.id,a.stock_id,a.invoice_no,CONCAT(c.last_name,', ',c.first_name,' ',c.middle_name) as customer_name,d.id as branch_id,d.branch_code,d.branch_name,c.customer_subd_brgy as brgy,c.customer_street_num as street,e.province_name as province, f.city_name as city";
					
					if($branch_id != 1){
						$where = "a.category = 1 AND a.invoice_no = b.invoice_no AND b.customer_id = c.id AND c.branch_id = d.id AND c.customer_province_id=e.id AND c.customer_city_town_id=f.id AND CONCAT(c.last_name,',
					',c.first_name,' ',c.middle_name) LIKE '%".$trimmed."%' AND  a.branch = '$branch_id' group by b.customer_id";
					}else{
						$where = "a.category = 1 AND a.invoice_no = b.invoice_no AND b.customer_id = c.id AND c.branch_id = d.id AND c.customer_province_id=e.id AND c.customer_city_town_id=f.id AND CONCAT(c.last_name,',
					',c.first_name,' ',c.middle_name) LIKE '%".$trimmed."%' group by b.customer_id";
					}
					
					
					$db->select("sale_invoice_details a, sales_invoice b,tbl_customer c, tbl_branch d,tbl_province e, tbl_city f",$row,$where); 
					
				}
				/* if($category == "branch") {
					$rows ="e.dr_no,a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as customer_name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code";
					
					if($branch_id != 1){
						$where = "e.dr_no = f.dr_no  AND f.status = 'SOLD' AND  e.type = 1  AND e.branch = a.branch_id AND a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND d.branch_name LIKE '%".$trimmed."%' group by a.branch_id";
					
					}else{
						$where = "e.dr_no = f.dr_no  AND f.status = 'SOLD' AND  e.type = 1  AND e.branch = a.branch_id AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND d.branch_name LIKE '%".$trimmed."%'  group by a.branch_id";
					
					}
					
					$order = "$sort1 $sortType";
					$db->select("stocks e,stocks_motors f,tbl_customer a, tbl_province b, tbl_city c, tbl_branch d ",$rows,$where,$order);
				} */
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}'; 
				
			break;
			
			
			case 'select_branch';
				$db->select("tbl_branch","*");
				$result = $db->getResult();
		
				print json_encode($result);
			break;
			
			
			case 'load_stockid';
			$invoice_no = $_REQUEST['invoice_no'];
			
			$rows = "b.dr_no,b.id";
			$where = "a.invoice_no = '$invoice_no' AND a.stock_id = b.id";
			$db->select("sale_invoice_details a,stocks_motors b",$rows,$where);
			$result = $db->getResult();
			echo '{"members":'.json_encode($result).'}';
			break;
			
			
	case 'load_stock_brand';

	$dr_no2 = explode(",",$_REQUEST['dr_no']);
	$arr = array();

	foreach($dr_no2 as $dr_no){
		$i = 0;

	 	$tables= "stocks_motors a,tbl_manufacturer b";
		
		
	
			$rows = "a.model,b.id, b.brand,a.dr_no";
			 $where = "a.dr_no = '$dr_no'  and a.brand = b.id and a.status = 'SOLD'";

				$db->select($tables,$rows,$where);

				$result = $db->getResult();
				 foreach($result as $info){
			
					 $new_arr[$i] =  array(
							'brand' =>$info['brand'],
							 'id' =>$info['id'],
							 'dr_no' =>$info['dr_no'],
							 'model' =>$info['model'],
							
							 );
				
							array_push($arr,$new_arr[$i]);
						 $i++;
					
				 }
			 
	
		
	}
	echo '{"members":'.json_encode($arr).'}'; 
	break;
	
			
			
			
			
			case 'select_brand';
				$dr_no=$_REQUEST["dr_no"];
				$row = "b.brand,b.id,a.model,a.dr_no";
				$where ="a.dr_no = '$dr_no' AND a.brand = b.id AND a.status = 'SOLD' GROUP BY a.brand ";
			
				$db->select("stocks_motors a, tbl_manufacturer b",$row,$where);
				$result = $db->getResult();
		
				print json_encode($result);
			break;
			
			case 'select_model';
				$dr_no=$_REQUEST["dr_no"];
				$brand=$_REQUEST["brand"];
				$model=$_REQUEST["model"];
				
				$row = "b.model as model,b.motor_id,a.dr_no,a.id as stock_id,a.model as model_id";
				$where ="a.dr_no = '$dr_no' AND a.brand ='$brand' AND  a.model = '$model' AND a.model = b.motor_id AND  a.brand = b.brand   AND a.status = 'SOLD' GROUP BY a.model	 ";
			
				$db->select("stocks_motors a, tbl_motorcycle b",$row,$where);
				$result = $db->getResult();
		
				print json_encode($result);
			break;
			
			case 'select_engine_motor';
				$dr_no=$_REQUEST["dr_no"];
				$stock_id=$_REQUEST["stock_id"];
				
				
				$row = "id,dr_no,engine_no,frame_no,color";
				$where ="dr_no = '$dr_no' AND id = '$stock_id' AND  status = 'SOLD'";
			
				$db->select("stocks_motors",$row,$where);
				$result = $db->getResult();
		
				print json_encode($result);
			break;
			
			case "saveREPO";
				
				$key = array();
				$plateno = array();
				
				$txtrepo=$_REQUEST["txtrepo"];
				$txtbranch=$_REQUEST["txtbranch"];
				$txtplateno=$_REQUEST["txtplateno"];
				$txtdate=$_REQUEST["txtdate"];
				$txtengine=$_REQUEST["txtengine"];
				$txtmotor=$_REQUEST["txtmotor"];
			
				
				$model=$_REQUEST["model"];
				$brand=$_REQUEST["brand"];
				$color=$_REQUEST["color"];
				
				$rows1 = "*";
				$where1 = "dr_no= '$txtrepo' ";
				$db->select("stock_repo",$rows1,$where1);
				$result = $db->getResult();
				
				
				$rows2 = "*";
				$where2 = "brand= '$brand' AND model = '$model' AND engine = '$txtengine' AND color ='$color' ";
				$db->select("stock_repo",$rows2,$where2);
				$key  = $db->getResult();
				
				
				$rows3 = "*";
				$where3 = "plate_no= '$txtplateno' ";
				$db->select("stock_repo",$rows3,$where3);
				$plateno  = $db->getResult();
				
				
				if(count($result)>0){
					echo "exists";
				}
				
				elseif(count($key)>0){
					echo "exists2";
				}
				elseif(count($plateno)>0){
					echo "exists3";
				}
				else {
				
					$rows ='dr_no,brand,model,engine,frame,color,plate_no,status';
					$values = array($txtrepo,$brand,$model,$txtengine,$txtmotor,$color,$txtplateno,"ON HAND");
					
					$db->insert('stock_repo',$values,$rows);
					
					$rows ='dr_no,date,branch,type';
					$values = array($txtrepo,$txtdate,$txtbranch,'5');
					
					$db->insert('stocks',$values,$rows);
					
				
					
					
					echo "saved";
					
				}
		break;
			
		case "updateREPO";
				
				$plateno = array();
				
				$txtrepo=$_REQUEST["txtrepo"];
				$txtbranch=$_REQUEST["txtbranch"];
				$txtplateno=$_REQUEST["txtplateno"];
				$txtdate=$_REQUEST["txtdate"];
				$plate2=$_REQUEST["plate2"];
				
				if($plate2 != $txtplateno){
				
				$rows3 = "*";
				$where3 = "plate_no= '$txtplateno' ";
				$db->select("stock_repo",$rows3,$where3);
				$plateno  = $db->getResult();
				
				}
						
				if(count($plateno)>0){
					echo "exists3";
				}
				else {
								
					$rowsx = array('branch' => $txtbranch, 'date' => $txtdate);
					$wherex ="dr_no = '$txtrepo' AND type = 5";
					$db->update("stocks",$rowsx,$wherex);
					
					$rowsx = array('plate_no' => $txtplateno);
					$wherex ="dr_no = '$txtrepo'";
					$db->update("stock_repo",$rowsx,$wherex); 
					
					
					echo "saved";
					
				}
		break;
			
			
		case 'loadREPO';
		
		$sort = $_REQUEST['sort'];
		$sortType = $_REQUEST['sortType'];
		$branch_id=$_REQUEST['branch_id'];
		
		
		$order = "$sort $sortType";
		
		$category=$_REQUEST['category'];
		$trimmed=trim($_REQUEST['inputsearch']);
		
		$row = "a.dr_no,b.date,a.plate_no,a.engine,a.frame,c.brand,d.model ,e.branch_name" ;
		
		$table = "stock_repo a,stocks b,tbl_manufacturer c,tbl_motorcycle d,tbl_branch e";
		
		if($branch_id != 1){
			
			$where = "a.dr_no = b.dr_no AND b.branch = '$branch_id' AND a.brand = c.id AND  a.model = d.motor_id AND  b.branch = e.id  AND $category LIKE '%".$trimmed."%' group by a.dr_no ";
		
		
		}else{
			$where = "a.dr_no = b.dr_no AND a.brand = c.id AND  a.model = d.motor_id AND  b.branch = e.id  AND $category LIKE '%".$trimmed."%' group by a.dr_no ";
		}
			
		
		$db->select($table,$row,$where,$order);
		
		
		$result = $db->getResult();

		print '{"members":'.json_encode($result).'}'; 
			
		break;
		
		case 'load_repo';

		$branch_id=$_REQUEST['branch_id'];
		$dr_no=$_REQUEST['dr_no'];
		
	
		$row = "a.engine,a.frame,a.color,a.status,a.plate_no,b.brand,c.model" ;
		
		$table = "stock_repo a,tbl_manufacturer b,tbl_motorcycle c";
		

		$where = "a.dr_no = '$dr_no' AND a.brand = b.id AND  a.model = c.motor_id ";
		
		$db->select($table,$row,$where,$order);
		
		
		$result = $db->getResult();

		print '{"members":'.json_encode($result).'}'; 
			
		break;
		
		case 'load_repo_header';

	
		$dr_no=$_REQUEST['dr_no'];
		
	
		$row = "dr_no,date,branch" ;
		
		$table = "stocks";
		$where = "dr_no = '$dr_no' ";
		
		$db->select($table,$row,$where,$order);
		
		
		$result = $db->getResult();

		print '{"members":'.json_encode($result).'}'; 
			
		break;
		
		case 'deleteTwotable';
	$id=$_REQUEST['id'];
	$table1=$_REQUEST['table1'];
	$table2=$_REQUEST['table2'];
	$table_id=$_REQUEST['table_id'];

	$db->delete($table1,"$table_id ='$id'");
	$db->delete($table2,"$table_id ='$id' AND type= '5'");	

	break;
		
	
			
			
		}
		
	}

?>