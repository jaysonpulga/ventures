<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Repo Units</title>
<head>

	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
<input type="hidden" id="branch_id" value="<?php echo $_SESSION['branch_id']; ?>" >
<input type="hidden" id="branch_name" value="<?php echo $_SESSION['branch_name']; ?>" >
<input type="hidden" id="branch_code" value="<?php echo $_SESSION['branch_code']; ?>" >
<input type="hidden" id="dr_no" value="<?php echo $_REQUEST['dr_no']; ?>" >

<input type="hidden" id="repo" value="<?php echo $_REQUEST['repo']; ?>" >

	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:750px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>REPO UNITS DETAILS</h2><hr></label>
							</span>
						</div>
						
						
				<div>
							<span>
								
								<label>REPO NO.:</label>
								<input type="text" id = "txtrepo" readonly style = "margin-left:15px; text-align:center; width:130px;" maxlength='6'>
							</span>

							
							<span style="margin-left:300px">
									<label>Date:</label>
									<input type="date" id = "txtdate" style="margin-left:10px; text-align:center">
							</span>
				</div>
						
				<div>
					
					<span >
						<label>Plate NO.:</label>
						<input type="text" id = "txtplateno" style="margin-left:10px; text-align:center">
						
						<input type="hidden" id = "plate2" style="margin-left:10px; text-align:center">
					</span>
					
					
					<span style="margin-left:250px">
						<label>Branch:</label>
						<select id = 'txtbranch' name='brand' style="margin-left:10px;">
						<option value="">Branch</option>
						</select>
					</span>
				</div>
				
				<div  class="contents">
						<table style="width:750;margin-top:20px" id="table">
							<thead>
								<tr><th>BRAND</th><th>MODEL</th><th>ENGINE NO.</th><th>FRAME NO.</th><th>COLOR</th><th>STATUS</th></tr>
							</thead>
							<tbody></tbody>
						</table>
				</div>
				
				
				<div align="center" style="margin-top:20px">
							<span>
								<input type="button" value="UPDATE" style="width:100px;top:1px;" onclick="edit();">	
								<input type="button" value="DELETE" style="width:100px;top:1px;" onclick="delete_item();"  >
								<input type="button" value="BACK" style="width:100px;top:1px;" onclick="back();">
							</span>
						</div>
				
				
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="stocks#"){
			menu="stocks";
		}
		else{
			menu = getUrlVars()["menu"];
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -25px 5px no-repeat",
		"padding":"30px 36px 0px 36px",
		"border-bottom":"4px solid #c95447"
		});
		

		loadBody();
		loadheader();
	});
	
	var branch_id = $("#branch_id").val();
	var branch_name = $("#branch_name").val();
	var branch_code = $("#branch_code").val();
	var dr_no = $("#dr_no").val();
	
	
	function loadheader() {		
		var url="function_stocks.php?request=ajax&action=load_repo_header&dr_no="+dr_no;
		var counter=0;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtrepo").val(res.dr_no);
				$("#txtdate").val(res.date);
				loadBranch(res.branch)
				counter++;	
			});
			
		});
		
	}
	
	
	
	function loadBody() {
		$("#table > tbody").empty();
		
		var url="function_stocks.php?request=ajax&action=load_repo&dr_no="+dr_no;
		var counter=0;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				
				$("#table > tbody").append("<tr class = 'x'></td><td>"+res.brand+"</td><td>"+res.model+"</td><td>"+res.engine+"</td><td>"+res.frame+"</td><td>"+res.color+"</td><td>"+res.status+"</td></tr>");
				
				$("#txtplateno").val(res.plate_no);
				$("#plate2").val(res.plate_no);
				counter++;
				
			});
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Items on record! </th></tr>");
			}
		});
		
	}
	
	
	function loadBranch(branch_id){
		var count=0, x=0;
		var select = $("#txtbranch");

		$.ajax({
				url:"function_stocks.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					
					
					
					if(reply.length > 0){
						select.empty();
								
							$.each(reply, function(i,res){
							 count++;
							 
							if(res.id == branch_id ){
							select.append("<option  value='"+res.id+"' selected='selected' >"+res.branch_code+"</option>");
							}	else{
							select.append("<option  value='"+res.id+"'>"+res.branch_code+"</option>");
							}	
								
																		
							});
			
					}
				}
			});
	}
	
	function back() {
		window.location = "repoUnits.php?menu=stocks";
	}
	
	function delete_item(){
	
		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){
			
			if(e){
			
				var table1 =  "stock_repo";
				var table2 =  "stocks";
				$.ajax({
					url: "function_stocks.php",
					data:{"request":"ajax","action":"deleteTwotable","id":dr_no,"table1":table1,"table2":table2,"table_id":"dr_no"},
					success: function(reply){
					jAlert("successfully Deleted");
				window.location = "repoUnits.php?menu=stocks";

					}
				});
				
			
					
				
			}
		
		});
	}
	
	
	
	function edit() {
		
		
		var txtrepo=$("#txtrepo").val();		
		var txtbranch=$("#txtbranch").val();
		var txtplateno=$("#txtplateno").val();	
		var txtdate=$("#txtdate").val();
		var plate2 = $("#plate2").val();
		
		
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
	
		if(txtbranch == ""){
			errormsg+="- Input Branch .\n";
		}
		if(txtplateno == ""){
			errormsg+="- Input Plate NO..\n";
		}
		if(txtdate == ""){
			errormsg+="- Input Date.\n";
		}
		
				if(errormsg.length==emsg){
				
					
								$.ajax({
									url: "function_stocks.php",
									data:{"request":"ajax","action":"updateREPO","txtrepo":txtrepo,"txtbranch":txtbranch,"txtplateno":txtplateno,"txtdate":txtdate,"plate2":plate2},
									success: function(reply){
										console.log(reply);
											if(reply == 'saved'){
												jAlert("REPO Successfully Updated!", "Alert Dialog");
												window.location = "repoUnits.php?menu=stocks";
												
											}
											else if(reply == 'exists3'){
												jAlert('This Plate No.:'+txtplateno+' Already Exists!', 'Alert Dialog');
											}
											else{
												alert('Error');
												event.preventDefault();
											}
									}
								});
						
				}
				
				else{
					jAlert(errormsg,"Alert Dialog");
					event.preventDefault();
				}
		
	}
	
	</script>