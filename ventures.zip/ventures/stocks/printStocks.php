<?php
include("../database.php");
$db = new Database();
$db->connect();
require('../fpdf.php');
date_default_timezone_set("Asia/Singapore");
//$date = date ('Y-m-d h:i:s A');
$dr_no=$_REQUEST["dr_no"];
	
class PDF extends FPDF
{



//Page header
function Header()
{
    //Logo
    //$this->Image('images/logo.jpg',20,2,30);
	$now=date("M d,Y");
    //Arial bold 15
    $this->SetFont('Arial','B',15);
    //Move to the right
    $this->Cell(90);
    //Title
	$this->Cell(10,10,'Stocks Details');
    //Line break
    $this->Ln(30);
	
}



//Simple table
// for hearder to put into array
function BasicTable($header)
{
    //Header
    foreach($header as $col)
		
    $this->Cell(45,10,$col,1,0,'C');
    $this->Ln(10);
	$this->SetFont('Arial','',10);
	
    
    
}

//Page footer
function Footer()
{
    //Position at 1.5 cm from bottom
    $this->SetY(-15);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    //Page number
    $this->Cell(0,20,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

$pdf=new PDF();
//Column titles.
$header = array("Model","Engine No.","Frame No.","Color","Status");	

$pdf->AliasNbPages();
$pdf->AddPage('L');
$pdf->SetFont('Arial','B',10);
$pdf->BasicTable($header);

$data_array=Array();
// sql statement
	$dr_no=$_REQUEST["dr_no"];
	$row = "b.model as item,a.engine_no,a.frame_no,a.color,a.status";
	$where="a.dr_no=$dr_no and a.model=b.motor_id";
	$db->select('stocks_motors a,tbl_motorcycle b',$row,$where);

	$result = $db->getResult();

		
	//echo '{"members":'.json_encode($result).'}';
		
	$width=45;
	
	for($j=0;$j<count($result);$j++){
		foreach($result[$j] as $key => $value){
			
			$pdf->Cell($width,8,$value,1,0,'C');
			
		}
		$pdf->Ln(8);
	}
			
	$pdf->Output();
?>