<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Repo Units</title>
<head>

	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:910px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>ADD REPO UNITS</h2><hr></label>
							</span>
						</div>
						
						
						<div>
							<span>
								
								<label>REPO NO.:</label>
								<input type="text" id = "txtrepo" style = "margin-left:47px; text-align:center; width:130px;" maxlength='6'>
							</span>
						</div>
						
						
						<div>
							<span>
								<input type = "hidden" id = "brand">
								<input type = "hidden" id = "model">
								
								
								<input type = "hidden" id = "branch_id">
								<input type = "hidden" id = "invoice_no">
								
								
								<label>Customer Name:</label>
								<input type="text" id = "txtcusname" style = "margin-left:7px; text-align:center; width:200px;">
								<a href="#"  style="width:30px;" onClick="search_customer();"><img src="" id="search" valign="bottom"></a>	
							</span>
							<span style="margin-left:335px">
									<label>Date:</label>
									<input type="date" id = "txtdate" value="<?php echo date('Y-m-d'); ?>" style="margin-left:10px; text-align:center">
							</span>
						</div>
						
						<div>
					<span>
						<label>Plate No.:</label>
						<input type="text" id = "txtplateno" style="width:200px;margin-left:50px" maxlength="6">
					</span>
					<span style="margin-left:360px">
						<label>Branch:</label>
						<select id = 'txtbranch' name='brand' style="margin-left:6px;">
						<option value="">Branch</option>
						</select>
					</span>
				</div>
				<div style="margin-top:30px;">
					<span>
						<label style="margin-left:5px">Manufacturer</label>
						<label style="margin-left:91px">Model</label>
						<label style="margin-left:140px">Engine No.</label>
						<label style="margin-left:110px">Motor No.s</label>
						<label style="margin-left:110px">COLOR</label>
					</span>
				</div>
				
				<div>
					<span style="margin-right:10px;">
						<select id = 'txtman' name='txtman'>
						<option value="">Select</option>
						</select>
					</span>	
					
					<span style="margin-right:20px;">
						<select id = 'txtmodel' name='txtmodel'>
						<option value="">Select</option>
						</select>
					</span>
					
					<span style="margin-right:10px;">
						<input type="text"   readonly id = "txtengine" class='txtengine'  style = "text-align:center;"  placeholder = "ENGINE NO.">
					</span>
					
					<span style="margin-right:10px;">	
						<input type="text"  readonly id = "txtmotor" class='txtmotor'  style = "text-align:center;" placeholder = "MOTOR NO.s">
					</span>
					
					<span style="margin-right:10px;">	
						<input type="text" readonly  id = "color" class='color'  style = "text-align:center;" placeholder = "COLOR">
					</span>
				
					<input type="hidden"   id = "stock_id">
				
				</div>
				
				<div align="center" style="margin-top:20px;">
					<span>
						<input type="button" id = "btnadd" value="CREATE" onclick="Add();">
						<input type="button" value="CANCEL" onclick = "window.location='repoUnits.php?menu=stocks'">
					</span>
				</div>
						
						
						<div id="customer_items" style="display:none;">
							<iframe id="item_dialog" width="954" height="595" style="border:none"></iframe>
						</div>
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="stocks#"){
			menu="stocks";
		}
		else{
			menu = getUrlVars()["menu"];
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -25px 5px no-repeat",
		"padding":"30px 36px 0px 36px",
		"border-bottom":"4px solid #c95447"
		});
		

		
	});
	
	
	$('#txtman')
	.prop('disabled', true)
	.empty()
	.append('<option value="">--SELECT--</option>')
	.find('option:first')
	.attr("selected","selected");
		
		
	$('#txtmodel')
	.prop('disabled', true)
	.empty()
	.append('<option value="">--SELECT--</option>')
	.find('option:first')
	.attr("selected","selected");
		
	
	function search_customer(){
			$("#customer_items").attr("title","SEARCH CUSTOMER");
			$("#item_dialog").attr('src','customer_name.php');
			$("#customer_items").dialog({
				width: 955,
				height: 640,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
				}
			});
			return false;
	}
	
	
	
	function closeIframe(id,name,branch_id,invoice_no) {
		$("#customer_items").dialog('close');
		$("#txtcusid").val(id);
		$("#txtcusname").val(name);
		$("#branch_id").val(branch_id);
		$("#invoice_no").val(invoice_no);
		
		loadBranch(branch_id);
		select_stockid(invoice_no);
		reset();
		
	}
	
	
	function reset(){
	$('#txtman')
	.prop('disabled', false)
	.empty()
	.append('<option value="">--SELECT--</option>')
	.find('option:first')
	.attr("selected","selected");
		
		
	$('#txtmodel')
	.prop('disabled', true)
	.empty()
	.append('<option value="">--SELECT--</option>')
	.find('option:first')
	.attr("selected","selected");
	
	
	$("#txtengine").val("");
	$("#txtmotor").val("");
	
	$("#brand").val("");
	$("#model").val("");
	$("#color").val("");
	
	}
	
	
	
	
	function select_stockid(invoice_no){
	
	var dr_no = [];
			var url="function_stocks.php?request=ajax&action=load_stockid&invoice_no="+invoice_no;
			var counter=1;
			$.getJSON(url,function(data){
	
			$.each(data.members, function(i,res){
				dr_no.push(res.dr_no);
				
			counter++;
				
			});
			
			load_manufacturer(dr_no);
		});	
		
		
			$('#txtman')
			.prop('disabled', false)
			.empty()
			.append('<option value="">--SELECT--</option>')
			.find('option:first')
			.attr("selected","selected");
	
	}
	

	
	function Add() {
		
		
		var txtrepo=$("#txtrepo").val();		
		var txtbranch=$("#txtbranch").val();
		var txtplateno=$("#txtplateno").val();	
		var txtdate=$("#txtdate").val();
		var txtengine=$("#txtengine").val();
		var txtmotor=$("#txtmotor").val();
		var stock_id=$("#stock_id").val();
		
		var brand=$("#brand").val();
		var model=$("#model").val();
		var color=$("#color").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(txtrepo == ""){
			errormsg+="- Input REPO No.\n";
		}
		if(txtbranch == ""){
			errormsg+="- Input Branch .\n";
		}
		if(txtplateno == ""){
			errormsg+="- Input Plate NO..\n";
		}
		if(txtdate == ""){
			errormsg+="- Input Date.\n";
		}
		if(txtengine == ""){
			errormsg+="- Input Engine No.\n";
		}
		if(txtmotor == ""){
			errormsg+="- Input Motor.\n";
		}
		
				if(errormsg.length==emsg){
				
					jConfirm('Do you really want to CREATE REPO ?','Confirmation Dialog',function(e){
							if(e){	
								$.ajax({
									url: "function_stocks.php",
									data:{"request":"ajax","action":"saveREPO","txtrepo":txtrepo,"txtbranch":txtbranch,"txtplateno":txtplateno,"txtdate":txtdate,"txtengine":txtengine,"txtmotor":txtmotor,"brand":brand,"model":model,"color":color},
									success: function(reply){
										console.log(reply);
											if(reply == 'saved'){
												jAlert("Invoice Successfully Added!", "Alert Dialog");
												window.location = "repoUnits.php?menu=stocks";
												
											}else if(reply == 'exists'){
												jAlert('REPO No. Already Exists!', 'Alert Dialog');
											}
											else if(reply == 'exists2'){
												jAlert('This Item AND Model are Already Exists!', 'Alert Dialog');
											}
											else if(reply == 'exists3'){
												jAlert('This Plate No.:'+txtplateno+' Already Exists!', 'Alert Dialog');
											}
											else{
												alert('Error');
												event.preventDefault();
											}
									}
								});
							}	
						});	
				}
				
				else{
					jAlert(errormsg,"Alert Dialog");
					event.preventDefault();
				}
		
	}
	
	function loadBranch(branch_id){
		var count=0, x=0;
		var select = $("#txtbranch");

		$.ajax({
				url:"function_stocks.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					
					
					
					if(reply.length > 0){
						select.empty();
								
							$.each(reply, function(i,res){
							 count++;
							 
							if(res.id == branch_id ){
							select.append("<option  value='"+res.id+"' selected='selected' >"+res.branch_code+"</option>");
							}	else{
							select.append("<option  value='"+res.id+"'>"+res.branch_code+"</option>");
							}	
								
																		
							});
			
					}
				}
			});
	}
	

	
	function load_manufacturer(dr_no){
	
	event.preventDefault();
	var array2 = [];
	var container = [];

	array2.push(dr_no);
	
	

	var url="function_stocks.php?request=ajax&action=load_stock_brand&dr_no="+array2;
	var counter=1;
	var select = $("#txtman");

		$.getJSON(url,function(data){
	
		select.empty();
		
			select.append("<option  value=''>--Select--</option>");
			$.each(data.members, function(i,res){
				
				select.append("<option  value='"+res.id+","+res.model+","+res.dr_no+"'>"+res.brand+"</option>");
			
			
			
			counter++;
				
			});
			
			if (counter <= 1){
			select.append("<option value='NO RECORD' >NO RECORD</option>");
			}
			
			
		});	 

	}
	
	

	
	
	$( "#txtman" ).change(function() {
			
			if($(this).val() == "") {
				
				$('#txtmodel')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
			}
			else {
				
				$('#txtmodel')
				.prop('disabled', false)
				.empty()
				.append('<option value="">--SELECT--</option>')
				.find('option:first')
				.attr("selected","selected")
				;
			}
			
		var brand =	$("#txtman").val(); 				
		var brandx = brand.split(',');
		var brand = brandx[0];
		var model = brandx[1];
		var dr_no = brandx[2];
		
		$("#txtengine").val("");
		$("#txtmotor").val("");
		$("#color").val("");
		
		$("#brand").val(brand);
		
		select_model(brand,model,dr_no);
			
		});
	
	
	
	
	function select_model(brand,model,dr_no){

		var count=0, x=0;
		var select = $("#txtmodel");

		$.ajax({
				url:"function_stocks.php",
				data:{"request":"ajax","action":"select_model","dr_no":dr_no,"brand":brand,"model":model},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					
					if(reply.length > 0){
						select.empty();
								
							select.append("<option  value=''>--SELECT--</option>");
								
							$.each(reply, function(i,res){
							 count++;
							 		
							select.append("<option  value='"+res.stock_id+","+res.dr_no+", "+res.model_id+"'>"+res.model+"</option>");
																
							});
			
					}
					
					
					
					
				}
			}); 
		
	
	}
	
	
	$( "#txtmodel" ).change(function() {
						
		var model = $("#txtmodel").val();
					
					var modelx = model.split(',');
					var stock_id = modelx[0];
					var dr_no = modelx[1];
					var model_id = modelx[2];
					
		$("#model").val(model_id);		
		load_engine_motor(stock_id,dr_no);
			
	});
	
	
	
	function load_engine_motor(stock_id,dr_no){

		var count=0, x=0;
		$("#txtengine").val("");
		$("#txtmotor").val("");
		$("#color").val("");

		$.ajax({
				url:"function_stocks.php",
				data:{"request":"ajax","action":"select_engine_motor","dr_no":dr_no,"stock_id":stock_id},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					console.log(reply.length);
					
					if(reply.length > 0){
			
									
							$.each(reply, function(i,res){
							 count++;
							 		
							$("#txtengine").val(res.engine_no);
							$("#txtmotor").val(res.frame_no);
							$("#color").val(res.color);
							
							$("#stock_id").val(res.id);
							$("#dr_nox").val(res.dr_no);
								
										
							});
			
					}
					
					
				}
			});
	}
	
	
	</script>