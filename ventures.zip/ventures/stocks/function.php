<?php
session_start();
include('../database.php');  
$db = new Database();  
$db->connect(); 
$action = $_REQUEST["action"];




if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){

	switch($action){
	
	case 'loadAllData';
		$dataArray=array();
		$type=$_REQUEST["type"];
		$category=$_REQUEST["category"];
		$txtsearch=$_REQUEST["inputsearch"];
		$trimmed=trim($txtsearch);
		$sortType=$_REQUEST["sortType"];
		$sort=$_REQUEST["sort"];
		$branch_id=$_REQUEST["branch_id"];
		
		if($type==1){
			$table="stocks_motors";
		}
		else if($type==2){
			$table="stocks_parts";
		}
		else if($type==3){
			$table="stocks_promo";
		}
		else if($type==4){
			$table="stocks_consumables";
		}
		
		if($category==""){
						if($branch_id != 1){
							$where="a.branch = '$branch_id' AND a.type=$type and a.supplier=b.id and a.branch=c.id";
						}else{
							$where="a.type=$type and a.supplier=b.id and a.branch=c.id";
						}
							$row = "a.dr_no,b.supplier_name,a.date,c.branch_name";
							
		}
		else{
						if($branch_id != 1){
							$where="a.branch = '$branch_id'AND a.type=$type and a.supplier=b.id and a.branch=c.id and $category LIKE '%".$trimmed."%'";
						}else{
							$where="a.type=$type and a.supplier=b.id and a.branch=c.id and $category LIKE '%".$trimmed."%'";
						}
						
						$row = "a.dr_no,b.supplier_name,a.date,c.branch_name";
						
		}
		
		$order="$sort $sortType";
		$db->select('stocks a,tbl_supplier b,tbl_branch c',$row,$where,$order);

		$result = $db->getResult();
		$i=0;
		foreach($result as $key){		
			$dr_no=$key["dr_no"];
			$where2="dr_no=$dr_no";
			$db->select($table,"*","dr_no=$dr_no");
			$result2 = $db->getResult();
			
			//print_r($result2);
			if(count($result2) > 0){
				$total_onhand=0;
				$total_sold=0;
				$total_transfer=0;	
				$total_returned=0;				
				foreach($result2 as $key2){		
					
					if($key2["status"]=="ON HAND"){
						$total_onhand++;
					}
					
					else if($key2["status"]=="SOLD"){
						$total_sold++;
					}
					else if (($key2["status"]=="TRANSFERRED") || ($key2["status"]=="PO RETURNED") || ($key2["status"]=="SALES RETURN")) {
						$total_transfer++;
					}
					else{
						$total_onhand=$total_onhand+$key2["remaining"] ;
					}							
					
					$new_arr[$i]=array(
						'dr_no'=> $key["dr_no"],
						'supplier'=> $key["supplier_name"],
						'date_received'=> $key["date"],
						'branch'=> $key["branch_name"],
						'total_onhand'=> $total_onhand,
						'total_sold'=> $total_sold,
						'total_transfer'=> $total_transfer,
					);	
					
				}
				array_push($dataArray,$new_arr[$i]);
				
			}
			else{
				$new_arr[$i]=array(
					'dr_no'=> $key["dr_no"],
					'supplier'=> $key["supplier_name"],
					'date_received'=> $key["date"],
					'branch'=> $key["branch_name"],
					'total_onhand'=> "0",
					'total_sold'=> "0",
					'total_transfer'=> "0",
				);
				array_push($dataArray,$new_arr[$i]);	
			}
			
			$i++;	
		}		
		
		echo '{"members":'.json_encode($dataArray).'}';
		
		
	break;
	
	
	case 'loadSupplier';
	
		$row = "*";
		
		$db->select('tbl_supplier',$row);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadBranches';
	
		$row = "id,branch_name";
		$db->select('tbl_branch',$row);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadBrand';
		$category=$_REQUEST["category"];
		$row = "*";
		$where="category=$category";
		$db->select('tbl_manufacturer',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadModel';
		$brandID=$_REQUEST["brandID"];
		$row = "*";
		$where="brand=$brandID";
		$db->select('tbl_motorcycle',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadItemsPromo';
		$brandID=$_REQUEST["brandID"];
		$row = "*";
		$where="brand=$brandID";
		$db->select('tbl_promo',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadItemsConsumables';
		$brandID=$_REQUEST["brandID"];
		$row = "*";
		$where="brand=$brandID";
		$db->select('tbl_consumables',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'saveDR';
	
		$remarks=$_REQUEST["remarks"];
		$type=$_REQUEST["type"];
		$dr_no=$_REQUEST["dr_no"];
		$date_created=$_REQUEST["date_created"];
		$branch=$_REQUEST["branch"];
		$supplier=$_REQUEST["supplier"];
		
		$where="dr_no='".$dr_no."' AND type='".$type."'";
		$values = array('',$dr_no,$date_created,$branch,$supplier,$remarks,$type);
		
	
		$db->select('stocks','*',$where);
		$result = $db->getResult();
		
		//print_r($result);
		if(count($result) > 0){
			print("exist");
		}
		else{
			$db->insert("stocks",$values);
			print 'saved';
		}
					
	break;
	
	case 'loadDR';
	
		$dr_no=$_REQUEST["dr_no"];
		$type=$_REQUEST["type"];
		$row = "*";
		$where="dr_no=$dr_no and type=$type";
		$db->select('stocks',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadMotorStocks';
	
		$dr_no=$_REQUEST["dr_no"];
		$row = "a.*,b.model as item";
		$where="a.dr_no=$dr_no and a.model=b.motor_id";
		$db->select('stocks_motors a,tbl_motorcycle b',$row,$where);

		$result = $db->getResult();
		
		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadPromoStocks';
	
		$dr_no=$_REQUEST["dr_no"];
		$row = "a.*,b.item_code as item";
		$where="a.dr_no=$dr_no and a.item=b.promo_id";
		$db->select('stocks_promo a,tbl_promo b',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	
	/** Consumables **/
	
	case 'loadConsumables';
	
		$dr_no=$_REQUEST["dr_no"];
		$row = "a.dr_no,a.brand,a.item,a.serial_no,sum(a.quantity) as quantity,sum(a.remaining) as remaining,b.type as type, b.item_code as code";
		$where="a.dr_no=$dr_no and a.item=b.con_id";
		$db->select('stocks_consumables a,tbl_consumables b',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'addPromoStocks';
		$brand=$_REQUEST["brand"];
		$item=$_REQUEST["item"];
		$serial_no=strtoupper($_REQUEST["serial_no"]);
		$color=strtoupper($_REQUEST["color"]);
		$dr_no=$_REQUEST["dr_no"];
		$status="ON HAND";
		
		$values = array('',$dr_no,$brand,$item,$serial_no,$color,$status);
		
		$where="item=$item and serial_no='".$serial_no."'";
		$db->select('stocks_promo','*',$where);
		$result = $db->getResult();
		
		if(count($result) > 0){
			print("exist");
		}
		else{
			$db->insert("stocks_promo",$values);
			print 'saved';
		}
	break;
	
	case 'addConsumables';
		$brand=$_REQUEST["brand"];
		$item=$_REQUEST["item"];
		$serial_no=strtoupper($_REQUEST["serial_no"]);
		$dr_no=$_REQUEST["dr_no"];
		$qty=$_REQUEST["qty"];

		$values = array('',$dr_no,$brand,$item,$serial_no,$qty,$qty);
		$where="item=$item and serial_no='".$serial_no."'";
		$db->select('stocks_consumables','*',$where);
		$result = $db->getResult();
		
		/* if(count($result) > 0){
			print("exist");
		}
		else{ */
			$db->insert("stocks_consumables",$values);
			print 'saved';
		//}
	break;
	
	case 'addMotorStocks';
		$brand=$_REQUEST["brand"];
		$model=$_REQUEST["model"];
		$frame_no=strtoupper($_REQUEST["frame_no"]);
		$engine_no=strtoupper($_REQUEST["engine_no"]);
		$color=strtoupper($_REQUEST["color"]);
		$dr_no=$_REQUEST["dr_no"];
		$status="ON HAND";
		
		$values = array('',$dr_no,$brand,$model,$engine_no,$frame_no,$color,$status);
		
		$where="frame_no='".$frame_no."' AND engine_no='".$engine_no."'";
		$db->select('stocks_motors','*',$where);
		$result = $db->getResult();
		
		if(count($result) > 0){
			print("exist");
		}
		else{
			$db->insert("stocks_motors",$values);
			print 'saved';
		}
	break;
	
	case 'deleteMotorStocks';
		$val=$_REQUEST['id'];
		
		$db->delete("stocks_motors","id='$val'");
		
		print 'deleted';
			
	break;
	
	case 'deleteConsumables';
		$val=$_REQUEST['id'];
		
		$db->delete("stocks_consumables","id='$val'");
		
		print 'deleted';
			
	break;
	
	case 'deletePromoStocks';
		$val=$_REQUEST['id'];
		
		$db->delete("stocks_promo","id='$val'");
		
		print 'deleted';
			
	break;
	
	case 'editPromoStocks';
		$val=$_REQUEST['id'];
		
		$items_array=array(
			'serial_no'=> $_REQUEST['serial_no'],
			'color'=> $_REQUEST['color'],
		);
				
		$where="id='$val'";
			
		$db->update("stocks_promo",$items_array,$where);
		
		print "updated";
			
	break;
	
	case 'editConsumables';
		$val=$_REQUEST['id'];
		
		$items_array=array(
			'serial_no'=> $_REQUEST['serial_no'],
			'quantity'=> $_REQUEST['quantity'],
		);
				
		$where="id='$val'";
			
		$db->update("stocks_consumables",$items_array,$where);
		
		print "updated";
			
	break;
	
	case 'editMotorStocks';
		$val=$_REQUEST['id'];
		
		$items_array=array(
			'frame_no'=> $_REQUEST['frame_no'],
			'engine_no'=> $_REQUEST['engine_no'],
			'color'=> $_REQUEST['color'],
		);
				
		$where="id='$val'";
			
		$db->update("stocks_motors",$items_array,$where);
		
		print "updated";
			
	break;
	
	case 'updateMotorStocks';
		$val=$_REQUEST['dr_no'];
		$type=$_REQUEST['type'];
		$items_array=array(
			'date'=> $_REQUEST['date'],
			'branch'=> $_REQUEST['branch'],
			'supplier'=> $_REQUEST['supplier'],
		);
				
		$where="dr_no='$val' and type='$type'";
			
		$db->update("stocks",$items_array,$where);
		
		print "updated";
			
	break;
	
	// PARTS
	
	case 'loadPartModel';
		$brandID=$_REQUEST["brandID"];
		$row = "*";
		$where="brand=$brandID";
		$db->select('tbl_parts',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadPartsStocks';
		$dataArray=array();
		$dr_no=$_REQUEST["dr_no"];
		$row = "a.id,a.dr_no,a.brand,a.item,a.serial_no,a.quantity,a.remaining,b.parts as item_code,b.item_code as code";
		$where="a.dr_no=$dr_no and a.item=b.parts_id";
		$db->select('stocks_parts a,tbl_parts b',$row,$where);

		$result = $db->getResult();
		
		
		foreach($result as $key){
			$item=$key["item"];
			$serial_no=$key["serial_no"];
			
			/** TRANSFER **/
			
			$row2 = "a.item,b.qty";
			$where2="a.item=".$item." and a.id=b.stock_id and b.category=2";
			$db->select('stocks_parts a,transfer_details b',$row2,$where2);	
			$result2 = $db->getResult();
			
			if(count($result2>0)){
				$total_transfer=0;
				foreach($result2 as $key2){
					$total_transfer=$total_transfer+$key2["qty"];
				}
			}
			else{
				$total_transfer=0;
			}
			
			/** PO RETURN **/
			$row3 = "a.item,b.qty";
			$where3="a.item=".$item." and a.id=b.stock_id and b.category=2";
			$db->select('stocks_parts a,purchase_return_details b',$row3,$where3);	
			$result3 = $db->getResult();
			
			if(count($result3>0)){
				$total_return=0;
				foreach($result3 as $key3){
					$total_return=$total_return+$key3["qty"];
				}
			}
			else{
				$total_return=0;
			}
			
			/** SALES **/
			$row4 = "a.item,b.qty,a.serial_no";
			$where4="a.item=".$item." and a.serial_no like '%".$serial_no."%' and a.id=b.stock_id and category=2";
			$db->select('stocks_parts a,sale_invoice_details b',$row4,$where4);	
			$result4 = $db->getResult();
			
			if(count($result4>0)){
				$total_sold=0;
				foreach($result4 as $key4){
					$total_sold=$total_sold+$key4["qty"];
				}
			}
			else{
				$total_sold=0;
			}
			
			
			$new_arr[$i]=array(
				'id'=> $key["id"],
				'parts'=> $key["code"],
				'item_code'=> $key["item_code"],
				'part_no'=> $key["serial_no"],
				'qty'=> $key["quantity"],
				'total_onhand'=> $key["remaining"],
				'total_return'=> $total_return,
				'total_sold'=> $total_sold,
				'total_transfer'=> $total_transfer,
			);	
				
			
			
			array_push($dataArray,$new_arr[$i]);
			$i++;
			
		
		}
			
		
		echo '{"members":'.json_encode($dataArray).'}';
					
	break;
	
	case 'loadConsumablesStocks';
		$dataArray=array();
		$dr_no=$_REQUEST["dr_no"];
		$row = "a.id,a.dr_no,a.brand,a.item,a.serial_no,a.quantity,a.remaining,b.type,b.item_code";
		$where="a.dr_no=$dr_no and a.item=b.con_id";
		$db->select('stocks_consumables a,tbl_consumables b',$row,$where);

		$result = $db->getResult();
		
		
		foreach($result as $key){
			$item=$key["item"];
			$serial_no=$key['serial_no'];
			
			/** TRANSFER **/
			
			$row2 = "a.item,b.qty";
			$where2="a.item=".$item." and a.id=b.stock_id and b.category=4";
			$db->select('stocks_consumables a,transfer_details b',$row2,$where2);	
			$result2 = $db->getResult();
			
			if(count($result2>0)){
				$total_transfer=0;
				foreach($result2 as $key2){
					$total_transfer=$total_transfer+$key2["qty"];
				}
			}
			else{
				$total_transfer=0;
			}
			
			/** PO RETURN **/
			$row3 = "a.item,b.qty";
			$where3="a.item=".$item." and a.id=b.stock_id and b.category=4";
			$db->select('stocks_consumables a,purchase_return_details b',$row3,$where3);	
			$result3 = $db->getResult();
			
			if(count($result3>0)){
				$total_return=0;
				foreach($result3 as $key3){
					$total_return=$total_return+$key3["qty"];
				}
			}
			else{
				$total_return=0;
			}
			
			/** SALES **/
			$row4 = "a.item,b.qty,a.serial_no";
			$where4="a.item=".$item." and a.serial_no like '%".$serial_no."%' and a.id=b.stock_id and category=4";
			$db->select('stocks_consumables a,sale_invoice_details b',$row4,$where4);	
			$result4 = $db->getResult();
			
			if(count($result4>0)){
				$total_sold=0;
				foreach($result4 as $key4){
					$total_sold=$total_sold+$key4["qty"];
				}
			}
			else{
				$total_sold=0;
			}
			
			
			$new_arr[$i]=array(
				'id'=> $key["id"],
				'type'=> $key["type"],
				'item_code'=> $key["item_code"],
				'serial_no'=> $key["serial_no"],
				'qty'=> $key["quantity"],
				'total_onhand'=> $key["remaining"],
				'total_return'=> $total_return,
				'total_sold'=> $total_sold,
				'total_transfer'=> $total_transfer,
			);	
				
			
			
			array_push($dataArray,$new_arr[$i]);
			$i++;
			
		
		}
			
		
		echo '{"members":'.json_encode($dataArray).'}';
					
	break;
	
	case 'addPartStocks';
		$brand=$_REQUEST["brand"];
		$item=$_REQUEST["item"];
		$serial_no=strtoupper($_REQUEST["serial_no"]);
		$dr_no=$_REQUEST["dr_no"];
		$qty=$_REQUEST["qty"];
	
		
		$values = array('',$dr_no,$brand,$item,$serial_no,$qty,$qty);
		
		/* $where="serial_no='".$serial_no."'";
		$db->select('stocks_parts','*',$where);
		$result = $db->getResult();
		
		if(count($result) > 0){
			print("exist");
		} 
		else{*/
			$db->insert("stocks_parts",$values);
			print 'saved';
		//}
	break;
	
	case 'editPartsStocks';
		$val=$_REQUEST['id'];
		$serial_no=strtoupper($_REQUEST["serial_no"]);
		$or_serial_no=strtoupper($_REQUEST["OR_serial_no"]);
		$or_quantity=$_REQUEST["OR_quantity"];
		$quantity=$_REQUEST["quantity"];
		
		//$where="serial_no='".$serial_no."'";
		
		$items_array=array(
			'quantity'=> $_REQUEST['quantity'],'serial_no'=> $_REQUEST['serial_no'],
		);
				
		
		if(($or_serial_no==$serial_no) && ($or_quantity==$quantity)){
			print("no changes");
		}
		else{
			
			$where="id='$val'";
			
			$db->update("stocks_parts",$items_array,$where);
		
			print "updated";
			
		}
		
			
	break;
	
	case 'deletePartsStocks';
		$val=$_REQUEST['id'];
		
		$db->delete("stocks_parts","id='$val'");
		
		print 'deleted';
		
	break;
	
	}
}


?>