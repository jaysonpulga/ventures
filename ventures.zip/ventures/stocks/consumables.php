<?php
session_start();

if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION["username"];
$branch_name = $_SESSION["branch_name"];
$branch_id = $_SESSION['branch_id'];
?>
<html>
<title>Consumables</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link rel="stylesheet" href="../css/jPages.css" type="text/css" media="screen">
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript" ></script>
	<script type="text/javascript" src=""></script>
</head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
<body>
<input type="hidden" id="branch_id" value="<?php echo $_SESSION['branch_id']; ?>" >
<input type="hidden" id="branch_name" value="<?php echo $_SESSION['branch_name']; ?>" >
<input type="hidden" id="branch_code" value="<?php echo $_SESSION['branch_code']; ?>" >
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<table width="950px">
						<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2 style="margin-top:10px;">CONSUMABLES</h2>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
								<form name="search" action="" method="POST">
								<select id = 'category' name='category'>
									<option value="a.dr_no">DR No.</option>
									<option value="b.supplier_name">Supplier</option>
									<option value="c.branch_name">Branch</option>
								</select>
								<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Report">
								<input type="button" value="NEW STOCK" id='input' style="width:120px;" onclick="add_item();">
								</form>
							</td>
						</tr>
					</table>
					
				</div>
			
								
				<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:950px" cellspacing="0">
					<table id="table">
					<thead>	
						<tr><th><a href = "#"  class = "table_title" style='text-decoration:none;' onclick = "filter_list(0,'a.dr_no')">D.R. NO.</a></th><th><a href = "#"  class = "table_title" style='text-decoration:none;' onclick = "filter_list(0,'b.supplier_name')">SUPPLIER</a></th><th><a href = "#"  class = "table_title" style='text-decoration:none;' onclick = "filter_list(0,'a.date')">DATE RECEIVED</a></th><th><a href = "#"  class = "table_title" style='text-decoration:none;' onclick = "filter_list(0,'c.branch_name')">BRANCH</a></th><th>TOTAL<br>ON HAND</th><th>TOTAL<br>SOLD</th><th style="width:20px;">ACTION</th></tr>
					</thead>
					<tbody id="alldata"></tbody>
					</table>
				</div>
				
				<div id="pagination" style="position:relative;top:50px;"> 
					<div class="holder" ></div>
					<div style='font-size:11px;margin-top:5px;' align='center'><i>Pages</i></div>
				</div>
					
				<div id="new_items" title="NEW STOCK" style="display:none;">
					<iframe id="item_dialog" width="420" height="450" style="border:none"></iframe>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		if(menu=="stocks#"){
			menu="stocks";
		}
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -25px 5px no-repeat",
		"padding":"30px 36px 0px 36px",
		"border-bottom":"4px solid #c95447"
		});
		
		
		loadAllData("DESC","a.id");
	});
	
	
		  var branch_id = $("#branch_id").val();
	  var branch_name = $("#branch_name").val();
	  var branch_code = $("#branch_code").val();
	
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
	var sortType = "DESC";
	var sort = "a.id";
	function filter_list(index,sort){
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadAllData(sortType,sort);			
	}
		
	function add_item(){
		$("#item_dialog").attr('src','../stocks/newDR.php?type=4');
		$("#new_items").dialog({
			width:400,
			height: 420,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src',"about:blank");
				window.location.reload();
			}
		});
		return false;
	}
	function loadAllData(sortType,sort){
	
		$("#table > tbody").empty();
		
		var url="function.php?request=ajax&action=loadAllData&type=4&sortType="+sortType+"&sort="+sort+"&branch_id="+branch_id;
	
		$.getJSON(url,function(data){
			var counter=0;
			$.each(data.members, function(i,res){
				 $("#table > tbody").append("<tr class = 'x'><td>"+res.dr_no+"</td><td>"+res.supplier+"</td><td>"+res.date_received+"</td><td>"+res.branch+"</td><td>"+res.total_onhand+"</td><td>"+res.total_sold+"</td><td><a href='#' alt='View' title='View' class='view' onclick=\"window.location='newConsumables.php?menu=stocks&dr_no="+res.dr_no+"'\"></a></td></tr>");
				 counter++;	
			});
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
			}
			jpages();
		});
		
	}	
	function closeIframe(link)
	{
		$('#new_items').dialog('close');
		jAlert("Receiving Inventory  Created","Alert Dialog");
		
		window.location=link;
		
		return false;
	}
	function cancelIframe()
	{
		$('#new_items').dialog('close');

	}
	
	$("#txtsearch").blur(function(){
		$(this).val("");
	});
	
	$("#txtsearch").bind('keyup change',function(){
		var url ="function.php?request=ajax&action=loadAllData&type=4&inputsearch="+$(this).val()+"&category="+$('#category').val()+"&sortType="+sortType+"&sort="+sort+"&branch_id="+branch_id;
		var count=0;
				if($(this).val().trim() != ""){
			
					$("#table > tbody").empty();
		
					$.getJSON(url,function(data){
						var counter=0;
						$.each(data.members, function(i,res){
							 $("#table > tbody").append("<tr class = 'x'><td>"+res.dr_no+"</td><td>"+res.supplier+"</td><td>"+res.date_received+"</td><td>"+res.branch+"</td><td>"+res.total_onhand+"</td><td>"+res.total_sold+"</td><td><a href='#' alt='View' title='View' class='view_item' onclick=\"window.location='newConsumables.php?menu=stocks&dr_no="+res.dr_no+"'\"><img src='../images/view.png' /></a></td></tr>");
							 counter++;	
						});
						if (counter <= 0){
							$("#table > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
						}
						jpages();
					});
					
				}	
				else{
					$("#table > tbody").empty();
					loadAllData("DESC","a.id");
				}				
	});
	function jpages(){
		$("div.holder").jPages({
		  containerID : "alldata",
		  previous : "←",
		  next : "→",
		  perPage : 15,
		  delay :10,
		  startPage    : 1,
		  startRange   : 1,
		  midRange     : 5,
		  endRange     : 1
		});
	}
	</script>
	
</body>
</html>