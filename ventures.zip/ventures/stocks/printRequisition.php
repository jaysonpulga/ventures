<html>
<title>MOTORCYCLE STOCKS</title>
</html>
<?php
include('../database.php');  
$db = new Database();  
$db->connect(); 

	//$_REQUEST["sr_no"] = "AB101";	

	echo $sr_no = $_REQUEST["sr_no"];

	$where = "a.sr_no = '$sr_no' and  a.branch_id = b.id";
	$rows = "a.sr_no,a.date,a.sold,b.branch_name";
	
	$db->select("tbl_requisition a,tbl_branch b",$rows,$where);
	$result = $db->getResult();	
	
	
	foreach($result as $key2){
			
		echo $sr_no=$key["sr_no"];
		echo $date=$key["date"];
		echo $sold=$key["sold"];
		echo $branch_name=$key["branch_name"];

	
	}
	
	
	

?>