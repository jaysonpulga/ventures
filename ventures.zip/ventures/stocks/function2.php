<?php
include('../database.php');  
$db = new Database();  
$db->connect(); 
$action = $_REQUEST["action"];




if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){

	switch($action){
	
	
	
	case 'loadSupplier';
	
		$row = "*";
		
		$db->select('tbl_supplier',$row);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	
	case 'loadBrand';
		$category=$_REQUEST["category"];
		$row = "*";
		$where="category=$category";
		$db->select('tbl_manufacturer',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadModel';
		$brandID=$_REQUEST["brandID"];
		$row = "*";
		$where="brand=$brandID";
		$db->select('tbl_motorcycle',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadItemsPromo';
		$brandID=$_REQUEST["brandID"];
		$row = "*";
		$where="brand=$brandID";
		$db->select('tbl_promo',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadItemsConsumables';
		$brandID=$_REQUEST["brandID"];
		$row = "*";
		$where="brand=$brandID";
		$db->select('tbl_consumables',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'savePO';
	
		$po_no=$_REQUEST["po_no"];
		$date_created=$_REQUEST["date_created"];
		$terms=$_REQUEST["branch"];
		$supplier=$_REQUEST["supplier"];
		
		$where="po_no='".$po_no."'";
		$values = array('',$po_no,$supplier,$date_created,$terms);
		
	
		$db->select('purchase_order','*',$where);
		$result = $db->getResult();
		
		if(count($result) > 0){
			print("exist");
		}
		else{
			$db->insert("purchase_order",$values);
			print 'saved';
		}
					
	break;
	
	case 'loadPO';
	
		$po_no=$_REQUEST["po_no"];
		$row = "*";
		$where="po_no=$po_no";
		$db->select('purchase_order',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadPuchaseOrder';
	
		$po_no=$_REQUEST["po_no"];
		$row = "a.*,b.model as item";
		$where="a.dr_no=$dr_no and a.model=b.motor_id";
		$db->select('stocks_motors a,tbl_motorcycle b',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'addPurchaseOrder';
		$brand=$_REQUEST["brand"];
		$item=$_REQUEST["item"];
		$serial_no=strtoupper($_REQUEST["serial_no"]);
		$color=strtoupper($_REQUEST["color"]);
		$dr_no=$_REQUEST["dr_no"];
		$status="ON HAND";
		
		$values = array('',$dr_no,$brand,$item,$serial_no,$color,$status);
		
		$where="item=$item and serial_no='".$serial_no."'";
		$db->select('stocks_promo','*',$where);
		$result = $db->getResult();
		
		if(count($result) > 0){
			print("exist");
		}
		else{
			$db->insert("stocks_promo",$values);
			print 'saved';
		}
	break;

	case 'deletePurchaseOrder';
		$val=$_REQUEST['id'];
		
		$db->delete("purchase_order_details","id='$val'");
		
		print 'deleted';
			
	break;
	
	
	case 'editPurchaseOrder';
		$val=$_REQUEST['id'];
		
		$items_array=array(
			'serial_no'=> $_REQUEST['serial_no'],
			'color'=> $_REQUEST['color'],
		);
				
		$where="id='$val'";
			
		$db->update("stocks_promo",$items_array,$where);
		
		print "updated";
			
	break;
	
	
	
	/* PURCHASE RETURNS */
	
	case 'savePR';
	
		$po_no=$_REQUEST["po_no"];
		$date_created=$_REQUEST["date_created"];
		$terms=$_REQUEST["branch"];
		$supplier=$_REQUEST["supplier"];
		
		$where="po_no='".$po_no."'";
		$values = array('',$po_no,$supplier,$date_created,$terms);
		
	
		$db->select('purchase_order','*',$where);
		$result = $db->getResult();
		
		if(count($result) > 0){
			print("exist");
		}
		else{
			$db->insert("purchase_order",$values);
			print 'saved';
		}
					
	break;
	
	case 'loadPR';
	
		$po_no=$_REQUEST["po_no"];
		$row = "*";
		$where="po_no=$po_no";
		$db->select('purchase_order',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	
	case 'loadPuchaseReturn';
	
		$po_no=$_REQUEST["po_no"];
		$row = "a.*,b.model as item";
		$where="a.dr_no=$dr_no and a.model=b.motor_id";
		$db->select('stocks_motors a,tbl_motorcycle b',$row,$where);

		$result = $db->getResult();

		echo '{"members":'.json_encode($result).'}';
					
	break;
	

	case 'deletePurchaseReturn';
		$val=$_REQUEST['id'];
		
		$db->delete("purchase_return_details","id='$val'");
		
		print 'deleted';
			
	break;
	
	
	case 'editPurchaseReturn';
		$val=$_REQUEST['id'];
		
		$items_array=array(
			'serial_no'=> $_REQUEST['serial_no'],
			'color'=> $_REQUEST['color'],
		);
				
		$where="id='$val'";
			
		$db->update("stocks_promo",$items_array,$where);
		
		print "updated";
			
	break;
	
	
	
	}
}


?>