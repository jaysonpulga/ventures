<?php
	
	$to = $_REQUEST["to"];
	$from = $_REQUEST["from"];
	
	$month = substr($from,5,2);
	$year = substr($from,0,4);
		
	if($month == "01") {
		$month_name = "JANUARY";
	}
	if($month == "02") {
		$month_name = "FEBRUARY";
	}
	if($month == "03") {
		$month_name = "MARCH";
	}
	if($month == "04") {
		$month_name = "APRIL";
	}
	if($month == "05") {
		$month_name = "MAY";
	}
	if($month == "06") {
		$month_name = "JUNE";
	}
	if($month == "07") {
		$month_name = "JULY";
	}
	if($month == "08") {
		$month_name = "AUGUST";
	}
	if($month == "09") {
		$month_name = "SEPTEMBER";
	}
	if($month == "10") {
		$month_name = "OCTOBER";
	}
	if($month == "11") {
		$month_name = "NOVEMBER";
	}
	if($month == "12") {
		$month_name = "DECEMBER";
	}
	
	error_reporting(0);

?>
<html>
<title>INVENTORY REPORT-MOTORCYCLE</title>
<script src="../js/jquery-1.8.3.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="../js/jquery.alerts.js" type="text/javascript"></script>
<script type="text/javascript" src=""></script>
<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
</html>

<style>
body{
	font-family:Calibri,Helvetica,"sans-serif";
	font-size:14px;	
}
#table table{
	border-collapse:collapse;
	box-shadow: 1px 2px 3px gray;
	width:inherit;
}
#table th, td{
	border: 1px solid #3d3d45;
}
#table th{
	background:#3d3d45;
	color:#FFF;
	font-size:12px;
	padding:2px 5px;
	letter-spacing:1px;
	border: 1px solid #f3f2f2;
}
#table td{
	background:#f3f2f2;
	padding:0px;
	font-size:12px;
	text-align:center;	
}

</style>

<body>
	<div id="wrapper" style="width:100%">
			<div id="main" align="center" style="width:100%">
				<div id="options-top" align="center" style="width:100%;">
					<h2 style="margin-top:10px;">VENTURE MOTORCYCLE SALES CORPORATION</h2>
					<h3 style="margin-top:-15px;">CENTRAL OFFICE</h3>
					<h3 style="margin-top:-15px;">INVENTORY OF SPARE PARTS, ACCESSORIES AND OIL</h3>
					<h4 style="margin-top:-15px;">As of <?php echo $month_name; ?>&nbsp;<?php echo $year; ?></h4>
					<table width="1200px" border=0 cellspacing=0 cellpadding=0 width="100%" id = "table">
						<thead>
							<tr class="y" style='font-size:11px;'>
								<th style='padding:10px 0px;'>DATE</th><th>DR NO.</th><th>DESCRIPTION</th><th>SERIAL NO.</th><th>BEG</th><th>TOTAL</th><th>UNIT COST</th><th>NET OF VAT</th><th>COST OF SALE</th><th>NO. OF SALES</th><th>COSTY OF INVTY-<br>ENDING</th><th>ENDING</th>
							</tr>
						</thead>
						<tbody id="table">
						</tbody>
					</table>
					
				</div>
				
			</div>
	</div>
	<script src='../js/dropdowntabs.js'></script>	
	<script>
	var branch = getUrlVars()["branch"];
	var to= getUrlVars()["to"];
	var from = getUrlVars()["from"];
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="reports#"){
			menu="reports";
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
		"padding":"30px 31px 0px 31px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadInventory();
		
	});

	
	
	function loadInventory() {
		
		var url="functions.php?request=ajax&action=loadInventoryConsumables&branch="+branch+"&to="+to+"&from="+from;
		var beg=0;
		var unit_cost=0;
		var net_vat=0;
		var costsales=0;
		var no_sales=0;
		var costy=0;
		var ending=0;
		
		var total_beg=0;
		var total_total=0;
		var total_unit_cost=0;
		var total_net=0;
		var total_cost=0;
		var total_no_sales=0;
		var total_costy=0;
		var total_ending=0;
		
		$("#table > tbody").empty();
	
		$.getJSON(url,function(data){
			var counter=0;
			$.each(data.members, function(i,res){
				
				beg = res.quantity;
				unit_cost = res.unit_cost;
				no_sales = res.sales_qty;
				
				costsales = parseFloat(unit_cost)*parseFloat(no_sales);
				net_vat = costsales*0.12;
				costy = (parseFloat(beg)-parseFloat(no_sales))*parseFloat(unit_cost);
				ending = parseFloat(beg)-parseFloat(no_sales);
				
				total_beg += parseFloat(beg);
				total_unit_cost += parseFloat(unit_cost);
				total_net += parseFloat(net_vat);
				total_cost += parseFloat(costsales);
				total_no_sales += parseFloat(no_sales);
				total_costy += parseFloat(costy);
				total_ending += parseFloat(ending);
			
				$("#table > tbody").append("<tr class='x' style='font-size:14px;' align='center'><td style='padding:2px 0px;'>"+res.date+"</td><td>"+res.dr_no+"</td><td style = 'text-align:left;'>"+res.description+"</td><td style = 'text-align:left;'>"+res.serial_no+"</td><td>"+beg+"</td><td>"+beg+"</td><td>"+FormatNumberBy3(parseFloat(Math.round((unit_cost)*100)/100).toFixed(2))+"</td><td>"+FormatNumberBy3(parseFloat(Math.round((net_vat)*100)/100).toFixed(2))+"</td><td>"+FormatNumberBy3(parseFloat(Math.round((costsales)*100)/100).toFixed(2))+"</td><td>"+no_sales+"</td><td>"+FormatNumberBy3(parseFloat(Math.round((costy)*100)/100).toFixed(2))+"</td><td>"+ending+"</td></tr>");
				counter++;
			});
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '12' align = 'center'> No Payment History! </th></tr>");
			}
			if (counter >= 0) {
				$("#table > tbody").append("<tr style='font-size:14px; font-weight:bold; background:#FFFFCC;' align='center'><td style='padding:2px 0px; background:#FFFFCC;'>GRAND TOTAL</td><td style='background:#FFFFCC;'></td><td style = 'text-align:left; background:#FFFFCC;'></td><td style = 'text-align:left; background:#FFFFCC;'></td><td style='background:#FFFFCC;'>"+total_beg+"</td><td style = 'background:#FFFFCC;'>"+total_beg+"</td><td style = 'background:#FFFFCC;'>"+FormatNumberBy3(parseFloat(Math.round((total_unit_cost)*100)/100).toFixed(2))+"</td><td style='background:#FFFFCC;'>"+FormatNumberBy3(parseFloat(Math.round((total_net)*100)/100).toFixed(2))+"</td><td style='background:#FFFFCC;'>"+FormatNumberBy3(parseFloat(Math.round((total_cost)*100)/100).toFixed(2))+"</td><td style='background:#FFFFCC;'>"+total_no_sales+"</td><td style='background:#FFFFCC;'>"+FormatNumberBy3(parseFloat(Math.round((total_costy)*100)/100).toFixed(2))+"</td><td style='background:#FFFFCC;'>"+total_ending+"</td></tr>");
			}
		});
		
	}
	
	</script>
</body>
</html>