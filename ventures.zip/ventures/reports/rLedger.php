<html>
<title>Ledger</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
		<div id="main" align="center">
			<div id="options-top" align="center" style="width:100%;">
				<table width="900px">
					<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2 style="margin-top:10px;">LEDGER</h2>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
							<form name="search" action="" method="POST">
							<select id = 'category' name='category'>
								<option value="name">Name</option>
								<option value="c.branch_code">Branch Code</option>
							</select>
								<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Report">
								</form>
							</td>
						</tr>
				</table>
			</div>
			
				<div  class="contents" style="width:900px; margin-top:-10px;" cellspacing="0">
					<table id="table">
					<thead>
						<tr><th width="40%"><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'customer_name')">NAME</a></th><th width="40%"><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'branch')">BRANCH</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'balance')">BALANCE</a></th><th style="width:10px;">ACTION</th></tr>
					</thead>
					<tbody id="alldata">
					
					</tbody>
					</table>
					
				</div>
				
				<div id="pagination">
					<div class="holder" style = "margin-top:30px;"></div>
					<i>Pages</i>
				</div>
				
			<div id="new_items" title="NEW CATEGORY " style="display:none;">
			<iframe id="item_dialog" width="380" height="90" style="border:none"></iframe>
			</div>
		</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	function jpages(){
		$("div.holder").jPages({
		  containerID : "alldata",
		  previous : "←",
		  next : "→",
		  perPage : 15,
		  delay :10,
		  startPage    : 1,
		  startRange   : 1,
		  midRange     : 5,
		  endRange     : 1
		});
	}
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
				
	var sortType = "ASC";
	
	function filter_list(index,cVar){
		sort = cVar;
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadAllData(sortType,sort);
	}
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		if(menu=="reports#"){
			menu="reports";
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
		"padding":"30px 31px 0px 31px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadAllData("DESC","id");
	});
	
	$("#txtsearch").live("keyup change",function(){
		$("#customer_list > tbody").empty();
		loadAllData("DESC","id");				
	})

	function loadAllData(sortType,sort){
		
		$("#table > tbody").empty();
		
		var url="function.php?request=ajax&action=loadAllData&type=3&sortType="+sortType+"&sort="+sort+"&inputsearch="+$("#txtsearch").val()+"&category="+$("#category").val();
	
		$.getJSON(url,function(data){
			var counter=0;
			$.each(data.members, function(i,res){
				 $("#table > tbody").append("<tr class = 'x' onmouseover = 'clickSearch();'><td>"+res.customer_name+"</td><td>"+res.branch+"</td><td>"+FormatNumberBy3(parseFloat(Math.round((res.balance)*100)/100).toFixed(2))+"</td><td><a href='#' alt='View' title='View' class='view' onclick=\"window.location='installment_ledger.php?menu=reports&id="+res.id+"'\"></a></td></tr>");
				 counter++;	
			});
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '4' align = 'center'> No Items on record! </th></tr>");
			}
			jpages();
		});
		
	}
	
	function clickSearch() {
	
		$("#txtsearch").blur();
	
	}
	
	</script>
	
</body>
</html>