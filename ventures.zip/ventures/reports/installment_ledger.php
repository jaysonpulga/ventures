<html>
<title>INSTALLMENT LEDGER</title>
<script src="../js/jquery-1.8.3.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="../js/jquery.alerts.js" type="text/javascript"></script>
<script type="text/javascript" src=""></script>
</html>
<style>
body{
	font-family:Calibri,Helvetica,"sans-serif";
	font-size:14px;	
}
.x:nth-child(even) td{
	background:lightgray;
}
.y:nth-child(odd) td{
	background:lightgray;
	font-weight:bold;
	text-align:center;
}
</style>

<body>
	<div id="wrapper">
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<h2 style="margin-top:10px;">INSTALLMENT LEDGER</h2>
					<table width="1200px" border=0 style="font-size:14px;">
						<tr>
							<td style="text-align:left;" colspan=2>Name:</td><td style="text-align:left;" width="60%" colspan=4 id="name"></td>
							<td style="text-align:left;" colspan=1>Account No:</td><td style="text-align:left;" width="15%" colspan=2 id="account_no">-</td>
						</tr>
						<tr>
							<td style="text-align:left;" colspan=2>Address:</td><td style="text-align:left;" width="60%" colspan=4 id="address">-</td>
							<td style="text-align:left;" colspan=1>Type of Loan:</td><td style="text-align:left;" width="15%" colspan=2 id="loan_type">-</td>
						</tr>
						<tr>
							<td style="text-align:left;" colspan=2>Amount of Loan:</td><td style="text-align:left;" width="60%" colspan=4 id="amount_loan">-</td>
							<td style="text-align:left;" colspan=1>Monthly Rebate:</td><td style="text-align:left;" width="15%" colspan=2 id="monthly_rebate">-</td>
						</tr>
						<tr>
							<td style="text-align:left;" colspan=2>Term:</td><td style="text-align:left;" width="60%" colspan=4 id="terms">-</td>
							<td style="text-align:left;" colspan=1>1st Ins. Due on:</td><td style="text-align:left;" width="15%" colspan=2 id="first_due">-</td>
						</tr>
						<tr class="y" style='font-size:11px;'>
							<td colspan=2>DATE</td><td>NO. OF INST.</td><td>DUE DATE</td><td>INSTALLMENT AMOUNT</td><td>PROMISORRY <br> NOTE VALUE</td><td>UNEARNED <br>DISCOUNT</td><td>REBATABLE <br> COLL FEE</td>
						</tr>
						<tr class="y" style='font-size:13px;' align="center">
							<td id="first_due_2" colspan=2></td><td id="no_terms"></td><td id="date_due"></td><td id="inst_amount"></td><td id="prom_value"></td><td id="unearned_dis"></td><td id="rebate"></td>
						</tr>
					</table>
					<div style="margin-bottom:10px;border:1px solid #777;width:1200px" ></div>
					<table width="1200px" border=1 id="table">
						<thead>
							<tr class="y" style='font-size:11px;'>
								<td colspan=9>PAYMENT DETAILS</td><td colspan=3>PRINCIPAL AMORTIZATION</td><td colspan=3>UNEARNED INTEREST<br>INCOME</td><td colspan=2>A/P RCF</td>
							</tr>
							<tr class="y" style='font-size:11px;text-align:center;font-weight:bold'>
								<td>DATE PAID</td><td>INST. NO</td><td>O.R. #</td><td >TOTAL AMOUNT PAID</td><td>DISCOUNT</td><td>PAST DUE CHARGES</td><td>ACCOUNT <br> BALANCE</td><td>BALANCE <br> BROUGHT <br> FORWARD</td><td>DATE DUE</td><td>AMT <br> PAYABALE</td><td>EARNED</td><td>BALANCE</td><td>INTEREST <br> PAYABALE</td><td>EARNED</td><td>BALANCE</td><td>AWARDED <br> (Forfeited)</td><td>BALANCE</td>
							</tr>
						</thead>
						<tbody id="alldata">
						</tbody>
					</table>
					
				</div>
			
								
				
			</div>
	</div>
<script src='../js/dropdowntabs.js'></script>	
<script>
var id = getUrlVars()["id"];
var terms=0;
var number=1;
var int_income=0;
var interest_income=0;
var first_principal_amt=0;
$(document).ready(function(){
	
	var menu = getUrlVars()["menu"];
	
	if(menu=="reports#"){
		menu="reports";
	}
	
	$("."+menu).attr("class",menu+"-active");
	
	$("."+menu+"-active a").css({
	"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
	"padding":"30px 31px 0px 31px",
	"border-bottom":"4px solid #c95447"
	});
	
	loadLoanInfo(id);
});

function loadLoanInfo(id){
	
	var url="function.php?request=ajax&action=loadLoanInfo&id="+id;

	$.getJSON(url,function(data){
		$.each(data.members, function(i,res){
			$("#name").html(res.customer);
			$("#address").html(res.brgy+" "+res.street+" "+res.city_name+","+res.province_name);
			var amount=parseFloat(res.amount_loan).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
			$("#amount_loan").html(amount);
			$("#terms").html(res.terms+" months");
			$("#account_no").html(res.account_no);
			$("#loan_type").html(res.loan_type);
			$("#first_due").html(res.installment_due);
			$("#first_due_2").html(res.date_released);
			$("#rebate").html(res.rebate);
			due = res.installment_due.substr(5,2);
			$("#date_due").html(due);
			$("#no_terms").html(res.terms);
			$("#inst_amount").html(parseFloat(res.installment_amount).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'));
			$("#prom_value").html((parseFloat(res.installment_amount) * parseInt(res.terms)).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'));
			$("#unearned_dis").html(parseFloat(res.interest_income).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'));
			interest_income=parseFloat(res.interest_income);
			int_income= parseFloat(res.int_income_1);
			var total_loan=parseFloat(res.amount_loan).toFixed(2);
			first_principal_amt=parseFloat(res.principal_amt_1);
			loadLoanDetails("DESC","b.date",res.account_no,res.customer_name,res.terms,res.installment_due,res.rebate,amount,int_income,interest_income,total_loan,first_principal_amt);
		
		});
		
	});
	
	
	
}
function loadLoanDetails(sortType,sort,acc_no,cust_id,terms,due,rebate,amount,int_income,interest_income,total_loan,first_principal_amt){
	
		
		$("#table > tbody").empty();
		
		var url="function.php?request=ajax&action=loadLoanDetails&customer_id="+cust_id+"&account_no="+acc_no+"&terms="+terms+"&due="+due+"&sortType="+sortType+"&sort="+sort;
		
		var balance=0;
		var amount_paid=0;
		var principal=0;
		var m_interest=0;
		var int_income_value=0;
		var interest_balance=0;
		
		var int_income_value=0;
		var interest_balance=0;
	
		$.getJSON(url,function(data){
			var counter=0;
			var due_count=0;
			var j=0;
			var total_balance=new Array();
			var total_int_balance=new Array();
			var total_principal_balance=new Array();
			var principal_earned=0
			var interest_earned=0;
			var principal_bal=0;
			var interest_bal=0;
			var INT_earned=0;
			var principal_due=0;
			var P_earned=0;
			var pbal;
			var ibal;
			$.each(data.members, function(i,res){
				
				balance=res.balance;
				var items=total_balance.length;
				
				
				
				
				
				amount_loan=res.amount_loan;
				amount_paid = res.amount_paid;
				amt_paid = res.amount_paid;

				var principal_dues=parseFloat(amount_loan/terms).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
				var date=new Date(due);
				var dd=date.getMonth();
				date.setMonth(dd+due_count);
				
			
				var penalty = res.penalty;
				var discount = res.discount;
				//Principal
				principal_amt=parseInt(total_loan)/parseInt(terms);
				
				principal=parseFloat(principal_amt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
				
				
	
				
				interest_amt=amount_paid-parseInt(principal_amt);
				
				
				
			
				
				//INCOME & PRINCIPAL
				
				if(j > 0){
					first_principal_value=(total_loan-first_principal_amt)/(terms-1);
					int_income_value=(interest_income-int_income)/(terms-1);
					total_int_balance[j]=int_income_value;
				}
				else{
					first_principal_value=first_principal_amt;
					int_income_value=int_income;
						
				}
				
				//EARNED 
				if( amount_paid >= int_income_value){
					interest_earned=int_income_value;
					principal_earned=amount_paid-interest_earned;
				}
				
				//alert(principal_due);
				//BALANCE
				if( items > 0){
					balance=total_balance[j-1]-res.amount_paid;
					
					
				}
				else{
				
					balance=res.balance;
				}
				
				
				
				if(amount_paid > 0 ){
					if(j==0){
						interest_bal=interest_income-interest_earned;
						principal_bal=total_loan-principal_earned;	
						
					}
					else{
						interest_bal=total_int_balance[j-1]-interest_earned;
						principal_bal=total_principal_balance[j-1]-principal_earned;
					}
					
					balance=interest_bal+principal_bal;
					total_int_balance[j]=interest_bal;
					total_principal_balance[j]=principal_bal;
					
					bal=parseFloat(balance).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
					ibal=parseFloat(interest_bal).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
					pbal=parseFloat(principal_bal).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
					amt_paid=parseFloat(amt_paid).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
					m_interest=parseFloat(interest_amt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
					penalty=parseFloat(penalty).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
					discount=parseFloat(discount).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
					INT_earned=parseFloat(interest_earned).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
					P_earned=parseFloat(principal_earned).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
					//balance=balance;
					
				}
				else{
					bal="-";
					INT_earned="-";
					ibal="-";
					P_earned="-";
					pbal="-";
				}
					
				var date = new Date(date);
				var iso = date.toISOString().match(/(\d{4}\-\d{2}\-\d{2})/)
				
				$("#table > tbody").append("<tr class='x' style='font-size:14px;' align='center'><td>"+res.date_paid+"</td><td>"+number+"</td><td>"+res.or_no+"</td><td>"+amt_paid+"</td><td>"+discount+"</td><td>"+penalty+"</td><td>"+bal+"</td><td></td><td>"+iso[1]+"</td><td>"+parseFloat(first_principal_value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+"</td><td>"+P_earned+"</td><td>"+pbal+"</td><td>"+parseFloat(int_income_value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+"</td><td>"+INT_earned+"</td><td>"+ibal+"</td><td></td><td></td></tr>");
				counter++;
				number++;
				due_count++;
				
				j++;
			});
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Payment History! </th></tr>");
			}
			
		});
	
		
}




</script>
</body>
</html>