<?php
	include('../database.php'); 
	$db = new Database();  
	$db->connect();
	
	$category = $_REQUEST["category"];
	$loan_type = $_REQUEST["loan_type"];
	$month = $_REQUEST["month"];
	$year = $_REQUEST["year"];
	$quad = $_REQUEST["quad"];
	
	if($month == "01") {
		$month_name = "JANUARY";
	}
	if($month == "02") {
		$month_name = "FEBRUARY";
	}
	if($month == "03") {
		$month_name = "MARCH";
	}
	if($month == "04") {
		$month_name = "APRIL";
	}
	if($month == "05") {
		$month_name = "MAY";
	}
	if($month == "06") {
		$month_name = "JUNE";
	}
	if($month == "07") {
		$month_name = "JULY";
	}
	if($month == "08") {
		$month_name = "AUGUST";
	}
	if($month == "09") {
		$month_name = "SEPTEMBER";
	}
	if($month == "10") {
		$month_name = "OCTOBER";
	}
	if($month == "11") {
		$month_name = "NOVEMBER";
	}
	if($month == "12") {
		$month_name = "DECEMBER";
	}
	
	
	if($quad == "Quad LC") {
		$Quad = "QUAD LC";
	}else if($quad == "Laguna LC"){
		$Quad = "LAGUNA LC";
	}
	
	error_reporting(0);

?>

<html>
<title>SUMMARY REPORT</title>
<script src="../js/jquery-1.8.3.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="../js/jquery.alerts.js" type="text/javascript"></script>
<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
<script type="text/javascript" src=""></script>
</html>
<style>
body{
	font-family:Calibri,Helvetica,"sans-serif";
	font-size:14px;	
}

#table table{
	border-collapse:collapse;
	box-shadow: 1px 2px 3px gray;
	width:inherit;
}


#table th{
	background:#3d3d45;
	color:#FFF;
	font-size:12px;
	padding:2px 5px;
	letter-spacing:1px;
	border: 1px solid #f3f2f2;
}
#table td{
	background:#f3f2f2;
	padding:0px;
	font-size:15px;
	text-align:center;	
}
</style>

<body>
	<div id="wrapper">
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<h2 style="margin-top:40px;">
					<?php
						if($_REQUEST['lending'] == "QuadLC") {
							echo "Quad Lending Corporation";
						}
						if($_REQUEST['lending'] == "LagunaLC") {
							echo "Laguna Lending Corporation";
						}
					?>
					</h2>
					<h3 style="margin-top:-15px;">MONTHLY LOAN COLLECTION</h3>
					<h4 style="margin-top:-15px;">As of <?php echo $month_name; ?>&nbsp;<?php echo $year; ?></h4>
					<table  width="800px" border=1 cellspacing=0 cellpadding=0 id="table">
						<thead>
							<tr class="y" style='font-size:15px;'>
								<?php
									if(isset($_REQUEST['loan_type'])) {
										$id=$_REQUEST['loan_type'];
										$row = "loan_type";
										$where = "id=".$id;
										$db->select("tbl_loan",$row,$where);
										$res = $db->getResult();
										
										foreach($res as $data) {
											$loan_type=$data["loan_type"];
											echo "<th>".$loan_type."</th>";
										}
										
									}
								?>
								<th>THIS MONTH</th><th>NO. OF<br>ACCOUNTS</th><th>LAST MONTH</th><th>NO. OF<br>ACCOUNTS</th>
							</tr>
						</thead>
						<tbody id="table">
						</tbody>
					</table>
					
				</div>
			
								
				
			</div>
	</div>
<script src='../js/dropdowntabs.js'></script>	
<script>
var lending = getUrlVars()["lending"];
var loan_type = getUrlVars()["loan_type"];
var month = getUrlVars()["month"];
var year = getUrlVars()["year"];

$(document).ready(function(){
	
	var menu = getUrlVars()["menu"];
	
	if(menu=="reports#"){
		menu="reports";
	}
	
	$("."+menu).attr("class",menu+"-active");
	
	$("."+menu+"-active a").css({
	"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
	"padding":"30px 31px 0px 31px",
	"border-bottom":"4px solid #c95447"
	});
	
	loadSummaryInfo(lending,loan_type,month,year);
	
});

function loadSummaryInfo(lending,loan_type,month,year){
	$("#table > tbody").empty();
	
	var url="function.php?request=ajax&action=loadLoanSummary&lending="+lending+"&loan_type="+loan_type+"&month="+month+"&year="+year;
	var counter=0;
	var total_this_month=0;
	var total_this_acct=0;
	var total_last_month=0;
	var total_last_acct=0;

	$.getJSON(url,function(data){
		$.each(data.members, function(i,res){
			var this_amount = FormatNumberBy3(parseFloat(Math.round((res.this_amount)*100)/100).toFixed(2))
			var last_amount = FormatNumberBy3(parseFloat(Math.round((res.last_amount)*100)/100).toFixed(2))
			
			if(this_amount == "NaN") {
				this_amount = "-";
			}
			if(last_amount == "NaN") {
				last_amount = "-";
			}
			
			$("#table > tbody").append("<tr class='x' align='center'><td>"+res.branch_name+"</td><td style = 'font-weight:bold; width:150px;'>"+this_amount+"</td><td style='font-weight:bold; width:80px;'>"+res.no_acct+"</td><td style='font-weight:bold; width:150px;'>"+last_amount+"</td><td style='font-weight:bold; width:80px;'>"+res.no_acct_last+"</td></tr>");
			counter++;
		});
		if (counter <= 0){
			$("#table > tbody").append("<tr id = 'noItems'><th colspan = '5' align = 'center'> No Items on record! </th></tr>");
		}
	});
	
}


</script>
</body>
</html>