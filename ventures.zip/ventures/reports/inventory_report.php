<?php error_reporting(0); ?>
<html>
<title>INVENTORY REPORT-MOTORCYCLE</title>
<script src="../js/jquery-1.8.3.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="../js/jquery.alerts.js" type="text/javascript"></script>
<script type="text/javascript" src=""></script>
<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
</html>
<style>
body{
	font-family:Calibri,Helvetica,"sans-serif";
	font-size:14px;	
}

.contents table{
	border-collapse:collapse;
	box-shadow: 1px 2px 3px gray;
	width:inherit;
}
.contents th, td{
	border: 1px solid #3d3d45;
}
.contents th{
	background:#3d3d45;
	color:#FFF;
	font-size:12px;
	padding:2px 5px;
	letter-spacing:1px;
	border: 1px solid #f3f2f2;
}
.contents td{
	background:#f3f2f2;
	padding:0px;
	font-size:12px;
	text-align:center;	
}
</style>

<body>
	<div id="wrapper" style="width:100%">
			<div id="main" align="center" style="width:100%">
				<div id="options-top" align="center" style="width:100%;">
					<h2 style="margin-top:10px;">VENTURE MOTORCYCLE SALES CORPORATION</h2>
					<h3 style="margin-top:-15px;">CENTRAL OFFICE</h3>
					<h3 style="margin-top:-15px;">INVENTORY OF MOTORCYCLE</h3>
					
					
					<h4 style="margin-top:-15px;">From <?php echo date('M d, Y',strtotime($_REQUEST["txtfrom1"])); ?> To <?php echo date('M d, Y',strtotime($_REQUEST["txtto1"])); ?></h4>
					
						<table border=0 cellspacing=0 cellpadding=0 width="100%" class="contents" ><tr  align='center' class="y" style='font-size:12px;'><th style='padding:10px 0px;'>MODEL</th><th colspan=3>BEGINNING INVENTORY</th><th colspan=4>PURCHASES</th><th colspan=5>INTERBRANCH</th><th colspan=3>COST OF SALES</th><th colspan=3>ENDING INVENTORY</th></tr>
						
						<tr class="x" style='font-size:12px;background:lightgray;font-weight:bold;text-align:center;padding:0px;border-top:1px solid #000'><th style="padding:0px;"></th><th style="padding:0px;">NO. OF <br> UNITS</th><th>SERIAL NO</th><th>UNIT COST</th><th>DATE</th><th>NO OF <br> UNITS</th><th>SERIAL NO.</th><th>UNIT COST.</th><th> DATE</th><th>MOVE TO</th><th>NO. OF <br> UNITS</th><th>SERIAL NO</th><th>UNIT COST</th><th> DATE</th><th>NO. OF <br> UNITS</th><th>COST</th><th>NO. OF <br>UNITS</th><th>SERIAL NO.</th><th>UNIT COST</th></tr>
				
					
				<?php
				
				include('../database.php');
				$db = new Database();  
				$db->connect();
	
				$branch = $_REQUEST["branch"];
				$month = $_REQUEST["month"];
				$year = $_REQUEST["year"];
				
				echo $from = $_REQUEST["txtfrom1"];
				echo $to = $_REQUEST["txtto1"];
				
				
				$sales=array();
				$purchases=array();
				$transfers=array();
				$ending=array();
				$start=array();
				$begin_inventory=array();
				$items_sold=array();
				$sales_Arr=array();	
				$purchases_Arr=array();
				$transferTo_Arr=array();
				$transferFrom_Arr=array();
				$rows = "*";
				$db->select("tbl_branch",$rows);
				$res = $db->getResult();
				
				
				
				foreach($res as $info){
					$branch_code=$info["branch_code"];
					$branch_id=$info["id"];
					$branch_name=$info["branch_name"];
					
					$i=0;					
					$rows = "a.*,b.*";
					$where="b.branch='".$branch_id."' and DATE(a.date_issued) < '".$from."' and b.invoice_no=a.invoice_no and b.category=1";
					$db->select("sales_invoice a,sale_invoice_details b",$rows,$where);
					$result_sales = $db->getResult();
						
						foreach($result_sales as $info_sales){
							array_push($items_sold,$info_sales["stock_id"]);
						}
						
						
						
				}
				
				
				$ids = "(".implode(',',$items_sold).")";
				
				
				//** BEGINNING **//
				foreach($res as $info){
					$branch_code=$info["branch_code"];
					$branch_id=$info["id"];
					$branch_name=$info["branch_name"];
					
					$i=0;					
					$rows = "a.*,b.*,c.model,c.unit_cost,b.id as stock_id";
					if(count($items_sold) > 0){
						$where="a.branch='".$branch_id."' and DATE(a.date) < '".$from."'  and a.dr_no=b.dr_no and a.type=1 and b.model=c.motor_id and b.id and b.id NOT IN $ids" ;
					}
					else{
						$where="a.branch='".$branch_id."' and DATE(a.date) < '".$from."'  and a.dr_no=b.dr_no and a.type=1 and b.model=c.motor_id and b.id and b.id";
					}
					$order="c.model asc";
					$db->select("stocks a,stocks_motors b,tbl_motorcycle c",$rows,$where,$order);
					$result_beginning = $db->getResult();
						
						
						foreach($result_beginning as $info_beginning){
							$item_beginning=array('stock_id'=>$info_beginning['stock_id'],$branch_code,'branch_code'=>$branch_code,'no_of_units'=>1,'serial_no'=>$info_beginning['engine_no'],'item'=>$info_beginning['model'],'cost'=>$info_beginning['unit_cost']);
							array_push($begin_inventory,$item_beginning);
							array_push($ending,$info_beginning['id']);
						}
						
						
						
				}
				
				//print_r($begin_inventory);
				//die();
				
				//** SALES **//
				foreach($res as $info){
					$branch_code=$info["branch_code"];
					$branch_id=$info["id"];
					$branch_name=$info["branch_name"];
					
					$i=0;					
					$rows = "a.*,b.*,d.model,d.unit_cost";
					$where="b.branch='".$branch_id."' and DATE(a.date_issued) > '".$from."' and DATE(a.date_issued) <= '".$to."' and b.invoice_no=a.invoice_no and b.category=1 and b.stock_id=c.id and c.model=d.motor_id and b.stock_id";
				
					$db->select("sales_invoice a,sale_invoice_details b,stocks_motors c,tbl_motorcycle d",$rows,$where);
					$result_sales = $db->getResult();
						
						foreach($result_sales as $info_sales){
							$item_sold=array('stock_id'=>$info_sales['stock_id'],'branch_code'=>$branch_code,'no_of_units'=>1,'serial_no'=>$info_sales['serial_no'],'item'=>$info_sales['model'],'cost_sales'=>$info_sales['amount'],'cost'=>$info_sales['unit_cost']);
							array_push($ending,$info_sales['stock_id']);
							array_push($sales_Arr,$info_sales['stock_id']);
							array_push($sales,$item_sold);
						}
				}
				
				foreach($res as $info){
					$branch_code=$info["branch_code"];
					$branch_id=$info["id"];
					$branch_name=$info["branch_name"];
					
					$i=0;					
					$rows = "a.*,b.*,d.model,d.unit_cost";
					$where="a.branch_code='".$branch_code."' and DATE(a.date) > '".$from."' and DATE(a.date) <= '".$to."' and b.or_no=a.or_no and b.category=1 and a.type='CASH' and b.stock_id=c.id and c.model=d.motor_id";
				
					$db->select("collections a,collection_cash b,stocks_motors c,tbl_motorcycle d",$rows,$where);
					$result_cash = $db->getResult();
						
						foreach($result_cash as $info_cash){
							$item_sold=array('stock_id'=>$info_cash['stock_id'],'branch_code'=>$branch_code,'no_of_units'=>1,'serial_no'=>$info_cash['serial_no'],'item'=>$info_cash['model'],'cost_sales'=>$info_cash['amount'],'cost'=>$info_cash['unit_cost']);
							array_push($ending,$info_cash['stock_id']);
							array_push($sales_Arr,$info_cash['stock_id']);
							array_push($sales,$item_sold);
						}
				}
				
				
				
				//** PURCHASES **//
				foreach($res as $info){
					$branch_code=$info["branch_code"];
					$branch_id=$info["id"];
					$branch_name=$info["branch_name"];
					
					$i=0;					
					$rows = "a.*,b.*,c.model,c.unit_cost,b.id as stock_id";
					$where="a.branch='".$branch_id."' and DATE(a.date) > '".$from."' and DATE(a.date) <= '".$to."'  and a.dr_no=b.dr_no and a.type=1 and b.model=c.motor_id";
					$db->select("stocks a,stocks_motors b,tbl_motorcycle c",$rows,$where);
					$result_purchases = $db->getResult();
						
						
						foreach($result_purchases as $info_purchase){
							$item_purchases=array('stock_id'=>$info_purchase['stock_id'],'branch_code'=>$branch_code,'no_of_units'=>1,'serial_no'=>$info_purchase['engine_no'],'item'=>$info_purchase['model'],'cost'=>$info_purchase['unit_cost']);
							array_push($purchases,$item_purchases);
							array_push($purchases_Arr,$info_purchase['stock_id']);
							array_push($ending,$info_purchase['stock_id']);
						}
						
						
						
				}
				
				//** TRANSFER **//
				foreach($res as $info){
					$branch_code=$info["branch_code"];
					$branch_id=$info["id"];
					$branch_name=$info["branch_name"];
					
					$rows = "a.*,b.*,c.engine_no as serial_no,d.model,d.unit_cost,c.id as stock_id";
					$where="a.branch_code='".$branch_code."' and DATE(a.date) > '".$from."' and DATE(a.date) <= '".$to."' and a.dr_no=b.dr_no and b.category=1 and b.stock_id=c.id and c.model=d.motor_id";
					$db->select("transfer_item a,transfer_details b,stocks_motors c,tbl_motorcycle d",$rows,$where);
					$result_transfers = $db->getResult();
					
					
						foreach($result_transfers as $info_transfers){
							$item_transfers=array('stock_id'=>$info_transfers['stock_id'],'branch_code'=>$branch_code,'no_of_units'=>1,'serial_no'=>$info_transfers['serial_no'],'item'=>$info_transfers['model'],'cost'=>$info_transfers['unit_cost'],'in'=> 0 ,'out' => 1);
							array_push($transfers,$item_transfers);
							array_push($ending,$info_transfers['stock_id']);
							array_push($transferFrom_Arr,$info_transfers['stock_id']);
							
						}
						
					
					$rows2 = "a.*,b.*,c.engine_no as serial_no,d.model,d.unit_cost,c.id as stock_id";
					$where2="a.move_to='".$branch_code."' and DATE(a.date) > '".$from."' and DATE(a.date) <= '".$to."' and a.dr_no=b.dr_no and b.category=1 and b.stock_id=c.id and c.model=d.motor_id";
					$db->select("transfer_item a,transfer_details b,stocks_motors c,tbl_motorcycle d",$rows2,$where2);
					$result_transfers2 = $db->getResult();
					
						foreach($result_transfers2 as $info_transfers){
							$item_transfers2=array('stock_id'=>$info_transfers['stock_id'],'branch_code'=>$branch_code,'no_of_units'=>1,'serial_no'=>$info_transfers['serial_no'],'item'=>$info_transfers['model'],'cost'=>$info_transfers['unit_cost'],'in'=> 1 ,'out' => 0);
							array_push($transfers,$item_transfers2);
							array_push($ending,$info_transfers['stock_id']);
							array_push($transferTo_Arr,$info_transfers['stock_id']);
							
						}
										
						
				}
				
				
				$unique=array_unique($ending);
				
				$merge_Array=array_merge($purchases_Arr,$transferTo_Arr,$transferFrom_Arr);	
				
				$ending_Array=array_merge($transferFrom_Arr,$sales_Arr);	
				
				
				$gtotal_begin=0;$gtotal_purchase=0;$gtotal_transfer=0;$gtotal_sales=0;$gtotal_end=0;
				$gtotal_begin_cost=0;$gtotal_purchase_cost=0;$gtotal_transfer_cost=0;$gtotal_sales_cost=0;$gtotal_end_cost=0;
					
				foreach($res as $info_branch){
					$total_begin=0;$total_purchase=0;$total_transfer=0;$total_sales=0;$total_end=0;
					$total_begin_cost=0;$total_purchase_cost=0;$total_transfer_cost=0;$total_sales_cost=0;$total_end_cost=0;
					$branch_code=$info_branch["branch_code"];
					$branch_id=$info_branch["id"];
					echo "<tr style='font-size:14px;'>";
					echo "<td colspan=19 style='background:#ff6767;'><div align='left' style='font-size:15px;color:#3d3d45'><b>".$branch_code."</div></b></td>";
					echo "</tr>";		
					foreach($unique as $info){
						
						$rows = "a.*,b.model,b.unit_cost";
						$where="a.id='".$info."' and a.model=b.motor_id and c.branch='".$branch_id."' and a.dr_no=c.dr_no and type=1";
						$order="b.model asc";
						$db->select("stocks_motors a,tbl_motorcycle b,stocks c",$rows,$where,$order);
						$result_unique = $db->getResult();
						
						//echo $branch_code;
						//print_r($result_unique);
						//echo "<br>";
						foreach($result_unique as $info_unique){
							echo "<tr class='x' style='font-size:12px;'>";
							echo "<td>".$info_unique["model"]."</td>";
							$stock_id=$info_unique["id"];
							if (!in_array($stock_id,$merge_Array)){
								echo "<td align='center'>1</td><td>".$info_unique["engine_no"]."</td><td><div align='right'>".number_format($info_unique["unit_cost"],2)."</div></td>";
								
								$total_begin++;
								$total_begin_cost=$total_begin_cost+$info_unique["unit_cost"];
							}
							else{
								echo "<td align='center'></td><td align='center'></td><td align='center'></td>";
							}
							
							//Purchases
							if (in_array($stock_id,$purchases_Arr)){
								$db->selectSingle("stocks a,stocks_motors b","a.date","b.id='".$stock_id."' and a.dr_no=b.dr_no and a.branch='".$branch_id."'");
								$date=$db->getSingleResult();
								
								$total_purchase++;
								$total_purchase_cost=$total_purchase_cost+$info_unique["unit_cost"];
								
								echo "<td>$date</td>";
								echo "<td>1</td><td>".$info_unique["engine_no"]."</td><td><div align='right'>".number_format($info_unique["unit_cost"],2)."</div></td>";
								
							}
							else{
								echo "<td align='center'></td><td align='center'></td ><td align='center'></td><td align='center'></td>";
							}
							
							//Transfer To
							if (in_array($stock_id,$transferTo_Arr)){
								
								$db->select("transfer_item a,transfer_details b","a.*","b.stock_id='".$stock_id."' and a.dr_no=b.dr_no and b.category=1 and a.branch_code='".$branch_code."'");
								$date_transfer=$db->getResult();
								
								if(count($date_transfer) > 0){
									foreach($date_transfer as $info_transfer){
										
										$total_transfer++;
										$total_transfer_cost=$total_transfer_cost+$info_unique["unit_cost"];
										
										echo "<td>".$info_transfer["date"]."</td>";
										echo "<td align='center'>".$info_transfer["move_to"]."</td><td align='center'>1</td><td>".$info_unique["engine_no"]."</td><td><div align='right'>".number_format($info_unique["unit_cost"],2)."</div></td>";
									}
								}
								else{
									echo "<td align='center'></td><td align='center'></td><td align='center'></td><td align='center'></td><td align='center'></td>";
								}
							
							}
							else{
								echo "<td align='center'></td><td align='center'></td><td align='center'></td><td align='center'></td><td align='center'></td>";
							}
							
							
							
							
							/*
							else if(in_array($stock_id,$transferFrom_Arr)){
								$db->selectSingle("transfer_item a,transfer_details b","a.date","b.stock_id='".$stock_id."' and a.dr_no=b.dr_no and b.category=1 and a.branch_code='".$branch_code."'");
								$date=$db->getSingleResult();
								echo $date;
								if($date==""){
									echo "<td>-</td><td>-</td><td></td><td></td><td></td>";
								}
								else{
									echo "<td>$date</td>";
									echo "<td></td>1<td></td><td>".$info_unique["engine_no"]."</td><td>".$info_unique["unit_cost"]."</td>";
								}
							}
							
								*/						
							//Sales
							if (in_array($stock_id,$sales_Arr)){
								$db->selectSingle("sales_invoice a,sale_invoice_details b","a.date_issued","b.stock_id='".$stock_id."' and a.invoice_no=b.invoice_no and category=1");
								$date=$db->getSingleResult();
								
								$total_sales++;
								$total_sales_cost=$total_sales_cost+$info_unique["unit_cost"];
								
								if($date==""){
									$db->selectSingle("collections a,collection_cash b","a.date","b.stock_id='".$stock_id."' and a.or_no=b.or_no and b.category=1 and a.type='CASH' ");
									$date=$db->getSingleResult();
									echo "<td>$date</td>";
									echo "<td align='center' >1</td><td><div align='right'>".number_format($info_unique["unit_cost"],2)."</div></td>";	
								}
								else{	
									echo "<td>$date</td>";
									echo "<td align='center'>1</td><td><div align='right'>".number_format($info_unique["unit_cost"],2)."</div></td>";
								}
							}
							else{
								echo "<td align='center'></td><td align='center'></td><td align='center'></td>";
							}
							
							//ENDING
							if (!in_array($stock_id,$ending_Array)){
								$total_end++;
								$total_end_cost=$total_end_cost+$info_unique["unit_cost"];
								
								echo "<td align='center'>1</td>";
								echo "<td>".$info_unique["engine_no"]."</td><td><div align='right'>".number_format($info_unique["unit_cost"],2)."</div></td>";
							}
							else{
								echo "<td align='center'></td><td align='center'></td><td align='center'></td>";
							}
							
							echo "</tr>";
							
							
						
						}
						
						
					
					}
					
					$gtotal_begin=$gtotal_begin+$total_begin;
					$gtotal_begin_cost=$gtotal_begin_cost+$total_begin_cost;
					$gtotal_purchase=$gtotal_purchase+$total_purchase;
					$gtotal_purchase_cost=$gtotal_purchase_cost+$total_purchase_cost;
					$gtotal_transfer=$gtotal_transfer+$total_transfer;
					$gtotal_transfer_cost=$gtotal_transfer_cost+$total_transfer_cost;
					$gtotal_sales=$gtotal_sales+$total_sales;
					$gtotal_sales_cost=$gtotal_sales_cost+$total_sales_cost;
					$gtotal_end=$gtotal_end+$total_end;
					$gtotal_end_cost=$gtotal_end_cost+$total_begin_end;
					
					$total_begin=number_format($total_begin,2);
					$total_begin_cost=number_format($total_begin_cost,2);
					$total_purchase=number_format($total_purchase,2);
					$total_purchase_cost=number_format($total_purchase_cost,2);
					$total_transfer=number_format($total_transfer,2);
					$total_transfer_cost=number_format($total_transfer_cost,2);
					$total_sales=number_format($total_sales,2);
					$total_sales_cost=number_format($total_sales_cost,2);
					$total_end=number_format($total_end,2);
					$total_end_cost=number_format($total_end_cost,2);
					
					echo "<tr style='font-size:16px;font-weight:bold'>";
					echo "<td style=''><div align='center' style='font-size:14px;'><b>SUBTOTAL:</b></div></td><td>".$total_begin."</td><td></td><td><div align='right'>".$total_begin_cost."</div></td><td></td><td>".$total_purchase."</td><td></td><td><div align='right'>".$total_purchase_cost."</div></td><td></td><td></td><td>".$total_transfer."</td><td></td><td><div align='right'>".$total_transfer_cost."</div></td><td></td><td>".$total_sales."</td><td><div align='right'>".$total_sales_cost."</div></td><td>".$total_end."</td><td></td><td><div align='right'>".$total_end_cost."</div></td>";
					echo "</tr>";
				}
				
					$gtotal_begin=number_format($gtotal_begin,2);
					$gtotal_begin_cost=number_format($gtotal_begin_cost,2);
					$gtotal_purchase=number_format($gtotal_purchase,2);
					$gtotal_purchase_cost=number_format($gtotal_purchase_cost,2);
					$gtotal_transfer=number_format($gtotal_transfer,2);
					$gtotal_transfer_cost=number_format($gtotal_transfer_cost,2);
					$gtotal_sales=number_format($gtotal_sales,2);
					$gtotal_sales_cost=number_format($gtotal_sales_cost,2);
					$gtotal_end=number_format($gtotal_end,2);
					$gtotal_end_cost=number_format($gtotal_end_cost,2);
					
					echo "<tr style='font-size:16px;font-weight:bold;background:#FFFFCC'>";
					echo "<td style=''><div align='center' style='font-size:14px;background:#FFFFCC'><b>GRAND TOTAL:</b></div></td><td style='font-size:14px;background:#FFFFCC'>".$gtotal_begin."</td><td style='background:#FFFFCC'></td><td style='background:#FFFFCC'><div align='right' style='font-size:14px;'>".$gtotal_begin_cost."</div></td><td style='background:#FFFFCC'></td><td style='font-size:14px;background:#FFFFCC'>".$gtotal_purchase."</td><td style='background:#FFFFCC'></td><td style='background:#FFFFCC'><div align='right' style='font-size:14px;'>".$gtotal_purchase_cost."</div></td><td style='background:#FFFFCC'></td><td style='background:#FFFFCC'></td><td style='font-size:14px;background:#FFFFCC'>".$gtotal_transfer."</td><td style='background:#FFFFCC'></td><td style='background:#FFFFCC'><div align='right' style='font-size:14px;'>".$gtotal_transfer_cost."</div></td><td style='background:#FFFFCC'></td><td style='font-size:14px;background:#FFFFCC'>".$gtotal_sales."</td><td style='background:#FFFFCC'><div align='right' style='font-size:14px;'>".$gtotal_sales_cost."</div></td><td style='font-size:14px;background:#FFFFCC'>".$gtotal_end."</td><td style='background:#FFFFCC'></td><td style='background:#FFFFCC'><div align='right' style='font-size:14px;'>".$gtotal_end_cost."</div></td>";
					echo "</tr>";
				
				?>
				</table>
				</div>
			</div>
	</div>
	<script src='../js/dropdowntabs.js'></script>	
	<script>
	var branch = getUrlVars()["branch"];
	var month= getUrlVars()["month"];
	var year = getUrlVars()["year"];
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="reports#"){
			menu="reports";
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
		"padding":"30px 31px 0px 31px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadInventoryMotors();
		
	});

	
	
	
	</script>
</body>
</html>