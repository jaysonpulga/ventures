<html>
<title>STOCK CARD</title>
<script src="../js/jquery-1.8.3.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="../js/jquery.alerts.js" type="text/javascript"></script>
<script type="text/javascript" src=""></script>
<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
</html>
<style>
body{
	font-family:Calibri,Helvetica,"sans-serif";
	font-size:14px;	
}
.x:nth-child(even) td{
	background:lightgray;
}
.y:nth-child(odd) td{
	background:lightgray;
	font-weight:bold;
	text-align:center;
}
</style>

<body>
	<div id="wrapper">
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<h2 style="margin-top:10px;">STOCK CARD</h2>
					<table width="950px" border=0 style="font-size:14px;">
						<tr>
							<td style="text-align:left;" colspan=2>Branch:</td><td style="text-align:left;" width="90%" colspan=2 id="branch"></td>
						</tr>
						<tr>
							<td style="text-align:left;" colspan=2>Unit/Model:</td><td style="text-align:left;" width="90%" colspan=2 id="model"></td>
						</tr>
					</table>
					<div style="margin-bottom:10px;border:1px solid #777;width:945px" ></div>
					<table width="950px" border=1 id="table">
						<thead>
							<tr class="y" style='font-size:11px;'>
								<td>DATE<br>PURCHASED</td><td>D.R. NO.</td><td>MOTOR NO.</td><td>SERIAL NO.</td><td>COLOR</td><td>DATE SOLD</td><td>S.I. NO.</td><td>NAME OF CUSTOMER</td><td>SELLING PRICE</td><td>COST</td><td>NO. OF DAYS<br>IN INVENTORY</td>
							</tr>
						</thead>
						<tbody id="alldata">
						</tbody>
					</table>
					
				</div>
				
			</div>
	</div>
	<script src='../js/dropdowntabs.js'></script>	
	<script>
	var branch = getUrlVars()["branch"];
	var brand = getUrlVars()["brand"];
	var model = getUrlVars()["model"];
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="reports#"){
			menu="reports";
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
		"padding":"30px 31px 0px 31px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadStockCard(branch,brand,model);
		
	});

	
	function loadStockCard(branch,brand,model) {
			
		var url="functions.php?request=ajax&action=loadStockCard&branch="+branch+"&brand="+brand+"&model="+model;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				$("#branch").html(res.branch_name);
				$("#model").html(res.brand+" "+res.model);
				
				loadStockCardTable(branch,brand,model);
				
			});
		});
		
	}
	
	function loadStockCardTable(branch,brand,model) {
		
		var url="functions.php?request=ajax&action=loadStockCardItems&branch="+branch+"&brand="+brand+"&model="+model;
		$("#table > tbody").empty();
	
		$.getJSON(url,function(data){
			var counter=0;
			$.each(data.members, function(i,res){
				 $("#table > tbody").append("<tr class='x' style='font-size:14px;' align='center'><td>"+res.date_received+"</td><td>"+res.dr_no+"</td><td>"+res.motor_no+"</td><td>"+res.serial_no+"</td><td>"+res.color+"</td><td>"+res.date_released+"</td><td>"+res.invoice_no+"</td><td>"+res.customer_name+"</td><td>"+FormatNumberBy3(parseFloat(Math.round((res.selling_price)*100)/100).toFixed(2))+"</td><td>"+FormatNumberBy3(parseFloat(Math.round((res.cost)*100)/100).toFixed(2))+"</td><td>"+res.no_days+"</td></tr>");
				 counter++;
			});
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Payment History! </th></tr>");
			}
			
		});
		
	}
	
	</script>
</body>
</html>