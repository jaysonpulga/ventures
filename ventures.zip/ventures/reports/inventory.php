<html>
<title>Inventory</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
		<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:400px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>INVENTORY MOTORCYCLE</h2><hr></label>
							</span>
						</div>
						<form name="frm" method="POST" action="inventory_report.php">
						<div>
							<span>
								<label style = "margin-left:51px;">From:</label>
								<input type = "date" name="txtfrom1" id = "txtfrom1" style="margin-left:10px;">
							</span>
						</div>
						<div>
							<span>
								<label style = "margin-left:69px;">To:</label>
								<input type = "date" name="txtto1" id = "txtto1" style="margin-left:10px;">
							</span>
						</div>
						<div>
							<span>
								<label>Select Branch:</label>
								<select id = 'txtbranch1' class = "select_to" name='brand' style="margin-left:10px; width:250px;">
									<option value="">- Branch -</option>
								</select>
							</span>
						</div>
						<div style="margin-top:10px" align="center">
							<input type="submit" value="VIEW REPORT" id = "btnreport1" style="width:130px">
						</div>
						</form>
						<div>
							<span>
								<label><h2>INVENTORY PARTS/PROMO/CONSUMABLES</h2><hr></label>
							</span>
						</div>
						<div>
							<span>
								<label style = "margin-left:51px;">From:</label>
								<input type = "date" id = "txtfrom2" style="margin-left:10px;">
							</span>
						</div>
						<div>
							<span>
								<label style = "margin-left:69px;">To:</label>
								<input type = "date" id = "txtto2" style="margin-left:10px;">
							</span>
						</div>
						<div>
							<span>
								<label>Select Branch:</label>
								<select id = 'txtbranch2' class = "select_to" name='brand' style="margin-left:10px; width:250px;">
									<option value="">- Branch -</option>
								</select>
							</span>
						</div>
						<div style="margin-top:10px" align="center">
							<input type="button" value="VIEW REPORT" id = "btnreport2" style="width:130px">
						</div>
						
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
		"padding":"30px 31px 0px 31px",
		"border-bottom":"4px solid #c95447"
		});
		
		$('#txtfrom2')
		.prop('disabled', false)
		
		$('#txtto2')
		.prop('disabled', true)
		
		$('#txtbranch2')
		.prop('disabled', true)
		.empty()
		.append('<option value="">- Branch -</option>')
		.find('option:first')
		.attr("selected","selected");
		
		$("#txtfrom2").change(function() {
			if($(this).val() == "mm/dd/yyyy") {
				$('#txtto2').prop('disabled', true);
			}
			else {
				$('#txtto2').prop('disabled', false);
			}
		});
		
		$("#txtto2").change(function() {
			if($(this).val() == "mm/dd/yyyy") {
				$('#txtbranch2')
				.prop('disabled', true)
				.empty()
				.append('<option value="">- Branch -</option>')
				.find('option:first')
				.attr("selected","selected");
			}
			else {
				$('#txtbranch2')
				.prop('disabled', false)
				.empty()
				.append('<option value="">- Branch -</option>')
				.find('option:first')
				.attr("selected","selected");
			}
			loadBranch2();
		});
		
		$("#btnreport2").click(function() {
			
			var from = $("#txtfrom2").val();
			var to = $("#txtto2").val();
			var branch = $("#txtbranch2 :selected").val();
			
			window.location = "inventory_consumables.php?branch="+branch+"&from="+from+"&to="+to;
		});
		
	});
	
	function loadBranch2() {
		
		var url="functions.php?request=ajax&action=loadInventoryBranch";
			
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtbranch2").append("<option value="+ res.id+">" + res.branch_name + "</option>");
				
			});
		});
		
	}
	
	</script>
	
</body>
</html>