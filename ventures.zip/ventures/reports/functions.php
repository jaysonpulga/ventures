<?php
	session_start();
	include('../database.php');
	$db = new Database();  
	$db->connect();
	
	$action = $_REQUEST["action"];
	
	if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){
		
		switch($action){
		
			// INVENTORY
			
			case "loadInventoryBranch";
				
				$rows = "id,branch_name";
				$where = "";
				$db->select("tbl_branch",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadInventoryConsumables";
				
				$data = array();
				$dataArrayParts = array();
				$dataArrayConsumables = array();
				$dataArrayPromo = array();
				$data_qty = array();
				
				$branch = $_REQUEST["branch"];
				$to = $_REQUEST["to"];
				$from = $_REQUEST["from"];
				
				$rows1 = "b.dr_no,a.date,SUBSTR(a.date,1,4) as year,SUBSTR(a.date,6,2) as month,b.serial_no,b.id,SUM(b.quantity) as quantity,c.unit_cost,c.description";
				$where1 = "a.type=4 AND (a.date <= '$to') AND a.dr_no=b.dr_no AND b.item=c.con_id AND c.brand=d.id AND d.category=4 AND a.branch=e.id AND e.id='$branch' GROUP BY b.dr_no,b.item,b.serial_no";
				$order1 = "c.description ASC";
				$db->select("stocks a, stocks_consumables b, tbl_consumables c, tbl_manufacturer d, tbl_branch e",$rows1,$where1,$order1);
				$res1 = $db->getResult();
				$i=0;
				$unit_cost=0;
				
				foreach($res1 as $dataConsumables) {
					$date=$dataConsumables['date'];
					$year=$dataConsumables['year'];
					$month=$dataConsumables['month'];
					$dr=$dataConsumables['dr_no'];
					$serial_no=$dataConsumables['serial_no'];
					$item_id=$dataConsumables['id'];
					$quantity=$dataConsumables['quantity'];
					$unit_cost=$dataConsumables['unit_cost'];
					$description=$dataConsumables['description'];
					
					$row_con = "b.qty AS qty1";
					$where_con = "(c.date_issued <= '$to') AND a.id=b.stock_id AND b.stock_id=$item_id AND b.category=4 AND b.branch='$branch' GROUP BY b.stock_id,b.category";
					$db->select("stocks_consumables a, sale_invoice_details b, sales_invoice c",$row_con,$where_con);
					$qty_con = $db->getResult();
					
					$row_col_con = "SUM(b.qty) AS qty2";
					$where_col_con = "a.id=b.stock_id AND b.stock_id=$item_id AND b.category=4 AND b.or_no=c.or_no AND (c.date <= '$to') AND c.branch_code=d.branch_code AND d.id='$branch' GROUP BY b.stock_id,b.category";
					$db->select("stocks_parts a, collection_cash b, collections c, tbl_branch d",$row_col_con,$where_col_con);
					$col_con = $db->getResult();
					
					if(count($qty_con) > 0){
							foreach($qty_con as $data_cons) {
								$qty1 =  $data_cons["qty1"];
								
								if(count($col_con) > 0) {
									foreach($col_con as $data_col_con) {
										$qty2 = $data_col_con['qty2'];
										$qty = $qty1+$qty2;
									
										$new_array[$i]=array(
											'date'=> $date,
											'dr_no'=> $dr,
											'serial_no' => $serial_no,
											'quantity' => $quantity,
											'unit_cost' => $unit_cost,
											'description' => $description,
											'sales_qty' => $qty
										);
									}
								}
								else {
									$qty2 = 0;
									
									$qty = $qty1+$qty2;
									
									$new_array[$i]=array(
										'date'=> $date,
										'dr_no'=> $dr,
										'serial_no' => $serial_no,
										'quantity' => $quantity,
										'unit_cost' => $unit_cost,
										'description' => $description,
										'sales_qty' => $qty
									);
									
								}
								
							}
						}
						else{
							$qty1 = 0;
							$t=0;
							
							if(count($col_con) > 0) {
								foreach($col_con as $data_col_con) {
									$qty2 = $data_col_con['qty2'];
									$qty = $qty1+$qty2;
								
									$new_array[$i]=array(
										'date'=> $date,
										'dr_no'=> $dr,
										'serial_no' => $serial_no,
										'quantity' => $quantity,
										'unit_cost' => $unit_cost,
										'description' => $description,
										'sales_qty' => $qty
									);
								}
							}
							else {
								$qty2 = 0;
								
								$qty = $qty1+$qty2;
								
								$new_array[$i]=array(
									'date'=> $date,
									'dr_no'=> $dr,
									'serial_no' => $serial_no,
									'quantity' => $quantity,
									'unit_cost' => $unit_cost,
									'description' => $description,
									'sales_qty' => $qty
								);
								
							}
						}
						
						array_push($dataArrayConsumables,$new_array[$i]);
						$i++;
					
				}
				
				$rows2 = "b.dr_no,a.date,SUBSTR(a.date,1,4) as year,SUBSTR(a.date,6,2) as month,b.serial_no,b.id,SUM(b.quantity) as quantity,c.unit_cost,c.description";
				$where2 = "a.type=2 AND (a.date <= '$to') AND a.dr_no=b.dr_no AND b.item=c.parts_id AND c.brand=d.id AND d.category=2 AND a.branch=e.id AND e.id='$branch' GROUP BY b.dr_no,b.item,b.serial_no";
				$order2 = "c.description ASC";
				$db->select("stocks a, stocks_parts b, tbl_parts c, tbl_manufacturer d, tbl_branch e",$rows2,$where2,$order2);
				$res2 = $db->getResult();
				$j=0;
				
				foreach($res2 as $dataParts) {
					$date=$dataParts['date'];
					$year=$dataConsumables['year'];
					$month=$dataConsumables['month'];
					$dr=$dataParts['dr_no'];
					$serial_no=$dataParts['serial_no'];
					$item_id=$dataParts['id'];
					$quantity=$dataParts['quantity'];
					$unit_cost=$dataParts['unit_cost'];
					$description=$dataParts['description'];
					
					$row_part = "b.qty as qty1";
					$where_part = "(c.date_issued <= '$to') AND a.id=b.stock_id AND b.stock_id=$item_id AND b.category=2 AND b.branch='$branch' GROUP BY b.stock_id,b.category";
					$db->select("stocks_parts a, sale_invoice_details b, sales_invoice c",$row_part,$where_part);
					$qty_part = $db->getResult();
					
					$row_col_part = "SUM(b.qty) AS qty2";
					$where_col_part = "a.id=b.stock_id AND b.stock_id=$item_id AND b.category=2 AND b.or_no=c.or_no AND (c.date <= '$to') AND c.branch_code=d.branch_code AND d.id='$branch' GROUP BY b.stock_id,b.category";
					$db->select("stocks_parts a, collection_cash b, collections c, tbl_branch d",$row_col_part,$where_col_part);
					$col_part = $db->getResult();
					
					if(count($qty_part) > 0){
						foreach($qty_part as $data_parts) {
							$qty1 =  $data_parts["qty1"];
							
							if(count($col_part) > 0) {
								$qty2=0;
								foreach($col_part as $data_col_part) {
									$qty2 = $data_col_part['qty2'];
									$qty = $qty1+$qty2;
								
									$new_array1[$j]=array(
										'date'=> $date,
										'dr_no'=> $dr,
										'serial_no' => $serial_no,
										'quantity' => $quantity,
										'unit_cost' => $unit_cost,
										'description' => $description,
										'sales_qty' => $qty
									);
								}
							}
							else {
								$qty2 = 0;
								
								$qty = $qty1+$qty2;
								
								$new_array1[$j]=array(
									'date'=> $date,
									'dr_no'=> $dr,
									'serial_no' => $serial_no,
									'quantity' => $quantity,
									'unit_cost' => $unit_cost,
									'description' => $description,
									'sales_qty' => $qty
								);
									
							}
						}
								
					}
					else{
						$qty1 = 0;
						
						if(count($col_part) > 0) {
							$qty2=0;
							foreach($col_part as $data_col_part) {
								$qty2 = $data_col_part['qty2'];
								$qty = $qty1+$qty2;
							
								$new_array1[$j]=array(
									'date'=> $date,
									'dr_no'=> $dr,
									'serial_no' => $serial_no,
									'quantity' => $quantity,
									'unit_cost' => $unit_cost,
									'description' => $description,
									'sales_qty' => $qty
								);
							}
						}
						else {
							$qty2 = 0;
							
							$qty = $qty1+$qty2;
							
							$new_array1[$j]=array(
								'date'=> $date,
								'dr_no'=> $dr,
								'serial_no' => $serial_no,
								'quantity' => $quantity,
								'unit_cost' => $unit_cost,
								'description' => $description,
								'sales_qty' => $qty
							);
								
						}
					}
						
					array_push($dataArrayParts,$new_array1[$j]);
					$j++;
					
				}
				
				
				$rows3 = "b.dr_no,a.date,SUBSTR(a.date,1,4) as year,SUBSTR(a.date,6,2) as month,CONCAT(b.serial_no,' ',b.color) as serial_no,b.id,c.unit_cost,c.description";
				$where3 = "a.type=3 AND (a.date <= '$to') AND a.dr_no=b.dr_no AND b.item=c.promo_id AND c.brand=d.id AND d.category=3 AND a.branch=e.id AND e.id='$branch'";
				$order3 = "c.description ASC";
				$db->select("stocks a, stocks_promo b, tbl_promo c, tbl_manufacturer d, tbl_branch e",$rows3,$where3,$order3);
				$res3 = $db->getResult();
				$k=0;
				
				foreach($res3 as $dataPromo) {
					$date=$dataPromo['date'];
					$year=$dataConsumables['year'];
					$month=$dataConsumables['month'];
					$dr=$dataPromo['dr_no'];
					$serial_no=$dataPromo['serial_no'];
					$item_id=$dataPromo['id'];
					$quantity=1;
					$unit_cost=$dataPromo['unit_cost'];
					$description=$dataPromo['description'];
					
					$row_promo = "b.qty AS qty1";
					$where_promo = "(c.date_issued <= '$to') AND a.id=b.stock_id AND b.stock_id=$item_id AND b.category=3 AND b.branch='$branch' GROUP BY b.stock_id,b.category";
					$db->select("stocks_promo a, sale_invoice_details b, sales_invoice c",$row_promo,$where_promo);
					$qty_promo = $db->getResult();
					
					$row_col_promo = "SUM(b.qty) AS qty2";
					$where_col_promo = "a.id=b.stock_id AND b.stock_id=$item_id AND b.category=3 AND b.or_no=c.or_no AND (c.date <= '$to') AND c.branch_code=d.branch_code AND d.id='$branch' GROUP BY b.stock_id,b.category";
					$db->select("stocks_parts a, collection_cash b, collections c, tbl_branch d",$row_col_promo,$where_col_promo);
					$col_promo = $db->getResult();
					
					if(count($qty_promo) > 0){
						foreach($qty_promo as $data_promo) {
							$qty1 =  $data_promo["qty1"];
							
							if(count($col_promo) > 0) {
								$qty2=0;
								foreach($col_promo as $data_col_promo) {
									$qty2 = $data_col_promo['qty2'];
									$qty = $qty1+$qty2;
								
									$new_array2[$k]=array(
										'date'=> $date,
										'dr_no'=> $dr,
										'serial_no' => $serial_no,
										'quantity' => $quantity,
										'unit_cost' => $unit_cost,
										'description' => $description,
										'sales_qty' => $qty
									);
								}
							}
							else {
								$qty2 = 0;
								
								$qty = $qty1+$qty2;
								
								$new_array2[$k]=array(
									'date'=> $date,
									'dr_no'=> $dr,
									'serial_no' => $serial_no,
									'quantity' => $quantity,
									'unit_cost' => $unit_cost,
									'description' => $description,
									'sales_qty' => $qty
								);
									
							}
						}
					}
					else{
							$qty1 = 0;
							
							if(count($col_promo) > 0) {
								$qty2=0;
								foreach($col_promo as $data_col_promo) {
									$qty2 = $data_col_promo['qty2'];
									$qty = $qty1+$qty2;
								
									$new_array2[$k]=array(
										'date'=> $date,
										'dr_no'=> $dr,
										'serial_no' => $serial_no,
										'quantity' => $quantity,
										'unit_cost' => $unit_cost,
										'description' => $description,
										'sales_qty' => $qty
									);
								}
							}
							else {
								$qty2 = 0;
								
								$qty = $qty1+$qty2;
								
								$new_array2[$k]=array(
									'date'=> $date,
									'dr_no'=> $dr,
									'serial_no' => $serial_no,
									'quantity' => $quantity,
									'unit_cost' => $unit_cost,
									'description' => $description,
									'sales_qty' => $qty
								);
									
							}
						
					}
					
					array_push($dataArrayPromo,$new_array2[$k]);
					$k++;
				}
				
				
				$data = array_merge($dataArrayParts,$dataArrayConsumables,$dataArrayPromo);
				
				print '{"members":'.json_encode($data).'}';
			
			break;
			
			// STOCK CARD
			
			case "loadStockBranch";
			
				$rows = "DISTINCT(a.branch_name),a.id";
				$where = "a.id=b.branch AND b.dr_no=c.dr_no GROUP BY a.branch_name";
				$db->select("tbl_branch a, stocks b, stocks_motors c",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadStockBrand";
				
				$branch_id = $_REQUEST["branch_id"];
			
				$rows = "DISTINCT(a.brand),a.id";
				$where = "b.branch='$branch_id' AND b.dr_no=c.dr_no AND c.brand=a.id AND a.category=1";
				$db->select("tbl_manufacturer a, stocks b, stocks_motors c",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadStockModel";
			
				$branch_id = $_REQUEST["branch_id"];
				$brand_id = $_REQUEST["brand_id"];
				
				$rows = "DISTINCT(a.model),a.motor_id";
				$where = "c.branch='$branch_id' AND a.brand='$brand_id' AND a.brand=b.brand AND b.dr_no=c.dr_no";
				$db->select("tbl_motorcycle a, stocks_motors b, stocks c",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadStockCard";
				
				$branch = $_REQUEST["branch"];
				$brand = $_REQUEST["brand"];
				$model = $_REQUEST["model"];
				
				$rows = "a.*,b.*,c.motor_id,c.model";
				$where = "a.id='$branch' AND b.id='$brand' AND c.motor_id='$model'";
				$db->select("tbl_branch a, tbl_manufacturer b, tbl_motorcycle c",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			break;
			
			case "loadStockCardItems";
				
				$stock = array();
				$result = array();
				$stocks_transfer=array();
				
				$branch_id = $_REQUEST["branch"];
				$brand_id = $_REQUEST["brand"];
				$model_id = $_REQUEST["model"];
				$branch_code="";
				
				$rows_transfer = "a.date as date_received,a.branch_code,a.dr_no,b.stock_id,b.item,c.engine_no,c.frame_no,c.color,d.model,d.unit_cost as cost,e.brand";
				$where_transfer = "b.stock_id=c.id AND f.id='$branch_id' AND b.item=d.motor_id AND d.motor_id='$model_id' AND e.id=c.brand AND a.branch_code=f.branch_code";
				$db->select("transfer_item a, transfer_details b, stocks_motors c, tbl_motorcycle d,tbl_manufacturer e,tbl_branch f",$rows_transfer,$where_transfer);
				$results_transfer = $db->getResult();
				
				$k=0;
				foreach($results_transfer as $keys_transfer){
					array_push($stocks_transfer,$keys_transfer["stock_id"]);		
				}
				
				$ids = "(".implode(',',$stocks_transfer).")";
				
				$rows = "e.id as branch_id,e.branch_name,e.branch_code,d.id as brand_id,d.brand,c.motor_id,c.model,c.unit_cost as cost,a.date as date_received,b.id as stock_id,b.dr_no,b.engine_no as motor_no,b.frame_no as serial_no,b.color,b.status";
				if(count($stocks_transfer) > 0){
					$where = "c.motor_id=$model_id AND a.dr_no=b.dr_no AND a.branch='$branch_id' AND a.type=1 AND b.brand='$brand_id' AND b.model='$model_id' AND b.brand=c.brand AND b.model=c.motor_id AND c.brand=d.id AND a.branch=e.id AND b.id NOT IN $ids";
				}
				else{
					$where = "c.motor_id=$model_id AND a.dr_no=b.dr_no AND a.branch='$branch_id' AND a.type=1 AND b.brand='$brand_id' AND b.model='$model_id' AND b.brand=c.brand AND b.model=c.motor_id AND c.brand=d.id AND a.branch=e.id";
				}
				$db->select("stocks a, stocks_motors b, tbl_motorcycle c, tbl_manufacturer d, tbl_branch e",$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				//print_r($res);
				foreach($res as $data) {
					$branch_code = $data["branch_code"];
					$branch = $data["branch_id"];
					$brand = $data["brand_id"];
					$model = $data["motor_id"];
					$date_received = $data["date_received"];
					
					$now = date("Y-m-d");
					$diff = (strtotime($now)- strtotime($date_received))/24/3600;
					
					$dr_no = $data["dr_no"];
					$motor_no = $data["motor_no"];
					$serial_no = $data["serial_no"];
					$color = $data["color"];
					$cost = $data["cost"];
					$stock_id = $data["stock_id"];
					$status = $data["status"];
					
					
					$rows1 = "d.model,a.date_issued as date_released,b.invoice_no,CONCAT(c.last_name,', ',c.first_name,' ',c.middle_name) as customer_name,b.amount as selling_price";
					$where1 = "b.stock_id=d.id AND b.stock_id='$stock_id' AND b.invoice_no=a.invoice_no AND a.customer_id=c.id AND d.brand='$brand' AND d.dr_no=e.dr_no AND e.branch='$branch' and b.category=1 AND f.motor_id=$model_id AND d.model=f.motor_id";
					$db->select("sales_invoice a, sale_invoice_details b, tbl_customer c, stocks_motors d,stocks e,tbl_motorcycle f",$rows1,$where1);
					$result = $db->getResult();
					
						if(count($result) > 0){
							foreach($result as $data_res) {
								$released = $data_res["date_released"];
								$invoice_no = $data_res["invoice_no"];
								$customer_name = $data_res["customer_name"];
								$selling_price =  $data_res["selling_price"];
								
								$new_array[$i]=array(
									'date_received'=> $date_received,
									'dr_no'=> $dr_no,
									'motor_no'=> $motor_no,
									'serial_no'=> $serial_no,
									'color'=> $color,
									'no_days'=> $diff,
									'date_released'=> $released,
									'invoice_no'=> $invoice_no,
									'customer_name'=> $customer_name,
									'selling_price'=> $selling_price,
									'cost'=> $cost
								);
							}
						}
						else{
								$released = "-";
								$invoice_no = "-";
								$customer_name = "-";
								$selling_price =  "0.00";
								
								$new_array[$i]=array(
									'date_received'=> $date_received,
									'dr_no'=> $dr_no,
									'motor_no'=> $motor_no,
									'serial_no'=> $serial_no,
									'color'=> $color,
									'no_days'=> $diff,
									'date_released'=> $released,
									'invoice_no'=> $invoice_no,
									'customer_name'=> $customer_name,
									'selling_price'=> $selling_price,
									'cost'=> $cost
								);
						
						}
					
					
					array_push($stock,$new_array[$i]);
					$i++;
					
					
				}
				
				$rows2 = "a.date as date_received,a.branch_code,a.dr_no,b.stock_id,b.item,c.engine_no,c.frame_no,c.color,d.model,d.unit_cost as cost,e.brand";
				$where2 = "b.stock_id=c.id AND a.move_to='$branch_code' AND b.item=d.motor_id AND e.id=c.brand and c.model=$model_id";
				$db->select("transfer_item a, transfer_details b, stocks_motors c, tbl_motorcycle d,tbl_manufacturer e",$rows2,$where2);
				$results = $db->getResult();
					
				//print_r($results);
				
				foreach($results as $keys){
					$stock_id=$keys["stock_id"];
					
					$date_received = $keys["date_received"];
					
					$now = date("Y-m-d");
					$diff = (strtotime($now)- strtotime($date_received))/24/3600;
					
					$dr_no = $keys["dr_no"];
					$motor_no = $keys["engine_no"];
					$serial_no = $keys["frame_no"];
					$color = $keys["color"];
					$cost = $keys["cost"];
					
					$rows1 = "a.date_issued as date_released,b.invoice_no,CONCAT(c.last_name,', ',c.first_name,' ',c.middle_name) as customer_name,b.amount as selling_price";
					$where1 = "a.invoice_no=b.invoice_no and d.id=b.stock_id and a.customer_id=c.id and b.stock_id=$stock_id";
					$db->select("sales_invoice a, sale_invoice_details b, tbl_customer c,stocks_motors d",$rows1,$where1);
					$result_sales = $db->getResult();
					
					if(count($result_sales) > 0){
							foreach($result_sales as $data_sales) {
								$released = $data_sales["date_released"];
								$invoice_no = $data_sales["invoice_no"];
								$customer_name = $data_sales["customer_name"];
								$selling_price =  $data_sales["selling_price"];
								
								$new_array[$i]=array(
									'date_received'=> $date_received,
									'dr_no'=> $dr_no,
									'motor_no'=> $motor_no,
									'serial_no'=> $serial_no,
									'color'=> $color,
									'no_days'=> $diff,
									'date_released'=> $released,
									'invoice_no'=> $invoice_no,
									'customer_name'=> $customer_name,
									'selling_price'=> $selling_price,
									'cost'=> $cost
								);
							}
						}
						else{
								$released = "-";
								$invoice_no = "-";
								$customer_name = "-";
								$selling_price =  "0.00";
								
								$new_array[$i]=array(
									'date_received'=> $date_received,
									'dr_no'=> $dr_no,
									'motor_no'=> $motor_no,
									'serial_no'=> $serial_no,
									'color'=> $color,
									'no_days'=> $diff,
									'date_released'=> $released,
									'invoice_no'=> $invoice_no,
									'customer_name'=> $customer_name,
									'selling_price'=> $selling_price,
									'cost'=> $cost
								);
						
						}
					
					
					array_push($stock,$new_array[$i]);
					$i++;
				}
				
				//print_r($result_sales);
				print '{"members":'.json_encode($stock).'}';
			
			break;
			
			case "loadInventoryMotors";
				
				$branch = $_REQUEST["branch"];
				$month = $_REQUEST["month"];
				$year = $_REQUEST["year"];
				
				
				$sales=array();
				$purchases=array();
				$transfers=array();
				$ending=array();
				$start=array();
				$begin_inventory=array();
				$items_sold=array();
				$sales_Arr=array();	
				$purchases_Arr=array();
				$transferTo_Arr=array();
				$transferFrom_Arr=array();
				$rows = "*";
				$db->select("tbl_branch",$rows);
				$res = $db->getResult();
				
				
				
				foreach($res as $info){
					$branch_code=$info["branch_code"];
					$branch_id=$info["id"];
					$branch_name=$info["branch_name"];
					
					$i=0;					
					$rows = "a.*,b.*";
					$where="b.branch='".$branch_id."' and DATE(a.date_issued) < '2014-05-01' and b.invoice_no=a.invoice_no and b.category=1";
					$db->select("sales_invoice a,sale_invoice_details b",$rows,$where);
					$result_sales = $db->getResult();
						
						foreach($result_sales as $info_sales){
							array_push($items_sold,$info_sales["stock_id"]);
						}
						
						
						
				}
				
				
				$ids = "(".implode(',',$items_sold).")";
				
				
				//** BEGINNING **//
				foreach($res as $info){
					$branch_code=$info["branch_code"];
					$branch_id=$info["id"];
					$branch_name=$info["branch_name"];
					
					$i=0;					
					$rows = "a.*,b.*,c.model,c.unit_cost,b.id as stock_id";
					if(count($items_sold) > 0){
						$where="a.branch='".$branch_id."' and DATE(a.date) < '2014-05-01'  and a.dr_no=b.dr_no and a.type=1 and b.model=c.motor_id and b.id and b.id NOT IN $ids" ;
					}
					else{
						$where="a.branch='".$branch_id."' and DATE(a.date) < '2014-05-01'  and a.dr_no=b.dr_no and a.type=1 and b.model=c.motor_id and b.id and b.id";
					}
					$order="c.model asc";
					$db->select("stocks a,stocks_motors b,tbl_motorcycle c",$rows,$where,$order);
					$result_beginning = $db->getResult();
						
						
						foreach($result_beginning as $info_beginning){
							$item_beginning=array('stock_id'=>$info_beginning['stock_id'],$branch_code,'branch_code'=>$branch_code,'no_of_units'=>1,'serial_no'=>$info_beginning['engine_no'],'item'=>$info_beginning['model'],'cost'=>$info_beginning['unit_cost']);
							array_push($begin_inventory,$item_beginning);
							array_push($ending,$info_beginning['id']);
						}
						
						
						
				}
				
				//print_r($begin_inventory);
				//die();
				
				//** SALES **//
				foreach($res as $info){
					$branch_code=$info["branch_code"];
					$branch_id=$info["id"];
					$branch_name=$info["branch_name"];
					
					$i=0;					
					$rows = "a.*,b.*,d.model,d.unit_cost";
					$where="b.branch='".$branch_id."' and DATE(a.date_issued) > '2014-05-01' and DATE(a.date_issued) <= '2014-05-31' and b.invoice_no=a.invoice_no and b.category=1 and b.stock_id=c.id and c.model=d.motor_id and b.stock_id";
				
					$db->select("sales_invoice a,sale_invoice_details b,stocks_motors c,tbl_motorcycle d",$rows,$where);
					$result_sales = $db->getResult();
						
						foreach($result_sales as $info_sales){
							$item_sold=array('stock_id'=>$info_sales['stock_id'],'branch_code'=>$branch_code,'no_of_units'=>1,'serial_no'=>$info_sales['serial_no'],'item'=>$info_sales['model'],'cost_sales'=>$info_sales['amount'],'cost'=>$info_sales['unit_cost']);
							array_push($ending,$info_sales['stock_id']);
							array_push($sales_Arr,$info_sales['stock_id']);
							array_push($sales,$item_sold);
						}
				}
				
				
				
				//** PURCHASES **//
				foreach($res as $info){
					$branch_code=$info["branch_code"];
					$branch_id=$info["id"];
					$branch_name=$info["branch_name"];
					
					$i=0;					
					$rows = "a.*,b.*,c.model,c.unit_cost,b.id as stock_id";
					$where="a.branch='".$branch_id."' and DATE(a.date) > '2014-05-01' and DATE(a.date) < '2014-05-31'  and a.dr_no=b.dr_no and a.type=1 and b.model=c.motor_id";
					$db->select("stocks a,stocks_motors b,tbl_motorcycle c",$rows,$where);
					$result_purchases = $db->getResult();
						
						
						foreach($result_purchases as $info_purchase){
							$item_purchases=array('stock_id'=>$info_purchase['stock_id'],'branch_code'=>$branch_code,'no_of_units'=>1,'serial_no'=>$info_purchase['engine_no'],'item'=>$info_purchase['model'],'cost'=>$info_purchase['unit_cost']);
							array_push($purchases,$item_purchases);
							array_push($purchases_Arr,$info_purchase['stock_id']);
							array_push($ending,$info_purchase['stock_id']);
						}
						
						
						
				}
				
				//** TRANSFER **//
				foreach($res as $info){
					$branch_code=$info["branch_code"];
					$branch_id=$info["id"];
					$branch_name=$info["branch_name"];
					
					$rows = "a.*,b.*,c.engine_no as serial_no,d.model,d.unit_cost,c.id as stock_id";
					$where="a.branch_code='".$branch_code."' and DATE(a.date) > '2014-05-01' and DATE(a.date) < '2014-05-31' and a.dr_no=b.dr_no and b.category=1 and b.stock_id=c.id and c.model=d.motor_id";
					$db->select("transfer_item a,transfer_details b,stocks_motors c,tbl_motorcycle d",$rows,$where);
					$result_transfers = $db->getResult();
					
					
						foreach($result_transfers as $info_transfers){
							$item_transfers=array('stock_id'=>$info_transfers['stock_id'],'branch_code'=>$branch_code,'no_of_units'=>1,'serial_no'=>$info_transfers['serial_no'],'item'=>$info_transfers['model'],'cost'=>$info_transfers['unit_cost'],'in'=> 0 ,'out' => 1);
							array_push($transfers,$item_transfers);
							array_push($ending,$info_transfers['stock_id']);
							array_push($transferFrom_Arr,$info_transfers['stock_id']);
							
						}
						
					
					$rows2 = "a.*,b.*,c.engine_no as serial_no,d.model,d.unit_cost,c.id as stock_id";
					$where2="a.move_to='".$branch_code."' and DATE(a.date) > '2014-05-01' and DATE(a.date) < '2014-05-31' and a.dr_no=b.dr_no and b.category=1 and b.stock_id=c.id and c.model=d.motor_id";
					$db->select("transfer_item a,transfer_details b,stocks_motors c,tbl_motorcycle d",$rows2,$where2);
					$result_transfers2 = $db->getResult();
					
						foreach($result_transfers2 as $info_transfers){
							$item_transfers2=array('stock_id'=>$info_transfers['stock_id'],'branch_code'=>$branch_code,'no_of_units'=>1,'serial_no'=>$info_transfers['serial_no'],'item'=>$info_transfers['model'],'cost'=>$info_transfers['unit_cost'],'in'=> 1 ,'out' => 0);
							array_push($transfers,$item_transfers2);
							array_push($ending,$info_transfers['stock_id']);
							array_push($transferTo_Arr,$info_transfers['stock_id']);
							
						}
										
						
				}
				
				
				$unique=array_unique($ending);
				
				$merge_Array=array_merge($purchases_Arr,$transferTo_Arr,$transferFrom_Arr);	
				
				$ending_Array=array_merge($transferFrom_Arr,$sales_Arr);	
				
				print_r($merge_Array);
				
				echo "<table border=1><tr  align='center'><td>MODEL</td><td colspan=3>BEGINNING INVENTORY</td><td colspan=4>PURCHASES</td><td colspan=5>INTERBRANCH</td><td colspan=3>COST OF SALES</td><td colspan=3>ENDING INVENTORY</td></tr>";
				echo "<tr><td></td><td>NO. OF <br> UNITS</td><td>SERIAL NO</td><td>UNIT COST</td><td>DATE</td><td>NO OF <br> UNITS</td><td>SERIAL NO.</td><td>UNIT COST.</td><td> DATE</td><td>IN</td><td>OUT</td><td>SERIAL NO</td><td>UNIT COST</td><td> DATE</td><td>NO. OF UNITS</td><td>COST</td><td>NO. OF UNITS</td><td>SERIAL NO.</td><td>UNIT COST</td></tr>";
				
				
				foreach($unique as $info){
					
					$rows = "a.*,b.model,b.unit_cost";
					$where="id='".$info."' and a.model=b.motor_id";
					$order="b.model asc";
					$db->select("stocks_motors a,tbl_motorcycle b",$rows,$where,$order);
					$result_unique = $db->getResult();
					
					
					
					foreach($result_unique as $info_unique){
						echo "<tr>";
						echo "<td>".$info_unique["model"]."</td>";
						$stock_id=$info_unique["id"];
						if (!in_array($stock_id,$merge_Array)){
							echo "<td>1</td><td>".$info_unique["engine_no"]."</td><td>".$info_unique["unit_cost"]."</td>";
						}
						else{
							echo "<td>-</td><td>-</td><td></td>";
						}
						
						//Purchases
						if (in_array($stock_id,$purchases_Arr)){
							$db->selectSingle("stocks a,stocks_motors b","a.date","b.id='".$stock_id."' and a.dr_no=b.dr_no");
							$date=$db->getSingleResult();
							

							echo "<td>$date</td>";
							echo "<td>1</td><td>".$info_unique["engine_no"]."</td><td>".$info_unique["unit_cost"]."</td>";
						}
						else{
							echo "<td>-</td><td>-</td><td></td><td></td>";
						}
						
						//Transfer
						if (in_array($stock_id,$transferTo_Arr)){
							$db->selectSingle("transfer_item a,transfer_details b","a.date","b.stock_id='".$stock_id."' and a.transfer_id=b.id_s and b.category=1");
							$date=$db->getSingleResult();
							

							echo "<td>$date</td>";
							echo "<td>1</td><td></td><td>".$info_unique["engine_no"]."</td><td>".$info_unique["unit_cost"]."</td>";
						}
						else if(in_array($stock_id,$transferFrom_Arr)){
							$db->selectSingle("transfer_item a,transfer_details b","a.date","b.stock_id='".$stock_id."' and a.transfer_id=b.id_s and b.category=1");
							$date=$db->getSingleResult();
	
							echo "<td>$date</td>";
							echo "<td></td>1<td></td><td>".$info_unique["engine_no"]."</td><td>".$info_unique["unit_cost"]."</td>";
						}
						else{
							echo "<td>-</td><td>-</td><td></td><td></td><td></td>";
						}
						
						//Sales
						if (in_array($stock_id,$sales_Arr)){
							$db->selectSingle("sales_invoice a,sale_invoice_details b","a.date_issued","b.stock_id='".$stock_id."' and a.invoice_no=b.invoice_no and category=1");
							$date=$db->getSingleResult();
							

							echo "<td>$date</td>";
							echo "<td>1</td><td>".$info_unique["unit_cost"]."</td>";
						}
						else{
							echo "<td>-</td><td>-</td><td></td>";
						}
						
						//ENDING
						if (!in_array($stock_id,$ending_Array)){
							
							echo "<td>1</td>";
							echo "<td>".$info_unique["engine_no"]."</td><td>".$info_unique["unit_cost"]."</td>";
						}
						else{
							echo "<td>-</td><td>-</td><td></td>";
						}
						
						echo "</tr>";
					
					}
					
					
				
				}
				
				
				
				

			break;
			
			
			
			
		}	
		
	}

?>