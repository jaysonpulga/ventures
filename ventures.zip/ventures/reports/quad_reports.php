<?php
	
	 $category = $_REQUEST["category"];
	 $loan_type = $_REQUEST["loan_type"];
	 $month = $_REQUEST["month"];
	 $year = $_REQUEST["year"];
	 $quad = $_REQUEST["quad"];
	
	//$from = $_REQUEST["from"];
	
	//$month = substr($from,5,2);
	//$year = substr($from,0,4);
		
	if($month == "01") {
		$month_name = "JANUARY";
	}
	if($month == "02") {
		$month_name = "FEBRUARY";
	}
	if($month == "03") {
		$month_name = "MARCH";
	}
	if($month == "04") {
		$month_name = "APRIL";
	}
	if($month == "05") {
		$month_name = "MAY";
	}
	if($month == "06") {
		$month_name = "JUNE";
	}
	if($month == "07") {
		$month_name = "JULY";
	}
	if($month == "08") {
		$month_name = "AUGUST";
	}
	if($month == "09") {
		$month_name = "SEPTEMBER";
	}
	if($month == "10") {
		$month_name = "OCTOBER";
	}
	if($month == "11") {
		$month_name = "NOVEMBER";
	}
	if($month == "12") {
		$month_name = "DECEMBER";
	}
	
	
	if($quad == "Quad LC") {
		$Quad = "QUAD LC";
	}else if($quad == "Laguna LC"){
		$Quad = "LAGUNA LC";
	}
	
	error_reporting(0);

?>
<html>
<title>INVENTORY REPORT-MOTORCYCLE</title>

<script src="../js/jquery-1.8.3.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="../js/jquery.alerts.js" type="text/javascript"></script>
<script type="text/javascript" src=""></script>
<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
</html>

<style>
body{
	font-family:Calibri,Helvetica,"sans-serif";
	font-size:14px;	
}

#table table{
	border-collapse:collapse;
	box-shadow: 1px 2px 3px gray;
	width:inherit;
}


#table th{
	background:#3d3d45;
	color:#FFF;
	font-size:12px;
	padding:2px 5px;
	letter-spacing:1px;
	border: 1px solid #f3f2f2;
}
#table td{
	background:#f3f2f2;
	padding:0px;
	font-size:12px;
	text-align:center;	
}
</style>

<body>


<input type="hidden" name="category" id="category" value="<?php echo $category; ?>" />
<input type="hidden" name="loan_type" id="loan_type" value="<?php echo $loan_type; ?>" />
<input type="hidden" name="month" id="month" value="<?php echo $month; ?>" />
<input type="hidden" name="year" id="year" value="<?php echo $year; ?>" />
<input type="hidden" name="quad" id="quad" value="<?php echo $quad; ?>" />


	<div id="wrapper" style="width:100%">
			<div id="main" align="center" style="width:100%">
				<div id="options-top" align="center" style="width:95%;">
					<h2 style="margin-top:10px;">QUAD LENDING CORPORATION</h2>
					<h3 style="margin-top:-15px;"><?php echo $Quad ;?></h3>
					<h3 style="margin-top:-15px;">MONTHLY COLLECTION</h3>
					<h4 style="margin-top:-15px;">As of <?php echo $month_name; ?>&nbsp;<?php echo $year; ?></h4>
					<table width="1200px" border=1 cellspacing=0 cellpadding=0 id = "table">
						<thead>
							<tr class="y" style='font-size:12px;'>
								<th style='padding:10px 0px;'>ACCOUNT NO:</th><th>DATE</th><th>O.R NO:</th><th>AMOUNT PAID</th><th>PRINCIPAL</th><th>INTEREST</th><th>PENALTY</th><th>DISCOUNT</th><th>REBATES</th><th style='width:50px'>DAYS OF PENALTY</th>
							</tr>
						</thead>
						<tbody id="table">
						</tbody>
					</table>
				</div>
				
			<div style='margin-top:20px'>
				
				<table align='left' border=0 style="width:300px;margin-left:75px" >
						<tr>
						  <td ><b>TOTAL AMOUNT PAID:</b></td>
						  <td align='left'><span id='total_amt'></span></td> 
						</tr>
						
						<tr>
						  <td ><b>TOTAL PENALTY CHARGES:</b></td>
						  <td align='left'><span id='total_penalty'></span></td> 
						</tr>
						
						<tr>
						  <td ><b style='margin-left:102px'>SUBTOTAL:</b></td>
						  <td align='left'><span id='total_sub1'></span></td> 
						</tr>

						<tr>
						  <td ><b style='margin-left:2px'>LESS:</b></td>
						</tr>
						<tr>
						  <td ><b>TOTAL DISCOUNT:</b></td>
						  <td align='left'><span id='total_dis'></span></td> 
						</tr>
						
						<tr>
						  <td ><b>TOTAL REBATES:</b></td>
						  <td align='left'><span id='total_reb'></span></td> 
						</tr>
						
						<tr>
						  <td ><b style='margin-left:102px'>SUBTOTAL:</b></td>
						  <td align='left'><span id='total_sub2'></span></td> 
						</tr>
						
						<tr>
						  <tr bgcolor='black'><td colspan=10 height=1></td></tr>
						</tr>
						
						
						<tr>
						  <td ><b>GRAND TOTAL:</b></td>
						  <td align='left' bgcolor='d3d3d3' style='font-style:bold' ><b><span id='grand_total'></span></b></td> 
						</tr>
						
				</table>
				
			</div>
				
				
			
				
				
				
			
			</div>
			
					
	</div>
	
	
	

	
	
	<script src='../js/dropdowntabs.js'></script>	
	<script>
	var branch = getUrlVars()["branch"];
	var to= getUrlVars()["to"];
	var from = getUrlVars()["from"];
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="reports#"){
			menu="reports";
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
		"padding":"30px 31px 0px 31px",
		"border-bottom":"4px solid #c95447"
		});
		
			
		var category = $("#category").val();
		var loan_type = $("#loan_type").val();
		var month = $("#month").val();
		var year = $("#year").val();
		var quad = $("#quad").val();
		
		

		
		load_loan(category,loan_type,month,year,quad);
		
	});
	
	
	function load_loan(category,loan_type,month,year,quad){
		
	$("#table > tbody").empty();	
		
	var url="function_report.php?request=ajax&action=load_loan_report&category="+category+"&loan_type="+loan_type+"&month="+month+"&year="+year+"&quad="+quad;
	var counter=0;
	var amount_paid=0;
	var principal=0;
	var interest=0;
	var penalty=0;
	var discount=0;
	var rebate=0;
	var days_penalty=0;
	var terms = 0;
	var date_due = 0;
	
	var  total_amt_paid = 0;
	var  total_principal = 0;
	var  total_interest = 0;
	var  total_penalty = 0;
	var  total_discount = 0;
	var  total_rebate = 0;
	

		$.getJSON(url,function(data){
		
			$("#table > tbody").empty();
				$.each(data.members, function(i,res){
				
				amount_paid = res.dues;
				terms = parseFloat(res.terms);
				
				penalty = parseFloat(res.penalty_discount);
				discount = parseFloat(res.discount);
				rebate = parseFloat(res.rebate);
				date_due = discount = parseFloat(res.ins_due);
				var date = res.date;
				var ins_date = date.substr(8);
				
				var days_penalty = date_due - ins_date;
				
				
				
				total_amt_paid = total_amt_paid + parseFloat(amount_paid);
				
				
				
				if(res.status == "1st loan"){
						principal = parseFloat(res.principal_amt_1);
						interest = parseFloat(res.int_income_1);
				}else{
									
						principal = ((parseFloat(res.amount_loan) - parseFloat(res.principal_amt_1)) / (terms - 1));
						interest = ((parseFloat(res.interest_income) - parseFloat(res.int_income_1)) / (terms - 1));
								
				}
				
				total_principal = total_principal + parseFloat(principal);
				total_interest = total_interest + parseFloat(interest);
				total_penalty =  total_penalty + parseFloat(penalty);
				total_discount =  total_discount + parseFloat(discount);
				total_rebate =  total_rebate + parseFloat(rebate);
				
				
				
				amount_paid = FormatNumberBy3(parseFloat(Math.round((amount_paid)*100)/100).toFixed(2));
				principal = FormatNumberBy3(parseFloat(Math.round((principal)*100)/100).toFixed(2));
				interest = FormatNumberBy3(parseFloat(Math.round((interest)*100)/100).toFixed(2));
				
				
								
				$("#table > tbody").append("<tr class='x' id='record"+res.account_no+"'><td align='center'>"+res.account_no+"</td><td align='center'>"+res.date+"</td><td align='center'>"+res.or_no+"</td><td style = 'text-align:right;' >"+amount_paid+"</td><td style = 'text-align:right;' >"+principal+"</td><td style = 'text-align:right;'>"+interest+"</td><td style = 'text-align:right;'>"+penalty+"</td><td style = 'text-align:right;'>"+discount+"</td><td style = 'text-align:right;'>"+rebate+"</td><td align='center'>"+days_penalty+"</td></tr>");
							
						
				counter++;
						 
			});	
		
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Items on record! </th></tr>");
			}
			
			
			
			$("#total_amt").append(FormatNumberBy3(parseFloat(Math.round((total_amt_paid)*100)/100).toFixed(2)));
			$("#total_penalty").append(FormatNumberBy3(parseFloat(Math.round((total_penalty)*100)/100).toFixed(2)));
			
			var sub1 = parseFloat(total_amt_paid) + parseFloat(total_penalty);
			$("#total_sub1").append(FormatNumberBy3(parseFloat(Math.round((sub1)*100)/100).toFixed(2)));
			
			
			$("#total_dis").append(FormatNumberBy3(parseFloat(Math.round((total_discount)*100)/100).toFixed(2)));
			$("#total_reb").append(FormatNumberBy3(parseFloat(Math.round((total_rebate)*100)/100).toFixed(2)));
			
			var sub2 = parseFloat(total_discount) + parseFloat(total_rebate);
			$("#total_sub2").append(FormatNumberBy3(parseFloat(Math.round((sub2)*100)/100).toFixed(2)));
			
			
			var grand_tot = parseFloat(sub1) - parseFloat(sub2);
			
			$("#grand_total").append(FormatNumberBy3(parseFloat(Math.round((grand_tot)*100)/100).toFixed(2)));
			
			
			total_amt_paid = FormatNumberBy3(parseFloat(Math.round((total_amt_paid)*100)/100).toFixed(2));
			total_principal = FormatNumberBy3(parseFloat(Math.round((total_principal)*100)/100).toFixed(2));
			total_interest = FormatNumberBy3(parseFloat(Math.round((total_interest)*100)/100).toFixed(2));
			total_penalty = FormatNumberBy3(parseFloat(Math.round((total_penalty)*100)/100).toFixed(2));
			total_discount = FormatNumberBy3(parseFloat(Math.round((total_discount)*100)/100).toFixed(2));
			total_rebate = FormatNumberBy3(parseFloat(Math.round((total_rebate)*100)/100).toFixed(2));
			
			
			
			
			if (counter >= 0) {
				$("#table > tbody").append("<tr style='font-size:14px; font-weight:bold; background:#FFFFCC;' align='center'><td style='padding:2px 0px; background:#FFFFCC;'>GRAND TOTAL</td><td style='background:#FFFFCC;'></td><td style = 'text-align:left; background:#FFFFCC;'></td><td style = 'text-align:right; background:#FFFFCC;'>"+total_amt_paid+"</td><td style='text-align:right;background:#FFFFCC;'>"+total_principal+"</td><td style = 'text-align:right; background:#FFFFCC;'>"+total_interest+"</td><td style = 'text-align:right;background:#FFFFCC;'>"+total_penalty+"</td><td style='text-align:right;background:#FFFFCC;'>"+total_discount+"</td><td style='text-align:right;background:#FFFFCC;'>"+total_rebate+"</td><td style='background:#FFFFCC;'></td></tr>");
			}
			
			
					
					
		});
		
		
		
	
	}
	

	
	
/* 	function loadInventory() {
		
		var url="functions.php?request=ajax&action=loadInventoryConsumables&branch="+branch+"&to="+to+"&from="+from;
		var beg=0;
		var unit_cost=0;
		var net_vat=0;
		var costsales=0;
		var no_sales=0;
		var costy=0;
		var ending=0;
		
		var total_beg=0;
		var total_total=0;
		var total_unit_cost=0;
		var total_net=0;
		var total_cost=0;
		var total_no_sales=0;
		var total_costy=0;
		var total_ending=0;
		
		$("#table > tbody").empty();
	
		$.getJSON(url,function(data){
			var counter=0;
			$.each(data.members, function(i,res){
				
				beg = res.quantity;
				unit_cost = res.unit_cost;
				no_sales = res.sales_qty;
				
				costsales = parseFloat(unit_cost)*parseFloat(no_sales);
				net_vat = costsales*0.12;
				costy = (parseFloat(beg)-parseFloat(no_sales))*parseFloat(unit_cost);
				ending = parseFloat(beg)-parseFloat(no_sales);
				
				total_beg += parseFloat(beg);
				total_unit_cost += parseFloat(unit_cost);
				total_net += parseFloat(net_vat);
				total_cost += parseFloat(costsales);
				total_no_sales += parseFloat(no_sales);
				total_costy += parseFloat(costy);
				total_ending += parseFloat(ending);
			
				$("#table > tbody").append("<tr class='x' style='font-size:14px;' align='center'><td style='padding:2px 0px;'>"+res.date+"</td><td>"+res.dr_no+"</td><td style = 'text-align:left;'>"+res.description+"</td><td style = 'text-align:left;'>"+res.serial_no+"</td><td>"+beg+"</td><td>"+beg+"</td><td>"+FormatNumberBy3(parseFloat(Math.round((unit_cost)*100)/100).toFixed(2))+"</td><td>"+FormatNumberBy3(parseFloat(Math.round((net_vat)*100)/100).toFixed(2))+"</td><td>"+FormatNumberBy3(parseFloat(Math.round((costsales)*100)/100).toFixed(2))+"</td><td>"+no_sales+"</td><td>"+FormatNumberBy3(parseFloat(Math.round((costy)*100)/100).toFixed(2))+"</td><td>"+ending+"</td></tr>");
				counter++;
			});
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '12' align = 'center'> No Payment History! </th></tr>");
			}
			if (counter >= 0) {
				$("#table > tbody").append("<tr style='font-size:14px; font-weight:bold; background:#FFFFCC;' align='center'><td style='padding:2px 0px; background:#FFFFCC;'>GRAND TOTAL</td><td style='background:#FFFFCC;'></td><td style = 'text-align:left; background:#FFFFCC;'></td><td style = 'text-align:left; background:#FFFFCC;'></td><td style='background:#FFFFCC;'>"+total_beg+"</td><td style = 'background:#FFFFCC;'>"+total_beg+"</td><td style = 'background:#FFFFCC;'>"+FormatNumberBy3(parseFloat(Math.round((total_unit_cost)*100)/100).toFixed(2))+"</td><td style='background:#FFFFCC;'>"+FormatNumberBy3(parseFloat(Math.round((total_net)*100)/100).toFixed(2))+"</td><td style='background:#FFFFCC;'>"+FormatNumberBy3(parseFloat(Math.round((total_cost)*100)/100).toFixed(2))+"</td><td style='background:#FFFFCC;'>"+total_no_sales+"</td><td style='background:#FFFFCC;'>"+FormatNumberBy3(parseFloat(Math.round((total_costy)*100)/100).toFixed(2))+"</td><td style='background:#FFFFCC;'>"+total_ending+"</td></tr>");
			}
		});
		
	} */
	
	</script>
</body>
</html>