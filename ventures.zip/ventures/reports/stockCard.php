<html>
<title>Stock Card</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:300px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>STOCK CARD</h2><hr></label>
							</span>
						</div>
						<div style="margin-left:25px">
							<span>
								<label>Select Branch:</label>
								<select id = 'txtbranch' name='brand'>
									<option value="">-- SELECT --</option>
								</select>
							</span>
						</div>
						<div style="margin-left:25px">
							<span>
								<label>Manufacturer:</label>
								<select id = 'txtbrand' name='brand'>
									<option value="">-- SELECT --</option>
								</select>
							</span>
						</div>
						<div style="margin-left:25px">
							<span>
								<label>Model:</label>
								<select id = 'txtmodel' name='brand' style = "margin-left:44px;">
									<option value="">-- SELECT --</option>
								</select>
							</span>
						</div>
						<div style="margin-top:10px" align="center">
							<input type="button" value="VIEW REPORT" onclick = "viewReport();" style="width:130px">
						</div>
					
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="reports#"){
			menu="reports";
		}
		else{
			menu = getUrlVars()["menu"];	
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
		"padding":"30px 31px 0px 31px",
		"border-bottom":"4px solid #c95447"
		});
		
		$("#txtbrand")
		.prop('disabled', true)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$("#txtmodel")
		.prop('disabled', true)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		var branch_id;
		loadBranch();
		
		$("#txtbranch").change(function() {
		
			$("#txtbrand")
			.prop('disabled', false)
			.empty()
			.append('<option value="">-- SELECT --</option>')
			.find('option:first')
			.attr("selected","selected")
			;
			
			$("#txtmodel")
			.prop('disabled', true)
			.empty()
			.append('<option value="">-- SELECT --</option>')
			.find('option:first')
			.attr("selected","selected")
			;
			
			branch_id=$("#txtbranch :selected").val();
			var branch_name=$("#txtbranch :selected").text();
			
			loadBrand(branch_id);
			
		});
		
		$("#txtbrand").change(function() {
			
			$("#txtmodel")
			.prop('disabled', false)
			.empty()
			.append('<option value="">-- SELECT --</option>')
			.find('option:first')
			.attr("selected","selected")
			;
			
			var brand_id=$("#txtbrand :selected").val();
			var brand_name=$("#txtbrand :selected").text();
			
			loadModel(branch_id,brand_id);
			
		});
		
	});
	
	function loadBranch() {
		
		var url="functions.php?request=ajax&action=loadStockBranch";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtbranch").append("<option value="+ res.id+">" + res.branch_name + "</option>");
				
			});
		});
	
	}
	
	function loadBrand(id) {
		
		var url="functions.php?request=ajax&action=loadStockBrand&branch_id="+id;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtbrand").append("<option value="+ res.id+">" + res.brand + "</option>");
				
			});
		});
		
	}
	
	function loadModel(branch,brand) {
		
		var url="functions.php?request=ajax&action=loadStockModel&branch_id="+branch+"&brand_id="+brand;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtmodel").append("<option value="+ res.motor_id+">" + res.model + "</option>");
				
			});
		});
		
	}
	
	function viewReport() {
		
		var branch = $("#txtbranch").val();
		var brand = $("#txtbrand").val();
		var model = $("#txtmodel").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(branch == ""){
			errormsg+="- Select Branch.\n";
		}
		if(brand == ""){
			errormsg+="- Select Brand.\n";
		}
		if(model == ""){
			errormsg+="- Select Model.\n";
		}
		
		if(errormsg.length==emsg){
			window.location = "reportStockCard.php?branch="+branch+"&brand="+brand+"&model="+model;
		}
		else {
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		
	}
	
	</script>
	
</body>
</html>