<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<?php
include('../database.php');  
$db = new Database();  
$db->connect();
?>
<html>
<title>Loan</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:300px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>LOAN COLLECTIONS</h2><hr></label>
							</span>
						</div>
						<div>
							<span>
								<label>CATEGORY:</label>
								<select id = "category" style = "margin-left:40px;">
								<option value='LOAN'>LOAN</option>
								<option value='CASH'>CASH</option>
								<option value='INTERBRANCH'>INTERBRANCH</option>
								</select>
							</span>
						</div>
						<div>
							<span>
								<label>Loan Type:</label>
								<select id = "loan_type" style = "margin-left:43px;">
									<?php  
									$db->select("tbl_loan","loan_type");
									$result = $db->getResult();
											
									foreach($result as $info){
										$loan_type	 = $info['loan_type'];
									echo '<option value="'.$loan_type .'">'.strtoupper($loan_type).'</option>';								
									}
									?>
									</select>
							</span>
						</div>	
						<div>
							<span>
								<label>Select Month:</label>
								<select id = "month" style = "margin-left:23px;">
									<?php  
									
									$months = array('JANUARY'=>'01' ,'FEBRUARY'=>'02','MARCH'=>'03','APRIL'=>'04','MAY'=>'05','JUNE'=>'06','JULY'=>'07','AUGUST'=>'08','SEPTEMBER'=>'09','OCTOBER'=>'10','NOVEMBER'=>'11','DECEMBER'=>'12');
									
									foreach ($months  as $key =>$value){
									
									echo '<option value="'.$value.'">'.strtoupper($key).'</option>';	
									
									}	
									?>
								</select>
							</span>
						</div>
						<div>
							<span>
								<label>YEAR:</label>
								<input type='text' id='year' style = 'margin-left:74px; width:162px;'/>
							</span>
						</div>
						<div>
							<span>
								<label>Select Lending:</label>
								<select id = 'quad' name='quad' style="margin-left:15px;">
									<option value="Quad LC">QUAD LC</option>
									<option value="Laguna LC">LAGUNA LC</option>
								</select>
							</span>
						</div>
						<div style="margin-top:10px" align="center">
							<input type="button" value="VIEW REPORT" style="width:130px" onclick='loan_report();'>
						</div>
						
						
						<!-- LOAN SUMMARY -->
						
						<div>
							<span>
								<label><h2>LOAN SUMMARY</h2><hr></label>
							</span>
						</div>
						<div>
							<span>
								<label>Lending:</label>
								<select id = "txtlending" style = "margin-left:55px;">
									<option value="QuadLC">Quad LC</option>
									<option value="LagunaLC">Laguna LC</option>
								</select>
							</span>
						</div>
						<div>
							<span>
								<label>Type of Loan:</label>
								<select id = "txttype" style = "margin-left:26px;">
									<?php  
									$db->select("tbl_loan","id,loan_type");
									$result = $db->getResult();
											
									foreach($result as $info){
										$id	 = $info['id'];
										$loan_type	 = $info['loan_type'];
									echo '<option value="'.$id.'">'.strtoupper($loan_type).'</option>';								
									}
									?>
									</select>
							</span>
						</div>	
						<div>
							<span>
								<label>Month:</label>
								<select id = "txtmonth" style = "margin-left:63px;">
									<?php  
									
									$months = array('JANUARY'=>'01' ,'FEBRUARY'=>'02','MARCH'=>'03','APRIL'=>'04','MAY'=>'05','JUNE'=>'06','JULY'=>'07','AUGUST'=>'08','SEPTEMBER'=>'09','OCTOBER'=>'10','NOVEMBER'=>'11','DECEMBER'=>'12');
									
									foreach ($months  as $key =>$value){
									
									echo '<option value="'.$value.'">'.strtoupper($key).'</option>';	
									
									}	
									?>
								</select>
							</span>
						</div>
						<div>
							<span>
								<label>Year:</label>
								<input type='text' id='txtyear' style = 'margin-left:77px; width:162px;' maxlength = '4'/>
							</span>
						</div>
						<div style="margin-top:10px" align="center">
							<input type="button" value="VIEW REPORT" style="width:130px" onclick = "summary_report();">
						</div>
						
						<!-- END OF LOAN SUMMARY -->
						
						<div>
							<span>
								<label><h2>INDIVIDUAL COLLECTIONS</h2><hr></label>
							</span>
						</div>
						<div>
							<span>
								<label>CATEGORY:</label>
								<select id = "category_1" style = "margin-left:40px;">
								<option value='LOAN'>LOAN</option>
								<option value='CASH'>CASH</option>
								<option value='INTERBRANCH'>INTERBRANCH</option>
								</select>
							</span>
						</div>
						<div>
							<span>
								<label>Loan Type:</label>
								<select id = "loan_type_1" style = "margin-left:43px;">
									<?php  
									$db->select("tbl_loan","loan_type");
									$result = $db->getResult();
											
									foreach($result as $info){
										$loan_type	 = $info['loan_type'];
									echo '<option value="'.$loan_type .'">'.strtoupper($loan_type).'</option>';								
									}
									?>
									</select>
							</span>
						</div>	
					

						<div>
							<span>
								<label>Select Lending:</label>
								<select id = 'quad_1' name='quad' style="margin-left:15px;">
									<option value="Quad LC">QUAD LC</option>
									<option value="Laguna LC">LAGUNA LC</option>
								</select>
							</span>
						</div>
						
						<div>
							<span>
								<label>Select Month:</label>
								<select id = "month_1" style = "margin-left:23px;">
									<?php  
									
									$months = array('JANUARY'=>'01' ,'FEBRUARY'=>'02','MARCH'=>'03','APRIL'=>'04','MAY'=>'05','JUNE'=>'06','JULY'=>'07','AUGUST'=>'08','SEPTEMBER'=>'09','OCTOBER'=>'10','NOVEMBER'=>'11','DECEMBER'=>'12');
									
									foreach ($months  as $key =>$value){
									
									echo '<option value="'.$value.'">'.strtoupper($key).'</option>';	
									
									}	
									?>
								</select>
							</span>
						</div>
						<div>
							<span>
								<label>YEAR:</label>
								<input type='text' id='year_1' style = 'margin-left:74px; width:162px;'/>
							</span>
						</div>
						
						
						<div style="margin-top:10px" align="center">
							<input type="button" value="VIEW REPORT" style="width:130px" onclick='individual_report();'>
						</div>
								
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
		"padding":"30px 31px 0px 31px",
		"border-bottom":"4px solid #c95447"
		});
	});	
	
	
	function loan_report(){
	
		var category = $("#category").val();
		var loan_type = $("#loan_type").val();
		var month = $("#month").val();
		var year = $("#year").val();
		var quad = $("#quad").val();
		
		window.open("quad_reports.php?category="+category+"&loan_type="+loan_type+"&month="+month+"&year="+year+"&quad="+quad,'_blank');
	
	}
	
	
	function individual_report(){
	
		var category = $("#category_1").val();
		var loan_type = $("#loan_type_1").val();
		var month = $("#month_1").val();
		var year = $("#year_1").val();
		var quad = $("#quad_1").val();
		
		window.open("individual_report.php?category="+category+"&loan_type="+loan_type+"&month="+month+"&year="+year+"&quad="+quad,'_blank');
	
	}
	
	
	/* LOAN SUMMARY */
	
	function summary_report() {
	
		var lending = $("#txtlending").val();
		var loan_type = $("#txttype").val();
		var month = $("#txtmonth").val();
		var year = $("#txtyear").val();
		
		window.open("summary_report.php?lending="+lending+"&loan_type="+loan_type+"&month="+month+"&year="+year);
		
	}
	
	</script>
	
</body>
</html>