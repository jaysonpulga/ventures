<?php
include('../database.php'); 
 
$db = new Database();  
$db->connect(); 
$action = $_REQUEST["action"];

if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){

	switch($action){


	
	
	case 'load_loan_report';
				
				$category=$_REQUEST['category'];
			
				$loan_type=$_REQUEST['loan_type'];
			
				$month=$_REQUEST['month'];

				$year=$_REQUEST['year'];

				$quad=$_REQUEST['quad'];
						
				$date = $year."-".$month;
				
			
				$rows ='a.date,b.or_no,b.account_no,b.dues,b.penalty_discount,b.rebate,b.discount,b.status,c.principal_amt_1,c.int_income_1,c.terms,c.amount_loan,c.interest_income,substr(c.installment_due,9) as ins_due';
				$where = "a.type = '$category' AND a.or_no = b.or_no AND b.account_no = c.account_no AND c.loan_type_id = d.id AND d.loan_type =  '$loan_type' AND e.lending =  '$quad' AND c.branch_id = e.id AND substring(a.date,1,7) = '$date' ";
				$db->select('collections a, collection_loan b,tbl_ledger c,tbl_loan d, tbl_branch e',$rows,$where,"a.date"); 
				$result = $db->getResult();
				
								
				echo  '{"members":'.json_encode($result).'}';
				
			
	break;
	
	
	
	case 'load_loan_individual';
				
				$category=$_REQUEST['category'];
			
				$loan_type=$_REQUEST['loan_type'];
			
				$month=$_REQUEST['month'];

				$year=$_REQUEST['year'];

				$quad=$_REQUEST['quad'];
						
				$date = $year."-".$month;
				
			
				$rows ='MAX(a.date) as max_date,b.account_no,sum(b.dues) as monthly_pay   ,sum(b.principal),c.terms,c.amount_loan,c.date_released,c.installment_due,d.loan_type,d.interest_rate_3,f.first_name,f.last_name , (sum(b.principal)) as balance' ;
				
				$where = "a.customer_id = f.id AND a.type = '$category' AND a.or_no = b.or_no AND b.account_no = c.account_no AND c.loan_type_id = d.id AND d.loan_type =  '$loan_type' AND e.lending =  '$quad' AND c.branch_id = e.id AND substring(a.date,1,7) = '$date'";
				$db->select('collections a, collection_loan b,tbl_ledger c,tbl_loan d, tbl_branch e,tbl_customer f',$rows,$where,"a.date"); 
				$result = $db->getResult();
				
			
				/*$wherex = "MAX(date) AND customer_id = '5' ";
				
				$rowx = "date";
				$db->select('collections',$rowsx,$wherex); 
				$resultx = $db->getResult();
				print_r($resultx);
				*/
				
				
				//print_r($result);
								
				echo  '{"members":'.json_encode($result).'}';
				
			
	break;
	
	
	
	

	

		
	}
	

}	

?>