<?php
include('../database.php'); 
$db = new Database();  
$db->connect(); 
$action = $_REQUEST["action"];

if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){

	switch($action){
	
	case 'loadAllData';
		$dataArray=array();
		$new_arr=array();
		
		$i=0;
		$sort=$_REQUEST["sort"];
		$sortType=$_REQUEST["sortType"];
		
		$search=trim($_REQUEST['inputsearch']);
		$category1=$_REQUEST['category'];
		
		if($category1 == "name") {
			$category = "CONCAT(b.last_name,',',b.first_name,' ',b.middle_name)";
		}
		else {
			$category = $category1;
		}
		
		$row = "a.id,CONCAT(b.last_name,',',b.first_name,' ',b.middle_name) as customer,c.branch_code,a.customer_name,a.account_no,(a.interest_income+a.amount_loan) as total_loan";
		$where="a.customer_name=b.id and a.branch_id=c.id AND $category LIKE '%".$search."%'";
		
		$db->select('tbl_ledger a,tbl_customer b,tbl_branch c',$row,$where);
		
		$result = $db->getResult();
		
		foreach($result as $key){
			$account_no=$key["account_no"];
			$customer_id=$key["customer_name"];
			
			$row = "sum(dues) as total_paid";
			$where="customer_id=$customer_id and account_no='".$account_no."'";
			
			$db->selectSingle('collection_loan',$row,$where);
			$total_paid = $db->getSingleResult();
			
			$balance=$key["total_loan"]-$total_paid;
			
			$new_arr[$i]=array(
				'id'=> $key["id"],
				'customer_name'=> $key["customer"],
				'branch'=> $key["branch_code"],
				'balance'=> $balance
			);
			
			array_push($dataArray,$new_arr[$i]);
			$i++;
		}
		
		if(count($dataArray) > 0) {
			$sortArray = array();
			
			foreach($dataArray as $data){
				foreach($data as $key=>$value){
					if(!isset($sortArray[$key])){
						$sortArray[$key] = array(); 
					}
					$sortArray[$key][] = $value;
				}
			}
			
			$orderby = $sort;
			if($sortType=="ASC"){
				array_multisort($sortArray[$orderby],SORT_ASC,$dataArray);
			}
			else{
				array_multisort($sortArray[$orderby],SORT_DESC,$dataArray);
			}
		}
		
		echo '{"members":'.json_encode($dataArray).'}';
		
	break;
	
	case 'loadLoanInfo';
		$dataArray=array();
		$i=0;
		$sortType=$_REQUEST["sortType"];
		$sort=$_REQUEST["sort"];
		$id=$_REQUEST["id"];
		
		//$order="$sort $sortType";
		$row = "a.*,CONCAT(b.last_name,',',b.first_name,' ',b.middle_name) as customer,c.province_name,d.city_name,b.customer_subd_brgy as brgy,b.customer_street_num as street,e.loan_type,a.int_income_1";
		$where="a.customer_name=b.id and b.customer_province_id=c.id and b.customer_city_town_id=d.id and a.loan_type_id=e.id and a.id=$id";
		$db->select('tbl_ledger a,tbl_customer b,tbl_province c,tbl_city d,tbl_loan e',$row,$where);
		
		$result = $db->getResult();
		
		echo '{"members":'.json_encode($result).'}';
		
	break;
	
	case 'loadLoanDetails';
		$dataArray=array();
		$i=0;
		$sortType=$_REQUEST["sortType"];
		$sort=$_REQUEST["sort"];
		$customer_id=$_REQUEST["customer_id"];
		$account_no=$_REQUEST["account_no"];
		$terms=$_REQUEST["terms"];
		
		$order="b.date asc";
		$row = "a.id,c.account_no,c.customer_name,b.date,a.or_no,a.dues as amount_paid,(a.rebate+a.discount) as discounts,a.penalty,(c.installment_amount*c.terms) as total_loan,c.amount_loan,c.int_income_1,c.principal_amt_1";
		$where="a.account_no='".$account_no."' and a.customer_id='".$customer_id."' and a.or_no=b.or_no and a.account_no=c.account_no and a.customer_id=c.customer_name";
		$db->select('tbl_ledger c,collection_loan a,collections b',$row,$where,$order);
		
		$result = $db->getResult();
		
		foreach($result as $key){
			$id=$key["id"];
			$account_no=$key["account_no"];
			$customer_id=$key["customer_name"];
			
			$row = "sum(dues) as total_paid";
			$where="customer_id=$customer_id and account_no='".$account_no."' and id=$id";
			
			$db->selectSingle('collection_loan',$row,$where);
			$total_paid = $db->getSingleResult();
			
			$balance=$key["total_loan"]-$total_paid;
			
			
			$new_arr[$i]=array(
				'date_paid'=> $key["date"],
				'or_no'=> $key["or_no"],
				'amount_paid'=> $key["amount_paid"],
				'discount'=> $key["discounts"],
				'penalty'=> $key["penalty"],
				'balance'=> $balance,
				'amount_loan'=> $key["amount_loan"],
				
			);
			
			array_push($dataArray,$new_arr[$i]);
			$i++;
		}
		
		$data = count($dataArray);
		$x=0;
		if($data < $terms) {
			$tr_count = $terms-$data;
			
			for($x=0;$x<$tr_count;$x++) {
				$new_array[$x]=array(
					'date_paid'=> "-",
					'or_no'=> "-",
					'amount_paid'=> "-",
					'discount'=> "-",
					'penalty'=> "-",
					'balance'=> "-"
				);
				
				array_push($dataArray,$new_array[$x]);
			}
			
		}
		
		echo '{"members":'.json_encode($dataArray).'}';
		
	break;
	
	case "loadLoanSummary";
		
		$summary = array();
	
		$lending1 = $_REQUEST["lending"];
		$loan_type = $_REQUEST["loan_type"];
		$month = $_REQUEST["month"];
		$year = $_REQUEST["year"];
		
		if($lending1 == "QuadLC") {
			$lending = "Quad LC";
		}
		if($lending1 == "LagunaLC") {
			$lending = "Laguna LC";
		}
		
		$rows = "*";
		$where = "lending='$lending'";
		$order = "branch_code ASC";
		$db->select("tbl_branch",$rows,$where,$order);
		$res = $db->getResult();
		$i=0;
		
		foreach($res as $data) {
			$branch_id=$data["id"];
			$branch_code=$data["branch_code"];
			$branch_name=$data["branch_name"];
			$lending=$data["lending"];
		
			$rows1 = "SUM(a.amount_loan) as this_amount,COUNT(a.account_no) as no_acct,SUBSTR(a.date_released,6,2) as month,SUBSTR(a.date_released,1,4) as year";
			$where1 = "SUBSTR(a.date_released,6,2)=$month AND SUBSTR(a.date_released,1,4)=$year AND a.branch_id=$branch_id AND a.loan_type_id=b.id AND b.id=$loan_type GROUP BY a.branch_id";
			$db->select("tbl_ledger a, tbl_loan b",$rows1,$where1);
			$result_loan = $db->getResult();
			
			
			if($month=="01") {
				$last_month = "12";
				$last_year = $year-1;
			}
			else {
				$last_month = $month-1;
				$last_year = $year;
				if(strlen($last_month)== 1) {
					$last_month='0'.$last_month;
				}
				else {
					$last_month=$last_month;
				}
			}
			//echo $last_month;
			
			$row_last = "SUM(a.amount_loan) as last_amount,COUNT(a.account_no) as no_acct_last,SUBSTR(a.date_released,6,2) as last_month,SUBSTR(a.date_released,1,4) as last_year";
			$where_last = "SUBSTR(a.date_released,6,2)=$last_month AND SUBSTR(a.date_released,1,4)=$last_year AND a.branch_id=$branch_id AND a.loan_type_id=b.id AND b.id=$loan_type GROUP BY a.branch_id";
			$db->select("tbl_ledger a, tbl_loan b",$row_last,$where_last);
			$result_last = $db->getResult();
			
			if(count($result_loan) > 0){
				foreach($result_loan as $data_loan) {
					$this_amount=$data_loan['this_amount'];
					$no_acct=$data_loan['no_acct'];
					$data_month=$data_loan['month'];
					$data_year=$data_loan['year'];
					
					if(count($result_last) > 0) {
						foreach($result_last as $data_last) {
							$last_amount=$data_last['last_amount'];
							$no_acct_last=$data_last['no_acct_last'];
							$last_month=$data_last['last_month'];
							$last_year=$data_last['last_year'];
							
							$new_array[$i]=array(
								'branch_name'=> $branch_name,
								'this_amount'=> $this_amount,
								'no_acct'=> $no_acct,
								'month'=> $data_month,
								'year'=> $data_year,
								'lending'=> $lending,
								'last_amount'=> $last_amount,
								'no_acct_last'=> $no_acct_last,
								'last_month'=> $last_month,
								'last_year'=> $last_year
							);
						}
					}
					else {
						$last_amount='-';
						$no_acct_last='-';
						$last_month='-';
						$last_year='-';
						
						$new_array[$i]=array(
							'branch_name'=> $branch_name,
							'this_amount'=> $this_amount,
							'no_acct'=> $no_acct,
							'month'=> $data_month,
							'year'=> $data_year,
							'lending'=> $lending,
							'last_amount'=> $last_amount,
							'no_acct_last'=> $no_acct_last,
							'last_month'=> $last_month,
							'last_year'=> $last_year
						);
						
					}
				}
			}
			else{
			
				$this_amount='-';
				$no_acct='-';
				$data_month='-';
				$data_year='-';
				
				if(count($result_last) > 0) {
					foreach($result_last as $data_last) {
						$last_amount=$data_last['last_amount'];
						$no_acct_last=$data_last['no_acct_last'];
						$last_month=$data_last['last_month'];
						$last_year=$data_last['last_year'];
						
						$new_array[$i]=array(
							'branch_name'=> $branch_name,
							'this_amount'=> $this_amount,
							'no_acct'=> $no_acct,
							'month'=> $data_month,
							'year'=> $data_year,
							'lending'=> $lending,
							'last_amount'=> $last_amount,
							'no_acct_last'=> $no_acct_last,
							'last_month'=> $last_month,
							'last_year'=> $last_year
						);
					}
				}
				else {
					$last_amount='-';
					$no_acct_last='-';
					$last_month='-';
					$last_year='-';
					
					$new_array[$i]=array(
						'branch_name'=> $branch_name,
						'this_amount'=> $this_amount,
						'no_acct'=> $no_acct,
						'month'=> $data_month,
						'year'=> $data_year,
						'lending'=> $lending,
						'last_amount'=> $last_amount,
						'no_acct_last'=> $no_acct_last,
						'last_month'=> $last_month,
						'last_year'=> $last_year
					);
					
				}
			
			}
			
			array_push($summary,$new_array[$i]);
			$i++;
		
		}
		
		echo '{"members":'.json_encode($summary).'}';
	
	break;
	
	}
	
}


?>