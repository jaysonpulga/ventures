-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 09, 2014 at 12:48 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ventures`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category`) VALUES
(1, 'motorcycle'),
(2, 'parts'),
(3, 'promo item'),
(4, 'consumables');

-- --------------------------------------------------------

--
-- Table structure for table `collections`
--

CREATE TABLE IF NOT EXISTS `collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `or_no` varchar(25) NOT NULL,
  `customer_id` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `date` varchar(25) NOT NULL,
  `branch_code` varchar(15) NOT NULL,
  `type` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `collections`
--

INSERT INTO `collections` (`id`, `or_no`, `customer_id`, `address`, `date`, `branch_code`, `type`) VALUES
(1, '123', '5', 'Aurora, Isabela', '2014-05-08', 'VSQ', 'LOAN'),
(2, '456', '9', 'Alcala, Ilocos Sur', '2014-05-08', '3SS', 'CASH'),
(3, '891', '13', '1431 ST Delpilat, Calamba City, Laguna', '2014-05-07', 'RED', 'INTERBRANCH'),
(6, '001', '1', 'Manila, Ilocos Sur', '2014-05-09', '3SY', 'LOAN');

-- --------------------------------------------------------

--
-- Table structure for table `collection_cash`
--

CREATE TABLE IF NOT EXISTS `collection_cash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `or_no` varchar(20) NOT NULL,
  `stock_id` varchar(10) NOT NULL,
  `category` varchar(5) NOT NULL,
  `type` varchar(30) NOT NULL,
  `amount` int(20) NOT NULL,
  `qty` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `collection_cash`
--


-- --------------------------------------------------------

--
-- Table structure for table `collection_interbranch`
--

CREATE TABLE IF NOT EXISTS `collection_interbranch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `or_no` varchar(20) NOT NULL,
  `remarks` varchar(30) NOT NULL,
  `amount` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `collection_interbranch`
--

INSERT INTO `collection_interbranch` (`id`, `or_no`, `remarks`, `amount`) VALUES
(3, '891', 'loan payment', 5000),
(4, '891', 'DOWN PAYMENT', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `collection_loan`
--

CREATE TABLE IF NOT EXISTS `collection_loan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `or_no` varchar(20) NOT NULL,
  `dues` int(20) NOT NULL,
  `penalty` int(20) NOT NULL,
  `rebate` int(20) NOT NULL,
  `discount` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `collection_loan`
--

INSERT INTO `collection_loan` (`id`, `or_no`, `dues`, `penalty`, `rebate`, `discount`) VALUES
(1, '123', 2500, 0, 300, 100),
(4, '001', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_details`
--

CREATE TABLE IF NOT EXISTS `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` int(11) NOT NULL,
  `item_type` varchar(50) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `selling_price` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `invoice_details`
--

INSERT INTO `invoice_details` (`id`, `invoice_no`, `item_type`, `item_id`, `qty`, `selling_price`) VALUES
(20, 105, 'parts', 18, 3, 800),
(21, 105, 'parts', 24, 5, 3000),
(22, 123, 'consumables', 24, 2, 0),
(23, 123, 'consumables', 23, 1, 0),
(24, 108, 'motorcycle', 22, 1, 200),
(25, 777, 'motorcycle', 24, 1, 20);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order`
--

CREATE TABLE IF NOT EXISTS `purchase_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_num` varchar(20) NOT NULL,
  `supplier` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `terms` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `purchase_order`
--

INSERT INTO `purchase_order` (`id`, `po_num`, `supplier`, `date`, `terms`) VALUES
(1, '1', '2', '2014-04-21', 12),
(3, '3', '2', '2014-04-15', 12),
(9, '1051', '3', '2014-05-02', 2);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_details`
--

CREATE TABLE IF NOT EXISTS `purchase_order_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_num` varchar(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `item` varchar(20) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_cost` double NOT NULL,
  `branch` varchar(20) NOT NULL,
  `sr_num` varchar(20) NOT NULL,
  `stock_id` int(11) NOT NULL,
  `color` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `purchase_order_details`
--

INSERT INTO `purchase_order_details` (`id`, `po_num`, `category`, `brand`, `item`, `qty`, `unit_cost`, `branch`, `sr_num`, `stock_id`, `color`) VALUES
(39, '1', '1', '2', '4', 2, 200, '3SY', '101', 57, 'red'),
(40, '1', '1', '5', '0', 1, 3, '3SY', '101', 59, '2'),
(41, '1', '1', '1', '2', 5, 7500, 'VSQ', 'AB101', 33, 'red'),
(37, '1', '2', '64', '1', 10, 200, '3SY', '101', 56, ''),
(38, '1', '3', '37', '0', 1, 1, '3SY', '101', 58, ''),
(35, '1051', '1', '1', '28', 2, 0, '3SY', '', 0, ''),
(36, '1', '1', '1', '1', 2, 1150, '3SY', 'MARK12', 50, 'red'),
(34, '1051', '4', '56', '14', 2, 5000, 'RED', 'AAA', 55, ''),
(33, '1051', '1', '1', '3', 5, 9500, '3SY', '', 0, 'red'),
(32, '1051', '1', '3', '30', 2, 3000, 'VSQ', 'MARK12', 52, 'green'),
(42, '1', '1', '50', '32', 3, 3000, 'VSQ', 'MARK12', 51, 'brown'),
(43, '1', '1', '1', '3', 5, 9500, 'RED', 'AAA', 46, 'blue'),
(44, '1', '3', '58', '14', 5, 0, 'RED', 'AAA', 54, '');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_return`
--

CREATE TABLE IF NOT EXISTS `purchase_return` (
  `id_pr` int(11) NOT NULL AUTO_INCREMENT,
  `pr_num` varchar(20) NOT NULL,
  `supplier` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`id_pr`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `purchase_return`
--

INSERT INTO `purchase_return` (`id_pr`, `pr_num`, `supplier`, `date`, `remarks`) VALUES
(9, 'SAM12', '6', '2014-04-28', 'EWAN ko'),
(10, 'OKAY102', '2', '2014-04-29', 'return '),
(11, 'TRY45', '2', '2014-04-30', 'SUZUKI 3 products'),
(12, 'TRY46', '2', '2014-04-30', 'Sample po muna');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_return_details`
--

CREATE TABLE IF NOT EXISTS `purchase_return_details` (
  `id_return` int(11) NOT NULL AUTO_INCREMENT,
  `pr_num` varchar(20) NOT NULL,
  `stock_id` varchar(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `item` varchar(20) NOT NULL,
  `serial_no` varchar(50) NOT NULL,
  `frame_no` varchar(50) NOT NULL,
  `color` varchar(20) NOT NULL,
  `branch` varchar(20) NOT NULL,
  `qty` int(20) NOT NULL,
  PRIMARY KEY (`id_return`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `purchase_return_details`
--

INSERT INTO `purchase_return_details` (`id_return`, `pr_num`, `stock_id`, `category`, `brand`, `item`, `serial_no`, `frame_no`, `color`, `branch`, `qty`) VALUES
(53, 'TRY46', '22', '2', '63', '26', 'SKKK12', '', '', '5', 0),
(54, 'TRY46', '24', '2', '64', '1', 'ABCDEF', '', '', '4', 1),
(52, 'TRY46', '17', '2', '63', '26', '3QM-H2110-K2', '', '', '5', 3);

-- --------------------------------------------------------

--
-- Table structure for table `sales_invoice`
--

CREATE TABLE IF NOT EXISTS `sales_invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` int(11) NOT NULL,
  `date_issued` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `terms` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `sales_invoice`
--

INSERT INTO `sales_invoice` (`id`, `invoice_no`, `date_issued`, `customer_id`, `terms`, `address`) VALUES
(1, 101, '2014-04-28', 3, 12, 'Mandaluyong City, Metro Manila'),
(3, 102, '2014-04-28', 30, 12, '120, Buenavista, Quezon'),
(4, 105, '2014-05-05', 4, 12, 'Manila, Ilocos Sur'),
(5, 115, '2014-05-05', 5, 12, 'Lipa City, Batangas'),
(6, 108, '2014-05-07', 5, 10, 'dsada sdada, Manila, Metro Manila'),
(7, 123, '2014-05-07', 8, 10, 'Aurora, Isabela'),
(8, 777, '2014-05-08', 11, 15, 'Abucay, Bataan');

-- --------------------------------------------------------

--
-- Table structure for table `sales_return`
--

CREATE TABLE IF NOT EXISTS `sales_return` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sr_no` varchar(3) NOT NULL,
  `date_returned` varchar(20) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `sales_return`
--

INSERT INTO `sales_return` (`id`, `sr_no`, `date_returned`, `customer_id`, `address`) VALUES
(2, '112', '2014-04-30', 1, 'St. Peter Subd., Lipa City, Batangas'),
(3, '101', '2014-05-02', 29, '610 Pinagkawitan, Lipa City, Batangas'),
(4, '111', '2014-05-02', 4, 'Cuyapo, Nueva Ecija'),
(5, '165', '2014-05-05', 2, 'bvbfgv, Manila, Ilocos Sur');

-- --------------------------------------------------------

--
-- Table structure for table `sr_details`
--

CREATE TABLE IF NOT EXISTS `sr_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sr_no` varchar(3) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `item_type` varchar(20) NOT NULL,
  `item_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `selling_price` double NOT NULL,
  `reason` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sr_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE IF NOT EXISTS `stocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dr_no` int(11) NOT NULL,
  `date` date NOT NULL,
  `branch` varchar(20) NOT NULL,
  `supplier` varchar(20) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`id`, `dr_no`, `date`, `branch`, `supplier`, `remarks`, `type`) VALUES
(1, 101, '2014-04-14', '2', '3', 'asas', 1),
(5, 102, '2014-04-01', '3', '2', 'Complete with tool set,battery', 1),
(6, 103, '2014-04-02', '1', '3', 'Complete with tool set,battery', 1),
(8, 111, '2014-04-12', '5', '8', '', 2),
(25, 105, '2014-04-30', '4', '2', '1', 2),
(26, 105, '2014-04-29', '4', '2', '1', 1),
(27, 1, '2014-05-02', '1', '2', '', 2),
(22, 303, '2014-04-29', '2', '2', '3', 3),
(28, 12345, '2014-05-03', '3', '3', 'SAMPLE muna', 4),
(29, 6789, '2014-05-03', '2', '8', 'sample', 4),
(30, 222, '2014-05-09', '4', '8', 'OKAY', 1);

-- --------------------------------------------------------

--
-- Table structure for table `stocks_consumables`
--

CREATE TABLE IF NOT EXISTS `stocks_consumables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dr_no` int(11) NOT NULL,
  `brand` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `serial_no` varchar(30) NOT NULL,
  `quantity` int(20) NOT NULL,
  `remaining` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `stocks_consumables`
--

INSERT INTO `stocks_consumables` (`id`, `dr_no`, `brand`, `item`, `serial_no`, `quantity`, `remaining`) VALUES
(23, 12345, 56, 14, 'KAWA12', 5, 0),
(24, 6789, 56, 14, 'KAWA12', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `stocks_motors`
--

CREATE TABLE IF NOT EXISTS `stocks_motors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dr_no` int(11) NOT NULL,
  `brand` int(11) NOT NULL,
  `model` int(11) NOT NULL,
  `engine_no` varchar(30) NOT NULL,
  `frame_no` varchar(30) NOT NULL,
  `color` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `stocks_motors`
--

INSERT INTO `stocks_motors` (`id`, `dr_no`, `brand`, `model`, `engine_no`, `frame_no`, `color`, `status`) VALUES
(21, 103, 1, 1, 'KYZZ201 ', 'KY202', 'GRAY', 'TRANSFERRED'),
(20, 101, 1, 3, 'CCC101', 'CCC101', 'BLUE', 'ON HAND'),
(18, 101, 1, 1, 'KYY30E007509', 'KYY30007576', 'BLUE', 'PO RETURNED'),
(19, 101, 1, 2, 'XXX101', 'XXX101', 'RED', 'SALES RETURNED'),
(22, 102, 50, 31, 'ZZZ303', 'YYY303', 'PINK', 'SOLD'),
(23, 102, 1, 2, 'ABC', '123', 'RED', 'TRANSFERRED'),
(24, 222, 1, 28, 'ZZZZ123', 'ZZZZ123', 'PINK', 'SOLD'),
(25, 222, 1, 1, 'WWW123', 'WWW456', 'BLUE', 'ON HAND');

-- --------------------------------------------------------

--
-- Table structure for table `stocks_parts`
--

CREATE TABLE IF NOT EXISTS `stocks_parts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dr_no` int(11) NOT NULL,
  `brand` int(11) NOT NULL,
  `item` varchar(30) NOT NULL,
  `serial_no` varchar(30) NOT NULL,
  `quantity` int(20) NOT NULL,
  `remaining` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `stocks_parts`
--

INSERT INTO `stocks_parts` (`id`, `dr_no`, `brand`, `item`, `serial_no`, `quantity`, `remaining`) VALUES
(18, 111, 63, '26', '3QM-H2110-K2', 5, 2),
(24, 1, 64, '1', 'ABCDEF', 10, 5),
(22, 111, 63, '26', 'SKKK12', 10, 10),
(23, 105, 64, '1', 'ABC12345', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `stocks_promo`
--

CREATE TABLE IF NOT EXISTS `stocks_promo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dr_no` int(11) NOT NULL,
  `brand` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `serial_no` varchar(30) NOT NULL,
  `color` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `stocks_promo`
--

INSERT INTO `stocks_promo` (`id`, `dr_no`, `brand`, `item`, `serial_no`, `color`, `status`) VALUES
(20, 303, 42, 18, 'SAMPLE12', 'RED', 'ON HAND'),
(19, 303, 38, 16, 'ABC12345', 'BLUE', 'TRANSFERRED');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_branch`
--

CREATE TABLE IF NOT EXISTS `tbl_branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_code` varchar(50) NOT NULL,
  `branch_name` varchar(50) NOT NULL,
  `lending` varchar(20) NOT NULL,
  `registration_fee` varchar(10) NOT NULL,
  `region_id` int(50) NOT NULL,
  `province_id` int(50) NOT NULL,
  `city_town_id` int(50) NOT NULL,
  `subd_brgy` varchar(50) NOT NULL,
  `street_num` varchar(30) NOT NULL,
  `tel_no` varchar(20) NOT NULL,
  `fax_no` varchar(20) NOT NULL,
  `email_add` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_branch`
--

INSERT INTO `tbl_branch` (`id`, `branch_code`, `branch_name`, `lending`, `registration_fee`, `region_id`, `province_id`, `city_town_id`, `subd_brgy`, `street_num`, `tel_no`, `fax_no`, `email_add`) VALUES
(1, '3SS', '3''S Suzuki', 'Quad LC', '1400', 5, 25, 959, '112', 'Tambo', '756-0700', '', 'ria.ilagan29@gmail.com'),
(2, '3SY', '3S YAMAHA CANDELARIA', 'Quad LC', '1400', 4, 20, 1291, '', '', '', '', ''),
(3, 'LCB', 'LUCENA-BAYAN', 'Quad LC', '1400', 4, 20, 1283, '', '', '', '', ''),
(4, 'RED', 'LUCENA-RED-V', 'Quad LC', '1400', 4, 20, 1283, '', '', '', '', ''),
(5, 'VSQ', 'Ventures Sariaya', 'Laguna LC', '1400', 4, 20, 1320, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_city`
--

CREATE TABLE IF NOT EXISTS `tbl_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `province_id` int(11) NOT NULL,
  `province` varchar(50) NOT NULL,
  `city_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1696 ;

--
-- Dumping data for table `tbl_city`
--

INSERT INTO `tbl_city` (`id`, `province_id`, `province`, `city_name`) VALUES
(1, 77, 'Metro Manila', 'Caloocan City'),
(2, 77, 'Metro Manila', 'Las Pinas City'),
(3, 77, 'Metro Manila', 'Makati City'),
(4, 77, 'Metro Manila', 'Malabon City'),
(5, 77, 'Metro Manila', 'Mandaluyong City'),
(6, 77, 'Metro Manila', 'Manila'),
(7, 77, 'Metro Manila', 'Marikina City'),
(8, 77, 'Metro Manila', 'Muntinlupa City'),
(9, 77, 'Metro Manila', 'Navotas City'),
(10, 77, 'Metro Manila', 'Parañaque City'),
(11, 77, 'Metro Manila', 'Pasay City'),
(12, 77, 'Metro Manila', 'Pasig City'),
(13, 77, 'Metro Manila', 'Pateros'),
(14, 77, 'Metro Manila', 'Quezon City'),
(15, 77, 'Metro Manila', 'San Juan City'),
(16, 77, 'Metro Manila', 'Taguig City'),
(17, 77, 'Metro Manila', 'Valenzuela City'),
(18, 78, 'Abra', 'Bangued'),
(19, 78, 'Abra', 'Boliney'),
(20, 78, 'Abra', 'Bucay'),
(21, 78, 'Abra', 'Bucloc'),
(22, 78, 'Abra', 'Daguioman'),
(23, 78, 'Abra', 'Danglas'),
(24, 78, 'Abra', 'Dolores'),
(25, 78, 'Abra', 'La Paz'),
(26, 78, 'Abra', 'Lacub'),
(27, 78, 'Abra', 'Lagangilang'),
(28, 78, 'Abra', 'Lagayan'),
(29, 78, 'Abra', 'Langiden'),
(30, 78, 'Abra', 'Licuan-Baay'),
(31, 78, 'Abra', 'Luba'),
(32, 78, 'Abra', 'Malibcong'),
(33, 78, 'Abra', 'Manabo'),
(34, 78, 'Abra', 'Peñarrubia'),
(35, 78, 'Abra', 'Pidigan'),
(36, 78, 'Abra', 'Pilar'),
(37, 78, 'Abra', 'Sallapadan'),
(38, 78, 'Abra', 'San Isidro'),
(39, 78, 'Abra', 'San Juan'),
(40, 78, 'Abra', 'San Quintin'),
(41, 78, 'Abra', 'Tayum'),
(42, 78, 'Abra', 'Tineg'),
(43, 78, 'Abra', 'Tubo'),
(44, 78, 'Abra', 'Villaviciosa'),
(45, 66, 'Agusan del Norte', 'Butuan City'),
(46, 66, 'Agusan del Norte', 'Cabadbaran City'),
(47, 66, 'Agusan del Norte', 'Buenavista'),
(48, 66, 'Agusan del Norte', 'Carmen'),
(49, 66, 'Agusan del Norte', 'Jabonga'),
(50, 66, 'Agusan del Norte', 'Kitcharao'),
(51, 66, 'Agusan del Norte', 'Las Nieves'),
(52, 66, 'Agusan del Norte', 'Magallanes'),
(53, 66, 'Agusan del Norte', 'Nasipit'),
(54, 66, 'Agusan del Norte', 'Remedios T. Romualdez'),
(55, 66, 'Agusan del Norte', 'Santiago'),
(56, 66, 'Agusan del Norte', 'Tubay'),
(57, 67, 'Agusan del Sur', 'Bayugan City'),
(58, 67, 'Agusan del Sur', 'Bunawan'),
(59, 67, 'Agusan del Sur', 'Esperanza'),
(60, 67, 'Agusan del Sur', 'La Paz'),
(61, 67, 'Agusan del Sur', 'Loreto'),
(62, 67, 'Agusan del Sur', 'Prosperidad'),
(63, 67, 'Agusan del Sur', 'Rosario'),
(64, 67, 'Agusan del Sur', 'San Francisco'),
(65, 67, 'Agusan del Sur', 'San Luis'),
(66, 67, 'Agusan del Sur', 'Santa Josefa'),
(67, 67, 'Agusan del Sur', 'Sibagat'),
(68, 67, 'Agusan del Sur', 'Talacogon'),
(69, 67, 'Agusan del Sur', 'Trento'),
(70, 67, 'Agusan del Sur', 'Veruela'),
(71, 33, 'Aklan', 'Altavas'),
(72, 33, 'Aklan', 'Balete'),
(73, 33, 'Aklan', 'Banga'),
(74, 33, 'Aklan', 'Batan'),
(75, 33, 'Aklan', 'Buruanga'),
(76, 33, 'Aklan', 'Ibajay'),
(77, 33, 'Aklan', 'Kalibo'),
(78, 33, 'Aklan', 'Lezo'),
(79, 33, 'Aklan', 'Libacao'),
(80, 33, 'Aklan', 'Madalag'),
(81, 33, 'Aklan', 'Makato'),
(82, 33, 'Aklan', 'Malay'),
(83, 33, 'Aklan', 'Malinao'),
(84, 33, 'Aklan', 'Nabas'),
(85, 33, 'Aklan', 'New Washington'),
(86, 33, 'Aklan', 'Numancia'),
(87, 33, 'Aklan', 'Tangalan'),
(88, 27, 'Albay', 'Legaspi City'),
(89, 27, 'Albay', 'Ligao City'),
(90, 27, 'Albay', 'Tabaco City'),
(91, 27, 'Albay', 'Bacacay'),
(92, 27, 'Albay', 'Camalig'),
(93, 27, 'Albay', 'Daraga'),
(94, 27, 'Albay', 'Guinobatan'),
(95, 27, 'Albay', 'Jovellar'),
(96, 27, 'Albay', 'Libon'),
(97, 27, 'Albay', 'Malilipot'),
(98, 27, 'Albay', 'Malinao'),
(99, 27, 'Albay', 'Manito'),
(100, 27, 'Albay', 'Oas'),
(101, 27, 'Albay', 'Pio Duran'),
(102, 27, 'Albay', 'Polangui'),
(103, 27, 'Albay', 'Rapu-Rapu'),
(104, 27, 'Albay', 'Santo Domingo'),
(105, 34, 'Antique', 'Anini-y'),
(106, 34, 'Antique', 'Barbaza'),
(107, 34, 'Antique', 'Belison'),
(108, 34, 'Antique', 'Bugasong'),
(109, 34, 'Antique', 'Caluya'),
(110, 34, 'Antique', 'Culasi'),
(111, 34, 'Antique', 'Hamtic'),
(112, 34, 'Antique', 'Laua-an'),
(113, 34, 'Antique', 'Libertad'),
(114, 34, 'Antique', 'Pandan'),
(115, 34, 'Antique', 'Patnongon'),
(116, 34, 'Antique', 'San Jose'),
(117, 34, 'Antique', 'San Remigio'),
(118, 34, 'Antique', 'Sebaste'),
(119, 34, 'Antique', 'Sibalom'),
(120, 34, 'Antique', 'Tibiao'),
(121, 34, 'Antique', 'Tobias Fornier'),
(122, 34, 'Antique', 'Valderrama'),
(123, 79, 'Apayao', 'Calanasan'),
(124, 79, 'Apayao', 'Conner'),
(125, 79, 'Apayao', 'Flora'),
(126, 79, 'Apayao', 'Kabugao'),
(127, 79, 'Apayao', 'Luna'),
(128, 79, 'Apayao', 'Pudtol'),
(129, 79, 'Apayao', 'Santa Marcela'),
(130, 10, 'Aurora', 'Baler'),
(131, 10, 'Aurora', 'Casiguran'),
(132, 10, 'Aurora', 'Dilasag'),
(133, 10, 'Aurora', 'Dinalungan'),
(134, 10, 'Aurora', 'Dingalan'),
(135, 10, 'Aurora', 'Dipaculao'),
(136, 10, 'Aurora', 'Maria Aurora'),
(137, 10, 'Aurora', 'San Luis'),
(138, 71, 'Basilan', 'Isabela City'),
(139, 71, 'Basilan', 'Lamitan City'),
(140, 71, 'Basilan', 'Akbar'),
(141, 71, 'Basilan', 'Al-Barka'),
(142, 71, 'Basilan', 'Hadji Mohammad Ajul'),
(143, 71, 'Basilan', 'Hadji Muhtamad'),
(144, 71, 'Basilan', 'Lantawan'),
(145, 71, 'Basilan', 'Maluso'),
(146, 71, 'Basilan', 'Sumisip'),
(147, 71, 'Basilan', 'Tabuan-Lasa'),
(148, 71, 'Basilan', 'Tipo-Tipo'),
(149, 71, 'Basilan', 'Tuburan'),
(150, 71, 'Basilan', 'Ungkaya Pukan'),
(151, 11, 'Bataan', 'Balanga City'),
(152, 11, 'Bataan', 'Abucay'),
(153, 11, 'Bataan', 'Bagac'),
(154, 11, 'Bataan', 'Dinalupihan'),
(155, 11, 'Bataan', 'Hermosa'),
(156, 11, 'Bataan', 'Limay'),
(157, 11, 'Bataan', 'Mariveles'),
(158, 11, 'Bataan', 'Morong'),
(159, 11, 'Bataan', 'Orani'),
(160, 11, 'Bataan', 'Orion'),
(161, 11, 'Bataan', 'Pilar'),
(162, 11, 'Bataan', 'Samal'),
(163, 5, 'Batanes', 'Basco'),
(164, 5, 'Batanes', 'Itbayat'),
(165, 5, 'Batanes', 'Ivana'),
(166, 5, 'Batanes', 'Mahatao'),
(167, 5, 'Batanes', 'Sabtang'),
(168, 5, 'Batanes', 'Uyugan'),
(169, 17, 'Batangas', 'Batangas City'),
(170, 17, 'Batangas', 'Lipa City'),
(171, 17, 'Batangas', 'Tanauan City'),
(172, 17, 'Batangas', 'Agoncillo'),
(173, 17, 'Batangas', 'Alitagtag'),
(174, 17, 'Batangas', 'Balayan'),
(175, 17, 'Batangas', 'Balete'),
(176, 17, 'Batangas', 'Bauan'),
(177, 17, 'Batangas', 'Calaca'),
(178, 17, 'Batangas', 'Calatagan'),
(179, 17, 'Batangas', 'Cuenca'),
(180, 17, 'Batangas', 'Ibaan'),
(181, 17, 'Batangas', 'Laurel'),
(182, 17, 'Batangas', 'Lemery'),
(183, 17, 'Batangas', 'Lian'),
(184, 17, 'Batangas', 'Lobo'),
(185, 17, 'Batangas', 'Mabini'),
(186, 17, 'Batangas', 'Malvar'),
(187, 17, 'Batangas', 'Mataas na Kahoy'),
(188, 17, 'Batangas', 'Nasugbu'),
(189, 17, 'Batangas', 'Padre Garcia'),
(190, 17, 'Batangas', 'Rosario'),
(191, 17, 'Batangas', 'San Jose'),
(192, 17, 'Batangas', 'San Juan'),
(193, 17, 'Batangas', 'San Luis'),
(194, 17, 'Batangas', 'San Nicolas'),
(195, 17, 'Batangas', 'San Pascual'),
(196, 17, 'Batangas', 'Santa Teresita'),
(197, 17, 'Batangas', 'Santo Tomas'),
(198, 17, 'Batangas', 'Taal'),
(199, 17, 'Batangas', 'Talisay'),
(200, 17, 'Batangas', 'Taysan'),
(201, 17, 'Batangas', 'Tingloy'),
(202, 17, 'Batangas', 'Tuy'),
(203, 80, 'Benguet', 'Baguio City'),
(204, 80, 'Benguet', 'Atok'),
(205, 80, 'Benguet', 'Bakun'),
(206, 80, 'Benguet', 'Bokod'),
(207, 80, 'Benguet', 'Buguias'),
(208, 80, 'Benguet', 'Itogon'),
(209, 80, 'Benguet', 'Kabayan'),
(210, 80, 'Benguet', 'Kapangan'),
(211, 80, 'Benguet', 'Kibungan'),
(212, 80, 'Benguet', 'La Trinidad'),
(213, 80, 'Benguet', 'Mankayan'),
(214, 80, 'Benguet', 'Sablan'),
(215, 80, 'Benguet', 'Tuba'),
(216, 80, 'Benguet', 'Tublay'),
(217, 43, 'Biliran', 'Almeria'),
(218, 43, 'Biliran', 'Biliran'),
(219, 43, 'Biliran', 'Cabucgayan'),
(220, 43, 'Biliran', 'Caibiran'),
(221, 43, 'Biliran', 'Culaba'),
(222, 43, 'Biliran', 'Kawayan'),
(223, 43, 'Biliran', 'Maripipi'),
(224, 43, 'Biliran', 'Naval'),
(225, 39, 'Bohol', 'Alburquerque'),
(226, 39, 'Bohol', 'Alicia'),
(227, 39, 'Bohol', 'Anda'),
(228, 39, 'Bohol', 'Antequera'),
(229, 39, 'Bohol', 'Baclayon'),
(230, 39, 'Bohol', 'Balilihan'),
(231, 39, 'Bohol', 'Batuan'),
(232, 39, 'Bohol', 'Bien Unido'),
(233, 39, 'Bohol', 'Bilar'),
(234, 39, 'Bohol', 'Buenavista'),
(235, 39, 'Bohol', 'Calape'),
(236, 39, 'Bohol', 'Candijay'),
(237, 39, 'Bohol', 'Carmen'),
(238, 39, 'Bohol', 'Catigbian'),
(239, 39, 'Bohol', 'Clarin'),
(240, 39, 'Bohol', 'Corella'),
(241, 39, 'Bohol', 'Cortes'),
(242, 39, 'Bohol', 'Dagohoy'),
(243, 39, 'Bohol', 'Danao'),
(244, 39, 'Bohol', 'Dauis'),
(245, 39, 'Bohol', 'Dimiao'),
(246, 39, 'Bohol', 'Duero'),
(247, 39, 'Bohol', 'Garcia Hernandez'),
(248, 39, 'Bohol', 'Getafe'),
(249, 39, 'Bohol', 'Guindulman'),
(250, 39, 'Bohol', 'Inabanga'),
(251, 39, 'Bohol', 'Jagna'),
(252, 39, 'Bohol', 'Lila'),
(253, 39, 'Bohol', 'Loay'),
(254, 39, 'Bohol', 'Loboc'),
(255, 39, 'Bohol', 'Loon'),
(256, 39, 'Bohol', 'Mabini'),
(257, 39, 'Bohol', 'Maribojoc'),
(258, 39, 'Bohol', 'Panglao'),
(259, 39, 'Bohol', 'Pilar'),
(260, 39, 'Bohol', 'President Carlos P. Garcia'),
(261, 39, 'Bohol', 'Sagbayan'),
(262, 39, 'Bohol', 'San Isidro'),
(263, 39, 'Bohol', 'San Miguel'),
(264, 39, 'Bohol', 'Sevilla'),
(265, 39, 'Bohol', 'Sierra Bullones'),
(266, 39, 'Bohol', 'Sikatuna'),
(267, 39, 'Bohol', 'Talibon'),
(268, 39, 'Bohol', 'Trinidad'),
(269, 39, 'Bohol', 'Tubigon'),
(270, 39, 'Bohol', 'Ubay'),
(271, 39, 'Bohol', 'Valencia'),
(272, 52, 'Bukidnon', 'Malaybalay City'),
(273, 52, 'Bukidnon', 'Valencia City'),
(274, 52, 'Bukidnon', 'Baungon'),
(275, 52, 'Bukidnon', 'Cabanglasan'),
(276, 52, 'Bukidnon', 'Damulog'),
(277, 52, 'Bukidnon', 'Dangcagan'),
(278, 52, 'Bukidnon', 'Don Carlos'),
(279, 52, 'Bukidnon', 'Impasug-ong'),
(280, 52, 'Bukidnon', 'Kadingilan'),
(281, 52, 'Bukidnon', 'Kalilangan'),
(282, 52, 'Bukidnon', 'Kibawe'),
(283, 52, 'Bukidnon', 'Kitaotao'),
(284, 52, 'Bukidnon', 'Lantapan'),
(285, 52, 'Bukidnon', 'Libona'),
(286, 52, 'Bukidnon', 'Malitbog'),
(287, 52, 'Bukidnon', 'Manolo Fortich'),
(288, 52, 'Bukidnon', 'Maramag'),
(289, 52, 'Bukidnon', 'Pangantucan'),
(290, 52, 'Bukidnon', 'Quezon'),
(291, 52, 'Bukidnon', 'San Fernando'),
(292, 52, 'Bukidnon', 'Sumilao'),
(293, 52, 'Bukidnon', 'Talakag'),
(294, 12, 'Bulacan', 'Malolos City'),
(295, 12, 'Bulacan', 'Meycauayan City'),
(296, 12, 'Bulacan', 'San Jose del Monte City'),
(297, 12, 'Bulacan', 'Angat'),
(298, 12, 'Bulacan', 'Balagtas'),
(299, 12, 'Bulacan', 'Baliuag'),
(300, 12, 'Bulacan', 'Bocaue'),
(301, 12, 'Bulacan', 'Bulacan'),
(302, 12, 'Bulacan', 'Bustos'),
(303, 12, 'Bulacan', 'Calumpit'),
(304, 12, 'Bulacan', 'Do?a Remedios Trinidad'),
(305, 12, 'Bulacan', 'Guiguinto'),
(306, 12, 'Bulacan', 'Hagonoy'),
(307, 12, 'Bulacan', 'Marilao'),
(308, 12, 'Bulacan', 'Norzagaray'),
(309, 12, 'Bulacan', 'Obando'),
(310, 12, 'Bulacan', 'Pandi'),
(311, 12, 'Bulacan', 'Paombong'),
(312, 12, 'Bulacan', 'Plaridel'),
(313, 12, 'Bulacan', 'Pulilan'),
(314, 12, 'Bulacan', 'San Ildefonso'),
(315, 12, 'Bulacan', 'San Miguel'),
(316, 12, 'Bulacan', 'San Rafael'),
(317, 12, 'Bulacan', 'Santa Maria'),
(318, 2, 'Ilocos Sur', 'Tuguegarao City'),
(319, 2, 'Ilocos Sur', 'Abulug'),
(320, 2, 'Ilocos Sur', 'Alcala'),
(321, 2, 'Ilocos Sur', 'Allacapan'),
(322, 2, 'Ilocos Sur', 'Amulung'),
(323, 2, 'Ilocos Sur', 'Aparri'),
(324, 2, 'Ilocos Sur', 'Baggao'),
(325, 2, 'Ilocos Sur', 'Ballesteros'),
(326, 2, 'Ilocos Sur', 'Buguey'),
(327, 2, 'Ilocos Sur', 'Calayan'),
(328, 2, 'Ilocos Sur', 'Camalaniugan'),
(329, 2, 'Ilocos Sur', 'Claveria'),
(330, 2, 'Ilocos Sur', 'Enrile'),
(331, 2, 'Ilocos Sur', 'Gattaran'),
(332, 2, 'Ilocos Sur', 'Gonzaga'),
(333, 2, 'Ilocos Sur', 'Iguig'),
(334, 2, 'Ilocos Sur', 'Lal-lo'),
(335, 2, 'Ilocos Sur', 'Lasam'),
(336, 2, 'Ilocos Sur', 'Pamplona'),
(337, 2, 'Ilocos Sur', 'Penablanca'),
(338, 2, 'Ilocos Sur', 'Piat'),
(339, 2, 'Ilocos Sur', 'Rizal'),
(340, 2, 'Ilocos Sur', 'Sanchez-Mira'),
(341, 2, 'Ilocos Sur', 'Santa Ana'),
(342, 2, 'Ilocos Sur', 'Santa Praxedes'),
(343, 2, 'Ilocos Sur', 'Santa Teresita'),
(344, 2, 'Ilocos Sur', 'Santo Nino'),
(345, 2, 'Ilocos Sur', 'Solana'),
(346, 2, 'Ilocos Sur', 'Tuao'),
(347, 28, 'Camarines Norte', 'Basud'),
(348, 28, 'Camarines Norte', 'Capalonga'),
(349, 28, 'Camarines Norte', 'Daet'),
(350, 28, 'Camarines Norte', 'Jose Panganiban'),
(351, 28, 'Camarines Norte', 'Labo'),
(352, 28, 'Camarines Norte', 'Mercedes'),
(353, 28, 'Camarines Norte', 'Paracale'),
(354, 28, 'Camarines Norte', 'San Lorenzo Ruiz'),
(355, 28, 'Camarines Norte', 'San Vicente'),
(356, 28, 'Camarines Norte', 'Santa Elena'),
(357, 28, 'Camarines Norte', 'Talisay'),
(358, 28, 'Camarines Norte', 'Vinzons'),
(359, 29, 'Camarines Sur', 'Baao'),
(360, 29, 'Camarines Sur', 'Balatan'),
(361, 29, 'Camarines Sur', 'Bato'),
(362, 29, 'Camarines Sur', 'Bombon'),
(363, 29, 'Camarines Sur', 'Bula'),
(364, 29, 'Camarines Sur', 'Cabusao'),
(365, 29, 'Camarines Sur', 'Calabanga'),
(366, 29, 'Camarines Sur', 'Camaligan'),
(367, 29, 'Camarines Sur', 'Canaman'),
(368, 29, 'Camarines Sur', 'Caramoan'),
(369, 29, 'Camarines Sur', 'Del Gallego'),
(370, 29, 'Camarines Sur', 'Gainza'),
(371, 29, 'Camarines Sur', 'Garchitorena'),
(372, 29, 'Camarines Sur', 'Goa'),
(373, 29, 'Camarines Sur', 'Iriga City'),
(374, 29, 'Camarines Sur', 'Lagonoy'),
(375, 29, 'Camarines Sur', 'Lupi'),
(376, 29, 'Camarines Sur', 'Magarao'),
(377, 29, 'Camarines Sur', 'Milaor'),
(378, 29, 'Camarines Sur', 'Minalabac'),
(379, 29, 'Camarines Sur', 'Nabua'),
(380, 29, 'Camarines Sur', 'Naga City'),
(381, 29, 'Camarines Sur', 'Ocampo'),
(382, 29, 'Camarines Sur', 'Pamplona'),
(383, 29, 'Camarines Sur', 'Pasacao'),
(384, 29, 'Camarines Sur', 'Pili'),
(385, 29, 'Camarines Sur', 'Presentacion'),
(386, 29, 'Camarines Sur', 'Ragay'),
(387, 29, 'Camarines Sur', 'Sagnay'),
(388, 29, 'Camarines Sur', 'San Fernando'),
(389, 29, 'Camarines Sur', 'San Jose'),
(390, 29, 'Camarines Sur', 'Sipocot'),
(391, 29, 'Camarines Sur', 'Siruma'),
(392, 29, 'Camarines Sur', 'Tigaon'),
(393, 29, 'Camarines Sur', 'Tinambac'),
(394, 29, 'Camarines Sur', 'Buhi'),
(395, 29, 'Camarines Sur', 'Libmanan'),
(396, 53, 'Camiguin', 'Catarman'),
(397, 53, 'Camiguin', 'Guinsiliban'),
(398, 53, 'Camiguin', 'Mahinog'),
(399, 53, 'Camiguin', 'Mambajao'),
(400, 53, 'Camiguin', 'Sagay'),
(401, 35, 'Capiz', 'Roxas City'),
(402, 35, 'Capiz', 'Cuartero'),
(403, 35, 'Capiz', 'Dao'),
(404, 35, 'Capiz', 'Dumalag'),
(405, 35, 'Capiz', 'Dumarao'),
(406, 35, 'Capiz', 'Ivisan'),
(407, 35, 'Capiz', 'Jamindan'),
(408, 35, 'Capiz', 'Ma-ayon'),
(409, 35, 'Capiz', 'Mambusao'),
(410, 35, 'Capiz', 'Panay'),
(411, 35, 'Capiz', 'Panitan'),
(412, 35, 'Capiz', 'Pilar'),
(413, 35, 'Capiz', 'Pontevedra'),
(414, 35, 'Capiz', 'President Roxas'),
(415, 35, 'Capiz', 'Sapian'),
(416, 35, 'Capiz', 'Sigma'),
(417, 35, 'Capiz', 'Tapaz'),
(418, 30, 'Catanduanes', 'Bagamanoc'),
(419, 30, 'Catanduanes', 'Baras'),
(420, 30, 'Catanduanes', 'Bato'),
(421, 30, 'Catanduanes', 'Caramoran'),
(422, 30, 'Catanduanes', 'Gigmoto'),
(423, 30, 'Catanduanes', 'Pandan'),
(424, 30, 'Catanduanes', 'Panganiban'),
(425, 30, 'Catanduanes', 'San Andres'),
(426, 30, 'Catanduanes', 'San Miguel'),
(427, 30, 'Catanduanes', 'Viga'),
(428, 30, 'Catanduanes', 'Virac'),
(429, 18, 'Cavite', 'Bacoor'),
(430, 18, 'Cavite', 'Cavite City'),
(431, 18, 'Cavite', 'Dasmarinas City'),
(432, 18, 'Cavite', 'Imus'),
(433, 18, 'Cavite', 'Tagaytay'),
(434, 18, 'Cavite', 'Trece Martires'),
(435, 18, 'Cavite', 'Alfonso'),
(436, 18, 'Cavite', 'Amadeo'),
(437, 18, 'Cavite', 'Carmona'),
(438, 18, 'Cavite', 'General Emilio Aguinaldo'),
(439, 18, 'Cavite', 'General Mariano Alvarez'),
(440, 18, 'Cavite', 'General Trias'),
(441, 18, 'Cavite', 'Indang'),
(442, 18, 'Cavite', 'Kawit'),
(443, 18, 'Cavite', 'Magallanes'),
(444, 18, 'Cavite', 'Maragondon'),
(445, 18, 'Cavite', 'Mendez'),
(446, 18, 'Cavite', 'Naic'),
(447, 18, 'Cavite', 'Noveleta'),
(448, 18, 'Cavite', 'Rosario'),
(449, 18, 'Cavite', 'Silang'),
(450, 18, 'Cavite', 'Tanza'),
(451, 18, 'Cavite', 'Ternate'),
(452, 40, 'Cebu', 'Danao City'),
(453, 40, 'Cebu', 'Talisay City'),
(454, 40, 'Cebu', 'Toledo City'),
(455, 40, 'Cebu', 'Bogo City'),
(456, 40, 'Cebu', 'Carcar City'),
(457, 40, 'Cebu', 'Naga City'),
(458, 40, 'Cebu', 'Mandaue City'),
(459, 40, 'Cebu', 'Alcantara'),
(460, 40, 'Cebu', 'Alcoy'),
(461, 40, 'Cebu', 'Alegria'),
(462, 40, 'Cebu', 'Aloguinsan'),
(463, 40, 'Cebu', 'Argao'),
(464, 40, 'Cebu', 'Asturias'),
(465, 40, 'Cebu', 'Badian'),
(466, 40, 'Cebu', 'Balamban'),
(467, 40, 'Cebu', 'Bantayan'),
(468, 40, 'Cebu', 'Barili'),
(469, 40, 'Cebu', 'Boljoon'),
(470, 40, 'Cebu', 'Borbon'),
(471, 40, 'Cebu', 'Carmen'),
(472, 40, 'Cebu', 'Catmon'),
(473, 40, 'Cebu', 'Compostela'),
(474, 40, 'Cebu', 'Consolacion'),
(475, 40, 'Cebu', 'Cordova'),
(476, 40, 'Cebu', 'Daanbantayan'),
(477, 40, 'Cebu', 'Dalaguete'),
(478, 40, 'Cebu', 'Dumanjug'),
(479, 40, 'Cebu', 'Ginatilan'),
(480, 40, 'Cebu', 'Liloan'),
(481, 40, 'Cebu', 'Madridejos'),
(482, 40, 'Cebu', 'Malabuyoc'),
(483, 40, 'Cebu', 'Medellin'),
(484, 40, 'Cebu', 'Minglanilla'),
(485, 40, 'Cebu', 'Moalboal'),
(486, 40, 'Cebu', 'Oslob'),
(487, 40, 'Cebu', 'Pilar'),
(488, 40, 'Cebu', 'Pinamungahan'),
(489, 40, 'Cebu', 'Poro'),
(490, 40, 'Cebu', 'Ronda'),
(491, 40, 'Cebu', 'Samboan'),
(492, 40, 'Cebu', 'San Fernando'),
(493, 40, 'Cebu', 'San Francisco'),
(494, 40, 'Cebu', 'San Remigio'),
(495, 40, 'Cebu', 'Santa Fe'),
(496, 40, 'Cebu', 'Santander'),
(497, 40, 'Cebu', 'Sibonga'),
(498, 40, 'Cebu', 'Sogod'),
(499, 40, 'Cebu', 'Tabogon'),
(500, 40, 'Cebu', 'Tabuelan'),
(501, 40, 'Cebu', 'Tuburan'),
(502, 40, 'Cebu', 'Tudela'),
(503, 57, 'Compostela Valley', 'Compostela'),
(504, 57, 'Compostela Valley', 'Laak'),
(505, 57, 'Compostela Valley', 'Mabini'),
(506, 57, 'Compostela Valley', 'Maco'),
(507, 57, 'Compostela Valley', 'Maragusan'),
(508, 57, 'Compostela Valley', 'Mawab'),
(509, 57, 'Compostela Valley', 'Monkayo'),
(510, 57, 'Compostela Valley', 'Montevista'),
(511, 57, 'Compostela Valley', 'Nabunturan'),
(512, 57, 'Compostela Valley', 'New Bataan'),
(513, 57, 'Compostela Valley', 'Pantukan'),
(514, 61, 'Cotabato', 'Kidapawan City'),
(515, 61, 'Cotabato', 'Alamada'),
(516, 61, 'Cotabato', 'Aleosan'),
(517, 61, 'Cotabato', 'Antipas'),
(518, 61, 'Cotabato', 'Arakan'),
(519, 61, 'Cotabato', 'Banisilan'),
(520, 61, 'Cotabato', 'Carmen'),
(521, 61, 'Cotabato', 'Kabacan'),
(522, 61, 'Cotabato', 'Libungan'),
(523, 61, 'Cotabato', 'Mlang'),
(524, 61, 'Cotabato', 'Magpet'),
(525, 61, 'Cotabato', 'Makilala'),
(526, 61, 'Cotabato', 'Matalam'),
(527, 61, 'Cotabato', 'Midsayap'),
(528, 61, 'Cotabato', 'Pigkawayan'),
(529, 61, 'Cotabato', 'Pikit'),
(530, 61, 'Cotabato', 'President Roxas'),
(531, 61, 'Cotabato', 'Tulunan'),
(532, 58, 'Davao del Norte', 'Panabo City'),
(533, 58, 'Davao del Norte', 'Samal City'),
(534, 58, 'Davao del Norte', 'Tagum City'),
(535, 58, 'Davao del Norte', 'Asuncion'),
(536, 58, 'Davao del Norte', 'Braulio E. Dujali'),
(537, 58, 'Davao del Norte', 'Carmen'),
(538, 58, 'Davao del Norte', 'Kapalong'),
(539, 58, 'Davao del Norte', 'New Corella'),
(540, 58, 'Davao del Norte', 'San Isidro'),
(541, 58, 'Davao del Norte', 'Santo Tomas'),
(542, 58, 'Davao del Norte', 'Talaingod'),
(543, 59, 'Davao del Sur', 'Davao City'),
(544, 59, 'Davao del Sur', 'Digos City'),
(545, 59, 'Davao del Sur', 'Bansalan'),
(546, 59, 'Davao del Sur', 'Don Marcelino'),
(547, 59, 'Davao del Sur', 'Hagonoy'),
(548, 59, 'Davao del Sur', 'Jose Abad Santos'),
(549, 59, 'Davao del Sur', 'Kiblawan'),
(550, 59, 'Davao del Sur', 'Magsaysay'),
(551, 59, 'Davao del Sur', 'Malalag'),
(552, 59, 'Davao del Sur', 'Malita'),
(553, 59, 'Davao del Sur', 'Matanao'),
(554, 59, 'Davao del Sur', 'Padada'),
(555, 59, 'Davao del Sur', 'Santa Cruz'),
(556, 59, 'Davao del Sur', 'Santa Maria'),
(557, 59, 'Davao del Sur', 'Sarangani'),
(558, 59, 'Davao del Sur', 'Sulop'),
(559, 60, 'Davao Oriental', 'Mati City'),
(560, 60, 'Davao Oriental', 'Baganga'),
(561, 60, 'Davao Oriental', 'Banaybanay'),
(562, 60, 'Davao Oriental', 'Boston'),
(563, 60, 'Davao Oriental', 'Caraga'),
(564, 60, 'Davao Oriental', 'Cateel'),
(565, 60, 'Davao Oriental', 'Governor Generoso'),
(566, 60, 'Davao Oriental', 'Lupon'),
(567, 60, 'Davao Oriental', 'Manay'),
(568, 60, 'Davao Oriental', 'San Isidro'),
(569, 60, 'Davao Oriental', 'Tarragona'),
(570, 68, 'Dinagat Islands', 'Basilisa (Rizal)'),
(571, 68, 'Dinagat Islands', 'Cagdianao'),
(572, 68, 'Dinagat Islands', 'Dinagat'),
(573, 68, 'Dinagat Islands', 'Libjo (Albor)'),
(574, 68, 'Dinagat Islands', 'Loreto'),
(575, 68, 'Dinagat Islands', 'San Jose'),
(576, 68, 'Dinagat Islands', 'Tubajon'),
(577, 44, 'Eastern Samar', 'Borongan City'),
(578, 44, 'Eastern Samar', 'Arteche'),
(579, 44, 'Eastern Samar', 'Balangiga'),
(580, 44, 'Eastern Samar', 'Balangkayan'),
(581, 44, 'Eastern Samar', 'Can-avid'),
(582, 44, 'Eastern Samar', 'Dolores'),
(583, 44, 'Eastern Samar', 'General MacArthur'),
(584, 44, 'Eastern Samar', 'Giporlos'),
(585, 44, 'Eastern Samar', 'Guiuan'),
(586, 44, 'Eastern Samar', 'Hernani'),
(587, 44, 'Eastern Samar', 'Jipapad'),
(588, 44, 'Eastern Samar', 'Lawaan'),
(589, 44, 'Eastern Samar', 'Llorente'),
(590, 44, 'Eastern Samar', 'Maslog'),
(591, 44, 'Eastern Samar', 'Maydolong'),
(592, 44, 'Eastern Samar', 'Mercedes'),
(593, 44, 'Eastern Samar', 'Oras'),
(594, 44, 'Eastern Samar', 'Quinapondan'),
(595, 44, 'Eastern Samar', 'Salcedo'),
(596, 44, 'Eastern Samar', 'San Julian'),
(597, 44, 'Eastern Samar', 'San Policarpo'),
(598, 44, 'Eastern Samar', 'Sulat'),
(599, 44, 'Eastern Samar', 'Taft'),
(600, 36, 'Guimaras', 'Buenavista'),
(601, 36, 'Guimaras', 'Jordan'),
(602, 36, 'Guimaras', 'Nueva Valencia'),
(603, 36, 'Guimaras', 'San Lorenzo'),
(604, 36, 'Guimaras', 'Sibunag'),
(605, 81, 'Ifugao', 'Aguinaldo'),
(606, 81, 'Ifugao', 'Alfonso Lista'),
(607, 81, 'Ifugao', 'Asipulo'),
(608, 81, 'Ifugao', 'Banaue'),
(609, 81, 'Ifugao', 'Hingyon'),
(610, 81, 'Ifugao', 'Hungduan'),
(611, 81, 'Ifugao', 'Kiangan'),
(612, 81, 'Ifugao', 'Lagawe'),
(613, 81, 'Ifugao', 'Lamut'),
(614, 81, 'Ifugao', 'Mayoyao'),
(615, 81, 'Ifugao', 'Tinoc'),
(616, 1, 'Ilocos Norte', 'Batac City'),
(617, 1, 'Ilocos Norte', 'Laoag City'),
(618, 1, 'Ilocos Norte', 'Adams'),
(619, 1, 'Ilocos Norte', 'Bacarra'),
(620, 1, 'Ilocos Norte', 'Badoc'),
(621, 1, 'Ilocos Norte', 'Bangui'),
(622, 1, 'Ilocos Norte', 'Banna'),
(623, 1, 'Ilocos Norte', 'Burgos'),
(624, 1, 'Ilocos Norte', 'Carasi'),
(625, 1, 'Ilocos Norte', 'Currimao'),
(626, 1, 'Ilocos Norte', 'Dingras'),
(627, 1, 'Ilocos Norte', 'Dumalneg'),
(628, 1, 'Ilocos Norte', 'Marcos'),
(629, 1, 'Ilocos Norte', 'Nueva Era'),
(630, 1, 'Ilocos Norte', 'Pagudpud'),
(631, 1, 'Ilocos Norte', 'Paoay'),
(632, 1, 'Ilocos Norte', 'Pasuquin'),
(633, 1, 'Ilocos Norte', 'Piddig'),
(634, 1, 'Ilocos Norte', 'Pinili'),
(635, 1, 'Ilocos Norte', 'San Nicolas'),
(636, 1, 'Ilocos Norte', 'Sarrat'),
(637, 1, 'Ilocos Norte', 'Solsona'),
(638, 1, 'Ilocos Norte', 'Vintar'),
(639, 2, 'Ilocos Sur', 'Candon City'),
(640, 2, 'Ilocos Sur', 'Vigan City'),
(641, 2, 'Ilocos Sur', 'Alilem'),
(642, 2, 'Ilocos Sur', 'Banayoyo'),
(643, 2, 'Ilocos Sur', 'Bantay'),
(644, 2, 'Ilocos Sur', 'Burgos'),
(645, 2, 'Ilocos Sur', 'Cabugao'),
(646, 2, 'Ilocos Sur', 'Caoayan'),
(647, 2, 'Ilocos Sur', 'Cervantes'),
(648, 2, 'Ilocos Sur', 'Galimuyod'),
(649, 2, 'Ilocos Sur', 'Gregorio Del Pilar'),
(650, 2, 'Ilocos Sur', 'Lidlidda'),
(651, 2, 'Ilocos Sur', 'Magsingal'),
(652, 2, 'Ilocos Sur', 'Nagbukel'),
(653, 2, 'Ilocos Sur', 'Narvacan'),
(654, 2, 'Ilocos Sur', 'Quirino'),
(655, 2, 'Ilocos Sur', 'Salcedo'),
(656, 2, 'Ilocos Sur', 'San Emilio'),
(657, 2, 'Ilocos Sur', 'San Esteban'),
(658, 2, 'Ilocos Sur', 'San Ildefonso'),
(659, 2, 'Ilocos Sur', 'San Juan'),
(660, 2, 'Ilocos Sur', 'San Vicente'),
(661, 2, 'Ilocos Sur', 'Santa'),
(662, 2, 'Ilocos Sur', 'Santa Catalina'),
(663, 2, 'Ilocos Sur', 'Santa Cruz'),
(664, 2, 'Ilocos Sur', 'Santa Lucia'),
(665, 2, 'Ilocos Sur', 'Santa Maria'),
(666, 2, 'Ilocos Sur', 'Santiago'),
(667, 2, 'Ilocos Sur', 'Santo Domingo'),
(668, 2, 'Ilocos Sur', 'Sigay'),
(669, 2, 'Ilocos Sur', 'Sinait'),
(670, 2, 'Ilocos Sur', 'Sugpon'),
(671, 2, 'Ilocos Sur', 'Suyo'),
(672, 2, 'Ilocos Sur', 'Tagudin'),
(673, 37, 'Iloilo', 'Iloilo City'),
(674, 37, 'Iloilo', 'Passi City'),
(675, 37, 'Iloilo', 'Ajuy'),
(676, 37, 'Iloilo', 'Alimodian'),
(677, 37, 'Iloilo', 'Anilao'),
(678, 37, 'Iloilo', 'Badiangan'),
(679, 37, 'Iloilo', 'Balasan'),
(680, 37, 'Iloilo', 'Banate'),
(681, 37, 'Iloilo', 'Barotac Nuevo'),
(682, 37, 'Iloilo', 'Barotac Viejo'),
(683, 37, 'Iloilo', 'Batad'),
(684, 37, 'Iloilo', 'Bingawan'),
(685, 37, 'Iloilo', 'Cabatuan'),
(686, 37, 'Iloilo', 'Calinog'),
(687, 37, 'Iloilo', 'Carles'),
(688, 37, 'Iloilo', 'Concepcion'),
(689, 37, 'Iloilo', 'Dingle'),
(690, 37, 'Iloilo', 'Duenas'),
(691, 37, 'Iloilo', 'Dumangas'),
(692, 37, 'Iloilo', 'Estancia'),
(693, 37, 'Iloilo', 'Guimbal'),
(694, 37, 'Iloilo', 'Igbaras'),
(695, 37, 'Iloilo', 'Janiuay'),
(696, 37, 'Iloilo', 'Lambunao'),
(697, 37, 'Iloilo', 'Leganes'),
(698, 37, 'Iloilo', 'Lemery'),
(699, 37, 'Iloilo', 'Leon'),
(700, 37, 'Iloilo', 'Maasin'),
(701, 37, 'Iloilo', 'Miagao'),
(702, 37, 'Iloilo', 'Mina'),
(703, 37, 'Iloilo', 'New Lucena'),
(704, 37, 'Iloilo', 'Oton'),
(705, 37, 'Iloilo', 'Pavia'),
(706, 37, 'Iloilo', 'Pototan'),
(707, 37, 'Iloilo', 'San Dionisio'),
(708, 37, 'Iloilo', 'San Enrique'),
(709, 37, 'Iloilo', 'San Joaquin'),
(710, 37, 'Iloilo', 'San Miguel'),
(711, 37, 'Iloilo', 'San Rafael'),
(712, 37, 'Iloilo', 'Santa Barbara'),
(713, 37, 'Iloilo', 'Sara'),
(714, 37, 'Iloilo', 'Tigbauan'),
(715, 37, 'Iloilo', 'Tubungan'),
(716, 37, 'Iloilo', 'Zarraga'),
(717, 7, 'Isabela', 'Cauayan City'),
(718, 7, 'Isabela', 'Ilagan City'),
(719, 7, 'Isabela', 'Santiago City'),
(720, 7, 'Isabela', 'Alicia'),
(721, 7, 'Isabela', 'Angadanan'),
(722, 7, 'Isabela', 'Aurora'),
(723, 7, 'Isabela', 'Benito Soliven'),
(724, 7, 'Isabela', 'Burgos'),
(725, 7, 'Isabela', 'Cabagan'),
(726, 7, 'Isabela', 'Cabatuan'),
(727, 7, 'Isabela', 'Cordon'),
(728, 7, 'Isabela', 'Delfin Albano'),
(729, 7, 'Isabela', 'Dinapigue'),
(730, 7, 'Isabela', 'Divilacan'),
(731, 7, 'Isabela', 'Echague'),
(732, 7, 'Isabela', 'Gamu'),
(733, 7, 'Isabela', 'Jones'),
(734, 7, 'Isabela', 'Luna'),
(735, 7, 'Isabela', 'Maconacon'),
(736, 7, 'Isabela', 'Mallig'),
(737, 7, 'Isabela', 'Naguilian'),
(738, 7, 'Isabela', 'Palanan'),
(739, 7, 'Isabela', 'Quezon'),
(740, 7, 'Isabela', 'Quirino'),
(741, 7, 'Isabela', 'Ramon'),
(742, 7, 'Isabela', 'Reina Mercedes'),
(743, 7, 'Isabela', 'Roxas'),
(744, 7, 'Isabela', 'San Agustin'),
(745, 7, 'Isabela', 'San Guillermo'),
(746, 7, 'Isabela', 'San Isidro'),
(747, 7, 'Isabela', 'San Manuel'),
(748, 7, 'Isabela', 'San Mariano'),
(749, 7, 'Isabela', 'San Mateo'),
(750, 7, 'Isabela', 'San Pablo'),
(751, 7, 'Isabela', 'Santa Maria'),
(752, 7, 'Isabela', 'Santo Tomas'),
(753, 7, 'Isabela', 'Tumauini'),
(754, 82, 'Kalinga', 'Tabuk City'),
(755, 82, 'Kalinga', 'Balbalan'),
(756, 82, 'Kalinga', 'Lubuagan'),
(757, 82, 'Kalinga', 'Pasil'),
(758, 82, 'Kalinga', 'Pinukpuk'),
(759, 82, 'Kalinga', 'Rizal'),
(760, 82, 'Kalinga', 'Tanudan'),
(761, 82, 'Kalinga', 'Tinglayan'),
(762, 3, 'La Union', 'San Fernando City'),
(763, 3, 'La Union', 'Agoo'),
(764, 3, 'La Union', 'Aringay'),
(765, 3, 'La Union', 'Bacnotan'),
(766, 3, 'La Union', 'Bagulin'),
(767, 3, 'La Union', 'Balaoan'),
(768, 3, 'La Union', 'Bangar'),
(769, 3, 'La Union', 'Bauang'),
(770, 3, 'La Union', 'Burgos'),
(771, 3, 'La Union', 'Caba'),
(772, 3, 'La Union', 'Luna'),
(773, 3, 'La Union', 'Naguilian'),
(774, 3, 'La Union', 'Pugo'),
(775, 3, 'La Union', 'Rosario'),
(776, 3, 'La Union', 'San Gabriel'),
(777, 3, 'La Union', 'San Juan'),
(778, 3, 'La Union', 'Santo Tomas'),
(779, 3, 'La Union', 'Santol'),
(780, 3, 'La Union', 'Sudipen'),
(781, 3, 'La Union', 'Tubao'),
(782, 19, 'Laguna', 'Binan City'),
(783, 19, 'Laguna', 'Cabuyao City'),
(784, 19, 'Laguna', 'Calamba City'),
(785, 19, 'Laguna', 'San Pablo City'),
(786, 19, 'Laguna', 'Santa Rosa City'),
(787, 19, 'Laguna', 'Los Banos'),
(788, 19, 'Laguna', 'San Pedro'),
(789, 19, 'Laguna', 'Alaminos'),
(790, 19, 'Laguna', 'Bay'),
(791, 19, 'Laguna', 'Calauan'),
(792, 19, 'Laguna', 'Cavinti'),
(793, 19, 'Laguna', 'Famy'),
(794, 19, 'Laguna', 'Kalayaan'),
(795, 19, 'Laguna', 'Liliw'),
(796, 19, 'Laguna', 'Luisiana'),
(797, 19, 'Laguna', 'Lumban'),
(798, 19, 'Laguna', 'Mabitac'),
(799, 19, 'Laguna', 'Magdalena'),
(800, 19, 'Laguna', 'Majayjay'),
(801, 19, 'Laguna', 'Nagcarlan'),
(802, 19, 'Laguna', 'Paete'),
(803, 19, 'Laguna', 'Pagsanjan'),
(804, 19, 'Laguna', 'Pakil'),
(805, 19, 'Laguna', 'Pangil'),
(806, 19, 'Laguna', 'Pila'),
(807, 19, 'Laguna', 'Rizal'),
(808, 19, 'Laguna', 'Santa Cruz'),
(809, 19, 'Laguna', 'Santa Maria'),
(810, 19, 'Laguna', 'Siniloan'),
(811, 19, 'Laguna', 'Victoria'),
(812, 54, 'Lanao del Norte', 'Iligan City'),
(813, 54, 'Lanao del Norte', 'Bacolod'),
(814, 54, 'Lanao del Norte', 'Baloi'),
(815, 54, 'Lanao del Norte', 'Baroy'),
(816, 54, 'Lanao del Norte', 'Kapatagan'),
(817, 54, 'Lanao del Norte', 'Kauswagan'),
(818, 54, 'Lanao del Norte', 'Kolambugan'),
(819, 54, 'Lanao del Norte', 'Lala'),
(820, 54, 'Lanao del Norte', 'Linamon'),
(821, 54, 'Lanao del Norte', 'Magsaysay'),
(822, 54, 'Lanao del Norte', 'Maigo'),
(823, 54, 'Lanao del Norte', 'Matungao'),
(824, 54, 'Lanao del Norte', 'Munai'),
(825, 54, 'Lanao del Norte', 'Nunungan'),
(826, 54, 'Lanao del Norte', 'Pantao Ragat'),
(827, 54, 'Lanao del Norte', 'Pantar'),
(828, 54, 'Lanao del Norte', 'Poona Piagapo'),
(829, 54, 'Lanao del Norte', 'Salvador'),
(830, 54, 'Lanao del Norte', 'Sapad'),
(831, 54, 'Lanao del Norte', 'Sultan Naga Dimaporo'),
(832, 54, 'Lanao del Norte', 'Tagoloan'),
(833, 54, 'Lanao del Norte', 'Tangcal'),
(834, 54, 'Lanao del Norte', 'Tubod'),
(835, 72, 'Lanao del Sur', 'Marawi City'),
(836, 72, 'Lanao del Sur', 'Bacolod-Kalawi'),
(837, 72, 'Lanao del Sur', 'Balabagan'),
(838, 72, 'Lanao del Sur', 'Balindong'),
(839, 72, 'Lanao del Sur', 'Bayang'),
(840, 72, 'Lanao del Sur', 'Binidayan'),
(841, 72, 'Lanao del Sur', 'Buadiposo-Buntong'),
(842, 72, 'Lanao del Sur', 'Bubong'),
(843, 72, 'Lanao del Sur', 'Bumbaran'),
(844, 72, 'Lanao del Sur', 'Butig'),
(845, 72, 'Lanao del Sur', 'Calanogas'),
(846, 72, 'Lanao del Sur', 'Ditsaan-Ramain'),
(847, 72, 'Lanao del Sur', 'Ganassi'),
(848, 72, 'Lanao del Sur', 'Kapai'),
(849, 72, 'Lanao del Sur', 'Kapatagan'),
(850, 72, 'Lanao del Sur', 'Lumba-Bayabao'),
(851, 72, 'Lanao del Sur', 'Lumbaca-Unayan'),
(852, 72, 'Lanao del Sur', 'Lumbatan'),
(853, 72, 'Lanao del Sur', 'Lumbayanague'),
(854, 72, 'Lanao del Sur', 'Madalum'),
(855, 72, 'Lanao del Sur', 'Madamba'),
(856, 72, 'Lanao del Sur', 'Maguing'),
(857, 72, 'Lanao del Sur', 'Malabang'),
(858, 72, 'Lanao del Sur', 'Marantao'),
(859, 72, 'Lanao del Sur', 'Marogong'),
(860, 72, 'Lanao del Sur', 'Masiu'),
(861, 72, 'Lanao del Sur', 'Mulondo'),
(862, 72, 'Lanao del Sur', 'Pagayawan'),
(863, 72, 'Lanao del Sur', 'Piagapo'),
(864, 72, 'Lanao del Sur', 'Poona Bayabao'),
(865, 72, 'Lanao del Sur', 'Pualas'),
(866, 72, 'Lanao del Sur', 'Saguiaran'),
(867, 72, 'Lanao del Sur', 'Sultan Dumalondong'),
(868, 72, 'Lanao del Sur', 'Picong'),
(869, 72, 'Lanao del Sur', 'Tagoloan II'),
(870, 72, 'Lanao del Sur', 'Tamparan'),
(871, 72, 'Lanao del Sur', 'Taraka'),
(872, 72, 'Lanao del Sur', 'Tubaran'),
(873, 72, 'Lanao del Sur', 'Tugaya'),
(874, 72, 'Lanao del Sur', 'Wao'),
(875, 45, 'Leyte', 'Baybay'),
(876, 45, 'Leyte', 'Ormoc City'),
(877, 45, 'Leyte', 'Tacloban City'),
(878, 45, 'Leyte', 'Abuyog'),
(879, 45, 'Leyte', 'Alangalang'),
(880, 45, 'Leyte', 'Albuera'),
(881, 45, 'Leyte', 'Babatngon'),
(882, 45, 'Leyte', 'Barugo'),
(883, 45, 'Leyte', 'Bato'),
(884, 45, 'Leyte', 'Burauen'),
(885, 45, 'Leyte', 'Calubian'),
(886, 45, 'Leyte', 'Capoocan'),
(887, 45, 'Leyte', 'Carigara'),
(888, 45, 'Leyte', 'Dagami'),
(889, 45, 'Leyte', 'Dulag'),
(890, 45, 'Leyte', 'Hilongos'),
(891, 45, 'Leyte', 'Hindang'),
(892, 45, 'Leyte', 'Inopacan'),
(893, 45, 'Leyte', 'Isabel'),
(894, 45, 'Leyte', 'Jaro'),
(895, 45, 'Leyte', 'Javier'),
(896, 45, 'Leyte', 'Julita'),
(897, 45, 'Leyte', 'Kananga'),
(898, 45, 'Leyte', 'La Paz'),
(899, 45, 'Leyte', 'Leyte'),
(900, 45, 'Leyte', 'MacArthur'),
(901, 45, 'Leyte', 'Mahaplag'),
(902, 45, 'Leyte', 'Matag-ob'),
(903, 45, 'Leyte', 'Matalom'),
(904, 45, 'Leyte', 'Mayorga'),
(905, 45, 'Leyte', 'Merida'),
(906, 45, 'Leyte', 'Palo'),
(907, 45, 'Leyte', 'Palompon'),
(908, 45, 'Leyte', 'Pastrana'),
(909, 45, 'Leyte', 'San Isidro'),
(910, 45, 'Leyte', 'San Miguel'),
(911, 45, 'Leyte', 'Santa Fe'),
(912, 45, 'Leyte', 'Tabango'),
(913, 45, 'Leyte', 'Tabontabon'),
(914, 45, 'Leyte', 'Tanauan'),
(915, 45, 'Leyte', 'Tolosa'),
(916, 45, 'Leyte', 'Tunga'),
(917, 45, 'Leyte', 'Villaba'),
(918, 73, 'Maguindanao', 'Cotabato City'),
(919, 73, 'Maguindanao', 'Ampatuan'),
(920, 73, 'Maguindanao', 'Barira'),
(921, 73, 'Maguindanao', 'Buldon'),
(922, 73, 'Maguindanao', 'Buluan'),
(923, 73, 'Maguindanao', 'Datu Abdullah Sangki'),
(924, 73, 'Maguindanao', 'Datu Anggal Midtimbang'),
(925, 73, 'Maguindanao', 'Datu Blah T. Sinsuat'),
(926, 73, 'Maguindanao', 'Datu Hoffer Ampatuan'),
(927, 73, 'Maguindanao', 'Datu Montawal'),
(928, 73, 'Maguindanao', 'Datu Odin Sinsuat'),
(929, 73, 'Maguindanao', 'Datu Paglas'),
(930, 73, 'Maguindanao', 'Datu Piang'),
(931, 73, 'Maguindanao', 'Datu Salibo'),
(932, 73, 'Maguindanao', 'Datu Saudi-Ampatuan'),
(933, 73, 'Maguindanao', 'Datu Unsay'),
(934, 73, 'Maguindanao', 'General Salipada K. Pendatun'),
(935, 73, 'Maguindanao', 'Guindulungan'),
(936, 73, 'Maguindanao', 'Kabuntalan'),
(937, 73, 'Maguindanao', 'Mamasapano'),
(938, 73, 'Maguindanao', 'Mangudadatu'),
(939, 73, 'Maguindanao', 'Matanog'),
(940, 73, 'Maguindanao', 'Northern Kabuntalan'),
(941, 73, 'Maguindanao', 'Pagalungan'),
(942, 73, 'Maguindanao', 'Paglat'),
(943, 73, 'Maguindanao', 'Pandag'),
(944, 73, 'Maguindanao', 'Parang'),
(945, 73, 'Maguindanao', 'Rajah Buayan'),
(946, 73, 'Maguindanao', 'Shariff Aguak'),
(947, 73, 'Maguindanao', 'Shariff Saydona Mustapha'),
(948, 73, 'Maguindanao', 'South Upi'),
(949, 73, 'Maguindanao', 'Sultan Kudarat'),
(950, 73, 'Maguindanao', 'Sultan Mastura'),
(951, 73, 'Maguindanao', 'Sultan sa Barongis'),
(952, 73, 'Maguindanao', 'Talayan'),
(953, 73, 'Maguindanao', 'Talitay'),
(954, 73, 'Maguindanao', 'Upi'),
(955, 25, 'Marinduque', 'Boac'),
(956, 25, 'Marinduque', 'Buenavista'),
(957, 25, 'Marinduque', 'Gasan'),
(958, 25, 'Marinduque', 'Mogpog'),
(959, 25, 'Marinduque', 'Santa Cruz'),
(960, 25, 'Marinduque', 'Torrijos'),
(961, 31, 'Masbate', 'Masbate City'),
(962, 31, 'Masbate', 'Aroroy'),
(963, 31, 'Masbate', 'Baleno'),
(964, 31, 'Masbate', 'Balud'),
(965, 31, 'Masbate', 'Batuan'),
(966, 31, 'Masbate', 'Cataingan'),
(967, 31, 'Masbate', 'Cawayan'),
(968, 31, 'Masbate', 'Claveria'),
(969, 31, 'Masbate', 'Dimasalang'),
(970, 31, 'Masbate', 'Esperanza'),
(971, 31, 'Masbate', 'Mandaon'),
(972, 31, 'Masbate', 'Milagros'),
(973, 31, 'Masbate', 'Mobo'),
(974, 31, 'Masbate', 'Monreal'),
(975, 31, 'Masbate', 'Palanas'),
(976, 31, 'Masbate', 'Pio V. Corpuz'),
(977, 31, 'Masbate', 'Placer'),
(978, 31, 'Masbate', 'San Fernando'),
(979, 31, 'Masbate', 'San Jacinto'),
(980, 31, 'Masbate', 'San Pascual'),
(981, 31, 'Masbate', 'Uson'),
(982, 55, 'Misamis Occidental', 'Oroquieta City'),
(983, 55, 'Misamis Occidental', 'Ozamis City'),
(984, 55, 'Misamis Occidental', 'Tangub City'),
(985, 55, 'Misamis Occidental', 'Aloran'),
(986, 55, 'Misamis Occidental', 'Baliangao'),
(987, 55, 'Misamis Occidental', 'Bonifacio'),
(988, 55, 'Misamis Occidental', 'Calamba'),
(989, 55, 'Misamis Occidental', 'Clarin'),
(990, 55, 'Misamis Occidental', 'Concepcion'),
(991, 55, 'Misamis Occidental', 'Don Victoriano Chiongbian'),
(992, 55, 'Misamis Occidental', 'Jimenez'),
(993, 55, 'Misamis Occidental', 'Lopez Jaena'),
(994, 55, 'Misamis Occidental', 'Panaon'),
(995, 55, 'Misamis Occidental', 'Plaridel'),
(996, 55, 'Misamis Occidental', 'Sapang Dalaga'),
(997, 55, 'Misamis Occidental', 'Sinacaban'),
(998, 55, 'Misamis Occidental', 'Tudela'),
(999, 56, 'Misamis Oriental', 'Cagayan de Oro City'),
(1000, 56, 'Misamis Oriental', 'El Salvador City'),
(1001, 56, 'Misamis Oriental', 'Gingoog City'),
(1002, 56, 'Misamis Oriental', 'Alubijid'),
(1003, 56, 'Misamis Oriental', 'Balingasag'),
(1004, 56, 'Misamis Oriental', 'Balingoan'),
(1005, 56, 'Misamis Oriental', 'Binuangan'),
(1006, 56, 'Misamis Oriental', 'Claveria'),
(1007, 56, 'Misamis Oriental', 'Gitagum'),
(1008, 56, 'Misamis Oriental', 'Initao'),
(1009, 56, 'Misamis Oriental', 'Jasaan'),
(1010, 56, 'Misamis Oriental', 'Kinoguitan'),
(1011, 56, 'Misamis Oriental', 'Lagonglong'),
(1012, 56, 'Misamis Oriental', 'Laguindingan'),
(1013, 56, 'Misamis Oriental', 'Libertad'),
(1014, 56, 'Misamis Oriental', 'Lugait'),
(1015, 56, 'Misamis Oriental', 'Magsaysay'),
(1016, 56, 'Misamis Oriental', 'Manticao'),
(1017, 56, 'Misamis Oriental', 'Medina'),
(1018, 56, 'Misamis Oriental', 'Naawan'),
(1019, 56, 'Misamis Oriental', 'Opol'),
(1020, 56, 'Misamis Oriental', 'Salay'),
(1021, 56, 'Misamis Oriental', 'Sugbongcogon'),
(1022, 56, 'Misamis Oriental', 'Tagoloan'),
(1023, 56, 'Misamis Oriental', 'Talisayan'),
(1024, 56, 'Misamis Oriental', 'Villanueva'),
(1025, 83, 'Mountain Province', 'Barlig'),
(1026, 83, 'Mountain Province', 'Bauko'),
(1027, 83, 'Mountain Province', 'Besao'),
(1028, 83, 'Mountain Province', 'Bontoc'),
(1029, 83, 'Mountain Province', 'Natonin'),
(1030, 83, 'Mountain Province', 'Paracelis'),
(1031, 83, 'Mountain Province', 'Sabangan'),
(1032, 83, 'Mountain Province', 'Sadanga'),
(1033, 83, 'Mountain Province', 'Sagada'),
(1034, 83, 'Mountain Province', 'Tadian'),
(1035, 38, 'Negros Occidental', 'Bacolod City'),
(1036, 38, 'Negros Occidental', 'Bago City'),
(1037, 38, 'Negros Occidental', 'Cadiz City'),
(1038, 38, 'Negros Occidental', 'Escalante City'),
(1039, 38, 'Negros Occidental', 'Himamaylan City'),
(1040, 38, 'Negros Occidental', 'Kabankalan City'),
(1041, 38, 'Negros Occidental', 'La Carlota City'),
(1042, 38, 'Negros Occidental', 'Sagay City'),
(1043, 38, 'Negros Occidental', 'San Carlos City'),
(1044, 38, 'Negros Occidental', 'Silay City'),
(1045, 38, 'Negros Occidental', 'Sipalay City'),
(1046, 38, 'Negros Occidental', 'Talisay City'),
(1047, 38, 'Negros Occidental', 'Victorias City'),
(1048, 38, 'Negros Occidental', 'Binalbagan'),
(1049, 38, 'Negros Occidental', 'Calatrava'),
(1050, 38, 'Negros Occidental', 'Candoni'),
(1051, 38, 'Negros Occidental', 'Cauayan'),
(1052, 38, 'Negros Occidental', 'Enrique B. Magalona'),
(1053, 38, 'Negros Occidental', 'Hinigaran'),
(1054, 38, 'Negros Occidental', 'Hinoba-an'),
(1055, 38, 'Negros Occidental', 'Ilog'),
(1056, 38, 'Negros Occidental', 'Isabela'),
(1057, 38, 'Negros Occidental', 'La Castellana'),
(1058, 38, 'Negros Occidental', 'Manapla'),
(1059, 38, 'Negros Occidental', 'Moises Padilla'),
(1060, 38, 'Negros Occidental', 'Murcia'),
(1061, 38, 'Negros Occidental', 'Pontevedra'),
(1062, 38, 'Negros Occidental', 'Pulupandan'),
(1063, 38, 'Negros Occidental', 'Salvador Benedicto'),
(1064, 38, 'Negros Occidental', 'San Enrique'),
(1065, 38, 'Negros Occidental', 'Toboso'),
(1066, 38, 'Negros Occidental', 'Valladolid'),
(1067, 41, 'Negros Oriental', 'Bais City'),
(1068, 41, 'Negros Oriental', 'Bayawan City'),
(1069, 41, 'Negros Oriental', 'Canlaon City'),
(1070, 41, 'Negros Oriental', 'Guihulngan City'),
(1071, 41, 'Negros Oriental', 'Dumaguete City'),
(1072, 41, 'Negros Oriental', 'Tanjay City'),
(1073, 41, 'Negros Oriental', 'Amlan'),
(1074, 41, 'Negros Oriental', 'Ayungon'),
(1075, 41, 'Negros Oriental', 'Bacong'),
(1076, 41, 'Negros Oriental', 'Basay'),
(1077, 41, 'Negros Oriental', 'Bindoy'),
(1078, 41, 'Negros Oriental', 'Dauin'),
(1079, 41, 'Negros Oriental', 'Jimalalud'),
(1080, 41, 'Negros Oriental', 'La Libertad'),
(1081, 41, 'Negros Oriental', 'Mabinay'),
(1082, 41, 'Negros Oriental', 'Manjuyod'),
(1083, 41, 'Negros Oriental', 'Pamplona'),
(1084, 41, 'Negros Oriental', 'San Jose'),
(1085, 41, 'Negros Oriental', 'Santa Catalina'),
(1086, 41, 'Negros Oriental', 'Siaton'),
(1087, 41, 'Negros Oriental', 'Sibulan'),
(1088, 41, 'Negros Oriental', 'Tayasan'),
(1089, 41, 'Negros Oriental', 'Valencia'),
(1090, 41, 'Negros Oriental', 'Vallehermoso'),
(1091, 41, 'Negros Oriental', 'Zamboanguita'),
(1092, 46, 'Northern Samar', 'Allen'),
(1093, 46, 'Northern Samar', 'Biri'),
(1094, 46, 'Northern Samar', 'Bobon'),
(1095, 46, 'Northern Samar', 'Capul'),
(1096, 46, 'Northern Samar', 'Catarman'),
(1097, 46, 'Northern Samar', 'Catubig'),
(1098, 46, 'Northern Samar', 'Gamay'),
(1099, 46, 'Northern Samar', 'Laoang'),
(1100, 46, 'Northern Samar', 'Lapinig'),
(1101, 46, 'Northern Samar', 'Las Navas'),
(1102, 46, 'Northern Samar', 'Lavezares'),
(1103, 46, 'Northern Samar', 'Lope de Vega'),
(1104, 46, 'Northern Samar', 'Mapanas'),
(1105, 46, 'Northern Samar', 'Mondragon'),
(1106, 46, 'Northern Samar', 'Palapag'),
(1107, 46, 'Northern Samar', 'Pambujan'),
(1108, 46, 'Northern Samar', 'Rosario'),
(1109, 46, 'Northern Samar', 'San Antonio'),
(1110, 46, 'Northern Samar', 'San Isidro'),
(1111, 46, 'Northern Samar', 'San Jose'),
(1112, 46, 'Northern Samar', 'San Roque'),
(1113, 46, 'Northern Samar', 'San Vicente'),
(1114, 46, 'Northern Samar', 'Silvino Lobos'),
(1115, 46, 'Northern Samar', 'Victoria'),
(1116, 13, 'Nueva Ecija', 'Cabanatuan City'),
(1117, 13, 'Nueva Ecija', 'Gapan City'),
(1118, 13, 'Nueva Ecija', 'Palayan City'),
(1119, 13, 'Nueva Ecija', 'San Jose City'),
(1120, 13, 'Nueva Ecija', 'Munoz City'),
(1121, 13, 'Nueva Ecija', 'Aliaga'),
(1122, 13, 'Nueva Ecija', 'Bongabon'),
(1123, 13, 'Nueva Ecija', 'Cabiao'),
(1124, 13, 'Nueva Ecija', 'Carranglan'),
(1125, 13, 'Nueva Ecija', 'Cuyapo'),
(1126, 13, 'Nueva Ecija', 'Gabaldon'),
(1127, 13, 'Nueva Ecija', 'General Mamerto Natividad'),
(1128, 13, 'Nueva Ecija', 'General Tinio'),
(1129, 13, 'Nueva Ecija', 'Guimba'),
(1130, 13, 'Nueva Ecija', 'Jaen'),
(1131, 13, 'Nueva Ecija', 'Laur'),
(1132, 13, 'Nueva Ecija', 'Licab'),
(1133, 13, 'Nueva Ecija', 'Llanera'),
(1134, 13, 'Nueva Ecija', 'Lupao'),
(1135, 13, 'Nueva Ecija', 'Nampicuan'),
(1136, 13, 'Nueva Ecija', 'Pantabangan'),
(1137, 13, 'Nueva Ecija', 'Pe?aranda'),
(1138, 13, 'Nueva Ecija', 'Quezon'),
(1139, 13, 'Nueva Ecija', 'Rizal'),
(1140, 13, 'Nueva Ecija', 'San Antonio'),
(1141, 13, 'Nueva Ecija', 'San Isidro'),
(1142, 13, 'Nueva Ecija', 'San Leonardo'),
(1143, 13, 'Nueva Ecija', 'Santa Rosa'),
(1144, 13, 'Nueva Ecija', 'Santo Domingo'),
(1145, 13, 'Nueva Ecija', 'Talavera'),
(1146, 13, 'Nueva Ecija', 'Talugtug'),
(1147, 13, 'Nueva Ecija', 'Zaragoza'),
(1148, 8, 'Nueva Vizcaya', 'Alfonso Castaneda'),
(1149, 8, 'Nueva Vizcaya', 'Ambaguio'),
(1150, 8, 'Nueva Vizcaya', 'Aritao'),
(1151, 8, 'Nueva Vizcaya', 'Bagabag'),
(1152, 8, 'Nueva Vizcaya', 'Bambang'),
(1153, 8, 'Nueva Vizcaya', 'Bayombong'),
(1154, 8, 'Nueva Vizcaya', 'Diadi'),
(1155, 8, 'Nueva Vizcaya', 'Dupax del Norte'),
(1156, 8, 'Nueva Vizcaya', 'Dupax del Sur'),
(1157, 8, 'Nueva Vizcaya', 'Kasibu'),
(1158, 8, 'Nueva Vizcaya', 'Kayapa'),
(1159, 8, 'Nueva Vizcaya', 'Quezon'),
(1160, 8, 'Nueva Vizcaya', 'Santa Fe'),
(1161, 8, 'Nueva Vizcaya', 'Solano'),
(1162, 8, 'Nueva Vizcaya', 'Villaverde'),
(1163, 22, 'Occidental Mindoro', 'Abra de Ilog'),
(1164, 22, 'Occidental Mindoro', 'Calintaan'),
(1165, 22, 'Occidental Mindoro', 'Looc'),
(1166, 22, 'Occidental Mindoro', 'Lubang'),
(1167, 22, 'Occidental Mindoro', 'Magsaysay'),
(1168, 22, 'Occidental Mindoro', 'Mamburao'),
(1169, 22, 'Occidental Mindoro', 'Paluan'),
(1170, 22, 'Occidental Mindoro', 'Rizal'),
(1171, 22, 'Occidental Mindoro', 'Sablayan'),
(1172, 22, 'Occidental Mindoro', 'San Jose'),
(1173, 22, 'Occidental Mindoro', 'Santa Cruz'),
(1174, 23, 'Oriental Mindoro', 'Calapan City'),
(1175, 23, 'Oriental Mindoro', 'Baco'),
(1176, 23, 'Oriental Mindoro', 'Bansud'),
(1177, 23, 'Oriental Mindoro', 'Bongabong'),
(1178, 23, 'Oriental Mindoro', 'Bulalacao'),
(1179, 23, 'Oriental Mindoro', 'Gloria'),
(1180, 23, 'Oriental Mindoro', 'Mansalay'),
(1181, 23, 'Oriental Mindoro', 'Naujan'),
(1182, 23, 'Oriental Mindoro', 'Pinamalayan'),
(1183, 23, 'Oriental Mindoro', 'Pola'),
(1184, 23, 'Oriental Mindoro', 'Puerto Galera'),
(1185, 23, 'Oriental Mindoro', 'Roxas'),
(1186, 23, 'Oriental Mindoro', 'San Teodoro'),
(1187, 23, 'Oriental Mindoro', 'Socorro'),
(1188, 23, 'Oriental Mindoro', 'Victoria'),
(1189, 26, 'Palawan', 'Puerto Princesa City'),
(1190, 26, 'Palawan', 'Aborlan'),
(1191, 26, 'Palawan', 'Agutaya'),
(1192, 26, 'Palawan', 'Araceli'),
(1193, 26, 'Palawan', 'Balabac'),
(1194, 26, 'Palawan', 'Bataraza'),
(1195, 26, 'Palawan', 'Brooke\\''s Point'),
(1196, 26, 'Palawan', 'Busuanga'),
(1197, 26, 'Palawan', 'Cagayancillo'),
(1198, 26, 'Palawan', 'Coron'),
(1199, 26, 'Palawan', 'Culion'),
(1200, 26, 'Palawan', 'Cuyo'),
(1201, 26, 'Palawan', 'Dumaran'),
(1202, 26, 'Palawan', 'El Nido'),
(1203, 26, 'Palawan', 'Kalayaan'),
(1204, 26, 'Palawan', 'Linapacan'),
(1205, 26, 'Palawan', 'Magsaysay'),
(1206, 26, 'Palawan', 'Narra'),
(1207, 26, 'Palawan', 'Quezon'),
(1208, 26, 'Palawan', 'Rizal'),
(1209, 26, 'Palawan', 'Roxas'),
(1210, 26, 'Palawan', 'San Vicente'),
(1211, 26, 'Palawan', 'Sofronio Española'),
(1212, 26, 'Palawan', 'Taytay'),
(1213, 14, 'Pampanga', 'Angeles City'),
(1214, 14, 'Pampanga', 'San Fernando City'),
(1215, 14, 'Pampanga', 'Mabalacat City'),
(1216, 14, 'Pampanga', 'Apalit'),
(1217, 14, 'Pampanga', 'Arayat'),
(1218, 14, 'Pampanga', 'Bacolor'),
(1219, 14, 'Pampanga', 'Candaba'),
(1220, 14, 'Pampanga', 'Floridablanca'),
(1221, 14, 'Pampanga', 'Guagua'),
(1222, 14, 'Pampanga', 'Lubao'),
(1223, 14, 'Pampanga', 'Macabebe'),
(1224, 14, 'Pampanga', 'Magalang'),
(1225, 14, 'Pampanga', 'Masantol'),
(1226, 14, 'Pampanga', 'Mexico'),
(1227, 14, 'Pampanga', 'Minalin'),
(1228, 14, 'Pampanga', 'Porac'),
(1229, 14, 'Pampanga', 'San Luis'),
(1230, 14, 'Pampanga', 'San Simon'),
(1231, 14, 'Pampanga', 'Santa Ana'),
(1232, 14, 'Pampanga', 'Santa Rita'),
(1233, 14, 'Pampanga', 'Santo Tomas'),
(1234, 14, 'Pampanga', 'Sasmuan'),
(1235, 4, 'Pangasinan', 'Alaminos City'),
(1236, 4, 'Pangasinan', 'Dagupan City'),
(1237, 4, 'Pangasinan', 'San Carlos City'),
(1238, 4, 'Pangasinan', 'Urdaneta City'),
(1239, 4, 'Pangasinan', 'Agno'),
(1240, 4, 'Pangasinan', 'Aguilar'),
(1241, 4, 'Pangasinan', 'Alcala'),
(1242, 4, 'Pangasinan', 'Anda'),
(1243, 4, 'Pangasinan', 'Asingan'),
(1244, 4, 'Pangasinan', 'Balungao'),
(1245, 4, 'Pangasinan', 'Bani'),
(1246, 4, 'Pangasinan', 'Basista'),
(1247, 4, 'Pangasinan', 'Bautista'),
(1248, 4, 'Pangasinan', 'Bayambang'),
(1249, 4, 'Pangasinan', 'Binalonan'),
(1250, 4, 'Pangasinan', 'Binmaley'),
(1251, 4, 'Pangasinan', 'Bolinao'),
(1252, 4, 'Pangasinan', 'Bugallon'),
(1253, 4, 'Pangasinan', 'Burgos'),
(1254, 4, 'Pangasinan', 'Calasiao'),
(1255, 4, 'Pangasinan', 'Dasol'),
(1256, 4, 'Pangasinan', 'Infanta'),
(1257, 4, 'Pangasinan', 'Labrador'),
(1258, 4, 'Pangasinan', 'Laoac'),
(1259, 4, 'Pangasinan', 'Lingayen'),
(1260, 4, 'Pangasinan', 'Mabini'),
(1261, 4, 'Pangasinan', 'Malasiqui'),
(1262, 4, 'Pangasinan', 'Manaoag'),
(1263, 4, 'Pangasinan', 'Mangaldan'),
(1264, 4, 'Pangasinan', 'Mangatarem'),
(1265, 4, 'Pangasinan', 'Mapandan'),
(1266, 4, 'Pangasinan', 'Natividad'),
(1267, 4, 'Pangasinan', 'Pozzorubio'),
(1268, 4, 'Pangasinan', 'Rosales'),
(1269, 4, 'Pangasinan', 'San Fabian'),
(1270, 4, 'Pangasinan', 'San Jacinto'),
(1271, 4, 'Pangasinan', 'San Manuel'),
(1272, 4, 'Pangasinan', 'San Nicolas'),
(1273, 4, 'Pangasinan', 'San Quintin'),
(1274, 4, 'Pangasinan', 'Santa Barbara'),
(1275, 4, 'Pangasinan', 'Santa Maria'),
(1276, 4, 'Pangasinan', 'Santo Tomas'),
(1277, 4, 'Pangasinan', 'Sison'),
(1278, 4, 'Pangasinan', 'Sual'),
(1279, 4, 'Pangasinan', 'Tayug'),
(1280, 4, 'Pangasinan', 'Umingan'),
(1281, 4, 'Pangasinan', 'Urbiztondo'),
(1282, 4, 'Pangasinan', 'Villasis'),
(1283, 20, 'Quezon', 'Lucena City'),
(1284, 20, 'Quezon', 'Tayabas City'),
(1285, 20, 'Quezon', 'Agdangan'),
(1286, 20, 'Quezon', 'Alabat'),
(1287, 20, 'Quezon', 'Atimonan'),
(1288, 20, 'Quezon', 'Buenavista'),
(1289, 20, 'Quezon', 'Burdeos'),
(1290, 20, 'Quezon', 'Calauag'),
(1291, 20, 'Quezon', 'Candelaria'),
(1292, 20, 'Quezon', 'Catanauan'),
(1293, 20, 'Quezon', 'Dolores'),
(1294, 20, 'Quezon', 'General Luna'),
(1295, 20, 'Quezon', 'General Nakar'),
(1296, 20, 'Quezon', 'Guinayangan'),
(1297, 20, 'Quezon', 'Gumaca'),
(1298, 20, 'Quezon', 'Infanta'),
(1299, 20, 'Quezon', 'Jomalig'),
(1300, 20, 'Quezon', 'Lopez'),
(1301, 20, 'Quezon', 'Lucban'),
(1302, 20, 'Quezon', 'Macalelon'),
(1303, 20, 'Quezon', 'Mauban'),
(1304, 20, 'Quezon', 'Mulanay'),
(1305, 20, 'Quezon', 'Padre Burgos'),
(1306, 20, 'Quezon', 'Pagbilao'),
(1307, 20, 'Quezon', 'Panukulan'),
(1308, 20, 'Quezon', 'Patnanungan'),
(1309, 20, 'Quezon', 'Perez'),
(1310, 20, 'Quezon', 'Pitogo'),
(1311, 20, 'Quezon', 'Plaridel'),
(1312, 20, 'Quezon', 'Polillo'),
(1313, 20, 'Quezon', 'Quezon'),
(1314, 20, 'Quezon', 'Real'),
(1315, 20, 'Quezon', 'Sampaloc'),
(1316, 20, 'Quezon', 'San Andres'),
(1317, 20, 'Quezon', 'San Antonio'),
(1318, 20, 'Quezon', 'San Francisco'),
(1319, 20, 'Quezon', 'San Narciso'),
(1320, 20, 'Quezon', 'Sariaya'),
(1321, 20, 'Quezon', 'Tagkawayan'),
(1322, 20, 'Quezon', 'Tiaong'),
(1323, 20, 'Quezon', 'Unisan'),
(1324, 9, 'Quirino', 'Aglipay'),
(1325, 9, 'Quirino', 'Cabarroguis'),
(1326, 9, 'Quirino', 'Diffun'),
(1327, 9, 'Quirino', 'Maddela'),
(1328, 9, 'Quirino', 'Nagtipunan'),
(1329, 9, 'Quirino', 'Saguday'),
(1330, 21, 'Rizal', 'Antipolo City'),
(1331, 21, 'Rizal', 'Angono'),
(1332, 21, 'Rizal', 'Baras'),
(1333, 21, 'Rizal', 'Binangonan'),
(1334, 21, 'Rizal', 'Cainta'),
(1335, 21, 'Rizal', 'Cardona'),
(1336, 21, 'Rizal', 'Jalajala'),
(1337, 21, 'Rizal', 'Morong'),
(1338, 21, 'Rizal', 'Pililla'),
(1339, 21, 'Rizal', 'Rodriguez'),
(1340, 21, 'Rizal', 'San Mateo'),
(1341, 21, 'Rizal', 'Tanay'),
(1342, 21, 'Rizal', 'Taytay'),
(1343, 21, 'Rizal', 'Teresa'),
(1344, 24, 'Romblon', 'Alcantara'),
(1345, 24, 'Romblon', 'Banton'),
(1346, 24, 'Romblon', 'Cajidiocan'),
(1347, 24, 'Romblon', 'Calatrava'),
(1348, 24, 'Romblon', 'Concepcion'),
(1349, 24, 'Romblon', 'Corcuera'),
(1350, 24, 'Romblon', 'Ferrol'),
(1351, 24, 'Romblon', 'Looc'),
(1352, 24, 'Romblon', 'Magdiwang'),
(1353, 24, 'Romblon', 'Odiongan'),
(1354, 24, 'Romblon', 'Romblon'),
(1355, 24, 'Romblon', 'San Agustin'),
(1356, 24, 'Romblon', 'San Andres'),
(1357, 24, 'Romblon', 'San Fernando'),
(1358, 24, 'Romblon', 'San Jose'),
(1359, 24, 'Romblon', 'Santa Fe'),
(1360, 24, 'Romblon', 'Santa Maria'),
(1361, 47, 'Samar', 'Calbayog City'),
(1362, 47, 'Samar', 'Catbalogan City'),
(1363, 47, 'Samar', 'Almagro'),
(1364, 47, 'Samar', 'Basey'),
(1365, 47, 'Samar', 'Calbiga'),
(1366, 47, 'Samar', 'Daram'),
(1367, 47, 'Samar', 'Gandara'),
(1368, 47, 'Samar', 'Hinabangan'),
(1369, 47, 'Samar', 'Jiabong'),
(1370, 47, 'Samar', 'Marabut'),
(1371, 47, 'Samar', 'Matuguinao'),
(1372, 47, 'Samar', 'Motiong'),
(1373, 47, 'Samar', 'Pagsanghan'),
(1374, 47, 'Samar', 'Paranas'),
(1375, 47, 'Samar', 'Pinabacdao'),
(1376, 47, 'Samar', 'San Jorge'),
(1377, 47, 'Samar', 'San Jose De Buan'),
(1378, 47, 'Samar', 'San Sebastian'),
(1379, 47, 'Samar', 'Santa Margarita'),
(1380, 47, 'Samar', 'Santa Rita'),
(1381, 47, 'Samar', 'Santo Ni?o'),
(1382, 47, 'Samar', 'Tagapul-an'),
(1383, 47, 'Samar', 'Talalora'),
(1384, 47, 'Samar', 'Tarangnan'),
(1385, 47, 'Samar', 'Villareal'),
(1386, 47, 'Samar', 'Zumarraga'),
(1387, 62, 'Saranggani', 'Alabel'),
(1388, 62, 'Saranggani', 'Glan'),
(1389, 62, 'Saranggani', 'Kiamba'),
(1390, 62, 'Saranggani', 'Maasim'),
(1391, 62, 'Saranggani', 'Maitum'),
(1392, 62, 'Saranggani', 'Malapatan'),
(1393, 62, 'Saranggani', 'Malungon'),
(1394, 42, 'Siquijor', 'Enrique Villanueva'),
(1395, 42, 'Siquijor', 'Larena'),
(1396, 42, 'Siquijor', 'Lazi'),
(1397, 42, 'Siquijor', 'Maria'),
(1398, 42, 'Siquijor', 'San Juan'),
(1399, 42, 'Siquijor', 'Siquijor'),
(1400, 32, 'Sorsogon', 'Sorsogon City'),
(1401, 32, 'Sorsogon', 'Barcelona'),
(1402, 32, 'Sorsogon', 'Bulan'),
(1403, 32, 'Sorsogon', 'Bulusan'),
(1404, 32, 'Sorsogon', 'Casiguran'),
(1405, 32, 'Sorsogon', 'Castilla'),
(1406, 32, 'Sorsogon', 'Donsol'),
(1407, 32, 'Sorsogon', 'Gubat'),
(1408, 32, 'Sorsogon', 'Irosin'),
(1409, 32, 'Sorsogon', 'Juban'),
(1410, 32, 'Sorsogon', 'Magallanes'),
(1411, 32, 'Sorsogon', 'Matnog'),
(1412, 32, 'Sorsogon', 'Pilar'),
(1413, 32, 'Sorsogon', 'Prieto Diaz'),
(1414, 32, 'Sorsogon', 'Santa Magdalena'),
(1415, 63, 'South Cotabato', 'General Santos City'),
(1416, 63, 'South Cotabato', 'Koronadal City'),
(1417, 63, 'South Cotabato', 'Polomolok'),
(1418, 63, 'South Cotabato', 'Banga'),
(1419, 63, 'South Cotabato', 'Lake Sebu'),
(1420, 63, 'South Cotabato', 'Norala'),
(1421, 63, 'South Cotabato', 'Santo Ni&ntildeo'),
(1422, 63, 'South Cotabato', 'Surallah'),
(1423, 63, 'South Cotabato', 'Tboli'),
(1424, 63, 'South Cotabato', 'Tampakan'),
(1425, 63, 'South Cotabato', 'Tantangan'),
(1426, 63, 'South Cotabato', 'Tupi'),
(1427, 48, 'Southern Leyte', 'Maasin City'),
(1428, 48, 'Southern Leyte', 'Anahawan'),
(1429, 48, 'Southern Leyte', 'Bontoc'),
(1430, 48, 'Southern Leyte', 'Hinunangan');
INSERT INTO `tbl_city` (`id`, `province_id`, `province`, `city_name`) VALUES
(1431, 48, 'Southern Leyte', 'Hinundayan'),
(1432, 48, 'Southern Leyte', 'Libagon'),
(1433, 48, 'Southern Leyte', 'Liloan'),
(1434, 48, 'Southern Leyte', 'Limasawa'),
(1435, 48, 'Southern Leyte', 'Macrohon'),
(1436, 48, 'Southern Leyte', 'Malitbog'),
(1437, 48, 'Southern Leyte', 'Padre Burgos'),
(1438, 48, 'Southern Leyte', 'Pintuyan'),
(1439, 48, 'Southern Leyte', 'Saint Bernard'),
(1440, 48, 'Southern Leyte', 'San Francisco'),
(1441, 48, 'Southern Leyte', 'San Juan'),
(1442, 48, 'Southern Leyte', 'San Ricardo'),
(1443, 48, 'Southern Leyte', 'Silago'),
(1444, 48, 'Southern Leyte', 'Sogod'),
(1445, 48, 'Southern Leyte', 'Tomas Oppus'),
(1446, 64, 'Sultan Kudarat', 'Tacurong City'),
(1447, 64, 'Sultan Kudarat', 'Bagumbayan'),
(1448, 64, 'Sultan Kudarat', 'Columbio'),
(1449, 64, 'Sultan Kudarat', 'Esperanza'),
(1450, 64, 'Sultan Kudarat', 'Isulan'),
(1451, 64, 'Sultan Kudarat', 'Kalamansig'),
(1452, 64, 'Sultan Kudarat', 'Lambayong'),
(1453, 64, 'Sultan Kudarat', 'Lebak'),
(1454, 64, 'Sultan Kudarat', 'Lutayan'),
(1455, 64, 'Sultan Kudarat', 'Palimbang'),
(1456, 64, 'Sultan Kudarat', 'President Quirino'),
(1457, 64, 'Sultan Kudarat', 'Senator Ninoy Aquino'),
(1458, 75, 'Sulu', 'Banguingui'),
(1459, 75, 'Sulu', 'Hadji Panglima Tahil'),
(1460, 75, 'Sulu', 'Indanan'),
(1461, 75, 'Sulu', 'Jolo'),
(1462, 75, 'Sulu', 'Kalingalan Caluang'),
(1463, 75, 'Sulu', 'Lugus'),
(1464, 75, 'Sulu', 'Luuk'),
(1465, 75, 'Sulu', 'Maimbung'),
(1466, 75, 'Sulu', 'Old Panamao'),
(1467, 75, 'Sulu', 'Omar'),
(1468, 75, 'Sulu', 'Pandami'),
(1469, 75, 'Sulu', 'Panglima Estino'),
(1470, 75, 'Sulu', 'Pangutaran'),
(1471, 75, 'Sulu', 'Parang'),
(1472, 75, 'Sulu', 'Pata'),
(1473, 75, 'Sulu', 'Patikul'),
(1474, 75, 'Sulu', 'Siasi'),
(1475, 75, 'Sulu', 'Talipao'),
(1476, 75, 'Sulu', 'Tapul'),
(1477, 69, 'Surigao del Norte', 'Surigao City'),
(1478, 69, 'Surigao del Norte', 'Alegria'),
(1479, 69, 'Surigao del Norte', 'Bacuag'),
(1480, 69, 'Surigao del Norte', 'Burgos'),
(1481, 69, 'Surigao del Norte', 'Claver'),
(1482, 69, 'Surigao del Norte', 'Dapa'),
(1483, 69, 'Surigao del Norte', 'Del Carmen'),
(1484, 69, 'Surigao del Norte', 'General Luna'),
(1485, 69, 'Surigao del Norte', 'Gigaquit'),
(1486, 69, 'Surigao del Norte', 'Mainit'),
(1487, 69, 'Surigao del Norte', 'Malimono'),
(1488, 69, 'Surigao del Norte', 'Pilar'),
(1489, 69, 'Surigao del Norte', 'Placer'),
(1490, 69, 'Surigao del Norte', 'San Benito'),
(1491, 69, 'Surigao del Norte', 'San Francisco'),
(1492, 69, 'Surigao del Norte', 'San Isidro'),
(1493, 69, 'Surigao del Norte', 'Santa Monica'),
(1494, 69, 'Surigao del Norte', 'Sison'),
(1495, 69, 'Surigao del Norte', 'Socorro'),
(1496, 69, 'Surigao del Norte', 'Tagana-an'),
(1497, 69, 'Surigao del Norte', 'Tubod'),
(1498, 70, 'Surigao del Sur', 'Bislig City'),
(1499, 70, 'Surigao del Sur', 'Tandag City'),
(1500, 70, 'Surigao del Sur', 'Barobo'),
(1501, 70, 'Surigao del Sur', 'Bayabas'),
(1502, 70, 'Surigao del Sur', 'Cagwait'),
(1503, 70, 'Surigao del Sur', 'Cantilan'),
(1504, 70, 'Surigao del Sur', 'Carmen'),
(1505, 70, 'Surigao del Sur', 'Carrascal'),
(1506, 70, 'Surigao del Sur', 'Cortes'),
(1507, 70, 'Surigao del Sur', 'Hinatuan'),
(1508, 70, 'Surigao del Sur', 'Lanuza'),
(1509, 70, 'Surigao del Sur', 'Lianga'),
(1510, 70, 'Surigao del Sur', 'Lingig'),
(1511, 70, 'Surigao del Sur', 'Madrid'),
(1512, 70, 'Surigao del Sur', 'Marihatag'),
(1513, 70, 'Surigao del Sur', 'San Agustin'),
(1514, 70, 'Surigao del Sur', 'San Miguel'),
(1515, 70, 'Surigao del Sur', 'Tagbina'),
(1516, 70, 'Surigao del Sur', 'Tago'),
(1517, 15, 'Tarlac', 'Tarlac City'),
(1518, 15, 'Tarlac', 'Anao'),
(1519, 15, 'Tarlac', 'Bamban'),
(1520, 15, 'Tarlac', 'Camiling'),
(1521, 15, 'Tarlac', 'Capas'),
(1522, 15, 'Tarlac', 'Concepcion'),
(1523, 15, 'Tarlac', 'Gerona'),
(1524, 15, 'Tarlac', 'La Paz'),
(1525, 15, 'Tarlac', 'Mayantoc'),
(1526, 15, 'Tarlac', 'Moncada'),
(1527, 15, 'Tarlac', 'Paniqui'),
(1528, 15, 'Tarlac', 'Pura'),
(1529, 15, 'Tarlac', 'Ramos'),
(1530, 15, 'Tarlac', 'San Clemente'),
(1531, 15, 'Tarlac', 'San Jose'),
(1532, 15, 'Tarlac', 'San Manuel'),
(1533, 15, 'Tarlac', 'Santa Ignacia'),
(1534, 15, 'Tarlac', 'Victoria'),
(1535, 76, 'Tawi-tawi', 'Bongao'),
(1536, 76, 'Tawi-tawi', 'Languyan'),
(1537, 76, 'Tawi-tawi', 'Mapun'),
(1538, 76, 'Tawi-tawi', 'Panglima Sugala'),
(1539, 76, 'Tawi-tawi', 'Sapa-Sapa'),
(1540, 76, 'Tawi-tawi', 'Sibutu'),
(1541, 76, 'Tawi-tawi', 'Simunul'),
(1542, 76, 'Tawi-tawi', 'Sitangkai'),
(1543, 76, 'Tawi-tawi', 'South Ubian'),
(1544, 76, 'Tawi-tawi', 'Tandubas'),
(1545, 76, 'Tawi-tawi', 'Turtle Islands'),
(1546, 16, 'Zambales', 'Olongapo City'),
(1547, 16, 'Zambales', 'Botolan'),
(1548, 16, 'Zambales', 'Cabangan'),
(1549, 16, 'Zambales', 'Candelaria'),
(1550, 16, 'Zambales', 'Castillejos'),
(1551, 16, 'Zambales', 'Iba'),
(1552, 16, 'Zambales', 'Masinloc'),
(1553, 16, 'Zambales', 'Palauig'),
(1554, 16, 'Zambales', 'San Antonio'),
(1555, 16, 'Zambales', 'San Felipe'),
(1556, 16, 'Zambales', 'San Marcelino'),
(1557, 16, 'Zambales', 'San Narciso'),
(1558, 16, 'Zambales', 'Santa Cruz'),
(1559, 16, 'Zambales', 'Subic'),
(1560, 49, 'Zamboanga Del Norte', 'Dapitan City'),
(1561, 49, 'Zamboanga Del Norte', 'Dipolog City'),
(1562, 49, 'Zamboanga Del Norte', 'Bacungan'),
(1563, 49, 'Zamboanga Del Norte', 'Baliguian'),
(1564, 49, 'Zamboanga Del Norte', 'Godod'),
(1565, 49, 'Zamboanga Del Norte', 'Gutalac'),
(1566, 49, 'Zamboanga Del Norte', 'Jose Dalman'),
(1567, 49, 'Zamboanga Del Norte', 'Kalawit'),
(1568, 49, 'Zamboanga Del Norte', 'Katipunan'),
(1569, 49, 'Zamboanga Del Norte', 'La Libertad'),
(1570, 49, 'Zamboanga Del Norte', 'Labason'),
(1571, 49, 'Zamboanga Del Norte', 'Liloy'),
(1572, 49, 'Zamboanga Del Norte', 'Manukan'),
(1573, 49, 'Zamboanga Del Norte', 'Mutia'),
(1574, 49, 'Zamboanga Del Norte', 'Pinan'),
(1575, 49, 'Zamboanga Del Norte', 'Polanco'),
(1576, 49, 'Zamboanga Del Norte', 'President Manuel A. Roxas'),
(1577, 49, 'Zamboanga Del Norte', 'Rizal'),
(1578, 49, 'Zamboanga Del Norte', 'Salug'),
(1579, 49, 'Zamboanga Del Norte', 'Sergio Osme&ntildea Sr.'),
(1580, 49, 'Zamboanga Del Norte', 'Siayan'),
(1581, 49, 'Zamboanga Del Norte', 'Sibuco'),
(1582, 49, 'Zamboanga Del Norte', 'Sibutad'),
(1583, 49, 'Zamboanga Del Norte', 'Sindangan'),
(1584, 49, 'Zamboanga Del Norte', 'Siocon'),
(1585, 49, 'Zamboanga Del Norte', 'Sirawai'),
(1586, 49, 'Zamboanga Del Norte', 'Tampilisan'),
(1587, 50, 'Zamboanga Del Sur', 'Pagadian City'),
(1588, 50, 'Zamboanga Del Sur', 'Zamboanga City'),
(1589, 50, 'Zamboanga Del Sur', 'Aurora'),
(1590, 50, 'Zamboanga Del Sur', 'Bayog'),
(1591, 50, 'Zamboanga Del Sur', 'Dimataling'),
(1592, 50, 'Zamboanga Del Sur', 'Dinas'),
(1593, 50, 'Zamboanga Del Sur', 'Dumalinao'),
(1594, 50, 'Zamboanga Del Sur', 'Dumingag'),
(1595, 50, 'Zamboanga Del Sur', 'Guipos'),
(1596, 50, 'Zamboanga Del Sur', 'Josefina'),
(1597, 50, 'Zamboanga Del Sur', 'Kumalarang'),
(1598, 50, 'Zamboanga Del Sur', 'Labangan'),
(1599, 50, 'Zamboanga Del Sur', 'Lakewood'),
(1600, 50, 'Zamboanga Del Sur', 'Lapuyan'),
(1601, 50, 'Zamboanga Del Sur', 'Mahayag'),
(1602, 50, 'Zamboanga Del Sur', 'Margosatubig'),
(1603, 50, 'Zamboanga Del Sur', 'Midsalip'),
(1604, 50, 'Zamboanga Del Sur', 'Molave'),
(1605, 50, 'Zamboanga Del Sur', 'Pitogo'),
(1606, 50, 'Zamboanga Del Sur', 'Ramon Magsaysay'),
(1607, 50, 'Zamboanga Del Sur', 'San Miguel'),
(1608, 50, 'Zamboanga Del Sur', 'San Pablo'),
(1609, 50, 'Zamboanga Del Sur', 'Sominot'),
(1610, 50, 'Zamboanga Del Sur', 'Tabina'),
(1611, 50, 'Zamboanga Del Sur', 'Tambulig'),
(1612, 50, 'Zamboanga Del Sur', 'Tigbao'),
(1613, 50, 'Zamboanga Del Sur', 'Tukuran'),
(1614, 50, 'Zamboanga Del Sur', 'Vincenzo A. Sagun'),
(1615, 51, 'Zamboanga Sibugay', 'Alicia'),
(1616, 51, 'Zamboanga Sibugay', 'Buug'),
(1617, 51, 'Zamboanga Sibugay', 'Diplahan'),
(1618, 51, 'Zamboanga Sibugay', 'Imelda'),
(1619, 51, 'Zamboanga Sibugay', 'Ipil'),
(1620, 51, 'Zamboanga Sibugay', 'Kabasalan'),
(1621, 51, 'Zamboanga Sibugay', 'Mabuhay'),
(1622, 51, 'Zamboanga Sibugay', 'Malangas'),
(1623, 51, 'Zamboanga Sibugay', 'Naga'),
(1624, 51, 'Zamboanga Sibugay', 'Olutanga'),
(1625, 51, 'Zamboanga Sibugay', 'Payao'),
(1626, 51, 'Zamboanga Sibugay', 'Roseller Lim'),
(1627, 51, 'Zamboanga Sibugay', 'Siay'),
(1628, 51, 'Zamboanga Sibugay', 'Talusan'),
(1629, 51, 'Zamboanga Sibugay', 'Titay'),
(1630, 51, 'Zamboanga Sibugay', 'Tungawan'),
(1631, 6, 'Cagayan', 'Aparri'),
(1632, 6, 'Cagayan', 'Allacapan'),
(1633, 6, 'Cagayan', 'Abulug'),
(1634, 6, 'Cagayan', 'Divisoria'),
(1635, 6, 'Cagayan', 'Carmen'),
(1636, 6, 'Cagayan', 'Agora'),
(1637, 6, 'Cagayan', 'Cagayan de Oro City'),
(1638, 6, 'Cagayan', 'Bagong Barrio'),
(1639, 6, 'Cagayan', 'Sta. Ana'),
(1640, 6, 'Cagayan', 'Sanchez Mira'),
(1641, 6, 'Cagayan', 'Baggao'),
(1642, 6, 'Cagayan', 'Iguig'),
(1643, 6, 'Cagayan', 'Gonzaga'),
(1644, 6, 'Cagayan', 'Gattaran'),
(1645, 6, 'Cagayan', 'Tuguegarao City'),
(1646, 6, 'Cagayan', 'Solana'),
(1647, 6, 'Cagayan', 'Claveria'),
(1648, 2, 'Cagayan', 'Solana'),
(1649, 2, 'Cagayan', 'Claveria'),
(1650, 6, 'Cagayan', 'Camalaniugan'),
(1651, 36, 'Guimaras', 'Guimaras'),
(1652, 39, 'Bohol', 'Tagbilaran City'),
(1653, 40, 'Cebu', 'Cebu City'),
(1654, 40, 'Cebu', 'Daan Bantayan'),
(1655, 40, 'Cebu', 'Lapu-lapu City'),
(1656, 40, 'Cebu', 'Tabunok City'),
(1657, 40, 'Cebu', 'Bulacao'),
(1658, 40, 'Cebu', 'Inayawan'),
(1659, 40, 'Cebu', 'Labangon'),
(1660, 40, 'Cebu', 'Mambaling'),
(1661, 40, 'Cebu', 'Osme&ntildea'),
(1662, 40, 'Cebu', 'Pardo'),
(1663, 40, 'Cebu', 'Taboan'),
(1664, 40, 'Cebu', 'Talamban'),
(1665, 45, 'Leyte', 'San Juan'),
(1666, 2, 'Ilocos Sur', 'Sta. Lucia'),
(1667, 11, 'Bataan', ' Bala'),
(1668, 50, 'Zamboanga Del Sur', 'Sangali'),
(1669, 55, 'Misamis Occidental', 'Balingasag'),
(1670, 58, 'Davao del Norte', 'Panabo'),
(1671, 58, 'Davao del Norte', 'Sto. Tomas'),
(1672, 58, 'Davao del Norte', 'Lupon'),
(1673, 59, 'Davao del Sur', 'Buhanguin'),
(1674, 59, 'Davao del Sur', 'Lanang'),
(1675, 59, 'Davao del Sur', 'Piapi'),
(1676, 59, 'Davao del Sur', 'Sasa'),
(1677, 59, 'Davao del Sur', 'Bajada'),
(1678, 59, 'Davao del Sur', 'Calinan'),
(1679, 66, 'Agusan del Norte', 'Bayugan'),
(1680, 66, 'Agusan del Norte', 'Prosperidad'),
(1681, 66, 'Agusan del Norte', 'San Francisco'),
(1683, 79, 'Apayao', 'Tabuk'),
(1684, 4, 'Pangasinan', 'Pozzorobio'),
(1685, 6, 'Cagayan', 'Alcala'),
(1686, 27, 'Albay', 'Tiwi'),
(1687, 6, 'Cagayan', 'Ballesteros'),
(1688, 44, 'Eastern Samar', 'Homonhon'),
(1689, 6, 'Cagayan', 'Lasam'),
(1690, 6, 'Cagayan', 'Piat'),
(1691, 6, 'Cagayan', 'Tuao'),
(1692, 79, 'Apayao', 'Sta. Marcela'),
(1693, 69, 'Surigao Del Norte', 'Dinagat'),
(1694, 69, 'Surigao Del Norte', 'Loreto'),
(1695, 69, 'Surigao Del Norte', 'Siargao');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_consumables`
--

CREATE TABLE IF NOT EXISTS `tbl_consumables` (
  `con_id` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(10) NOT NULL,
  `item_code` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `unit_cost` int(15) NOT NULL,
  `description` varchar(35) NOT NULL,
  `selling_price` int(20) NOT NULL,
  PRIMARY KEY (`con_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_consumables`
--

INSERT INTO `tbl_consumables` (`con_id`, `brand`, `item_code`, `type`, `unit_cost`, `description`, `selling_price`) VALUES
(1, '40', 'CS-001', 'xxx', 0, 'Spark with Plugs', 10000),
(2, '40', 'CS-002', 'yyyx', 0, 'Piston Kit with pistonx', 500),
(3, '38', 'CS-003', 'zzzx', 0, 'Oil with Filterx', 0),
(7, '43', 'CS-123', '001x', 8000, 'asasax', 200),
(6, '40', 'CS-0023', 'sample typex', 0, 'ok sample typex', 500),
(8, '40', 'CS-007', 'ewan', 0, 'sample', 0),
(14, '56', 'CS-888', 'xxxx', 5000, 'sample', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `birthday` varchar(20) NOT NULL,
  `telephone_no` varchar(20) NOT NULL,
  `cellphone_no` varchar(20) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `customer_region_id` int(11) NOT NULL,
  `customer_province_id` int(11) NOT NULL,
  `customer_city_town_id` int(11) NOT NULL,
  `customer_subd_brgy` varchar(50) NOT NULL,
  `customer_street_num` varchar(50) NOT NULL,
  `shipping_region_id` int(11) NOT NULL,
  `shipping_province_id` int(11) NOT NULL,
  `shipping_city_town_id` int(11) NOT NULL,
  `shipping_subd_brgy` varchar(50) NOT NULL,
  `shipping_street_num` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `last_name`, `first_name`, `middle_name`, `birthday`, `telephone_no`, `cellphone_no`, `branch_id`, `customer_region_id`, `customer_province_id`, `customer_city_town_id`, `customer_subd_brgy`, `customer_street_num`, `shipping_region_id`, `shipping_province_id`, `shipping_city_town_id`, `shipping_subd_brgy`, `shipping_street_num`) VALUES
(1, 'Aguila', 'Maria Liza', 'de Leon', '1993-02-06', '2512121', '121231', 2, 1, 2, 6, '', '', 1, 2, 6, '', ''),
(2, 'fdsf', 'dfd', 'gfdgfd', '2014-04-04', '4512', '3231121', 2, 1, 2, 6, 'bvbfgv', '', 1, 2, 6, 'bvbfgv', ''),
(3, 'dsad', 'dfsfds', 'dsffds', '2014-04-04', '52121521', '152165', 5, 1, 2, 5, '', '', 1, 2, 5, '', ''),
(4, 'Aguila', 'Malou', 'de Leon', '2014-04-04', '21212', '3216546', 1, 1, 3, 9, '', '', 1, 2, 7, '', ''),
(5, 'Jason', 'Pulga', 'Chupachups', '2014-04-08', '212512512', '1212121', 1, 16, 77, 6, 'sdada', 'dsada', 16, 77, 5, 'sdada', 'dsada'),
(6, 'Ilagan', 'Maria', 'Theresa', '1989-11-29', '', '', 2, 4, 17, 187, 'Nangkaan', '', 4, 17, 187, 'Nangkaan', ''),
(7, 'LOYD', 'PATAWAD', 'AKO AY MAKASALANAN', '2014-05-07', '123', '1213', 2, 1, 1, 619, '', '', 12, 57, 505, '', ''),
(8, 'jayson', 'patawad', 'ako ay makasalanan', '2014-05-07', '12', '11', 5, 2, 7, 722, '', '', 2, 7, 722, '', ''),
(9, 'ACES', 'GEN', 'MAN', '2014-05-08', '1233', '1223', 1, 1, 2, 320, '', '', 1, 2, 320, '', ''),
(11, 'test', 'test', 'test', '2014-05-08', '123', '123', 4, 3, 11, 152, '', '', 3, 11, 152, '', ''),
(12, 'she', 'she', 'gajjkk', '2014-05-08', '1223', '123', 5, 4, 19, 784, 'mayapa', '', 4, 19, 784, 'mayapa', ''),
(13, 'Nastimo', 'Sample', 'Sample', '2014-05-09', '12345', '123456', 4, 4, 19, 784, 'Delpilat', '1431 ST', 4, 19, 784, 'Delpilat', '1431 ST');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ledger`
--

CREATE TABLE IF NOT EXISTS `tbl_ledger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_no` varchar(50) NOT NULL,
  `customer_name` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `amount_loan` int(11) NOT NULL,
  `loan_type_id` int(11) NOT NULL,
  `interest_rate` double NOT NULL,
  `date_released` varchar(10) NOT NULL,
  `installment_due` varchar(10) NOT NULL,
  `terms` int(11) NOT NULL,
  `installment_amount` int(11) NOT NULL,
  `interest_income` int(11) NOT NULL,
  `finance_charges` double NOT NULL,
  `mortgage_details` varchar(100) NOT NULL,
  `co_name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_ledger`
--

INSERT INTO `tbl_ledger` (`id`, `account_no`, `customer_name`, `branch_id`, `amount_loan`, `loan_type_id`, `interest_rate`, `date_released`, `installment_due`, `terms`, `installment_amount`, `interest_income`, `finance_charges`, `mortgage_details`, `co_name`, `address`, `contact_no`) VALUES
(1, 'DSASDADA', 1, 2, 25000, 2, 0.03, '2014-04-08', '2014-04-21', 12, 13353, 135000, 233.82, 'bhgvbvnb', 'bvcbcv', 'bvcbcvb', '215215'),
(2, 'fsdfdsfds', 2, 5, 10000, 2, 0.45, '2014-04-20', '2014-04-14', 7, 8019, 81000, 233.82, 'xdzscszfsdzfc', 'czxdcsd', 'szcxsc', '215545'),
(4, 'dsadsa', 5, 3, 15000, 2, 0.5, '2014-04-10', '2014-04-10', 5, 3497, 2250, 233.82, 'dsdsad', 'dsadasd', 'sadsad', '2546415');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_loan`
--

CREATE TABLE IF NOT EXISTS `tbl_loan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_type` varchar(50) NOT NULL,
  `interest_rate` double NOT NULL,
  `penalty_interest` int(11) NOT NULL,
  `monthly_rebate` double NOT NULL,
  `diminishing_method` varchar(50) NOT NULL,
  `insurance_fee` double NOT NULL,
  `notarial_fee` double NOT NULL,
  `filing_fee` double NOT NULL,
  `doc_stamp` double NOT NULL,
  `loan_advances` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_loan`
--

INSERT INTO `tbl_loan` (`id`, `loan_type`, `interest_rate`, `penalty_interest`, `monthly_rebate`, `diminishing_method`, `insurance_fee`, `notarial_fee`, `filing_fee`, `doc_stamp`, `loan_advances`) VALUES
(2, 'Car Loan', 0.03, 2, 300, 'daskdjas', 12.3, 45.5, 126.81, 4.01, 45.2),
(3, 'Motorcycle Loan', 0.03, 1, 300, '', 1200, 120, 50, 25, 100);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_manufacturer`
--

CREATE TABLE IF NOT EXISTS `tbl_manufacturer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(20) NOT NULL,
  `category` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `tbl_manufacturer`
--

INSERT INTO `tbl_manufacturer` (`id`, `brand`, `category`) VALUES
(1, 'YAMAHA', '1'),
(2, 'HONDA', '1'),
(3, 'SUZUKI', '1'),
(4, 'KAWASAKI', '1'),
(16, 'XRM', '1'),
(12, 'SYM', '1'),
(17, 'YAMAHA', '2'),
(18, 'HONDA', '2'),
(19, 'SUZUKI', '2'),
(20, 'KAWASAKI', '2'),
(21, 'seaoil', '2'),
(22, 'ZXY', '2'),
(23, 'XZY', '2'),
(24, 'ABC', '2'),
(37, 'KOWOSAKI', '3'),
(36, 'YOMOHO', '3'),
(32, 'AAA', '2'),
(31, 'BBB', '2'),
(33, 'DDD', '2'),
(34, 'XXX', '2'),
(35, 'ZZZ', '2'),
(38, 'YAMAHA', '3'),
(56, 'KAWASAKI', '4'),
(40, 'YAMAHA', '4'),
(41, 'Sinski', '1'),
(42, 'HONDA', '3'),
(43, 'Honda', '4'),
(47, 'XYZ', '1'),
(46, 'SUN', '1'),
(51, 'sample', '1'),
(50, 'ABC', '1'),
(52, 'GALAXY', '2'),
(53, 'ROXY', '2'),
(54, 'YAMAHAX', '2'),
(55, 'HONDA_SM', '3'),
(57, 'NORWAY', '4'),
(58, 'KAWASAKI', '3'),
(59, 'BMW', '1'),
(60, '102', '3'),
(62, 'SAMPLE2', '1'),
(63, 'Motolite', '2'),
(64, 'HONDA2', '2');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_motorcycle`
--

CREATE TABLE IF NOT EXISTS `tbl_motorcycle` (
  `motor_id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(25) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `engine_type` varchar(30) NOT NULL,
  `displacement` varchar(30) NOT NULL,
  `oil_capacity` varchar(30) NOT NULL,
  `unit_cost` int(15) NOT NULL,
  `selling_price` int(20) NOT NULL,
  `installment` int(20) NOT NULL,
  PRIMARY KEY (`motor_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `tbl_motorcycle`
--

INSERT INTO `tbl_motorcycle` (`motor_id`, `model`, `brand`, `engine_type`, `displacement`, `oil_capacity`, `unit_cost`, `selling_price`, `installment`) VALUES
(1, 'VEGAFORCE', '1', '4stroke AirCooled SOHC', '114ccx', '1liter', 50, 69, 3),
(2, 'MIO MX', '1', 'sample ko', '124.9ccx', '2liters', 7500, 70, 35),
(3, 'FINO CLASSIC', '1', 'Force AirCooled 4stoke', '144ccxx', '1liter', 9500, 30000, 4),
(4, 'Honda CBR 150R', '2', '2stokexs', '150CCxa', '95liters', 0, 500, 124),
(5, 'SUZUKI MOTORS', '3', '2stoke x', '130CC', '150 liters', 0, 1250, 300),
(18, 'Sinski Motorsiklos', '41', 'motor', '120 cc', '1 liter', 0, 0, 0),
(23, 'GD 500', '59', 'Air Cooled', '300 CC', '12', 1230, 2000, 500),
(26, 'ZASUS', '59', 'AIR CON', '150.CC', '50 liters', 0, 1, 300),
(27, 'ZIPPI CODE', '59', 'AIC', '150.CC', '25 liters', 0, 20, 7000),
(28, 'ZIPPI CODE', '1', 'sample', 'sample', 'sample', 0, 55000, 0),
(30, 'GD110HU', '2', '2 stroke', '100 cc', '1 liters', 0, 0, 0),
(31, 'RAZZI MODEL', '50', '4stroke LiquidCooled', '505.CC', '500 liter', 1200, 200, 0),
(32, 'ABC MODEL', '50', 'ABC ENGINE', '50.CC', '50 liters', 3000, 0, 0),
(37, 'a', '62', 'MA', 'Aa', 'as', 25000, 0, 0),
(38, 'GD100', '62', 'a', 'a', 'a', 3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_parts`
--

CREATE TABLE IF NOT EXISTS `tbl_parts` (
  `parts_id` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(10) NOT NULL,
  `item_code` varchar(30) NOT NULL,
  `parts` varchar(20) NOT NULL,
  `unit_cost` int(15) NOT NULL,
  `description` varchar(35) NOT NULL,
  `selling_price` int(20) NOT NULL,
  PRIMARY KEY (`parts_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `tbl_parts`
--

INSERT INTO `tbl_parts` (`parts_id`, `brand`, `item_code`, `parts`, `unit_cost`, `description`, `selling_price`) VALUES
(1, '64', 'PA-1213', 'Spark Plugs', 100, 'Spark with Plugsx', 3000),
(3, '17', 'PA-003', 'Oil Filter', 0, 'Oil with Filter', 30000),
(5, '17', 'PA-004', 'sample', 0, 'sample', 0),
(8, '20', 'PA-105', '2 TIER kawasaki', 300, 'front tier ', 8000),
(24, '20', 'PA-1212', 'sample', 9000, 'sample', 0),
(25, '53', 'PA-1956', 'CITIZEN PARTS', 3000, 'frontier', 0),
(26, '63', 'PA-BATT-12N5', 'BATTERY ASSY 12N5-3B', 472, 'BATTERY ASSY 12N5-3B', 800);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_promo`
--

CREATE TABLE IF NOT EXISTS `tbl_promo` (
  `promo_id` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(10) NOT NULL,
  `item_code` varchar(30) NOT NULL,
  `unit_cost` int(15) NOT NULL,
  `description` varchar(35) NOT NULL,
  `selling_price` int(20) NOT NULL,
  PRIMARY KEY (`promo_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbl_promo`
--

INSERT INTO `tbl_promo` (`promo_id`, `brand`, `item_code`, `unit_cost`, `description`, `selling_price`) VALUES
(8, '55', '001', 500, 'samples', 0),
(2, '38', '002', 1, 'Piston Kit with piston', 0),
(3, '38', '003', 0, 'Oil with Filter', 0),
(13, '58', '203', 0, 'example', 0),
(14, '58', '02323', 0, 'ewan sample', 0),
(16, '38', 'PI-005', 0, 'sample', 0),
(17, '55', 'PI-506', 3000, 'ewan sample', 0),
(18, '42', 'PI-500', 500, '1', 9000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_province`
--

CREATE TABLE IF NOT EXISTS `tbl_province` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) NOT NULL,
  `province_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `tbl_province`
--

INSERT INTO `tbl_province` (`id`, `region_id`, `province_name`) VALUES
(1, 1, 'Ilocos Norte'),
(2, 1, 'Ilocos Sur'),
(3, 1, 'La Union'),
(4, 1, 'Pangasinan'),
(5, 2, 'Batanes'),
(6, 2, 'Cagayan'),
(7, 2, 'Isabela'),
(8, 2, 'Nueva Vizcaya'),
(9, 2, 'Quirino'),
(10, 3, 'Aurora'),
(11, 3, 'Bataan'),
(12, 3, 'Bulacan'),
(13, 3, 'Nueva Ecija'),
(14, 3, 'Pampanga'),
(15, 3, 'Tarlac'),
(16, 3, 'Zambales'),
(17, 4, 'Batangas'),
(18, 4, 'Cavite'),
(19, 4, 'Laguna'),
(20, 4, 'Quezon'),
(21, 4, 'Rizal'),
(22, 5, 'Occidental Mindoro'),
(23, 5, 'Oriental Mindoro'),
(24, 5, 'Romblon'),
(25, 5, 'Marinduque'),
(26, 5, 'Palawan'),
(27, 6, 'Albay'),
(28, 6, 'Camarines Norte'),
(29, 6, 'Camarines Sur'),
(30, 6, 'Catanduanes'),
(31, 6, 'Masbate'),
(32, 6, 'Sorsogon'),
(33, 7, 'Aklan'),
(34, 7, 'Antique'),
(35, 7, 'Capiz'),
(36, 7, 'Guimaras'),
(37, 7, 'Iloilo'),
(38, 7, 'Negros Occidental'),
(39, 8, 'Bohol'),
(40, 8, 'Cebu'),
(41, 8, 'Negros Oriental'),
(42, 8, 'Siquijor'),
(43, 9, 'Biliran'),
(44, 9, 'Eastern Samar'),
(45, 9, 'Leyte'),
(46, 9, 'Northern Samar'),
(47, 9, 'Samar'),
(48, 9, 'Southern Leyte'),
(49, 10, 'Zamboanga del Norte'),
(50, 10, 'Zamboanga del Sur'),
(51, 10, 'Zamboanga Sibugay'),
(52, 11, 'Bukidnon'),
(53, 11, 'Camiguin'),
(54, 11, 'Lanao del Norte'),
(55, 11, 'Misamis Occidental'),
(56, 11, 'Misamis Oriental'),
(57, 12, 'Compostela Valley'),
(58, 12, 'Davao del Norte'),
(59, 12, 'Davao del Sur'),
(60, 12, 'Davao Oriental'),
(61, 13, 'Cotabato'),
(62, 13, 'Saranggani'),
(63, 13, 'South Cotabato'),
(64, 13, 'Sultan Kudarat'),
(66, 14, 'Agusan del Norte'),
(67, 14, 'Agusan del Sur'),
(68, 14, 'Dinagat Islands'),
(69, 14, 'Surigao del Norte'),
(70, 14, 'Surigao del Sur'),
(71, 15, 'Basilan'),
(72, 15, 'Lanao del Sur'),
(73, 15, 'Maguindanao'),
(74, 15, 'Shariff Kabunsuan'),
(75, 15, 'Sulu'),
(76, 15, 'Tawi-tawi'),
(77, 16, 'Metro Manila'),
(78, 17, 'Abra'),
(79, 17, 'Apayao'),
(80, 17, 'Benguet'),
(81, 17, 'Ifugao'),
(82, 17, 'Kalinga'),
(83, 17, 'Mountain Province');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_region`
--

CREATE TABLE IF NOT EXISTS `tbl_region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_region`
--

INSERT INTO `tbl_region` (`id`, `region_name`) VALUES
(1, 'Ilocos Region'),
(2, 'Cagayan Valley'),
(3, 'Central Luzon'),
(4, 'CALABARZON'),
(5, 'MIMAROPA'),
(6, 'Bicol Region'),
(7, 'Western Visayas'),
(8, 'Central Visayas'),
(9, 'Eastern Visayas'),
(10, 'Zamboanga Peninsula'),
(11, 'Northern Mindanao'),
(12, 'Davao Region'),
(13, 'SOCCSKSARGEN'),
(14, 'CARAGA'),
(15, 'ARMM'),
(16, 'NCR'),
(17, 'CAR');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_requisition`
--

CREATE TABLE IF NOT EXISTS `tbl_requisition` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT,
  `sr_no` varchar(20) NOT NULL,
  `date` varchar(30) NOT NULL,
  `branch_code` varchar(10) NOT NULL,
  `sold` varchar(35) NOT NULL,
  PRIMARY KEY (`req_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `tbl_requisition`
--

INSERT INTO `tbl_requisition` (`req_id`, `sr_no`, `date`, `branch_code`, `sold`) VALUES
(1, 'AB101', '2014-04-11', 'VSQ', 'gen aces'),
(30, 'MAN12', '2014-04-21', 'RED', 'jayson pulga'),
(29, 'JJJ', '2014-04-24', 'RED', 'jayson'),
(28, 'MARK12', '2014-04-14', 'VSQ', 'mark pamintuan'),
(25, 'ABC123', '2014-04-12', '3SS', 'gen aces'),
(21, 'JAY12', '2014-04-12', 'VSQ', 'jayson pulga'),
(27, 'AAA', '2014-04-14', 'RED', 'jayson pulga'),
(19, 'GEN23', '2014-04-12', '3SS', 'jayson gatungay'),
(31, '101', '2014-05-20', '3SY', 'SAMPLE');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stock_requisition`
--

CREATE TABLE IF NOT EXISTS `tbl_stock_requisition` (
  `stock_id` int(11) NOT NULL AUTO_INCREMENT,
  `sr_no` varchar(20) NOT NULL,
  `category` int(15) NOT NULL,
  `brand` int(15) NOT NULL,
  `item` int(10) NOT NULL,
  `color` varchar(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `unit_cost` float NOT NULL,
  PRIMARY KEY (`stock_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `tbl_stock_requisition`
--

INSERT INTO `tbl_stock_requisition` (`stock_id`, `sr_no`, `category`, `brand`, `item`, `color`, `quantity`, `unit_cost`) VALUES
(38, 'GEN23', 1, 1, 3, 'magenda', 8, 28500),
(50, 'MARK12', 1, 1, 1, 'yellow', 2, 1150),
(32, 'AB101', 3, 38, 2, '', 6, 5000),
(31, 'AB101', 2, 32, 7, '', 5, 2000),
(46, 'AAA', 1, 1, 3, 'blue', 5, 9500),
(30, 'AB101', 1, 1, 3, 'blue', 5, 28500),
(33, 'AB101', 1, 1, 2, 'red', 5, 7500),
(36, 'JAY12', 4, 43, 7, '', 10, 8000),
(37, 'JAY12', 1, 1, 3, 'blue', 8, 2000),
(48, 'ABC123', 1, 1, 2, 'green', 5, 7500),
(49, 'ABC123', 1, 41, 18, 'brown', 2, 300),
(51, 'MARK12', 1, 50, 32, 'brown', 3, 3000),
(52, 'MARK12', 1, 3, 30, 'green', 2, 3000),
(54, 'AAA', 3, 58, 14, '', 5, 0),
(55, 'AAA', 4, 56, 14, '', 2, 5000),
(56, '101', 2, 64, 1, '', 50, 2000),
(57, '101', 1, 2, 4, 'red', 8, 4000),
(58, '101', 3, 37, 0, '', 8, 4000),
(59, '101', 1, 5, 0, '2', 8, 4000),
(60, '101', 2, 32, 0, '', 8, 4000),
(61, '101', 2, 31, 0, '', 8, 4000),
(62, '101', 1, 2, 4, 'BLUE', 5, 2000),
(63, '101', 1, 47, 0, 'blue', 30, 30),
(64, '101', 1, 16, 0, 'blue', 10, 30),
(65, '101', 2, 22, 0, '', 1, 30);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(50) NOT NULL,
  `telephone_number` varchar(50) NOT NULL,
  `contact_person` varchar(50) NOT NULL,
  `region_id` int(11) NOT NULL,
  `province_id` int(11) NOT NULL,
  `city_town_id` int(11) NOT NULL,
  `subd_brgy` varchar(50) NOT NULL,
  `street_num` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `supplier_name`, `telephone_number`, `contact_person`, `region_id`, `province_id`, `city_town_id`, `subd_brgy`, `street_num`) VALUES
(2, 'SUZUKI', '902-1000', 'Ronald Cabangon', 1, 3, 765, 'skjdks', 'kjhdksd'),
(3, 'Kawasaki', '07204589', 'Marlon', 15, 71, 140, 'Lodlod', '124'),
(6, 'rieri', 'jkhjnkh', 'khjkh', 2, 9, 1324, 'fdf', 'fdfds'),
(7, 'sadsad', 'dsdsds', 'dss', 6, 27, 91, 'fdsfsf', 'fdsfsf'),
(8, 'Kawasaki MNL', '091659', 'Liza Aguila', 16, 77, 3, '156', '4');

-- --------------------------------------------------------

--
-- Table structure for table `transfer_details`
--

CREATE TABLE IF NOT EXISTS `transfer_details` (
  `id_s` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(20) NOT NULL,
  `dr_no` varchar(20) NOT NULL,
  `category` varchar(15) NOT NULL,
  `brand` int(15) NOT NULL,
  `item` int(10) NOT NULL,
  `color` varchar(30) NOT NULL,
  `qty` int(20) NOT NULL,
  PRIMARY KEY (`id_s`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=244 ;

--
-- Dumping data for table `transfer_details`
--

INSERT INTO `transfer_details` (`id_s`, `stock_id`, `dr_no`, `category`, `brand`, `item`, `color`, `qty`) VALUES
(230, '21', 'MAN', '1', 1, 1, 'GRAY', 1),
(240, '18', 'MAN', '2', 63, 26, '', 5),
(241, '22', 'MAN', '2', 63, 26, '', 0),
(242, '24', 'MAN', '2', 64, 1, '', 5),
(243, '23', 'OKAY', '1', 1, 2, 'RED', 1);

-- --------------------------------------------------------

--
-- Table structure for table `transfer_item`
--

CREATE TABLE IF NOT EXISTS `transfer_item` (
  `transfer_id` int(11) NOT NULL AUTO_INCREMENT,
  `dr_no` varchar(10) NOT NULL,
  `branch_code` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `move_to` varchar(25) NOT NULL,
  `remarks` varchar(40) NOT NULL,
  PRIMARY KEY (`transfer_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `transfer_item`
--

INSERT INTO `transfer_item` (`transfer_id`, `dr_no`, `branch_code`, `date`, `move_to`, `remarks`) VALUES
(39, 'OKAY', 'LCB', '2014-05-06', '3SY', ''),
(37, 'MAN', '3SS', '2014-05-02', 'VSQ', 'Sample');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
