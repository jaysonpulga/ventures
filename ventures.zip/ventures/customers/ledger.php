<?php
session_start();
include('../database.php');
$db = new Database();  
$db->connect();

if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION["username"];
$branch_name = $_SESSION["branch_name"];
$branch_id = $_SESSION['branch_id'];
?>
<html>
<title>Ledger</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
<body>
<input type="hidden" id="branch_id" value="<?php echo $_SESSION['branch_id']; ?>" >
<input type="hidden" id="branch_name" value="<?php echo $_SESSION['branch_name']; ?>" >
<input type="hidden" id="branch_code" value="<?php echo $_SESSION['branch_code']; ?>" >
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<table width="1000px">
						<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2 style="margin-top:10px;">LEDGER</h2>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
								<form name="search" action="" method="POST">
								<select id = "txttype">
								<?php 
									$db->select('tbl_loan','id,loan_type');
									$result = $db->getResult();
											
									foreach($result as $info){
										$id = $info['id'];
										$loan_type = $info['loan_type'];
										
									echo '<option value='.$id.'>'.$loan_type.'</option>';
									}
								?>
								</select>
								<select id = 'category' name='category'>
									<option value = "name">Name</option>
								</select>
								<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Report">
								<a href="newLoan.php?menu=customers"><input type="button" value="NEW LOAN" style="width:130px;top:1px;"></a>
								</form> 
							</td>
						</tr>
					</table>
				</div>
			
								
				<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:1000px" cellspacing="0">
					<table id="ledger_list" border=1 align = "center">

						<thead align="center">
						<tr>
							<th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'name')">NAME</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'date_released')">DATE RELEASED</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'amount_loan')">LOAN AMOUNT</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'terms')">TERMS</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'interest_income')">INTEREST</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'balance')">BALANCE</th><th colspan="2">ACTION</th>
						</tr>
						</thead>
						
						<tbody id="ledger_data"></tbody>
						
					</table>
				</div>
				
				<div id="pagination"> 
					<div class="holder" style = "margin-top:30px;"></div>
					<i>Pages</i>
				</div>
				
				<div id="new_items" title="" style="display:none;">
					<iframe id="item_dialog" width="400" height="430" style="border:none"></iframe>
				</div>
				
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	
	function jpages(){
		$("div.holder").jPages({
		  containerID : "ledger_data",
		  previous : "←",
		  next : "→",
		  perPage : 15,
		  delay :10,
		  startPage    : 1,
		  startRange   : 1,
		  midRange     : 5,
		  endRange     : 1
		});
	}
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="customers#"){
			menu="customers";
		}
		else{
			menu = getUrlVars()["menu"];	
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -100px 5px no-repeat",
		"padding":"30px 20px 0px 20px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadData("id","DESC");
		
	});
	
	$("#txttype").change(function () {
		var txttype =	$("#txttype :selected").val();
		loadData("id","DESC");	
	});
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
				
	var sortType = "ASC";
	
	function filter_list(index,cVar){
		sort = cVar;
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadData(sort,sortType);
	}
	
	var branch_id = $("#branch_id").val();
	var branch_name = $("#branch_name").val();
	var branch_code = $("#branch_code").val();
	var type = $("#txttype :selected").val();
	
	$("#txtsearch").live("keyup change",function(){
		$("#customer_list > tbody").empty();
		var txttype =	$("#txttype :selected").val();
		loadData("id","DESC");			
	})
	
	
	function loadData(sort,sortType){

		 $("#ledger_list > tbody").empty();
		
		var url="functions.php?request=ajax&action=viewLedgerData&sort="+sort+"&sortType="+sortType+"&inputsearch="+$("#txtsearch").val()+"&category="+$("#category").val()+"&branch_id="+branch_id+"&loan_type="+$("#txttype :selected").val();
		var counter = 0;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				var data_collect = res.data_collect;
				var amount = FormatNumberBy3(parseFloat(Math.round((res.amount_loan)*100)/100).toFixed(2));
				var interest = FormatNumberBy3(parseFloat(Math.round((res.interest_income)*100)/100).toFixed(2));
				var balance = FormatNumberBy3(parseFloat(Math.round((res.balance)*100)/100).toFixed(2));
				
				if(data_collect == "true") {
					$("#ledger_list > tbody").append("<tr class = 'x' onmouseover = 'clickSearch();'><td>"+res.name+"</td><td>"+res.date_released+"</td><td><div align = 'right'>"+amount+"</div></td><td>"+res.terms+"</td><td><div align = 'right'>"+interest+"</div></td><td><div align = 'right'>"+balance+"</div></td><td align = 'center' colspan=2><a href='#' class='view' title='VIEW link' onclick=\"view_ledger("+res.id+",'"+res.account_no+"','"+data_collect+"')\"></a></tr>");
				}
				
				if(data_collect == "false") {
					$("#ledger_list > tbody").append("<tr class = 'x' onmouseover = 'clickSearch();'><td>"+res.name+"</td><td>"+res.date_released+"</td><td><div align = 'right'>"+amount+"</div></td><td>"+res.terms+"</td><td><div align = 'right'>"+interest+"</div></td><td><div align = 'right'>"+balance+"</div></td><td align = 'center'><a href='#' class='view' title='VIEW link' onclick=\"view_ledger("+res.id+",'"+res.account_no+"','"+data_collect+"')\"></a></td><td align = 'center'><a href = '#' class = 'delete' title = 'DELETE' onclick='delete_data("+res.id+")'></td></tr>");
				}
				counter++;
			});
			if (counter <= 0){
				$("#ledger_list > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
			}
			jpages();
		});
	}
	
	function view_ledger(id,acct,collect){
		window.location = "viewLedger.php?menu=customers&ledger_id="+id+"&account_no="+acct+"&collection="+collect;
	}

	function closeIframe(action,id) {
		if (action=="add") {
			jAlert('Data was successfully Saved!','Alert Dialog');
		}
		else {
			
		}
		$("#new_items").dialog('close');
		loadData("id","DESC");
	}
	
	function delete_data(id) {
			
		jConfirm('Do you really want to DELETE this LEDGER?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "functions.php",
					data:{"request":"ajax","action":"deleteLedger","id":id},
					success: function(reply){
						console.log(reply);
							if(reply == 'deleted'){
								jAlert('Loan Deleted','Alert Dialog');
								window.reload();
							}else{
								jAlert('Error','Alert Dialog');
								event.preventDefault();
							}
						
					}
				});
			}
		});
		
	}
	
	function clickSearch() {
	
		$("#txtsearch").blur();
	
	}

	</script>
	
</body>
</html>