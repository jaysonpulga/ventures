<?php
session_start();

if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION["username"];
$branch_name = $_SESSION["branch_name"];
$branch_id = $_SESSION['branch_id'];
?>
<!DOCTYPE HTML>
<html lang="en">
<title>Information</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
<body>
<input type="hidden" id="branch_id" value="<?php echo $_SESSION['branch_id']; ?>" >
<input type="hidden" id="branch_name" value="<?php echo $_SESSION['branch_name']; ?>" >
<input type="hidden" id="branch_code" value="<?php echo $_SESSION['branch_code']; ?>" >
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<table width="950px">
						<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2 style="margin-top:10px;">CUSTOMER INFORMATION</h2>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
								<form name="search" action="" method="POST">
								<select id = 'category' name='category'>
									<option value = "branch_id">Branch</option>
									<option value = "customer_province_id">Province</option>
									<option value = "last_name">Last Name</option>
								</select>
								<input type="search" name="txtsearch" id="txtsearch" placeholder="Search">
								<input type="button" value="ADD NEW" id = "btnadd" onclick = "add_item();">
								</form>
							</td>
						</tr>
					</table>
				</div>
			
								
				<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:950px" cellspacing="0">
				
					<table id="customer_list" border=1 align = "center">

						<thead align="center">
						<tr>
							<th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'a.last_name')">CUSTOMER NAME</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'c.branch_name')">BRANCH</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'b.province_name')">ADDRESS</a></th><th>CONTACT #</th><th colspan = "2">ACTION</th>
						</tr>
						</thead>
						
						<tbody id="customer_data"></tbody>
						
					</table>
					
					<div id="pagination"> 
						<div class="holder" style = "margin-top:30px;"></div>
						<i>Pages</i>
					</div>
					
					<div id="add_items" style="display:none;">
						<iframe id="item_dialog" width="900" height="380" style="border:none"></iframe>
					</div>
			
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	
	function jpages(){
		$("div.holder").jPages({
		  containerID : "customer_data",
		  previous : "←",
		  next : "→",
		  perPage : 15,
		  delay :10,
		  startPage    : 1,
		  startRange   : 1,
		  midRange     : 5,
		  endRange     : 1
		});
	}
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
				
	var sortType = "ASC";
	
	function filter_list(index,cVar){
		sort = cVar;
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadData(sort,sortType);
	}
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="customers#"){
			menu="customers";
		}
		else{
			menu = getUrlVars()["menu"];	
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -100px 5px no-repeat",
		"padding":"30px 20px 0px 20px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadData("a.id","DESC");
		
	});
	
	
	var branch_id = $("#branch_id").val();
	  var branch_name = $("#branch_name").val();
	  var branch_code = $("#branch_code").val();
	
	function loadData(sort,sortType){
		$("#customer_list > tbody").empty();
		
		var url="functions.php?request=ajax&action=viewCustomerData&sort="+sort+"&sortType="+sortType+"&branch_id="+branch_id;
		var counter=0;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				$("#customer_list > tbody").append("<tr class = 'x'><td>"+res.last_name+", "+res.first_name+" "+res.middle_name+"</td><td>"+res.branch_name+"</td><td>"+res.province_name+"</td><td>"+res.telephone_no+"</td><td><a href='#' class='edit' title='EDIT link' onclick=\"edit_customer("+res.id+",'"+res.last_name+"','"+res["first_name"]+"','"+res.middle_name+"')\"></a></td><td><a href='#' class='delete' title='DELETE link' onclick=delete_customer("+res.id+")></a></td></tr>");
				counter++;	
			});
			if (counter <= 0){
				$("#customer_list > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
			}
			jpages();
		});
	}

	function add_item(){
	
		$("#add_items").attr('title', "New Customer");
		$("#item_dialog").attr('src', "newCustomer.php");
		$("#add_items").dialog({
			width: 905,
			height: 430,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src', "about:blank");
				window.location.reload();
			},
		});
		return false;
	}

	function edit_customer(id,last,first,middle){

		$("#add_items").attr('title', "Edit Information");
		$("#item_dialog").attr('src', "editCustomer.php?customer_id="+id+"&last="+last+"&first="+first+"&middle="+middle);
		$("#add_items").dialog({
			width: 905,
			height: 430,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src', "about:blank");
				window.location="information.php?menu=customers";
			},
		});
		return false;
	}

	function delete_customer(id){

		jConfirm('Do you really want to DELETE this CUSTOMER INFO?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "functions.php",
					data:{"request":"ajax","action":"delete_customer","id":id},
					success: function(reply){
						console.log(reply);
							if(reply == 'deleted'){
								jAlert('Customer Deleted','Alert Dialog');
								window.location="information.php?menu=customers";
								loadData();
							}else{
								jAlert('Error','Alert Dialog');
								event.preventDefault();
							}
						
						}
				});
			}
		});

	}

	function closeIframe(action,id) {
		if (action=="add") {
			jAlert('Data was successfully Saved!');
		}
		
		else if (action=="edit") {
			jAlert('Data was successfully Updated!');
			window.location="information.php?menu=customers";
		}
		else {
			
		}
		$("#add_items").dialog('close');
		loadData();
	}
	
	function clickSearch() {
	
		$("#txtsearch").blur();
	
	}
	
	$("#txtsearch").blur(function(){
		$(this).val("");
	});

	$("#txtsearch").bind('keyup change',function(){
		var url ="functions.php?request=ajax&action=searchCustomer&inputsearch="+$(this).val()+"&category="+$('#category').val()+"&branch_id="+branch_id;
		var counter=0;
			if($(this).val().trim() != ""){
		
				$("#customer_list > tbody").empty();
		
				$.getJSON(url,function(data){
					$.each(data.members, function(i,res){
						$("#customer_list > tbody").append("<tr class = 'x' onmouseover = 'clickSearch();'><td>"+res.last_name+", "+res.first_name+" "+res.middle_name+"</td><td>"+res.branch_name+"</td><td>"+res.province_name+"</td><td>"+res.telephone_no+"</td><td><a href='#' class='edit' title='EDIT link' onclick=\"edit_customer("+res.id+",'"+res.last_name+"','"+res["first_name"]+"','"+res.middle_name+"')\"></a></td><td><a href='#' class='delete' title='DELETE link' onclick=delete_customer("+res.id+")></a></td></tr>");
						counter++;	
					});
					if (counter <= 0){
						$("#customer_list > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
					}
					jpages();
				});
			}
			else{
				$("#customer_list > tbody").empty();
				loadData("a.id","DESC");
			}
	});
	
	</script>
	
</body>
</html>