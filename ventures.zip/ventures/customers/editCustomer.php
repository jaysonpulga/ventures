<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px; margin-left:15px;" >
				<div>
					<span>
						<label><h3>CUSTOMER NAME</h3></label>
					</span>
				</div>
				<div>
					<span>
						<input type="text" id = "txtlast" placeholder="Last Name" style="text-align:center">
						<input type="text" id = "txtfirst" placeholder="First Name" style="text-align:center">
						<input type="text" id = "txtmiddle" placeholder="Middle Name" style="text-align:center">
					</span>
				</div>
				<div>
					<span>
						<label>Birthday:</label>
						<input type="date" id = "txtbirth">
						<label>Telephone No.:</label>
						<input type="text" id = "txttel" onkeyup="javascript:this.value = this.value.replace(/[^0-9,-]/, '')">
						<label>Cellphone No.:</label>
						<input type="text" id = "txtcell" onkeyup="javascript:this.value = this.value.replace(/[^0-9,-]/, '')">
					</span>
				</div>
				<div>
					<span>
						<label>Branch:</label>
						<select id = "txtbranch">
							<option value = "">-- SELECT --</option>
						</select>
						<input type = "hidden" id = "customerid" value = "<?php echo $_REQUEST["customer_id"]; ?>">
						<input type = "hidden" id = "last" value = "<?php echo $_REQUEST["last"]; ?>">
						<input type = "hidden" id = "first" value = "<?php echo $_REQUEST["first"]; ?>">
						<input type = "hidden" id = "middle" value = "<?php echo $_REQUEST["middle"]; ?>">
					</span>
				</div>
				<div>
					<span>
						<label><h3>CUSTOMER ADDRESS</h3></label>
					</span>
				</div>
				<div>
					<span>
						<label>Region</label>
						<label style="margin-left:125px">Province</label>
						<label style="margin-left:102px">City/Town</label>
						<label style="margin-left:97px">Subd/Brgy</label>
						<label style="margin-left:107px">Street/Num</label>
					</span>
				</div>
				<div>
					<span>
						<select id = "txtcusregion" name='brand'>
						<option value="">-- SELECT --</option>
						</select>
						<select id = "txtcusprovince" name='brand'>
						<option value="">-- SELECT --</option>
						</select>
						<select id = "txtcuscity" name='brand'>
						<option value="">-- SELECT --</option>
						</select>
						<input type="text" id = "txtcussubd">
						<input type="text" id = "txtcusstreet">
					</span>
				</div>
				<div>
					<span>
						<label><h3>SHIPPING ADDRESS</h3></label>
					</span>
				</div>
				<div>
					<span>
						<label>Region</label>
						<label style="margin-left:125px">Province</label>
						<label style="margin-left:102px">City/Town</label>
						<label style="margin-left:97px">Subd/Brgy</label>
						<label style="margin-left:107px">Street/Num</label>
					</span>
				</div>
				<div>
					<span>
						<select id = "txtshipregion" name='brand'>
						<option value="">-- SELECT --</option>
						</select>
						<select id = "txtshipprovince" name='brand'>
						<option value="">-- SELECT --</option>
						</select>
						<select id = "txtshipcity" name='brand'>
						<option value="">-- SELECT --</option>
						</select>
						<input type="text" id = "txtshipsubd">
						<input type="text" id = "txtshipstreet">
					</span>
				</div>
				<div align="center" style="margin-top:15px">
					<span>
					<input type="button" value="SAVE" onclick = "Update();">
					<input type="button" value="CANCEL"  onclick = "window.parent.closeIframe('cancel');">
					</span>
				</div>
			</div>
		<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="customers#"){
			menu="customers";
		}
		else{
			menu = getUrlVars()["menu"];	
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadBranch();
		loadRegion();
		loadRegion2();
		loadCustomerBody();
		loadShippingBody();
		
		$('#txtcusprovince').prop('disabled', true);
		$('#txtcuscity').prop('disabled', true);
		$('#txtcusprovince').prop('disabled', true);		
		$('#txtshipprovince').prop('disabled', true);
		
		$('#txtcuscity')
		.prop('disabled', true)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$('#txtshipcity')
		.prop('disabled', true)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
	});
	
	function loadCustomerBody() {
		var cid=$("#customerid").val();
		var url="functions.php?request=ajax&action=viewCustomerUpdate&customer_id="+cid;
		var cus_region;
		var cus_province;
		var cus_city;
		var branch;
	
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
			
				$('#customerid').val(res.id);
				$('#txtlast').val(res.last_name);
				$('#txtfirst').val(res.first_name);
				$('#txtmiddle').val(res.middle_name);
				$('#txtbirth').val(res.birthday);
				$('#txttel').val(res.telephone_no);
				$('#txtcell').val(res.cellphone_no);
				branch=res.branch_id;
				$('#txtbranch option[value="'+branch+'"]').attr('selected', 'selected');
				cus_region=res.customer_region_id;
				$('#txtcusregion option[value="'+cus_region+'"]').attr('selected', 'selected');
				cus_province=res.customer_province_id;
				$('#txtcusprovince option[value="'+cus_province+'"]').attr('selected', 'selected');
				cus_city=res.customer_city_town_id;
				$('#txtcuscity option[value="'+cus_city+'"]').attr('selected', 'selected');
				$('#txtcussubd').val(res.customer_subd_brgy);
				$('#txtcusstreet').val(res.customer_street_num);
				
			});
			
			$( "#txtcusregion" ).change(function() {
				if($(this).val() == "") {
					$('#txtcusprovince')
					.prop('disabled', true)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
					
					$('#txtcuscity')
					.prop('disabled', true)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
				}
				
				else {
					
					$('#txtcusprovince')
					.prop('disabled', false)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
					
					$('#txtcuscity')
					.prop('disabled', true)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
					
				}
				
				var region_id=$("#txtcusregion :selected").val();
				var region_name=$("#txtcusregion :selected").text();
				
				loadProvince(region_id,"");
			});
			
			$( "#txtcusprovince" ).change(function() {
				if($(this).val() == "") {
					$('#txtcuscity')
					.prop('disabled', true)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
				}
				else {
				
					$('#txtcuscity')
					.prop('disabled', false)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
					
				}
				
				var province_id=$("#txtcusprovince :selected").val();
				var province_name=$("#txtcusprovince :selected").text();
				
				loadCity(province_id,"");
			});
			
			$( "#txtcuscity" ).change(function() {
				cus_city_id=$("#txtcuscity :selected").val();
				cus_city_name=$("#txtcuscity :selected").text();
				
				var city=$('#txtcuscity').val();
				
				if(!city == "") {
					$('#txtsame').prop('disabled', false);
				}else {
					$('#txtsame').prop('disabled', true);
				}
				
			});	
			loadProvince(cus_region,cus_province);
			loadCity(cus_province,cus_city);
		});
		
	}

	function loadShippingBody() {
		var cid=$("#customerid").val();
		var url="functions.php?request=ajax&action=viewShippingUpdate&customer_id="+cid;
		var ship_region;
		var ship_province;
		var ship_city;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
			
				ship_region=res.shipping_region_id;
				$('#txtshipregion option[value="'+ship_region+'"]').attr('selected', 'selected');
				ship_province=res.shipping_province_id;
				$('#txtshipprovince option[value="'+ship_province+'"]').attr('selected', 'selected');
				ship_city=res.shipping_city_town_id;
				$('#txtshipcity option[value="'+ship_city+'"]').attr('selected', 'selected');
				$('#txtshipsubd').val(res.shipping_subd_brgy);
				$('#txtshipstreet').val(res.shipping_street_num);
				
			});
			
			$( "#txtshipregion" ).change(function() {
				if($(this).val() == "") {
					$('#txtshipprovince')
					.prop('disabled', true)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
					
					$('#txtshipcity')
					.prop('disabled', true)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
				}
				else {
					$('#txtshipprovince')
					.prop('disabled', false)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
					
					$('#txtshipcity')
					.prop('disabled', true)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
					
			}
				
				var region_id=$("#txtshipregion :selected").val();
				var region_name=$("#txtshipregion :selected").text();
				
				loadProvince2(region_id,"");
			});
			
			$( "#txtshipprovince" ).change(function() {
				if($(this).val() == "") {
					$('#txtshipcity')
					.prop('disabled', true)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
				}
				else {
					$('#txtshipcity')
					.prop('disabled', false)
					.empty()
					.append('<option value="">-- SELECT --</option>')
					.find('option:first')
					.attr("selected","selected")
					;
				}
				
				var province_id=$("#txtshipprovince :selected").val();
				var province_name=$("#txtshipprovince :selected").text();
				
				loadCity2(province_id,"");
			});
			
			loadProvince2(ship_region,ship_province);
			loadCity2(ship_province,ship_city);
		});
			
	}

	function loadBranch() {
		var url="functions.php?request=ajax&action=loadCustomerBranch";
		var branch_id;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
					$("#txtbranch").append("<option value="+ res.id+">" + res.branch_name + "</option>");
					branch_id=res.id;
			});
			
		});

	}

	function loadRegion(){

		var url="functions.php?request=ajax&action=loadCustomerRegion";
		var region;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
					$("#txtcusregion").append("<option value="+ res.id+">" + res.region_name + "</option>");
					region=res.id;
					
			});
			
		});
	}

	function loadProvince(region_id,province_id) {
		
		var url="functions.php?request=ajax&action=loadCustomerProvince&region_id="+region_id;
		var province;
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				province=res.id;
				$("#txtcusprovince").append("<option value="+ province+">" + res.province_name + "</option>");
				
			});
			
			$('#txtcusprovince option[value="'+province_id+'"]').attr('selected', 'selected');
			
		});

	}

	function loadCity(province_id,city_id) {
		
		var url="functions.php?request=ajax&action=loadCustomerCity&province_id="+province_id;
		var city;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				city=res.id;
				$("#txtcuscity").append("<option value="+ city +">" + res.city_name + "</option>");
			});
			$('#txtcuscity option[value="'+city_id+'"]').attr('selected', 'selected');

		});

	}

	function loadRegion2(){

		var url="functions.php?request=ajax&action=loadCustomerRegion";
		var region;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
					$("#txtshipregion").append("<option value="+ res.id+">" + res.region_name + "</option>");
					region=res.id;
			});
			
		});
	}

	function loadProvince2(region_id,province_id) {
		
		var url="functions.php?request=ajax&action=loadCustomerProvince&region_id="+region_id;
		var province;
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				province=res.id;
				$("#txtshipprovince").append("<option value="+ province+">" + res.province_name + "</option>");
				
			});
			
			$('#txtshipprovince option[value="'+province_id+'"]').attr('selected', 'selected');
			
		});

	}

	function loadCity2(province_id,city_id) {
		
		var url="functions.php?request=ajax&action=loadCustomerCity&province_id="+province_id;
		var city;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				city=res.id;
				$("#txtshipcity").append("<option value="+ city +">" + res.city_name + "</option>");
			});
			$('#txtshipcity option[value="'+city_id+'"]').attr('selected', 'selected');

		});

	}

	function Update(){
		
		var customer_id=$("#customerid").val(); 
		var last=$("#last").val();
		var first=$("#first").val();
		var middle=$("#middle").val();
		var last_name=$("#txtlast").val();
		var first_name=$("#txtfirst").val();
		var middle_name=$("#txtmiddle").val();
		var birthday=$("#txtbirth").val();
		var tel = /[^0-9,-]/
		var telno=$("#txttel").val();
		var tellno=tel.test(telno);
		var cel = /[^0-9,-]/
		var celno=$("#txtcell").val();
		var cellno=cel.test(celno);
		var branch_id=$("#txtbranch").val();
		var cus_region_id=$("#txtcusregion").val();
		var cus_province_id=$("#txtcusprovince").val();
		var cus_city_id=$("#txtcuscity").val();
		var cus_subd=$("#txtcussubd").val();
		var cus_street=$("#txtcusstreet").val();
		var ship_region_id=$("#txtshipregion").val();
		var ship_province_id=$("#txtshipprovince").val();
		var ship_city_id=$("#txtshipcity").val();
		var ship_subd=$("#txtshipsubd").val();
		var ship_street=$("#txtshipstreet").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(last_name == ""){
			errormsg+="- Input Last Name.\n";
		}
		if(first_name == ""){
			errormsg+="- Input First Name.\n";
		}
		if(middle_name == ""){
			errormsg+="- Input Middle Name.\n";
		}
		if(birthday == ""){
			errormsg+="- Input Birthday.\n";
		}
		if(tellno == true) {
			errormsg+="- Input the Correct Telephone Format.\n";
		}
		if(cellno == true) {
			errormsg+="- Input the Correct Cellphone Format.\n";
		}
		if(branch_id == ""){
			errormsg+="- Input Branch.\n";
		}
		if(cus_region_id == ""){
			errormsg+="- Input Customer Address Region.\n";
		}
		if(cus_province_id == ""){
			errormsg+="- Input Customer Address Province.\n";
		}
		if(cus_city_id == ""){
			errormsg+="- Input Customer Address City/Town.\n";
		}
		if(ship_region_id == ""){
			errormsg+="- Input Shipping Address Region.\n";
		}
		if(ship_province_id == ""){
			errormsg+="- Input Shipping Address Province.\n";
		}
		if(ship_city_id == ""){
			errormsg+="- Input Shipping Address City/Town.\n";
		}
		
		if(errormsg.length==emsg){
			
			jConfirm('Do you really want to UPDATE this SUPPLIER?','Confirmation Dialog',function(e){
				if(e){
					
					if((last == last_name) && (first == first_name) && (middle == middle_name)) {
					
						$.ajax({
							url: "functions.php",
							data:{"request":"ajax","action":"updateCustomerData1","customer_id":customer_id,"last_name":last_name,"first_name":first_name,"middle_name":middle_name,"birthday":birthday,"telno":telno,"cellno":celno,"branch_id":branch_id,"cus_region_id":cus_region_id,"cus_province_id":cus_province_id,"cus_city_id":cus_city_id,"cus_subd":cus_subd,"cus_street":cus_street,"ship_region_id":ship_region_id,"ship_province_id":ship_province_id,"ship_city_id":ship_city_id,"ship_subd":ship_subd,"ship_street":ship_street},
							success: function(reply){
								console.log(reply);
									if(reply == 'updated'){
										window.parent.closeIframe('edit',customer_id);
									}
									else{
										jAlert('Error', 'Alert Dialog');
										event.preventDefault();
									}
							}
						});
					}
					
					else {
						$.ajax({
							url: "functions.php",
							data:{"request":"ajax","action":"updateCustomerData2","customer_id":customer_id,"last_name":last_name,"first_name":first_name,"middle_name":middle_name,"birthday":birthday,"telno":telno,"cellno":celno,"branch_id":branch_id,"cus_region_id":cus_region_id,"cus_province_id":cus_province_id,"cus_city_id":cus_city_id,"cus_subd":cus_subd,"cus_street":cus_street,"ship_region_id":ship_region_id,"ship_province_id":ship_province_id,"ship_city_id":ship_city_id,"ship_subd":ship_subd,"ship_street":ship_street},
							success: function(reply){
								console.log(reply);
									if(reply == 'updated'){
										window.parent.closeIframe('edit',customer_id);
									}
									else if(reply == 'exists'){
										jAlert('Name Already Exists!', 'Alert Dialog');
									}
									else{
										jAlert('Error', 'Alert Dialog');
										event.preventDefault();
									}
							}
						});
					}
					
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
	}
	</script>
	
</body>
</html>