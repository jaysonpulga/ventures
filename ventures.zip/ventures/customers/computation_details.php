<html>
<title>LEDGER COMPUTATION REPORT</title>
<script src="../js/jquery-1.8.3.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.js"></script>
<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="../js/jquery.alerts.js" type="text/javascript"></script>
<script type="text/javascript" src=""></script>
<script src="../js/FormatNumberBy3.js" type="text/javascript"></script>
</html>

<style>
body{
	font-family:Calibri,Helvetica,"sans-serif";
	font-size:14px;	
}
.x:nth-child(even) td{
	background:lightgray;
}
.y:nth-child(odd) td{
	background:lightgray;
	font-weight:bold;
	text-align:center;
}
</style>

<body>
	<div id="wrapper" style="width:100%">
			<div id="main" align="center" style="width:100%">
				<div id="options-top" align="center" style="width:100%;">
					<h2 style="margin-top:10px;">VENTURE MOTORCYCLE SALES CORPORATION</h2>
					<h3 style="margin-top:-15px;">CENTRAL OFFICE</h3>
					<div style="margin-bottom:10px;border:1px solid #777;width:1200px" ></div>
					<div>
						<table width="700px" id="top">
							<tr>
								<td>ACCOUNT NO.: </td><td><?php echo $_REQUEST['account_no']; ?></td>
								<td width="200px">AMOUNT OF LOAN: </td><td ><?php echo $_REQUEST['amount_loan']; ?></td>
							</tr>
							<tr>
								<td>NAME: </td><td><?php echo $_REQUEST['name']; ?></td>
								<td>INTEREST RATE: </td><td><?php echo $_REQUEST['interest_rate']; ?></td>
							</tr>
							<tr>
								<td>DATE RELEASED: </td><td><?php echo $_REQUEST['date']; ?></td>
								<td>TERMS: </td><td><?php echo $_REQUEST['terms']; ?></td>
							</tr>
							<tr>
								<td>1ST INSTALLMENT DUE: </td><td><?php echo $_REQUEST['due']; ?></td>
							</tr>
						</table>
					</div>
					<div style = "margin-top:50px;">
						<table width="700px" id="table">
							<tbody id="table">
							</tbody>
						</table>
					</div>
				</div>
				
			</div>
	</div>
	<script src='../js/dropdowntabs.js'></script>	
	<script>
	var amount = getUrlVars()["amount_loan"];
	var interest= getUrlVars()["interest_rate"];
	var terms = getUrlVars()["terms"];
	var id = getUrlVars()["loan_id"];
	var avail = getUrlVars()["availment"];
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -175px 5px no-repeat",
		"padding":"30px 31px 0px 31px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadBody();
		
	});

	
	
	function loadBody() {
		
		$("#table > tbody").empty();
		
		var interest_income = interest*amount;
		var installment_amount = parseFloat(Math.round(((parseFloat(interest_income)+parseFloat(amount))/terms)*100)/100).toFixed(0);
		
		$("#table > tbody")
		.append("<tr style='font-size:14px; text-align:right; width:150px;'><td><b>INTEREST INCOME</b></td><td align='left'> = INTEREST RATE(<b>"+interest+"</b>) * LOAN AMOUNT(<b>"+amount+"</b>)</td></tr>")
		.append("<tr style='font-size:14px; text-align:right; width:150px;'><td></td><td align='left'> = <b>"+interest_income+"</b></td></tr>")
		.append("<tr style='font-size:14px; text-align:right; width:150px;'><td><b>INSTALLMENT AMOUNT</b></td><td align='left'> = (INTEREST INCOME(<b>"+interest_income+"</b>) + LOAN AMOUNT(<b>"+amount+"</b>)) / TERMS (<b>"+terms+"</b>)</td></tr>")
		.append("<tr style='font-size:14px; text-align:right; width:150px;'><td></td><td align='left'> = <b>"+parseFloat(Math.round((installment_amount)*100)/100).toFixed(2)+"</b></td></tr>")
		.append("<tr style='font-size:14px; text-align:right; width:150px;'><td><b>FINANCE CHARGES :</b></td></tr>")
		;
		
		var url = "functions.php?request=ajax&action=loadComputeLedger&loan_id="+id+"&terms="+terms+"&availment="+avail+"&amount="+amount;
		
		$.getJSON(url,function(data){
			var counter=0;
			$.each(data.members, function(i,res){
			
				var loan_proceed = parseFloat(Math.round((amount-parseFloat(res.total))*100)/100).toFixed(2);
			
				$("#table > tbody")
					.append("<tr style='font-size:14px; text-align:right; width:150px;'><td>  </td><td align='left'>MORTGAGE FEE <b>("+res.mortgage_fee+"</b>)</td></tr>")
					.append("<tr style='font-size:14px; text-align:right; width:150px;'><td>+ </td><td align='left'>INSURANCE FEE <b>("+res.insurance_fee+"</b>)</td></tr>")
					.append("<tr style='font-size:14px; text-align:right; width:150px;'><td>+ </td><td align='left'>NOTARIAL FEE <b>("+res.notarial_fee+"</b>)</td></tr>")
					.append("<tr style='font-size:14px; text-align:right; width:150px;'><td>+ </td><td align='left'>FILING FEE <b>("+res.filing+"</b>)</td></tr>")
					.append("<tr style='font-size:14px; text-align:right; width:150px;'><td>+ </td><td align='left'>DOC STAMP <b>("+res.doc_stamp+"</b>)</td></tr>")
					.append("<tr style='font-size:14px; text-align:right; width:150px;'><td>+ </td><td align='left'>INSPECTION FEE <b>("+res.inspection_fee+"</b>)</td></tr>")
					.append("<tr style='font-size:14px; text-align:right; width:150px;'><td>+ </td><td align='left'>OTHERS <b>("+res.others+"</b>)</td></tr>")
					.append("<tr style='font-size:14px; text-align:right; width:150px;'><td>= </td><td align='left'>TOTAL FINANCE CHARGES: <b>("+res.total+"</b>)</td></tr>")
					
					.append("<tr style='font-size:14px; text-align:right; width:150px;'><td><b>LOAN PROCEED</b></td><td align='left'> = LOAN AMOUNT(<b>"+amount+"</b>) - FINANCE CHARGES(<b>"+res.total+"</b>)</td></tr>")
					.append("<tr style='font-size:14px; text-align:right; width:150px;'><td></td><td align='left'> = <b>"+loan_proceed+"</b></td></tr>")
					;
				
				counter++;
			});
			if (counter <= 0){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '11' align = 'center'> No Payment History! </th></tr>");
			}
			
		});
		
		
	}
	
	</script>
</body>
</html>