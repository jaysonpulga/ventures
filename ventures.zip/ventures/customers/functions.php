<?php
	session_start();
	include('../database.php');
	$db = new Database();  
	$db->connect();
	
	$action = $_REQUEST["action"];
	
	if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){
		
		switch($action){
		//Customer's Information
			case 'viewCustomerData';
				
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$branch_id=$_REQUEST["branch_id"];
				
				if($branch_id != 1){
					$where = "a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.branch_id=c.id";
				}else{
					$where = "a.customer_province_id=b.id AND a.branch_id=c.id";
				}
	
					$rows ='a.*, b.province_name as province_name, c.branch_name as branch_name';
					$order="$sort $sortType";
					$db->select('tbl_customer a, tbl_province b, tbl_branch c',$rows,$where,$order);
					$res = $db->getResult();
					
					print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'loadCustomerBranch';
			
				$rows="id,branch_name";
				$db->select('tbl_branch',$rows);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'loadCustomerRegion';
			
				$rows="id,region_name";
				$db->select('tbl_region',$rows);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'loadCustomerProvince';
				
				$region_id=$_REQUEST["region_id"];
				$where='region_id='.$region_id;
				$rows="*";
				$order = "province_name ASC";
				$db->select('tbl_province',$rows,$where,$order);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'loadCustomerCity';
				
				$province_id=$_REQUEST["province_id"];
				$where='province_id='.$province_id;
				$rows="*";
				$order = "city_name ASC";
				$db->select('tbl_city',$rows,$where,$order);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'searchCustomer';
				
				$search=trim($_REQUEST['inputsearch']);
				$category=$_REQUEST['category'];
				$branch_id=$_REQUEST['branch_id'];
				
				if($category=="branch_id"){
				
							if($branch_id != 1){
								$where = "a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.branch_id=c.id AND c.branch_name LIKE '%".$search."%'";
							}else{
								$where = "a.customer_province_id=b.id AND a.branch_id=c.id AND c.branch_name LIKE '%".$search."%'";
							}
					
								$rows ='a.*, b.province_name as province_name, c.branch_name as branch_name';
								$db->select('tbl_customer a, tbl_province b, tbl_branch c',$rows,$where); 
				}
				else if($category=="customer_province_id"){
				
							if($branch_id != 1){
								$where = "a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.branch_id=c.id AND b.province_name LIKE '%".$search."%'";
							}else{
								$where = "a.customer_province_id=b.id AND a.branch_id=c.id AND b.province_name LIKE '%".$search."%'";
							}
							
								$rows ='a.*, b.province_name as province_name, c.branch_name as branch_name';
								$db->select('tbl_customer a, tbl_province b, tbl_branch c',$rows,$where); 
				}
				else{		
							if($branch_id != 1){
								$where = "a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.branch_id=c.id AND a.$category LIKE '%".$search."%'";
							}else{
								$where = "a.customer_province_id=b.id AND a.branch_id=c.id AND a.$category LIKE '%".$search."%'";
							}
						
				
								$rows = "a.*,b.province_name as province_name, c.branch_name as branch_name";		
								$db->select('tbl_customer a, tbl_province b, tbl_branch c', $rows, $where);
				}
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			break;
			
			case 'saveCustomerData';
			
				$last_name=$_REQUEST["last_name"];
				$first_name=$_REQUEST["first_name"];
				$middle_name=$_REQUEST["middle_name"];
				$birthday=$_REQUEST["birthday"];
				$telno=$_REQUEST["telno"];
				$cellno=$_REQUEST["cellno"];
				$branch_id=$_REQUEST["branch_id"];
				$cus_region_id=$_REQUEST["cus_region_id"];
				$cus_province_id=$_REQUEST["cus_province_id"];
				$cus_city_id=$_REQUEST["cus_city_id"];
				$cus_subd_brgy=$_REQUEST["cus_subd"];
				$cus_street_num=$_REQUEST["cus_street"];
				$ship_region_id=$_REQUEST["ship_region_id"];
				$ship_province_id=$_REQUEST["ship_province_id"];
				$ship_city_id=$_REQUEST["ship_city_id"];
				$ship_subd_brgy=$_REQUEST["ship_subd"];
				$ship_street_num=$_REQUEST["ship_street"];
				
				$rows1 = "*";
				$where1 = "last_name='$last_name' AND first_name='$first_name' AND middle_name='$middle_name' AND birthday='$birthday' AND branch_id='$branch_id'";
				
				$db->select("tbl_customer", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
				
					$rows ='last_name,first_name,middle_name,birthday,telephone_no,cellphone_no,branch_id,customer_region_id,customer_province_id,customer_city_town_id,customer_subd_brgy,customer_street_num,shipping_region_id,shipping_province_id,shipping_city_town_id,shipping_subd_brgy,shipping_street_num';
					$values = array($last_name,$first_name,$middle_name,$birthday,$telno,$cellno,$branch_id,$cus_region_id,$cus_province_id,$cus_city_id,$cus_subd_brgy,$cus_street_num,$ship_region_id,$ship_province_id,$ship_city_id,$ship_subd_brgy,$ship_street_num);
					
					$db->insert('tbl_customer',$values,$rows);
					
					echo "saved";
					
				}
				
			break;
			
			case 'viewCustomerUpdate';
				$customer_id = $_REQUEST['customer_id'];
				
				$where="a.id='$customer_id' AND b.id=a.customer_region_id AND c.id=a.customer_province_id AND d.id=a.customer_city_town_id AND a.branch_id=e.id";
				$rows ='a.*,b.region_name as r_name,c.province_name as province_name, d.city_name as city_name, e.branch_name as branch_name';
				
				$db->select('tbl_customer a,tbl_region b,tbl_province c, tbl_city d, tbl_branch e',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			
			break;
			
			case 'viewShippingUpdate';
				$customer_id = $_REQUEST['customer_id'];
				
				$where="a.id='$customer_id' AND b.id=a.shipping_region_id AND c.id=a.shipping_province_id AND d.id=a.shipping_city_town_id";
				$rows ='a.*,b.region_name as region_name,c.province_name as province_name, d.city_name as city_name';
				
				$db->select('tbl_customer a,tbl_region b,tbl_province c, tbl_city d',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			
			break;
			
			case 'delete_customer';
			
				$id=$_REQUEST["id"];
				$db->delete("tbl_customer","id='$id'");  
				
				print "deleted";
			
			break;
			
			case 'updateCustomerData1';
				
				$cid=$_REQUEST["customer_id"];
				$last_name=$_REQUEST["last_name"];
				$first_name=$_REQUEST["first_name"];
				$middle_name=$_REQUEST["middle_name"];
				$birthday=$_REQUEST["birthday"];
				$telno=$_REQUEST["telno"];
				$cellno=$_REQUEST["cellno"];
				$branch_id=$_REQUEST["branch_id"];
				$cus_region_id=$_REQUEST["cus_region_id"];
				$cus_province_id=$_REQUEST["cus_province_id"];
				$cus_city_id=$_REQUEST["cus_city_id"];
				$cus_subd_brgy=$_REQUEST["cus_subd"];
				$cus_street_num=$_REQUEST["cus_street"];
				$ship_region_id=$_REQUEST["ship_region_id"];
				$ship_province_id=$_REQUEST["ship_province_id"];
				$ship_city_id=$_REQUEST["ship_city_id"];
				$ship_subd_brgy=$_REQUEST["ship_subd"];
				$ship_street_num=$_REQUEST["ship_street"];
				
				$where='id='.$cid;
	
				$rows = array('last_name' => $last_name , 'first_name' => $first_name , 'middle_name' => $middle_name , 'birthday' => $birthday , 'telephone_no' => $telno, 'cellphone_no' => $cellno, 'branch_id' => $branch_id, 'customer_region_id' => $cus_region_id , 'customer_province_id' => $cus_province_id , 'customer_city_town_id' => $cus_city_id , 'customer_subd_brgy' => $cus_subd_brgy , 'customer_street_num' => $cus_street_num , 'shipping_region_id' => $ship_region_id , 'shipping_province_id' => $ship_province_id , 'shipping_city_town_id' => $ship_city_id , 'shipping_subd_brgy' => $ship_subd_brgy , 'shipping_street_num' => $ship_street_num);
				$db->update('tbl_customer',$rows, $where);
				
				echo "updated";
			break;
			
			case 'updateCustomerData2';
				
				$cid=$_REQUEST["customer_id"];
				$last_name=$_REQUEST["last_name"];
				$first_name=$_REQUEST["first_name"];
				$middle_name=$_REQUEST["middle_name"];
				$birthday=$_REQUEST["birthday"];
				$telno=$_REQUEST["telno"];
				$cellno=$_REQUEST["cellno"];
				$branch_id=$_REQUEST["branch_id"];
				$cus_region_id=$_REQUEST["cus_region_id"];
				$cus_province_id=$_REQUEST["cus_province_id"];
				$cus_city_id=$_REQUEST["cus_city_id"];
				$cus_subd_brgy=$_REQUEST["cus_subd"];
				$cus_street_num=$_REQUEST["cus_street"];
				$ship_region_id=$_REQUEST["ship_region_id"];
				$ship_province_id=$_REQUEST["ship_province_id"];
				$ship_city_id=$_REQUEST["ship_city_id"];
				$ship_subd_brgy=$_REQUEST["ship_subd"];
				$ship_street_num=$_REQUEST["ship_street"];
				
				$rows1 = "*";
				$where1 = "last_name='$last_name' AND first_name='$first_name' AND middle_name='$middle_name'";
				
				$db->select("tbl_customer", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
					$where='id='.$cid;
		
					$rows = array('last_name' => $last_name , 'first_name' => $first_name , 'middle_name' => $middle_name , 'birthday' => $birthday , 'telephone_no' => $telno, 'cellphone_no' => $cellno, 'branch_id' => $branch_id, 'customer_region_id' => $cus_region_id , 'customer_province_id' => $cus_province_id , 'customer_city_town_id' => $cus_city_id , 'customer_subd_brgy' => $cus_subd_brgy , 'customer_street_num' => $cus_street_num , 'shipping_region_id' => $ship_region_id , 'shipping_province_id' => $ship_province_id , 'shipping_city_town_id' => $ship_city_id , 'shipping_subd_brgy' => $ship_subd_brgy , 'shipping_street_num' => $ship_street_num);
					$db->update('tbl_customer',$rows, $where);
					
					echo "updated";
				}
			break;
			
			//Ledger
			
			case "viewLedgerData";
			
				$ledger = array();
				$new_array = array();
			
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$branch_id=$_REQUEST["branch_id"];
				$loan_type=$_REQUEST["loan_type"];
				
				$search=trim($_REQUEST['inputsearch']);
				$category1=$_REQUEST['category'];
				
				if($category1 == "name") {
					$category = "CONCAT(b.last_name,', ',b.first_name,' ',b.middle_name)";
				}
				else {
					$category = $category1;
				}
				if($branch_id != 1){
					$where1 = "b.branch_id = '$branch_id' AND a.customer_name=b.id AND a.loan_type_id='$loan_type' AND a.branch_id=c.id AND $category LIKE '%".$search."%'";
				}else{
					$where1 = "a.customer_name=b.id AND a.loan_type_id='$loan_type' AND a.branch_id=c.id AND $category LIKE '%".$search."%'";
				}
				
				$rows1 = "a.id,CONCAT(b.last_name,', ',b.first_name,' ',b.middle_name) as name,a.account_no,a.date_released,a.amount_loan,a.interest_income,a.terms,(a.installment_amount*a.terms) as total_loan";
				

				$db->select("tbl_ledger a,tbl_customer b,tbl_branch c",$rows1,$where1);
				
				$res = $db->getResult();
				
				
				foreach($res as $data) {
					$account_no = $data["account_no"];
					$customer_id = $data["customer_name"];
					$total_loan = $data["total_loan"];
					
					$rows = "SUM(dues) as total_paid";
					$where= "account_no='$account_no'";
					$db->selectSingle("collection_loan",$rows,$where);
					$total_paid = $db->getSingleResult();
					
					if(count($total_paid) > 0) {
						$data_collect = "true";
					}
					else {
						$data_collect = "false";
					}
					
					$balance=$total_loan-$total_paid;
					$i=0;
					
					if($balance > 0) {
						$new_array[$i]=array(
							'id'=> $data["id"],
							'account_no'=> $account_no,
							'name'=> $data["name"],
							'date_released'=> $data["date_released"],
							'amount_loan'=> $data["amount_loan"],
							'terms'=> $data["terms"],
							'interest_income'=> $data["interest_income"],
							'balance'=> $balance,
							'data_collect'=> $data_collect
						);
					}
					
					else {
						$new_array[$i]=array(
							'id'=> $data["id"],
							'account_no'=> $account_no,
							'name'=> $data["name"],
							'date_released'=> $data["date_released"],
							'amount_loan'=> $data["amount_loan"],
							'terms'=> $data["terms"],
							'interest_income'=> $data["interest_income"],
							'balance'=> '0',
							'data_collect'=> $data_collect
						);
					}
					
					array_push($ledger,$new_array[$i]);
					$i++;
					
				}
				if(count($ledger) > 0) {
					$sortArray = array();
					
					foreach($ledger as $total){
						foreach($total as $key=>$value){
							if(!isset($sortArray[$key])){
								$sortArray[$key] = array(); 
							}
							$sortArray[$key][] = $value;
						}
					}
					
					$orderby = $sort;
					if($sortType=="ASC"){
						array_multisort($sortArray[$orderby],SORT_ASC,$ledger);
					}
					else{
						array_multisort($sortArray[$orderby],SORT_DESC,$ledger);
					}
				}
				
				print '{"members":'.json_encode($ledger).'}';
			
			break;
			
			case 'loadLoanType';
				$rows = "*";
				$where = "";
				$db->select('tbl_loan',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			break;
			
			case "viewLoanType";
				$id = $_REQUEST["id"];
				
				$rows = "*";
				$where = "id=".$id;
				$db->select('tbl_loan',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			break;
			
			case 'saveLedgerData';
			
				$principal_amt_1=$_REQUEST['principal_amt_1'];
				$account_no=$_REQUEST['account_no'];
				$customer_name=$_REQUEST['customer_name'];
				$branch_id=$_REQUEST['branch_id'];
				$amount_loan=$_REQUEST['amount_loan'];
				$loan_type=$_REQUEST['loan_type'];
				$interest_rate=$_REQUEST['interest_rate'];
				$date_released=$_REQUEST['date_released'];
				$installment_due=$_REQUEST['installment_due'];
				$terms=$_REQUEST['terms'];
				$rebate=$_REQUEST['rebate'];
				$avail=$_REQUEST['availment'];
				$installment_amount=$_REQUEST['installment_amount'];
				$interest_income=$_REQUEST['interest_income'];
				$finance=$_REQUEST['finance_charges'];
				$mortgage=$_REQUEST['mortgage'];
				$co_name=$_REQUEST['co_name'];
				$address=$_REQUEST['address'];
				$contact_no=$_REQUEST['contact_no'];
				$monthly=$_REQUEST['monthly_rebate'];
				$first_int_income=$_REQUEST['f_int_income'];
				
				$rows1 = "*";
				$where1 = "account_no='$account_no'";
				
				$db->select("tbl_ledger", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
				
					$rows ='account_no,customer_name,branch_id,amount_loan,loan_type_id,interest_rate,date_released,installment_due,terms,rebate,availment,installment_amount,interest_income,finance_charges,mortgage_details,co_name,address,contact_no,monthly_rebate,int_income_1,principal_amt_1';
					$values = array($account_no,$customer_name,$branch_id,$amount_loan,$loan_type,$interest_rate,$date_released,$installment_due,$terms,$rebate,$avail,$installment_amount,$interest_income,$finance,$mortgage,$co_name,$address,$contact_no,$monthly,$first_int_income,$principal_amt_1);
					
					$db->insert('tbl_ledger',$values,$rows);
					
					echo "saved";
					
				}
			
			break;
			
			case 'viewLedgerUpdate';
			
				$ledger_id = $_REQUEST['ledger_id'];
				
				$where="a.id = '$ledger_id' AND a.customer_name=c.id AND b.id=a.loan_type_id";
				$rows ="a.*, b.loan_type as loan_type, CONCAT(c.last_name,', ',c.first_name,' ',c.middle_name) as name,c.id as cid";
				
				$db->select('tbl_ledger a,tbl_loan b, tbl_customer c',$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'updateLedgerData1';
				
				$ledger_id=$_REQUEST["ledger_id"];
				$account_no=$_REQUEST["account_no"];
				$customer_name=$_REQUEST["customer_name"];
				$branch_id=$_REQUEST['branch_id'];
				$amount_loan=$_REQUEST["amount_loan"];
				$loan_type=$_REQUEST["loan_type"];
				$rebate=$_REQUEST["rebate"];
				$interest_rate=$_REQUEST["interest_rate"];
				$date_released=$_REQUEST["date_released"];
				$installment_due=$_REQUEST["installment_due"];
				$terms=$_REQUEST["terms"];
				$avail=$_REQUEST["availment"];
				$installment_amount=$_REQUEST["installment_amount"];
				$interest_income=$_REQUEST["interest_income"];
				$finance_charges=$_REQUEST["finance_charges"];
				$mortgage=$_REQUEST["mortgage"];
				$co_name=$_REQUEST["co_name"];
				$address=$_REQUEST["address"];
				$contact_no=$_REQUEST["contact_no"];
				$monthly=$_REQUEST["monthly_rebate"];
				
				$where='id='.$ledger_id;
	
				$rows = array('account_no' => $account_no , 'customer_name' => $customer_name , 'branch_id' => $branch_id,'amount_loan' => $amount_loan , 'loan_type_id' => $loan_type , 'interest_rate' => $interest_rate, 'date_released' => $date_released, 'installment_due' => $installment_due, 'terms' => $terms , 'rebate' => $rebate , 'availment' => $avail , 'installment_amount' => $installment_amount , 'interest_income' => $interest_income , 'finance_charges' => $finance_charges , 'mortgage_details' => $mortgage , 'co_name' => $co_name , 'address' => $address , 'contact_no' => $contact_no , 'monthly_rebate' => $monthly);
				$db->update('tbl_ledger',$rows, $where);
				
				echo "updated";
				
			break;
			
			case 'updateLedgerData2';
				
				$ledger_id=$_REQUEST["ledger_id"];
				$account_no=$_REQUEST["account_no"];
				$customer_name=$_REQUEST["customer_name"];
				$branch_id=$_REQUEST['branch_id'];
				$amount_loan=$_REQUEST["amount_loan"];
				$loan_type=$_REQUEST["loan_type"];
				$interest_rate=$_REQUEST["interest_rate"];
				$rebate=$_REQUEST["rebate"];
				$date_released=$_REQUEST["date_released"];
				$installment_due=$_REQUEST["installment_due"];
				$terms=$_REQUEST["terms"];
				$avail=$_REQUEST["availment"];
				$installment_amount=$_REQUEST["installment_amount"];
				$interest_income=$_REQUEST["interest_income"];
				$finance_charges=$_REQUEST["finance_charges"];
				$mortgage=$_REQUEST["mortgage"];
				$co_name=$_REQUEST["co_name"];
				$address=$_REQUEST["address"];
				$contact_no=$_REQUEST["contact_no"];
				$monthly=$_REQUEST["monthly_rebate"];
				
				$rows1 = "*";
				$where1 = "account_no='$account_no'";
				
				$db->select("tbl_ledger", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
					$where='id='.$ledger_id;
		
					$rows = array('account_no' => $account_no , 'customer_name' => $customer_name , 'branch_id' => $branch_id,'amount_loan' => $amount_loan , 'loan_type_id' => $loan_type , 'interest_rate' => $interest_rate, 'date_released' => $date_released, 'installment_due' => $installment_due, 'terms' => $terms , 'rebate' => $rebate , 'availment' => $avail , 'installment_amount' => $installment_amount , 'interest_income' => $interest_income , 'finance_charges' => $finance_charges , 'mortgage_details' => $mortgage , 'co_name' => $co_name , 'address' => $address , 'contact_no' => $contact_no , 'monthly_rebate' => $monthly);
					$db->update('tbl_ledger',$rows, $where);
					
					echo "updated";
				}
				
			break;
			
			case 'deleteLedger';
			
				$id=$_REQUEST["id"];
				$db->delete("tbl_ledger","id='$id'");  
				
				print "deleted";
			
			break;
			
			case 'viewCustomerLists';
			
				$customer = array();
			
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$category=$_REQUEST['category'];
				$branch_id=$_REQUEST['branch_id'];
				$trimmed=trim($_REQUEST['inputsearch']);
				
				if($sort == "customer_name") {
					$sort1 = "CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name)";
				}
				else {
					$sort1 = $sort;
				}
				
				$rows ="a.id,CONCAT(a.last_name,', ',a.first_name,' ',a.middle_name) as name,a.customer_subd_brgy as brgy,a.customer_street_num as street,b.province_name as province, c.city_name as city, d.branch_name as branch_name, d.id as branch_id, d.branch_code";
				if($branch_id != 1){
					$where = "a.branch_id = '$branch_id' AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%'";
					
				}else{
					$where = "a.customer_province_id=b.id AND a.customer_city_town_id=c.id AND a.branch_id=d.id AND CONCAT(a.last_name,',',a.first_name,' ',a.middle_name) LIKE '%".$trimmed."%'";
					
				}
				$order = "$sort1 $sortType";
				$db->select("tbl_customer a, tbl_province b, tbl_city c, tbl_branch d",$rows,$where,$order);
				
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}'; 
			
			break;
			
			case "loadCustomerId";
			
				$last_name = $_REQUEST["last_name"];
				$first_name = $_REQUEST["first_name"];
				$middle_name = $_REQUEST["middle_name"];
				
				$where = "a.last_name='$last_name' AND a.first_name='$first_name' AND a.middle_name='$middle_name' AND a.customer_province_id=b.id AND a.customer_city_town_id=c.id";
				$rows = "a.id, a.last_name, a.first_name, a.middle_name, b.province_name, c.city_name, a.customer_subd_brgy as brgy, a.customer_street_num as street,a.branch_id";
				$db->select("tbl_customer a, tbl_province b, tbl_city c, tbl_branch d",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadLoanInterest";
			
				$id = $_REQUEST["id"];
				$terms = $_REQUEST["terms"];
				
				$rows = "id,interest_rate_$terms as interest_rate";
				$where = "id=".$id;
				$db->select("tbl_loan",$rows,$where);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case "loadLoan";
				
				$loans = array();
				
				$loan_id = $_REQUEST['loan_id'];
				$terms = $_REQUEST['terms'];
				$avail = $_REQUEST['availment'];
				$amount = $_REQUEST['amount'];
				
				$rows = "id,(filing_fee_percent*$amount) as filing_fee,filing_amount";
				$where = "id=".$loan_id;
				$db->select("tbl_loan",$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $data) {
					
					$id = $data['id'];
					$percent = $data['filing_fee'];
					$amount = $data['filing_amount'];
					$filing=0;
					
					if($percent <= $amount) {
						$filing = $amount;
					}
					if($percent >= $amount) {
						$filing = $percent;
					}
					
					if($avail == "new") {
						$rows1 = "id,loan_type,interest_rate_$terms as interest_rate,penalty_interest,(mortgage_fee+insurance_fee+notarial_fee_new+$filing+doc_stamp+inspection_fee_new+others) as total";
					}
					if($avail == "old") {
						$rows1 = "id,loan_type,interest_rate_$terms as interest_rate,penalty_interest,(mortgage_fee+insurance_fee+notarial_fee_old+$filing+doc_stamp+inspection_fee_old+others) as total";
					}
					
					$where1 = "id=".$id;
					$db->select("tbl_loan",$rows1,$where1);
					$result = $db->getResult();
					
					for($j=0;$j<count($result);$j++){
						array_push($loans,$result[$j]);
					}
					
				}
				
				print '{"members":'.json_encode($loans).'}';
			
			break;
			
			case "loadComputeLedger";
			
				$loans = array();
				
				$loan_id = $_REQUEST['loan_id'];
				$terms = $_REQUEST['terms'];
				$avail = $_REQUEST['availment'];
				$amount = $_REQUEST['amount'];
				
				$rows = "id,(filing_fee_percent*$amount) as filing_fee,filing_amount";
				$where = "id=".$loan_id;
				$db->select("tbl_loan",$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $data) {
					
					$id = $data['id'];
					$percent = $data['filing_fee'];
					$amount = $data['filing_amount'];
					$filing=0;
					
					if($percent <= $amount) {
						$filing = $amount;
					}
					if($percent >= $amount) {
						$filing = $percent;
					}
					
					if($avail == "new") {
						$rows1 = "id,mortgage_fee,insurance_fee,notarial_fee_new as notarial_fee,$filing as filing,doc_stamp,inspection_fee_new as inspection_fee,others,(mortgage_fee+insurance_fee+notarial_fee_new+$filing+doc_stamp+inspection_fee_new+others) as total";
					}
					if($avail == "old") {
						$rows1 = "id,mortgage_fee,insurance_fee,notarial_fee_old as notarial_fee,$filing as filing,doc_stamp,inspection_fee_old as inspection_fee,others,(mortgage_fee+insurance_fee+notarial_fee_old+$filing+doc_stamp+inspection_fee_old+others) as total";
					}
					
					$where1 = "id=".$id;
					$db->select("tbl_loan",$rows1,$where1);
					$result = $db->getResult();
					
					for($j=0;$j<count($result);$j++){
						array_push($loans,$result[$j]);
					}
					
				}
				
				print '{"members":'.json_encode($loans).'}';
			
			break;
			
		}
		
	}

?>