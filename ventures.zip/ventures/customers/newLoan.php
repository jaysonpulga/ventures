<!DOCTYPE HTML>
<html lang="en">
<title>Ledger</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	<script src="../js/FormatNUmberBy3.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" style="margin:0px auto" align="center">
					<div id="sample" style="text-align:left;padding:10px; width:800px; margin-left:15px;" >
						<div>
							<span>
								<label><h2>NEW LOAN</h2><hr></label>
							</span>
						</div>
						<div>
							<span>
								<input type = "hidden" id = "txtid">
								<label>Account No:</label>
								<input type="text" id = "txtaccount" style="margin-left:37px;" maxlength = "9">
							</span>
							<span>
								<label style="margin-left:196px">Date Release:</label>
								<input type="date" id = "txtreleased" value="<?php echo date('Y-m-d'); ?>" style="margin-left:49px; text-align:center">
							</span>
						</div>
						<div>
							<span>
								<label>Customer Name:</label>
								<input type="text" id = "txtcusname" style = "margin-left:8px;">
								<input type = "hidden" id = "txtcusid">
								<input type = "hidden" id = "txtbranch">
								<a href="#"  style="width:30px;" onclick="customer();"><img src="" id="search" valign="bottom"></a>
								<a href="#"  style="width:30px;" onclick="newCustomer();"><img src="" id="new" valign="bottom"></a>
								
							</span>
							<span>
								<label style="margin-left:130px">1st Installment Due:</label>
								<input type="date" id = "txtdue" value="<?php echo date('Y-m-d'); ?>" style="text-align:center;">
							</span>
						</div>
						<div>
							<span>
								<label>Amount of Loan:</label>
								<input type="text" style="margin-left:10px; text-align:right;" id = "txtamount" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')" onchange = "compute();">
							</span>
							<span>
								<label style="margin-left:197px;">Terms(In Months):</label>
								<!--
								<input type="text" style="margin-left:19px; text-align:right;" id = "txtterms" onkeyup="javascript:this.value = this.value.replace(/[^0-9]/, '')" onchange = "compute();">
								-->
								<select id = "txtterms" name = "brand" style="margin-left:19px;" onchange = "compute();">
									<option value = "">-- SELECT --</option>
									<option value = "3">3</option>
									<option value = "6">6</option>
									<option value = "9">9</option>
									<option value = "12">12</option>
									<option value = "15">15</option>
									<option value = "18">18</option>
									<option value = "21">21</option>
									<option value = "24">24</option>
								</select>
							</span>
						</div>
						<div>
							<span>
								<label>Type of Loan:</label>
								<select id = "txttype" name='brand' style="margin-left:30px" onchange = "compute();">
									<option value = "">-- SELECT --</option>
								</select>
								<input type="button" id = "btndetails" value="DETAILS">
							</span>
							<span style = "margin-left:104px;">
								<label>Rebate:</label>
								<input type = "text" id = "txtrebate" style = "margin-left:85px; text-align:right;" onchange = "compute();">
							</span>
						</div>
						<div>
							<span>
								<label>Interest Rate %:</label>
								<input type="text" style="margin-left:14px; text-align:right;" id = "txtrate" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')" onchange = "compute();">
								<input type="hidden" style="margin-left:14px; text-align:right;" id = "txtint_income">
							</span>
						</div>
						<div>
							<span>
								<label>Availment:</label>
								<select id = "txtavailment" name='brand' style="margin-left:44px">
									<option value = "">-- SELECT --</option>
									<option value = "new">New</option>
									<option value = "old">Re-availment</option>
								</select>
								<input type="button" id = "btncompute" value="COMPUTE" onclick = "finalcompute();">
								<input type = "hidden" id = "txttotal">
							</span>
						</div>
						<div  class="contents" style="border:0px solid #000; width:800px" cellspacing="0">	
							<table id="loan_list" border=1 align = "center">

								<thead align="center">
								<tr>
									<th>INSTALLMENT AMOUNT</th><th>INTEREST INCOME</th><th>FINANCE CHARGES</th><th>LOAN PROCEED</th><th>ACTION</th>
								</tr>
								</thead>
								
								<tbody id="loan_data"></tbody>
								
							</table>
						</div>
						<div style="margin-top:10px">
							<span>
								<input type = "hidden" id = "txtinterest">
								<input type = "hidden" id = "txtmonthly">
								<label>Mortgage Details:</label><br>
								<textarea id = "txtdetails" rows="4" style="margin-left:115px; margin-top:-17px"></textarea>
							</span>
						</div>
						<div>
							<span>
								<label><h3>CO-MAKER DETAILS<h3><hr style="margin-top:-15px"></label>
							</span>
						</div>
						<div>
							<span>
								<label>Name:</label>
								<input type="text" id = "txtname" style="margin-left:70px;">
							</span>
							<span>
								<label style="margin-left:195px;">Contact No.:</label>
								<input type="text" id = "txtcontact" onkeyup="javascript:this.value = this.value.replace(/[^0-9,-]/, '')" style="margin-left:48px;">
							</span>
						</div>
						<div>
							<span>
								<label>Address:</label>
								<input type="text" id = "txtaddress" style="margin-left:58px; width:350px">
							</span>
						</div>
						<div align="center" style="margin-top:10px">
							<span>
								<input type="button" id = "btnadd"  value="ADD" onclick = "Add();">
								<input type="button" id = "btncancel" value="CANCEL">
							</span>
						</div>
						<div id="customer_items" style="display:none;">
							<iframe id="item_dialog" width="900" height="452" style="border:none"></iframe>
						</div>
						<div id="loan_items" style="display:none;">
							<iframe id="loan_dialog" width="400" height="450" style="border:none"></iframe>
						</div>
						
					</div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	var first_int_income=0;
	var first_principal=0;
	var first_principal_amt=0;
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="customers#"){
			menu="customers";
		}
		else{
			menu = getUrlVars()["menu"];	
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -100px 5px no-repeat",
		"padding":"30px 20px 0px 20px",
		"border-bottom":"4px solid #c95447"
		});
		
		compute();
		loan();
		
		//$("#txtreleased").val(new Date().toDateInputValue());
		
		$('#txttype')
		.prop('disabled', true)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected");
		
		$("#txtterms").change(function() {
			if($(this).val() == "") {
				$('#txttype').prop('disabled', true);
			}
			else {
				$('#txttype').prop('disabled', false);
			}
			
			var loan_id = $("#txttype :selected").val();
			var terms=$("#txtterms").val();
			loadInterest(loan_id,terms);
			
		});
		
		$('#btndetails').prop('disabled', true);
		
		$( "#txttype" ).change(function() {
			$('#btndetails').prop('disabled', false);
			var loan_id = $("#txttype :selected").val();
			var terms=$("#txtterms").val();
			loadInterest(loan_id,terms);
		});
		
		$("#txtavailment").change(function() {
			
			var amount=$("#txtamount").val();
			var loan_id=$("#txttype :selected").val();
			var terms=$("#txtterms").val();
			var avail=$("#txtavailment :selected").val();
			
			loadLoan(loan_id,terms,avail,amount);
			
		});
		
		$("#txtrate").change(function() {
			compute();
		});
		
		$("#btndetails").click(function() {
			
			var loan_id=$("#txttype :selected").val();
			
			detail(loan_id);
			
		});
		
		$("#btncancel").click(function() {
			
			window.location = "ledger.php?menu=customers";
			
		});

		
	});
	
	function loadInterest(id,terms) {
		
		var url="functions.php?request=ajax&action=loadLoanInterest&id="+id+"&terms="+terms;
			
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtrate").val(res.interest_rate);
				
			});
		});
		
	}
	
	function customer() {

		$("#customer_items").attr("title","Customer Listing");
		$("#item_dialog").attr("src","customer_name.php");
		$("#customer_items").dialog({
			width: 901,
			height: 500,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr("src","about:blank");
			}
		});
		return false;

	}

	function newCustomer() {

		$("#customer_items").attr("title","New Customer");
		$("#item_dialog").attr('src','newCustomerLoan.php');
		$("#customer_items").dialog({
			width: 901,
			height: 500,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src',"about:blank");
			}
		});
		return false;

	}

	function detail(id) {

		$("#loan_items").attr("title","Loan Details");
		$("#loan_dialog").attr('src','viewLoan.php?loan_id='+id);
		$("#loan_items").dialog({
			width: 402,
			height: 498,
			modal: true,
			resizable:false,
			close: function () {
				$("#loan_dialog").attr('src',"about:blank");
			}
		});
		return false;

	}

	function loan() {
		var url="functions.php?request=ajax&action=loadLoanType";
			
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){

				$("#txttype").append("<option value="+ res.id+">" + res.loan_type + "</option>");

			});
		});
	}

	function loadLoan(id,terms,avail,amount) {
		
		var url="functions.php?request=ajax&action=loadLoan&loan_id="+id+"&terms="+terms+"&availment="+avail+"&amount="+amount;
		var interest;
			
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txttotal").val(res.total);
				compute();
				
			});
		});
		
	}
	
	function finalcompute() {
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if($("#txtamount").val() == ""){
			errormsg+="- Input Amount.\n";
		}
		if($("#txtterms").val() == ""){
			errormsg+="- Input Terms.\n";
		}
		if($("#txtrate").val() == ""){
			errormsg+="- Input Interest Rate %.\n";
		}
		
		if(errormsg.length==emsg){
			compute();
		}
		
		else {
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
	}

	function compute() {
	
		var acct = $("#txtaccount").val();
		var name = $("#txtcusname").val();
		var date = $("#txtreleased").val();
		var due = $("#txtdue").val();
		
		
		
		
		
		var type = $("#txttype option:selected").text();
		var interest = parseFloat($("#txtrate").val());
		var terms = parseInt($("#txtterms").val());
		var avail = $("#txtavailment").val();
		var vals = $("#txtamount").val();
		var loan = parseFloat(vals.replace(/,/g, ''));
		var charges = parseFloat($("#txttotal").val());
		//var interest = rate/100;
		var rebate = parseFloat($("#txtrebate").val());
		var loan_id = $("#txttype option:selected").val();
		
		//INTEREST
		var income = interest*loan;
			
		var int_income = parseFloat(Math.round((income/terms)*100)/100).toFixed(2);
		
		var whole = Math.floor(int_income);
		
		var interest_decimal=int_income.substr(-2,2);
		
		var excess=(interest_decimal/100)*terms;
		
		var first_int=parseFloat(Math.round((excess)*100)/100).toFixed(2);
		
		first_int=parseFloat(first_int)+parseFloat(whole);
		
		first_int_income=parseFloat(Math.round((first_int)*100)/100).toFixed(0);
		
		$("#txtint_income").val(first_int_income);
		
		$("#txtinterest").val(income);
		
		//Principal Monthly Computation
		var principal_amt=parseInt(vals)/parseInt(terms);
		
		var principal_amount=parseFloat(Math.round((principal_amt)*100)/100).toFixed(2);
		
		var whole_principal = Math.floor(principal_amount);
		
		var principal_decimal=principal_amount.substr(-2,2);

		var excess_principal=(principal_decimal/100)*terms;
		
		var first_principal=parseFloat(Math.round((excess_principal)*100)/100).toFixed(2);
		
		first_principal=parseFloat(first_principal)+parseFloat(whole_principal);
		
		first_principal_amt=parseFloat(Math.round((first_principal)*100)/100).toFixed(0);
		
		
		
		var installment = parseFloat(Math.round(((loan+income+rebate)/terms)*100)/100).toFixed(0);
		
		
		$("#txtinstall").val(installment);
		var loan_proceed = parseFloat(Math.round((loan-charges)*100)/100).toFixed(2);
		$("#txtmonthly").val(parseFloat(Math.round((rebate/terms)*100)/100).toFixed(2));
		
		$("#loan_list > tbody").empty();
		
		if(charges == "" || vals == "" || avail == "" || terms == "" || type == "") {
			$("#loan_list > tbody").append("<tr id = 'noItems'><th colspan = '5' align = 'center'> No Items on record! </th></tr>");
		}
		else {
			if(type == "Motorcycle Loan") {
				$("#loan_list > tbody").append("<tr><td><input type = 'text' id = 'txtinstall' value = '"+FormatNumberBy3(parseFloat(Math.round((installment)*100)/100).toFixed(2))+"' style = 'text-align:right;'></td><td><div align = 'right'>"+FormatNumberBy3(parseFloat(Math.round((income)*100)/100).toFixed(2))+"</div></td><td><div align = 'right'>"+FormatNumberBy3(parseFloat(Math.round((charges)*100)/100).toFixed(2))+"</div></td><td style='text-align:right;'>"+FormatNumberBy3(parseFloat(Math.round((loan_proceed)*100)/100).toFixed(2))+"</td><td><input type='button' id='computedetails' value='DETAILS' onclick = \"compute_details('"+acct+"','"+name+"','"+date+"','"+due+"',"+loan+","+interest+","+terms+","+loan_id+",'"+avail+"');\"></td></tr>");
			}
			else {
				$("#loan_list > tbody").append("<tr><td><div align = 'right'><input type = 'hidden' id = 'txtinstall' value = '"+installment+"'>"+FormatNumberBy3(parseFloat(Math.round((installment)*100)/100).toFixed(2))+"</div></td><td><div align = 'right'>"+FormatNumberBy3(parseFloat(Math.round((income)*100)/100).toFixed(2))+"</div></td><td><div align = 'right'>"+FormatNumberBy3(parseFloat(Math.round((charges)*100)/100).toFixed(2))+"</div></td><td style = 'text-align:right;'>"+FormatNumberBy3(parseFloat(Math.round((loan_proceed)*100)/100).toFixed(2))+"</td><td><input type='button' id='computedetails' value='DETAILS' onclick = \"compute_details('"+acct+"','"+name+"','"+date+"','"+due+"',"+loan+","+interest+","+terms+","+loan_id+",'"+avail+"');\"></td></tr>");
			}
		}
	}
	
	function compute_details(acct,name,date,due,amount,interest,terms,id,avail) {
		
		var url = "computation_details.php?account_no="+acct+"&name="+name+"&date="+date+"&due="+due+"&amount_loan="+amount+"&interest_rate="+interest+"&terms="+terms+"&loan_id="+id+"&availment="+avail;
		window.open(url,'_blank');
		
	}

	function Add(){

		var account_no=$("#txtaccount").val();	
		var customer_name=$("#txtcusid").val();
		var branch=$("#txtbranch").val();
		var value=$("#txtamount").val();
		var amount_loan = parseInt(value.replace(/,/g, ''));
		var loan_type=$("#txttype").val();
		var interest_rate=$("#txtrate").val();
		var date_released=$("#txtreleased").val();
		var installment_due=$("#txtdue").val();
		var terms=$("#txtterms").val();
		var rebate=$("#txtrebate").val();
		var avail=$("#txtavailment").val();
		var install=$("#txtinstall").val();
		var installment_amount = parseInt(install.replace(/,/g, ''));
		var interest_income=$("#txtinterest").val();
		var finance=$("#txttotal").val();
		var mortgage=$("#txtdetails").val();
		var co_name=$("#txtname").val();
		var contact_no=$("#txtcontact").val();
		var address=$("#txtaddress").val();
		var monthly=$("#txtmonthly").val();
		var f_int_income=$("#txtint_income").val();
		//var interest_rate = parseFloat(rate/100);
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(account_no == ""){
			errormsg+="- Input Account No.\n";
		}
		if(date_released == ""){
			errormsg+="- Input Date Released.\n";
		}
		if(customer_name == ""){
			errormsg+="- Input Customer Name.\n";
		}
		if(installment_due == ""){
			errormsg+="- Input 1st Installment Due.\n";
		}
		if(value == ""){
			errormsg+="- Input Amount Loan.\n";
		}
		if(terms == ""){
			errormsg+="- Input Terms.\n";
		}
		if(loan_type == "") {
			errormsg+="- Input Type of Loan.\n";
		}
		if(interest_rate == "") {
			errormsg+="- Input Interest Rate.\n";
		}
		if(rebate == ""){
			errormsg+="- Input Rebate.\n";
		}
		if(mortgage == "") {
			errormsg+="- Input Mortgage Details.\n";
		}
		if(date_released > installment_due) {
			errormsg+="- INSTALLMENT DUE. You must enter date not earlier in DATE RELEASED.\n";
		}

		if(errormsg.length==emsg){
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"saveLedgerData","account_no":account_no,"date_released":date_released,"customer_name":customer_name,"branch_id":branch,"installment_due":installment_due,"amount_loan":amount_loan,"terms":terms,"loan_type":loan_type,"rebate":rebate,"availment":avail,"interest_rate":interest_rate,"installment_amount":installment_amount,"interest_income":interest_income,"finance_charges":finance,"mortgage":mortgage,"co_name":co_name,"contact_no":contact_no,"address":address,"monthly_rebate":monthly,"f_int_income":f_int_income,"principal_amt_1":first_principal_amt},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							jAlert("Data was Successfully Saved!", "Alert Dialog");
							window.location = "ledger.php?menu=customers";
							
						}else if(reply == 'exists'){
							jAlert('Account No. Already Exists!', 'Alert Dialog');
						}
						else{
							alert('Error');
							event.preventDefault();
						}
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		
	}
	
	function closeIframe(id,name,branch) {
		var customer = name;
		$("#customer_items").dialog('close');
		$("#txtcusname").val(customer);
		$("#txtcusid").val(id);
		$("#txtbranch").val(branch);
	}
	
	function closeIframe2() {
		$("#loan_items").dialog('close');
	}

	</script>
	
</body>
</html>