<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
<form  name="frm"  method="POST">
<input type="hidden" id="promo_id" value="<?php echo $_REQUEST['promo_id']; ?>" name="promo_id" >
<input type="hidden" id="id_p"  name="id_p" >
<input type="hidden" id="item_code_a"  name="item_code_a" >
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px;">
				<div style="margin-top:10px;">
				
				
					<span>
						<label>Manufacturer:</label>
						<input type="text"id="manufacturer" name="manufacturer"  >
					</span>
				</div>
				<div>
					<span>
						<label>Item Code:</label>
						<input type="text" id="item_code" name="item_code" style="margin-left:20px">
					</span>
				</div>
				<div>
					<span>
						<label>Unit Cost:</label>
						<input type="text" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')" id="unit_cost" name="unit_cost" style="margin-left:26px">
					</span>
				</div>
				<div>
					<span>
						<label>Description:</label><br>
						<textarea rows="4" id="description" name="description" style="margin-left:89px; margin-top:-17px"></textarea>
					</span>
				</div>
			
				<div align="center">
					<span><br>
					
					<?php
						if($_REQUEST['status'] =="update"){
					     echo '<input type="button" value="UPDATE" onClick="update_promo(this)" >';
						
						}else{
							echo '<input type="button" value="ADD" onClick="save_promo(this)" >';
						}
						?>
					<input type="button" value="CANCEL" onClick="Cancel();">
					
					</span>
				</div>
			</div>
		</div>
	</div>

	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		 loadData();
	});	
	
	var promo_id = $('#promo_id').val();


function loadData(){
			
			var url="function_items.php?request=ajax&action=load_update&tablename=tbl_promo&pro=promo_id&id="+promo_id;
			var counter=1;
		
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){
					$('#id_p').val(res.promo_id);
					$('#manufacturer').val(res.brand);
					$('#item_code').val(res.item_code);
					$('#item_code_a').val(res.item_code);
					$('#unit_cost').val(res.unit_cost);
					$('#description').val(res.description);
					
	
				});	
			});
			
		}



function save_promo(obj){
	event.preventDefault();
	
	var manufacturer = $('#manufacturer').val();
	var item_code = $('#item_code').val();
	var unit_cost = $('#unit_cost').val();
	var description = $('#description').val();
	var errormsg="Please complete the following fields: \n";
	var emsg= errormsg.length;

		if(manufacturer == ""){
			errormsg+="-Manufacturer\n";
			
		}
		if(item_code == ""){
			errormsg+="-Item Code \n";
			
		}
		if(description == ""){
			errormsg+="-Description";
			
		}
		if(errormsg.length== emsg){
		
		
	$.ajax({
		
		       url: "function_items.php",
				data:{"request":"ajax","action":"add_promo","manufacturer":manufacturer,"item_code":item_code,"description":description,"unit_cost":unit_cost},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){	
							var actions="add";
							window.parent.closeIframe(actions);
						}else if(reply == 'no record'){
						 jAlert("The Manufacturer: "+manufacturer+ " did not exist in database!");
						
						}else if(reply == 'duplicate'){
						 jAlert("The Item code: PI-"+item_code+ " is already exist in database!");
						
						}else{
							jAlert("cannot add information");
						}
					
					}
		
		
		
		});
		
		}else{
			jAlert(errormsg);
			event.preventDefault();
		}
		
	}
	
		
	function update_promo(obj){
	event.preventDefault();
		
	var id_p = $('#id_p').val();
	var item_code_a = $('#item_code_a').val();	
	var manufacturer = $('#manufacturer').val();
	var item_code = $('#item_code').val();
	var unit_cost = $('#unit_cost').val();
	var description = $('#description').val();
	var errormsg="Please complete the following fields: \n";
	var emsg= errormsg.length;

		if(manufacturer == ""){
			errormsg+="-Manufacturer\n";
			
		}
		if(item_code == ""){
			errormsg+="-Item Code \n";
			
		}
		if(description == ""){
			errormsg+="-Description";
			
		}
		if(errormsg.length== emsg){
		
		$.ajax({
			url: "function_items.php",
			data:{"request":"ajax","action":"updatePromo","id_p":id_p,"manufacturer":manufacturer,"item_code":item_code,"description":description,"item_code_a":item_code_a,"unit_cost":unit_cost},
				success: function(reply){
					console.log(reply);
						if(reply == 'updated'){
						    	
							var actions="edit";
							window.parent.closeIframe(actions);
							
						}else if(reply == 'no record'){
						 jAlert("The Manufacturer: "+manufacturer+ " did not exist in database!");
						
						}else if(reply == 'duplicate'){
						 jAlert("The Item code: "+item_code+ " is already exist in database!");
						
						}else{
							jAlert("cannot update information");
					
					}
				}
			
			   });
				
		}
		
		else{
			jAlert(errormsg);
			event.preventDefault();
		}
				
}
	
	function Cancel(){
		var action = "cancel";
	window.parent.closeIframe(action);
	}
	</script>
	
</body>
</html>