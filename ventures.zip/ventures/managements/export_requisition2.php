<?php
include('../database.php');
$db = new Database();
$db->connect();


//if this parameter is included ($w=1), file returned will be in word format ('.doc')
//if parameter is not included, file returned will be in excel format ('.xls')
if (isset($w) && ($w==1))
{
	$file_type = "msword";
	$file_ending = "doc";
}else {
	$file_type = "vnd.ms-excel";
	$file_ending = "xls";
}
$date = date('Y-m-d');
//header info for browser: determines file type ('.doc' or '.xls')
@header("Content-Type: application/$file_type");
@header("Content-Disposition: attachment; filename=(Requisition_report)$date.$file_ending");
@header("Pragma: no-cache");
@header("Expires: 0");

?>

<?php 
	
	$sr_no=$_REQUEST["sr_no"];


	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();

	
	$where = "sr_no='$sr_no'";
	$db->select("tbl_stock_requisition","*",$where);
	$result = $db->getResult();
	
	foreach($result as $key){
		 $category=$key["category"];
		 $sr_no=$key["sr_no"];
		 
		if($category == '1'){
		 
			
			$row = "a.sr_no,a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.model";
			$table = "tbl_stock_requisition a,tbl_manufacturer b, tbl_motorcycle c ";
			
			$where = "a.brand = b.id and a.item = c.motor_id and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray=$result;
			
			
		 }else if($category == '2'){

			$row = "a.sr_no,a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.item_code";
			$table = "tbl_stock_requisition a,tbl_manufacturer b, tbl_parts c ";
			
			$where = "a.brand = b.id and a.item = c.parts_id and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray2=$result;
		   
		 
		 }
		 else if($category == '3'){
			
			
			$row = "a.sr_no,a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.item_code";
			$table = "tbl_stock_requisition a,tbl_manufacturer b, tbl_promo c ";
			
			$where = "a.brand = b.id and a.item = c.promo_id and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray3=$result;
		  
		 }
		 else if($category == '4'){
			
			
			$row = "a.sr_no,a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.item_code";
			$table = "tbl_stock_requisition a,tbl_manufacturer b,tbl_consumables c";
			
			$where = "a.brand = b.id and a.item = c.con_id  and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray4=$result;
		   
		 }
		
		$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4);
	}
	
	
	if(!empty($output)){
	
	
		$i=0;
		foreach($output as $key2){
			
			if($key2['category'] =='1'){	
			 
			 $item = $key2["model"];
			 $name = "motorcycle";
			
			 }else if ($key2['category'] =='2'){
			
			   $item = $key2["item_code"];
			    $name = "parts";
			 }
			 else if ($key2['category'] =='3'){
			
			   $item = $key2["item_code"];
			    $name = "promo item";
			 }
			 else if ($key2['category'] =='4'){
			
			   $item = $key2["item_code"];
			    $name = "consumables";
			 }
			
			
			
			$item_details_arr[$i]=array(
				'sr_no'=> $key2['sr_no'],
				'category'=> $key2['category'] ,
				'category_name'=> $name,
				'brand'=> $key2['brand'],
				'item'=> $item,
				'color'=> $key2['color'],
				'quantity'=> $key2['quantity'] ,
				'unit_cost'=> $key2['unit_cost'],
			);
			$i++;
		}
	}
	
	
	//print_r($item_details_arr);
	
		echo "<table align='left' border='1' cellpadding='1'; style='width:1100px;'>";
			echo "<tr align ='center'>";
				echo "<th>S.R NO</th>";
				echo "<th>CATEGORY CODE</th>";
				echo "<th>CATEGORY</th>";
				echo "<th>BRAND</th>";
				echo "<th>ITEM</th>";
				echo "<th>COLOR</th>";
				echo "<th>QUANTITY</th>";
				echo "<th>UNIT COST</th>";
			echo "</tr>";

		if(count($item_details_arr)>0){
			foreach($item_details_arr as $keyx){
		
			echo "<tr>
			<td>".$keyx['sr_no']."</td>
			<td>".$keyx['category']."</td>
			<td>".$keyx['category_name']."</td>
			<td>".$keyx['brand']."</td>
			<td>".$keyx['item']."</td>
			<td>".$keyx['color']."</td>
			<td>".$keyx['quantity']."</td>
			<td>".number_format((float)$keyx['unit_cost'], 2, '.', '')."</td>
			</tr>";
			
			
		
			}
	}else{
		echo "<tr align='center'><td colspan=12  style='padding:20px 0px 5px 0px;'>*** NO ITEMS TO DISPLAY ***</td></tr>";
	}
	
				
		
?>