<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Items</title>
<head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
.ui-dialog-title{
	text-align:left;
}

.deletex{
	width: 27px;
	height:27px;
	display:block;
	background:transparent url('../images/delete.png') center top no-repeat;
	margin:auto;
}

</style>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link rel="stylesheet" href="../css/jPages.css" type="text/css" media="screen">

	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript" ></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
		<div id="main" align="center">
			<div id="options-top" align="center" style="width:400px;">
				<div>	
					<table width="400px">
						<tr>
								<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
								<h2>MOTORCYCLE</h2>
								</td>
								<td style="text-align:right;background:#FFF;padding:0px;border:none">
								<input type="button" value="NEW BRAND" id='input' onclick="add_brand();" style="width:130px;">
								</td>
						<tr>
					</table>
				</div>
				<div  class="contents" style="width:400px; margin-top:-10px;" cellspacing="0">
					<table  align="center" id="table">
					<input type="hidden"  value="<?php echo $_REQUEST['category']; ?>" name="category" id="category" >
					<thead>
					<tr><th><a href = "#"  class = "table_title" style='text-decoration:none;' onclick = "filter_list(0,'brand')">MANUFACTURER</a></th>
					<th><a href = "#"  class = "table_title" style='text-decoration:none;' onclick = "filter_list(0,'no_of_item')">NO. OF UNITS</a></th>
					<th style="width:10px;" colspan="2">ACTION</th></tr>
					</thead>
					<tbody id="alldata"></tbody>
					</table>
				</div>
				
				<div align="right" style="margin-top:10px">
						<input type="button" value="BACK" onclick="cancel(); ">
				</div>
								
				<div>
				<div id="new_items" title="NEW BRAND " style="display:none;">
				<iframe id="item_dialog" width="380" height="90" style="border:none"></iframe>
				</div>
			</div>
			
			<div id="pagination" style="top:-50px;"> 
						<div class="holder" ></div>
						<div style='font-size:11px;margin-top:5px;' align='center'><i>Pages</i></div>
				</div>
			
		</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		
		if(menu=="management#"){
			menu="management";
		}
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});
		loadData("DESC","a.id");	
	});	
	

		var filter = 1;
		var display_result = [0,0,0,0,0];
		var sortType = "ASC";
		function filter_list(index,sorts){
			display_result[index] = display_result[index] == 0 ? 1 : 0;
			sortType = display_result[index] == 0 ? "ASC" : "DESC";
			loadData(sortType,sorts);			
		}


	var cat=$('#categoryx').val();
	var category=$('#category').val();
	
	
	function loadData(sortType,sort){
    		
	
	var count=0,x=0;	
	var container=$("#table > tbody");
	
		$.ajax({
					url:"function_items.php",
					data:{"request":"ajax","action":"load_item","category":category,"sort":sort,"sortType":sortType},
					dataType:'json',
					beforeSend: function(){
						
					},
			success: function(reply){
							//console.log(reply.length);
				if(reply.length > 0){
					container.empty();
							$.each(reply, function(i,res){
								count++;
								
						container.append("<tr class='x'  > </td><input type='hidden' name='brand"+res.id+"' id='brand"+res.id+"' value='"+res.brand+"' /><td align='center'>"+res.brand+"</td><td align='center'>"+res.no_of_item+"<td align='center'><a href='#' alt='Update' title='Update' class='view' onclick='view_item("+res.id+");'></a></td><td align='center'><div id='gen"+res.id+"'></div></td></tr>");
						
						if(res.no_of_item > 0){
							$("#gen"+res.id).empty().append("<a href='#' class='deletex' ></a>");
							
						}else{
							$("#gen"+res.id).empty().append("<a href='#' alt='Delete' title='delete' class='delete' onclick='deleteBrand("+res.id+");'></a>");
						}
						
						
																
				});
				jpages();
				}
				else{
					
				container.append("<tr id = 'noItems'><th colspan = '13' align = 'center'> No Items on record! </th></tr>");
				}
			}
		});

	}

	
	
	function add_brand(){
		
			$("#item_dialog").attr('src','../managements/newBrand.php?idx=brand');
			$("#new_items").dialog({
				width:381,
				height: 135,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
	}
	
	function view_item(num){
		
			var brand = $('#brand'+num).val();
			window.location = "view_details.php?brand="+brand+"&id="+num+"&menu=management";
		}
	
	function cancel(){
			window.location = "items.php?&menu=management";
		}
		
	function popup(m){
	
		jAlert(m,"Alert Dialog");
	
	}
	
	function closeIframe(actions){
			if(actions=="add"){
				jAlert("successfully Added");
			}
			else if(actions=="edit"){
				jAlert("successfully updated");
			}
			$('#new_items').dialog('close');
			 loadData();
			return false;
	}
	
	
	function jpages(){
			$("div.holder").jPages({
			  containerID : "alldata",
			  previous : "←",
			  next : "→",
			  perPage : 10,
			  delay :10,
			  startPage    : 1,
			  startRange   : 1,
			  midRange     : 5,
			  endRange     : 1
			});
		}
		
	function deleteBrand(id){

		jConfirm('Do you really want to DELETE this BRAND ?','Confirmation Dialog',function(e){	
			
		if(e){
		
			var table =  "tbl_manufacturer";
			$.ajax({
				url: "function_items.php",
				data:{"request":"ajax","action":"deleteSingleItem","id":id,"table_name":table,"table_id":"id"},
				success: function(reply){

				}
			});
			
		$('#record'+id).animate({ backgroundColor: '#fbc7c7' }, 'fast')
		.animate({ opacity: "hide" }, "slow");
		
		jAlert("Successfully Deleted");
		loadData("DESC","a.id");
	
  		}
		
		});
	}
	
	</script>
	
</body>
</html>