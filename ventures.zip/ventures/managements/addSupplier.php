<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px;margin-left:15px;">
					<div style="margin-top:10px">
						<span>
							<label>Supplier</label>
							<input type="text" id = "txtsupplier" style="margin-left:45px">
						</span>
						<span>
							<label style="margin-left:200px">Contact Person:</label>
							<input type="text" id = "txtperson">
						</span>
					</div>
					<div>
						<span>
							<label>Telephone No.:</label>
							<input type="text" id = "txttel" onkeyup="javascript:this.value = this.value.replace(/[^0-9,-]/, '')">
						</span>
					</div>
					<div>
						<span>
							<label><h3>ADDRESS</h3></label>
						</span>
					</div>
					<div>
						<span>
							<label>Region</label>
							<label style="margin-left:206px">Province</label>
							<label style="margin-left:197px">City/Town</label>
						</span>
					</div>
					<div>
						<span>
							<select id = "txtregion" name='brand' class = "select_to" style = "width:250px;">
							<option value="">-SELECT-</option>
							</select>
							<select id = "txtprovince" name='brand' class = "select_to" style = "width:250px;">
							<option value="">-SELECT-</option>
							</select>
							<select id = "txtcity" name='brand' class = "select_to" style = "width:250px;">
							<option value="">-SELECT-</option>
							</select>
						</span>
					</div>
					<div>
						<span>
							<label>Subd/Brgy</label>
							<label style="margin-left:185px">Street/Num</label>
						</span>
					</div>
					<div>
						<span>
							<input type="text" id = "txtsubd" style = "width:250px;">
							<input type="text" id = "txtstreet" style = "width:250px;">
						</span>
					</div>
					<div align = "center" style="margin-top:50px;">
						<span>
							<input type="button" value="ADD" id = "btnadd" onclick = "Add();" style="width:100px;top:1px;">
							<input type="button" value="CANCEL" onclick = "window.parent.closeIframe('cancel');" style="width:100px;top:1px;">
						</span>
					</div>
			</div>
		<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadRegion();
		
		$('#txtregion')
		.prop('disabled', false)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$('#txtprovince')
		.prop('disabled', true)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$('#txtcity')
		.prop('disabled', true)
		.empty()
		.append('<option value="">-- SELECT --</option>')
		.find('option:first')
		.attr("selected","selected")
		;
		
		$( "#txtregion" ).change(function() {
			if($(this).val() == "") {
				$('#txtprovince')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
				$('#txtcity')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
			}
			else {
				$('#txtprovince')
				.prop('disabled', false)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
				
				$('#txtcity')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
			}
			
			var region_id=$("#txtregion :selected").val();
			var region_name=$("#txtregion :selected").text();
			
			loadProvince(region_id);
		});
		
		$( "#txtprovince" ).change(function() {
			if($(this).val() == "") {
				$('#txtcity')
				.prop('disabled', true)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
			}
			else {
				$('#txtcity')
				.prop('disabled', false)
				.empty()
				.append('<option value="">-- SELECT --</option>')
				.find('option:first')
				.attr("selected","selected")
				;
			}
			
			var province_id=$("#txtprovince :selected").val();
			var province_name=$("#txtprovince :selected").text();
			
			loadCity(province_id);
		});
		
	});
	
	function loadRegion(){
	
		var url="functions.php?request=ajax&action=loadSupplierRegion";
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){

				$("#txtregion").append("<option value="+ res.id+">" + res.region_name + "</option>");

			});
		});
	}

	function loadProvince(pid){
		
		var url="functions.php?request=ajax&action=loadSupplierProvince&region_id="+pid;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
			
				$("#txtprovince").append("<option value="+ res.id+">" + res.province_name + "</option>");
				
			});
		});
	}

	function loadCity(cid){
		
		var url="functions.php?request=ajax&action=loadSupplierCity&province_id="+cid;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				
				$("#txtcity").append("<option value="+ res.id+">" + res.city_name + "</option>");

			});
		});
	}

	function Add(){

		var supplier=$("#txtsupplier").val();	
		var telno=$("#txttel").val();
		var person=$("#txtperson").val();
		var region_id=$("#txtregion").val();
		var province_id=$("#txtprovince").val();
		var city=$("#txtcity").val();
		var subd=$("#txtsubd").val();
		var street=$("#txtstreet").val();
		
		var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
		
		if(supplier == ""){
			errormsg+="- Input Supplier.\n";
		}
		if(region_id == ""){
			errormsg+="- Input Region.\n";
		}
		if(province_id == ""){
			errormsg+="- Input Province.\n";
		}
		if(city == ""){
			errormsg+="- Input City/Town.\n";
		}
		if(subd == ""){
			errormsg+="- Input Subd/Brgy.\n";
		}
		if(street == ""){
			errormsg+="- Input Street/Num.\n";
		}
		
		if(errormsg.length==emsg){
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"saveSupplierData","supplier":supplier,"person":person,"telno":telno,"region_id":region_id,"province_id":province_id,"city":city,"subd":subd,"street":street},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){
							window.parent.closeIframe('add');
							
						}else if(reply == 'exists'){
							jAlert('Supplier Already Exists!', 'Alert Dialog');
						}
						else{
							alert('Error');
							event.preventDefault();
						}
				}
			});
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
	}
	
	</script>
	
</body>
</html>