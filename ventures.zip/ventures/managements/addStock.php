<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Requisition</title>
<head>
<?php
include('../database.php');  
$db = new Database();  
$db->connect();
?>

<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
.ui-dialog-title{
	text-align:left;
}
</style>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/FormatNUmberBy3.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div style="width:900px;position:relative;">
					<div id="options-top" style="margin:0px auto" align="center">
						<div id="sample" style="text-align:left;padding:10px;margin-top:-25px" >
								<div>
									<span>
										<label><h2>REQUISITION</h2><hr></label>
										<input type="hidden" id="sr_no" value="<?php echo $_REQUEST['sr_no']; ?>"  name="sr_no"   />
									</span>
								</div>
								<div>
									<span>
										<label>S.R NO:</label>
										<input type="text" id="sr" name="sr" style="text-align:center;" style="color:black" readonly="readonly" style="margin-left:10px">
									</span>
									<span>
										<label style="margin-left:330px">Date:</label>
										<input type="date" id="date" name="date" style="margin-left:35px" >
									</span>
								</div>
								<div>
									<span>
										<label >To:</label>
										<input type="text" style="margin-left:27px" id="to" name="to">
									</span>
									<span>
										<label  style="margin-left:330px">Branch:</label>
										<select id = 'branch' class = "select_to" name='branch' style = "width:250px; margin-left:22px;"></select>
									</span>
								</div>
								<div>
									<span>
										<label><h3>Search Item</h3></label>
									</span>
								</div>
								<div>
									<span>
										<input type="hidden" name="cat" id="cat" />
										<select id = "category" name="category" onchange = "changeCategory(this.value)">
										<option value="motorcycle">MOTORCYCLE</option>
										<option value="parts">PARTS</option>
										<option value="promo item">PROMO ITEM</option>
										<option value="consumables">CONSUMABLES</option>
										</select>
										<input type="button" value="SEARCH" onclick="add_item();">
									</span>
								</div>
								<div  class="contents" style="width:900px;position:relative;">
									<table  align="center" id="table">
										<br>
										<thead><tr><th>PARTICULARS</th><th>QUANTITY</th><th>UNIT COST</th><th>AMOUNT</th><th colspan="2">ACTION</th></tr><thead>
											<tbody id="alldata"></tbody>
									</table>
								</div>
								<div style="margin-top:10px">
									<span>
										<label style="margin-left:700px">TOTAL QTY:</label>
										<input type="text" id="total_qty" name="total_qty" style="width:100px;text-align:center;" readonly="readonly" >
									</span>
								</div>
								<div>
									<span>
										<label style="margin-left:700px">TOTAL AMT</label>
										<input type="text"  id="total_amt" name="total_amt" style="width:100px;text-align:right;" readonly="readonly" >
									</span>
								</div>
								<div align="center">
									<span>
									
										<input type="button" value="UPDATE" onclick="edit_stock()" style="width:100px;top:1px;">
																	
										<input type="button" value="PRINT"  onclick="print_report()" style="width:100px;top:1px;">
										<input type="button" value="EXPORT" onclick="export_excel()" style="width:100px;top:1px;">
										<input type="button" value="CANCEL" onclick="cancel()" style="width:100px;top:1px;">
									</span>
								</div>
								<div id="new_items" title="" style="display:none;">
								<iframe id="item_dialog" width="750" height="290" style="border:none"></iframe>
								</div>
						</div>
					<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="management#"){
				menu="management";
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadData();
		loadItem();
		var category = $('#category').val();		
		$('#cat').val(category);
		
	});	
	
	function changeCategory(category){
	$('#cat').val(category);
	}
	
	var sr_no = $('#sr_no').val();	
	function loadData(){
			
			var url="function_items.php?request=ajax&action=load_SR&sr_no="+sr_no;
		
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){
					$('#sr').val(res.sr_no);
					$('#date').val(res.date);
					var branch_code = res.branch_code;
					$('#to').val(res.sold);load_select(branch_code);
				});	
			});
			
	}
	
	
	
	function loadItem(){
    		
	var total_qty = 0,count = 0,total_amout = 0,counter = 1,total_amoutx=0;		
	var url="function_items.php?request=ajax&action=load_ko&sr_no="+sr_no;
	var counter=1;
	var x = 1;

		$.getJSON(url,function(data){
		
			$("#table > tbody").empty();
					$.each(data.members, function(i,res){
					
					total_qty +=   parseFloat(res.quantity);
					total_amout += parseFloat(res.quantity) * parseFloat(res.unit_cost);
					total_amoutx = (Math.round(total_amout)).toFixed(2)	;
										
										$("#total_qty").val(total_qty);
										$("#total_amt").val(FormatNumberBy3(total_amoutx));
											
								
										
										var amount = parseFloat(res.quantity) * parseFloat(res.unit_cost);
										
										
										if(res.category == '1'){
										var particulars = res.brand+" - "+res.model+" - "+res.color;
										}else{
										var particulars = res.brand+" - "+res.item_code;
										}
											
										var particulars = 	particulars.toUpperCase();
										
									var unit_cost = FormatNumberBy3((Math.round(res.unit_cost)).toFixed(2));
						
				$("#table > tbody").append("<tr class='x' id='record"+res.stock_id+"' onmouseover='clickSearch()'  > </td><input type='hidden' name='brand"+res.stock_id+"' id='brand"+res.stock_id+"' value='"+res.stock_id+"' /><td align='center'>"+particulars+"</td><td><input type='text' id='quantity"+res.stock_id+"' name='quantity"+res.stock_id+"'style='width:100px;margin-left:23px;text-align:center;' value = '"+res.quantity+"' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\"></td><td><input type='text' id='unit_cost"+res.stock_id+"' name='unit_cost"+res.stock_id+"'style='width:100px;margin-left:23px;text-align:right;' value = '"+unit_cost+"' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\"></td><td  style='width:100px;margin-left:23px;text-align:right;' align='center'>"+FormatNumberBy3((Math.round(amount)).toFixed(2))+"</td><td align='center'><a href='#' alt='Update' title='Update' class='edit' onclick=\"edit_item('"+res.stock_id+"');\"></a></td><td align='center'><a href='#' alt='Update' title='Delete' class='delete' onclick=\"delete_item('"+res.stock_id+"');\"></a></td></tr>");
									
						 counter++;
						 x = x+1;
						 
						
					});	
		
			if (counter <= 1){
				$("#table > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Items on record! </th></tr>");
			}
					
					
		});
		
	}
	
	
	function load_select(branch_code){
		var count=0, x=0;
		var select = $("#branch");

		$.ajax({
				url:"function_items.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					if(reply.length > 0){
						select.empty();
							$.each(reply, function(i,res){
							 count++;
							if(res.branch_code == branch_code ){
							select.append("<option  value='"+res.branch_code+"' selected='selected' >"+res.branch_name+"</option>");
							}	else{
							select.append("<option  value='"+res.branch_code+"'>"+res.branch_name+"</option>");
							}	
								
																		
							});
			
					}
				}
			});
	}
	
	
	function add_item(){
	
	var val = $('#cat').val();
	
	if(val =="motorcycle"){
	var cat = 1;
	var table = "tbl_motorcycle";
	}
	else if(val =="parts"){
	var cat = 2;
	var table = "tbl_parts";
	}
	else if(val =="promo item"){
	var cat = 3;
	var table = "tbl_promo";
	}
	else if(val =="consumables"){
	var cat = 4;
	var table = "tbl_consumables";
	}
	
			$("#new_items").attr("title","ADD ITEM");
		$("#item_dialog").attr({
			height:340,
			width:400,
		});
			
	
	
			$("#new_items").attr("title",val );
			$("#item_dialog").attr('src','../managements/stockMotorcycle.php?&cat='+cat+'&table='+table+'&sr_no='+sr_no);
			$("#new_items").dialog({
			width: 401,
			height: 385,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
			
			
	}
	
	
	
	function edit_item(id){	
	
	event.preventDefault();
	
	
	var cost = $('#unit_cost'+id).val();
	var unit_cost = parseFloat(cost.replace(/,/g, ''));
	var quantity = $('#quantity'+id).val();
	var errormsg="Please complete the following fields: \n";
	var emsg= errormsg.length;
	
		if(unit_cost == ""){
			errormsg+="-Unit Cost\n";
			
		}
		if(quantity == ""){
			errormsg+="-Quantity\n";
			
		}
		if(errormsg.length== emsg){
	$.ajax({
			url: "function_items.php",
			data:{"request":"ajax","action":"update_stock_item","id":id,"unit_cost":unit_cost,"quantity":quantity},
				success: function(reply){
					console.log(reply);
						if(reply == 'updated'){
						    	
						jAlert('Successfully Updated','Updated');
						 $("#table > tbody").empty()
									loadData();
									loadItem();
						
						}else{
						jAlert("cannot update information");
					
					}
				}
			
		});
		}else{
			jAlert(errormsg);
			event.preventDefault();
		}
	 
	 }
	
	
	
	function closeIframe(actions){
		if(actions=="add"){
			jAlert("Successfully Added");
		}
		else if(actions=="edit"){
			jAlert("Successfully Updated");
		}
		else if(actions=="cancel"){
			$('#new_items').dialog('close');
		}
		$('#new_items').dialog('close');
		 loadData();
		return false;
	}
	

	
	function cancel(){
			window.location = "requisition.php?menu=management";
	}
	
	function edit_stock(){
		event.preventDefault();
		
		var date = $('#date').val();
		var branch = $('#branch').val();
		var to = $('#to').val();
		var errormsg="Please complete the following fields: \n";
		var emsg= errormsg.length;

			if(date == ""){
				errormsg+="-Date \n";
				
			}
			if(branch == ""){
				errormsg+="-Branch \n";
				
			}
			
			if(errormsg.length== emsg){
			
			
		$.ajax({
			
				  url: "function_items.php",
					data:{"request":"ajax","action":"update_SRNO","sr_no":sr_no,"date":date,"branch":branch,"to":to},
						success: function(reply){
							console.log(reply);
								if(reply == 'updated'){
									
									jAlert("Successfully Updated","UPDATED");
									window.location = "requisition.php?menu=management";
									//$("#table > tbody").empty()
									/* loadData();
									loadItem(); */
								
								}else{
									jAlert("cannot add information");
								}
							
							}
			
			
			
			});
			
			}else{
				jAlert(errormsg);
				event.preventDefault();
			}
	
	}
	
	
	
	function delete_item(id){

		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
		if(e){
		
			var table =  "tbl_stock_requisition";
			$.ajax({
				url: "function_items.php",
				data:{"request":"ajax","action":"deleteSingleItem","id":id,"table_name":table,"table_id":"stock_id"},
				success: function(reply){

				}
			});
			$('#record'+id).animate({ backgroundColor: '#fbc7c7' }, 'fast')
			.animate({ opacity: "hide" }, "slow");
				
			jAlert("successfully Deleted");
			loadItem();
	
  		}
		
		});
	}
	
	
	function print_report(){
	
	window.open("printRequisition.php?sr_no="+sr_no,'_blank');
	
	}
	
	function export_excel(){
	
	window.location="export_requisition.php?sr_no="+sr_no;
	
	}
	
	function clickSearch() {
	
	$("#txtsearch").blur();	
	
	}
	
	
	
	
	</script>
	</script>
	
</body>
</html>