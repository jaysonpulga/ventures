<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Manufacturer</title>
<head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
.ui-dialog-title{
	text-align:left;
}
</style>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link rel="stylesheet" href="../css/jPages.css" type="text/css" media="screen">
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
	<script src="../js/jPages.js" type="text/javascript" ></script>
	<script src="../js/FormatNUmberBy3.js" type="text/javascript"></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
		<div id="main" align="center">
				<div id="options-top" align="center" style="width:780px;">
					<div>
						<table width="780px">
							<tr>
								<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
								<h2 style="margin-top:10px;">PROMO ITEMS</h2>
								</td>
								<td style="text-align:right;background:#FFF;padding:0px;border:none">
								<form name="search" action="" method="POST">
								
								<select id = 'category' name='category'>
									<option value="b.brand">MANUFUCTURER</option>
									<option value="a.item_code">ITEM CODE</option>
									<option value="a.description">DESCRIPTION</option>
								</select>
									<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Category">
									<input type="button" value="ADD PROMO" id='input' style="width:110px;" onClick="add_promo();">
									</form>
								</td>
							</tr>
						</table>
					</div>
					
					<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:780px" cellspacing="0">
						<table   align="center" id="table">
							<thead>
							<tr>
							<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'b.brand')">MANUFACTURER</a></th>
							<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'a.item_code')">ITEM CODE</a></th>
							<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'a.unit_cost')">UNIT COST</a></th>
							<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'a.description')">DESCRIPTION</a></th>
							<th colspan="2">ACTION</th></tr>
							</thead>
							<tbody id="alldata"></tbody>
						</table>
					</div>	
					<div align="right" style="margin-top:10px">
						<input type="button" value="BACK" onClick="cancel(); ">
					</div>
					<div>
					<div id="new_items" title="ADD PROMO" style="display:none;">
					<iframe id="item_dialog" width="370" height="270" style="border:none"></iframe>
				</div>
				</div>
				<div id="pagination" style="top:-50px;"> 
						<div class="holder" ></div>
						<div style='font-size:11px;margin-top:5px;' align='center'><i>Pages</i></div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];

		if(menu=="management#"){
				menu="management";
		}
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});
		loadData("ASC","b.brand");
	});	
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
	var sortType = "ASC";
	function filter_list(index,sorts){
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadData(sortType,sorts);			
	}
	
	$("#txtsearch").live('keyup change',function(){
		$("#table > tbody").empty();
		loadData("ASC","b.brand");				
	});
	
	function loadData(sortType,sort){

		var count=0, x=0;
		var container = $("#table > tbody");

		$.ajax({
				url:"function_items.php",
				data:{"request":"ajax","action":"load_data","tablename":"tbl_promo","inputsearch":$("#txtsearch").val(),"category":$("#category").val(),"sort":sort,"sortType":sortType},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					if(reply.length > 0){
						container.empty();
							$.each(reply, function(i,res){
							 count++;
									
								container.append("<tr class='x' id='record"+res.promo_id+"' onmouseover='clickSearch()' ></td><td align='center'>"+res.brand+"</td><td align='center'>"+res.item_code+"</td><td  style='text-align:right;'>"+FormatNumberBy3((Math.round(res.unit_cost)).toFixed(2))+"</td></td><td align='center'>"+res.description+"</td><td align='center'><a href='#' alt='Update' title='Update' class='edit' onclick='edit_promo("+res.promo_id+");'></a></td><td align='center'><a href='#' alt='Update' title='DELETE' class='delete' onclick='deleteParts("+res.promo_id+");'></a></td></tr");
																		
							});
					jpages();
					}
					else{
						
						container.empty().append("<tr id = 'noItems'><th colspan = '13' align = 'center'> No Items on record! </th></tr>");
					}
				}
			});
		
		

	}


	function closeIframe(actions){
		if(actions=="add"){
			jAlert("Successfully Added");
		}
		else if(actions=="edit"){
			jAlert("Successfully Updated");
		}
		else if(actions=="cancel"){
			$('#new_items').dialog('close');
		}
		$('#new_items').dialog('close');
		 loadData();
		return false;
	}


	
	function add_promo(){
			$("#item_dialog").attr('src','../managements/addPromo.php');
			$("#new_items").dialog({
				width:370,
				height: 320,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src', "about:blank");
					window.location.reload();
				}
			});
			return false;
	}
		
	
	function edit_promo(id){

	document.getElementById('new_items').title = 'EDIT PROMO';
	$("#item_dialog").attr('src','../managements/addPromo.php?status=update&promo_id='+id);
		$("#new_items").dialog({
				width:370,
				height: 320,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src', "about:blank");
				window.location='itemPromo.php?category=promo%20item&menu=management';
				
				}
		});
			return false;
			
	}
	
			
	function cancel(){
	
	window.location = "items.php?&menu=management";
	
	}
	
	
	function deleteParts(id){

		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
			if(e){
		
		var table =  "tbl_promo";
		$.ajax({
		url: "function_items.php",
		data:{"request":"ajax","action":"deleteSingleItem","id":id,"table_name":table,"table_id":"promo_id"},
		success: function(reply){
		
		$('#record'+id).animate({ backgroundColor: '#fbc7c7' }, 'fast')
		.animate({ opacity: "hide" }, "slow");
		
			jAlert("Successfully Deleted");
		
		}
		});
			
		
	
  		}
		
		});
	}
	
	function jpages(){
		$("div.holder").jPages({
		  containerID : "alldata",
			previous : "←",
		  next : "→",
		  perPage : 10,
		  delay :10,
		  startPage    : 1,
		  startRange   : 1,
		  midRange     : 5,
		  endRange     : 1
		});
	}
	function clickSearch() {
	
		$("#txtsearch").blur();
	
	}
	</script>
	
</body>
</html>