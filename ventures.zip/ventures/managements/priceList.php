<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Price List</title>
<head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
.ui-dialog-title{
	text-align:left;
}
</style>
<?php
include('../database.php');  
$db = new Database();  
$db->connect();
?>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link rel="stylesheet" href="../css/jPages.css" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
	<script src="../js/jPages.js" type="text/javascript" ></script>
	<script src="../js/FormatNUmberBy3.js" type="text/javascript"></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
		<div id="main" align="center">
				<div id="options-top" align="center" style="width:790px;margin-bottom:10px;">
				<div>
					<table width="790px">
						<tr>
							<td colspan="6" style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2>PRICE LIST</h2><hr>
							</td>
						</tr>
						<tr>
							<td td style="text-align:left;background:#FFF;padding:0px;border:none">
								<form name="search" action="" method="POST">
								<input type="hidden" name="cat" id="cat" />
									Category: <select id = "category" onchange = "changeCategory(this.value)">
									<?php  
									$db->select("category","*");
									$result = $db->getResult();
											
									foreach($result as $info){
										$category = $info['category'];
									echo '<option value="'.$category .'">'.strtoupper($category).'</option>';								
									}
									?>
									</select>
								</form>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
								<form name="search" action="" method="POST">
									<select id = 'searchx' name='searchx'>
									</select>
									<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Report">
								</form>
							</td>
						</tr>
					</table>
				</div>
			
								
				<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:790px" cellspacing="0">
					<table   align="center" id="table">
					<thead></thead>
					<tbody id="alldata"></tbody>
					</table>
				</div>
				<div align="right" style="margin-top:10px">
						<input type="button" value="EXPORT" onClick="export_excel(); ">
					</div>
					<div>
					<div id="new_items" title="ADD PARTS " style="display:none;">
					<iframe id="item_dialog" width="370" height="270" style="border:none"></iframe>
				</div>
				</div>
				<div id="pagination" style="top:-50px;"> 
						<div class="holder" ></div>
						<div style='font-size:11px;margin-top:5px;' align='center'><i>Pages</i>
				</div>
				</div>
			</div>
		</div>
	
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});
		
		var category = $('#category').val();	
		$('#cat').val(category);
		
		load_parts(category);
		load_header(category)
		loadData(category,"b.brand");	
	});
	
		var filter = 1;
		var display_result = [0,0,0,0,0];
					
		var sortType = "ASC";
		function filter_list(cVar,index,cat){
		sort = cVar;
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadData(cat,index);
						
		}
	
	
	
	function export_excel(){
	var category = $('#cat').val();
	
		if(category == "motorcycle" ){
		   var table = "tbl_motorcycle";
		}
		if(category == "parts" ){
		   var table = "tbl_parts";
		}
		if(category == "promo item" ){
		   var table = "tbl_promo";
		}
		if(category == "consumables" ){
		   var table = "tbl_consumables";
		}
		
	window.open('excel_items.php?tablename='+table+"&category="+category,'_blank');
	
	}
	
	function jpages(){
			$("div.holder").jPages({
			  containerID : "alldata",
			  previous : "←",
			  next : "→",
			  perPage : 10,
			  delay :10,
			  startPage    : 1,
			  startRange   : 1,
			  midRange     : 5,
			  endRange     : 1
			});
		}
	
	function changeCategory(category){
	$('#cat').val(category);
	load_header(category)
	load_parts(category);
	loadData(category,"b.brand")
	}
	
	$("#txtsearch").live('keyup change',function(){
	var category = $('#category').val();
	$("#table > tbody").empty();
		loadData(category,"b.brand");				
	});
	
	function loadData(category,sort){
	event.preventDefault();
	var counter=1;
	var x = 1;
	
	if(category == "motorcycle" ){
	   var table = "tbl_motorcycle";
	}
	if(category == "parts" ){
	   var table = "tbl_parts";
	}
	if(category == "promo item" ){
	   var table = "tbl_promo";
	}
	if(category == "consumables" ){
	   var table = "tbl_consumables";
	}
	
	var count=0,x=0;
			
	var container=$("#table > tbody");
	$.ajax({
				url:"function_items.php",
				data:{"request":"ajax","action":"load_price","table_name":table,"inputsearch":$("#txtsearch").val(),"category":$("#searchx").val(),"sort":sort,"sortType":sortType},
				dataType:'json',
				beforeSend: function(){
					
				},
		success: function(reply){
						//console.log(reply.length);
			if(reply.length > 0){
				container.empty();
						$.each(reply, function(i,res){
							count++;
						
						if(category == "motorcycle" ){
						
					container.append("<tr class='x' id='record"+res.motor_id+"' onmouseover='clickSearch()' ></td><td align='center'>"+res.brand+"</td><td align='center'>"+res.model+"</td><td><input type='text' id='selling"+res.motor_id+"' name='selling"+res.motor_id+"'style='width:100px;margin-left:23px;text-align:right;' value = '"+FormatNumberBy3((Math.round(res.selling_price)).toFixed(2))+"' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\"></td><td><input type='text' style='width:100px;margin-left:23px;text-align:right;' id='installment"+res.motor_id+"' name ='installment"+res.motor_id+"' value = '"+FormatNumberBy3((Math.round(res.installment)).toFixed(2))+"' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\" ></td><td align='center'><a href='' alt='Update' title='Update' class='edit' onclick=\"Add("+res.motor_id+",'tbl_motorcycle','motor_id','motorcycle');\"></a></td></tr");
					
					}
						if(category == "parts" ){
						
					container.append("<tr class='x' id='record"+res.parts_id+"'  onmouseover='clickSearch()' ></td><td align='center'>"+res.brand+"</td><td align='center'>"+res.item_code+"</td><td align='center'>"+res.description+"</td></td><td><input type='text'   style='width:100px;margin-left:23px;text-align:right;' onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\" value ='"+FormatNumberBy3((Math.round(res.selling_price)).toFixed(2))+"' id='selling"+res.parts_id+"' name='selling"+res.parts_id+"' ></td><td align='center'><a href='' alt='Update' title='Update' class='edit'onclick=\"Add("+res.parts_id+",'tbl_parts','parts_id','parts');\"></a></td></tr");
	  
						}
						if(category == "promo item" ){
						
					container.append("<tr class='x' id='record"+res.promo_id+"' onmouseover='clickSearch()'  ></td><td align='center'>"+res.brand+"</td><td align='center'>"+res.item_code+"</td><td align='center'>"+res.description+"</td></td><td><input type='text' style='width:100px;margin-left:23px;text-align:right;'  onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\"  value ='"+FormatNumberBy3((Math.round(res.selling_price)).toFixed(2))+"' id='selling"+res.promo_id+"' name='selling"+res.parts_id+"' ></td><td align='center'><a href='' alt='Update' title='Update' class='edit' onclick=\"Add("+res.promo_id+",'tbl_promo','promo_id','promo item');\"></a></td></tr");
	 
						}
						if(category == "consumables" ){
						
					container.append("<tr class='x' id='record"+res.con_id+"'  onmouseover='clickSearch()' ></td><td align='center'>"+res.brand+"</td><td align='center'>"+res.item_code+"</td><td align='center'>"+res.description+"</td></td><td><input type='text' style='width:100px;margin-left:23px;text-align:right;'  onkeyup=\"javascript:this.value = this.value.replace(/[^0-9,.]/, '')\" value ='"+FormatNumberBy3((Math.round(res.selling_price)).toFixed(2))+"' id='selling"+res.con_id+"' name='selling"+res.con_id+"'  ></td><td align='center'><a href='#' alt='Update' title='Update' class='edit' onclick=\"Add("+res.con_id+",'tbl_consumables','con_id','consumables');\"></a></td></tr");
	  
						}	
										
			});
			jpages();
			}
			else{
				
			container.empty().append("<tr id = 'noItems'><th colspan = '13' align = 'center'> No Items on record! </th></tr>");
			}
		}
	});

	}
	
	
	
	function Add(id,table,tbl_id,category){
	event.preventDefault();
	
	//var selling = $('#selling'+id).val();
	
	var selling = parseInt($('#selling'+id).val().replace(/,/g, ''));
	//var installment = $('#installment'+id).val();
	
	if($('#installment'+id).val() > 0){
		var installment = parseInt($('#installment'+id).val().replace(/,/g, ''));
	}
	var errormsg="Please complete the following fields: \n";
	var emsg= errormsg.length;
		if(installment == "" && table =="tbl_motorcycle"){
			errormsg+="-Installment\n";
			
		}
		if(selling == ""){
			errormsg+="-Selling Price \n";
			
		}
		if(errormsg.length== emsg){
	$.ajax({
			url: "function_items.php",
			data:{"request":"ajax","action":"updatePrice","id_p":id,"tablename":table,"selling":selling,"installment":installment,"tbl_id":tbl_id},
				success: function(reply){
					console.log(reply);
						if(reply == 'updated'){
						    	
						jAlert('Successfully Updated','Alert Box');
						$("#table > tbody").empty();
						load_header(category)
						load_parts(category);
						loadData(category,"b.brand")
						
						}else{
							jAlert("cannot update information");
					
					}
				}
			
		});
		}else{
			jAlert(errormsg);
			event.preventDefault();
		}
			   
			   
	
	
	}
	
	
	function load_parts(category){
		$("#searchx").empty();
		 if(category == "motorcycle"){
		 $("#searchx").append("<option value='b.brand'>MANUFACTURER</option><option value='a.model'>MODEL</option><option value='a.selling_price'>SELLING PRICE</option><option value='a.installment'>INSTALLMENT</option>");
		 }
		 else{
		 $("#searchx").append("<option value='b.brand'>MANUFACTURER</option><option value='a.item_code'>ITEM CODE</option><option value='a.description'>DESCRIPTION</option><option value='a.selling_price'>SELLING PRICE</option>");
		 }
		 

	}
	
	function load_header(category){
	
		$("#table > thead").empty();
		if(category == "motorcycle"){
		 
			$("#table > thead").append("<tr><th><a  href='' onclick =\"filter_list('b.brand','b.brand','"+category+"');\" >MANUFACTURER</th></a><th><a  href='' onclick =\"filter_list('a.model','a.model','"+category+"');\" >MODEL</a></th><th><a  href='' onclick =\"filter_list('a.selling_price','a.selling_price','"+category+"');\" >SELLING PRICE</a></th><th><a  href='' onclick =\"filter_list('a.installment','a.installment','"+category+"');\" >INSTALLMENT<br>AMT(36MOS)</a></th><th>ACTION</th></tr>");
		}
		else{
			$("#table > thead").append("<tr><th><a href='' onclick =\"filter_list('b.brand','b.brand','"+category+"');\" >MANUFACTURER</a></th><th><a  href='' onclick =\"filter_list('a.item_code','a.item_code','"+category+"');\" >ITEM CODE</a></th><th><a  href='' onclick =\"filter_list('a.item_code','a.description','"+category+"');\" >DESCRIPTION</a></th><th><a  href='' onclick =\"filter_list('a.selling_price','a.selling_price','"+category+"');\" >SELLING PRICE</a></th><th colspan='2'>ACTION</th></tr>");
		}
		
	}
	
	function clickSearch() {
	
	$("#txtsearch").blur();	
	
	}

	</script>
    
	
</body>
</html>