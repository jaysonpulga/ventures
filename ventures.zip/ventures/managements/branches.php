<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<!DOCTYPE HTML>
<html lang="en">
<title>Branches</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<table width="950px">
						<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2 style="margin-top:10px;">BRANCH LIST</h2>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
								<form name="search" action="" method="POST">
								<select name = "txt_category" id = "category">
									<option value = "branch_code">Branch Code</option>
									<option value = "branch_name">Name</option>
									<option value = "province_id">Province</option>
								</select>
								<input type="search" name="txtsearch" id="txtsearch" placeholder="Search">
								<input type="button" value="ADD NEW" id='input' onclick="add_branch();">
								</form>
							</td>
						</tr>
					</table>
				</div>
			
				<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:950px" cellspacing="0">
				
					<table id="branch_list" border=1 align = "center">
						<thead align="center">
						<tr>
							<th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'a.branch_code')">BRANCH CODE</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'a.branch_name')">NAME</a></th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'b.province_name')">PROVINCE</th><th>CONTACT #</th><th colspan = "2">ACTION</th>
						</tr>
						</thead>
						<tbody id="branch_data"></tbody>						
					</table>
					
				</div>
				
				<div id="pagination"> 
					<div class="holder" style = "margin-top: 50px;"></div>
					<i>Pages</i>
				</div>

				
				<div id="add_items" title="Add Branch" style="display:none;">
					<iframe id="item_dialog" width="900" height="300" style="border:none"></iframe>
				</div>
	
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	function jpages(){
		$("div.holder").jPages({
		  containerID : "branch_data",
		  previous : "←",
		  next : "→",
		  perPage : 15,
		  delay :10,
		  startPage    : 1,
		  startRange   : 1,
		  midRange     : 5,
		  endRange     : 1
		});
	}
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
				
	var sortType = "ASC";
	
	function filter_list(index,cVar){
		sort = cVar;
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadData(sort,sortType);
	}
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		var menu = getUrlVars()["menu"];
	
		if(menu=="management#"){
			menu="management";
		}
		else{
			menu = getUrlVars()["menu"];	
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadData("a.id","DESC");
	});	
	function add_branch(){
		$("#add_items").attr("title","Add New Branch");
		$("#item_dialog").attr('src','addBranch.php');
		$("#add_items").dialog({
			width: 905,
			height: 350,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src',"about:blank");
				window.location.reload();
			}
		});
		return false;
	}

	$("#txtsearch").live('keyup change',function(){
		$("#branch_list > tbody").empty();
		loadData("a.id","DESC");				
	})
	
function loadData(sort,sortType){
	$("#branch_list > tbody").empty();
	
	var url="functions.php?request=ajax&action=viewBranchData&sort="+sort+"&sortType="+sortType+"&inputsearch="+$("#txtsearch").val()+"&category="+$("#category").val();
	var counter=0;
		
	$.getJSON(url,function(data){
		$.each(data.members, function(i,res){
			 
			  $("#branch_list > tbody").append("<tr class='x' onmouseover='clickSearch()'><td>"+res.branch_code+"</td><td>"+res.branch_name+"</td><td>"+res.province_name+"</td><td>"+res.tel_no+"</td><td><a href='#' class='edit' title='EDIT link' onclick=\"edit_branch("+res.id+",'"+res.branch_code+"')\"></a></td><td><a href='#' class='delete' title='DELETE link' onclick=delete_branch("+res.id+")></a></td></tr>");
			  counter++;	
		});
		if (counter <= 0){
			$("#branch_list > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
		}
		jpages();
	});
}

function edit_branch(id,code){

	$("#add_items").attr('title', "Edit Branch");
	$("#item_dialog").attr('src', "editBranch.php?branch_id="+id+"&branch_code="+code);
	$("#add_items").dialog({
		width: 905,
		height: 350,
		modal: true,
		resizable:false,
		close: function () {
			$("#item_dialog").attr('src', "about:blank");
			window.location="branches.php?menu=management";
		},
	});
	return false;
}

function delete_branch(id){

	jConfirm('Do you really want to DELETE this BRANCH?','Confirmation Dialog',function(e){
		if(e){
			$.ajax({
				url: "functions.php",
				data:{"request":"ajax","action":"delete_branch","id":id},
				success: function(reply){
					console.log(reply);
						if(reply == 'deleted'){
							jAlert('Branch Deleted','Alert Dialog');
							loadData();
						}else{
							jAlert('Error','Alert Dialog');
							event.preventDefault();
						}
					
					}
			});
		}
	});

}

function closeIframe(action,id) {
	if (action=="add") {
		jAlert('Data was successfully Saved!','Alert Dialog');
	}
	
	else if (action=="edit") {
		jAlert('Data was successfully Updated!','Alert Dialog');
		window.location="branches.php?menu=management";
	}
	else {
		
	}
	$("#add_items").dialog('close');
	loadData();
}

		$/* ("#txtsearch").blur(function(){
			$(this).val("");
		});
		
		$("#txtsearch").bind('keyup change',function(){
			var url ="functions.php?request=ajax&action=searchBranch&inputsearch="+$(this).val()+"&category="+$('#category').val();
			var count=0;
					if($(this).val().trim() != ""){
				
						$("#branch_list > tbody").empty();
						
						$.getJSON(url,function(data){
							var counter=0;
							$.each(data.members, function(i,res){
								 
								$("#branch_list > tbody").append("<tr class='x'><td>"+res.branch_code+"</td><td>"+res.branch_name+"</td><td>"+res.province_name+"</td><td>"+res.tel_no+"</td><td><a href='#' class='edit' title='EDIT link' onclick=\"edit_branch("+res.id+",'"+res.branch_code+"')\"></a></td><td><a href='#' class='delete' title='DELETE link' onclick=delete_branch("+res.id+")></a></td></tr>");
								 counter++;	
							});
							if (counter <= 0){
								$("#branch_list > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
							}
							jpages();
						});
					}
					else{
						$("#branch_list > tbody").empty();
						loadData();
					}
		}); */
		
	function clickSearch() {
	
		$("#txtsearch").blur();
	
	}
	
	</script>
	
</body>
</html>