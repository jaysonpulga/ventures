<?php
session_start();
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Requisition</title>
<head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
.ui-dialog-title{
	text-align:left;
}
</style>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link rel="stylesheet" href="../css/jPages.css" type="text/css" media="screen">
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	 <script src="../js/jPages.js" type="text/javascript" ></script>
	<script type="text/javascript" src=""></script>
	<script src="../js/FormatNUmberBy3.js" type="text/javascript"></script>
</head>
<body>

<input type="hidden" id="branch_id" value="<?php echo $_SESSION['branch_id']; ?>" >
<input type="hidden" id="branch_name" value="<?php echo $_SESSION['branch_name']; ?>" >
<input type="hidden" id="branch_code" value="<?php echo $_SESSION['branch_code']; ?>" >

	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<div>
						<table width="800px">
							<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2 style="margin-top:10px;">STOCK REQUISITION</h2>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
							<form name="search" action="" method="POST">
									<select id = 'category' name='category'>
										<option value="a.sr_no">S.R NO</option>
									<option value="a.date">DATE</option>
									</select>
										<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Report">
										<input type="button" value="Create New" id='input' style="width:100px;top:1px;" onClick="add_new();">
							</form>
							</td>
							</tr>
						</table>
					</div>
					
										
					<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:800px" cellspacing="0">
						<table  align="center" id="table">
						<thead>
							<tr>
							<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'a.sr_no')">S.R. NO.</a></th>
							<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'a.date')">DATE</a></th>
							<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'quantity')">TOTAL QTY</a></th>
							<th><a href = "#" class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'total_amt')">TOTAL AMOUNT</a></th>
							<th colspan="2">ACTION</th></tr>
						</thead>	
							<tbody id="alldata"></tbody>
						</table>
					</div>
					
				<div align="right" style="margin-top:50px">
					<div>
						<div id="new_items" title="ADD UNIT " style="display:none;">
							<iframe id="item_dialog" width="370" height="270" style="border:none"></iframe>
						</div>
					</div>
					<div id="pagination" style="top:-50px;"> 
						<div class="holder" ></div>
						<div style='font-size:11px;margin-top:5px;' align='center'><i>Pages</i></div>
					</div>
				</div>		
					
						
							
		</div>	

	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="management#"){
				menu="management";
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadData("ASC","a.sr_no");	
	});
	
	  var branch_id = $("#branch_id").val();
	  var branch_name = $("#branch_name").val();
	  var branch_code = $("#branch_code").val();
	
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
	var sortType = "ASC";
	function filter_list(index,sorts){
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadData(sortType,sorts);			
	}
	
	$("#txtsearch").live('keyup change',function(){
		$("#table > tbody").empty();
		loadData("ASC","a.sr_no");				
	})

	function loadData(sortType,sort){
	var count=0,x=0;	
	var container=$("#table > tbody");
	
		$.ajax({
					url:"function_items.php",
					data:{"request":"ajax","action":"load_requisition","inputsearch":$("#txtsearch").val(),"category":$("#category").val(),"sort":sort,"sortType":sortType,"branch_code":branch_code},
					dataType:'json',
					beforeSend: function(){
						
					},
			success: function(reply){
							//console.log(reply.length);
				if(reply.length > 0){
					container.empty();
							$.each(reply, function(i,res){
								count++;
								
						container.append("<tr class='x' id='record"+res.sr_no+"' onmouseover='clickSearch()' > </td><input type='hidden' name='brand"+res.sr_no+"' id='brand"+res.sr_no+"' value='"+res.brand+"' /><td align='center'>"+res.sr_no+"</td><td align='center'>"+res.date+"</td><td align='center'>"+(Math.round(res.quantity)).toFixed()+"</td><td style='text-align:right;' align='right'>"+FormatNumberBy3((Math.round(res.total_amt)).toFixed(2))+"</td><td align='center'><a href='#' alt='Update' title='Update' class='edit' onclick=\"edit('"+res.sr_no+"');\"></a></td><td align='center'><a href='#' alt='Update' title='Delete' class='delete' onclick=\"delete_stock('"+res.sr_no+"');\"></a></td></tr>");
																
				});
				jpages();
				}
				else{
					
				container.append("<tr id = 'noItems'><th colspan = '13' align = 'center'> No Items on record! </th></tr>");
				}
			}
		});

	}
	
	function Nexturl(actions,link){
		
		if(actions=="add"){
			jAlert("successfully Added");
		}
		$('#new_items').dialog('close');
		window.location = link;
		return false;
	}
	
	function closeIframe(actions){
		if(actions=="add"){
			jAlert("successfully Added");
		}
		else if(actions=="edit"){
			jAlert("Successfully Updated");
		}
		else if(actions=="cancel"){
			$('#new_items').dialog('close');
		}
		$('#new_items').dialog('close');
		 loadData();
		return false;
	}
		
	function add_new(){
			$("#new_items").attr("title","Create Stock Requisition" );
			$("#item_dialog").attr('src','../managements/addRequisition.php');
			$("#new_items").dialog({
				width:370,
				height: 320,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
			
	}
	
	
	function edit(id){
		window.location = "addStock.php?sr_no="+id+"&menu=management"
	}
	
	function delete_stock(id){
			jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
			if(e){
			
				var table1 =  "tbl_requisition";
				var table2 =  "tbl_stock_requisition";
				$.ajax({
					url: "function_items.php",
					data:{"request":"ajax","action":"deleteTwotable","id":id,"table1":table1,"table2":table2,"table_id":"sr_no"},
					success: function(reply){

					}
				});
				
				$('#record'+id).animate({ backgroundColor: '#fbc7c7' }, 'fast')
			.animate({ opacity: "hide" }, "slow");
				
			jAlert("successfully Deleted");
		
			}
		
		});
	}
	
	function jpages(){
			$("div.holder").jPages({
			  containerID : "alldata",
			   previous : "←",
				next : "→",
			  perPage : 10,
			  delay :10,
			  startPage    : 1,
			  startRange   : 1,
			  midRange     : 5,
			  endRange     : 1
			});
		}
	
	function clickSearch() {
	
		$("#txtsearch").blur();
	
	}
		
	
	</script>
	
</body>
</html>