<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<!DOCTYPE HTML>
<html lang="en">
<title>Supplier</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="../css/jPages.css" rel="stylesheet" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script src="../js/jPages.js" type="text/javascript"></script>
	
	<script type="text/javascript" src=""></script>
</head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
</style>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
			<div id="main" align="center">
				<div id="options-top" align="center" style="width:100%;">
					<table width="900px">
						<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2 style="margin-top:10px;">SUPPLIER</h2>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
							<form name="search" action="" method="POST">
									<select id = 'category' name='category'>
										<option value = "supplier_name">Supplier</option>
										<option value = "province_id">Province</option>
										<option value = "contact_person">Contact Person</option>
									</select>
										<input type="search" name="txtsearch" id="txtsearch" placeholder="Search">
										<input type="button" value="ADD NEW" id='input' style="width:100px;top:1px;" onclick="add_supplier();">
							</form>
							</td>
						</tr>
					</table>
				</div>
					
										
					<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:900px" cellspacing="0">
						<table id="supplier_list" border=1 align = "center">

							<thead align="center">
							<tr>
								<th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'a.supplier_name')">SUPPLIER</a></th><th>ADDRESS</th><th>CONTACT #</th><th><a href="#" style = "color: #FFF;" onclick = "filter_list(0,'a.contact_person')">CONTACT PERSON</a></th><th colspan = "2">ACTION</th>
							</tr>
							</thead>
							
							<tbody id="supplier_data"></tbody>
							
						</table>
					</div>
					
					<div id="pagination"> 
						<div class="holder" style = "margin-top: 50px;"></div>
						<i>Pages</i>
					</div>
					
					<div id="add_items" title="" style="display:none;">
					<iframe id="item_dialog" width="900" height="330" style="border:none"></iframe>
					</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	
	function jpages(){
		$("div.holder").jPages({
		  containerID : "supplier_data",
		  previous : "←",
		  next : "→",
		  perPage : 5,
		  delay :10,
		  startPage    : 1,
		  startRange   : 1,
		  midRange     : 5,
		  endRange     : 1
		});
	}
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
				
	var sortType = "ASC";
	
	function filter_list(index,cVar){
		sort = cVar;
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadData(sort,sortType);
	}
	
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		if(menu=="management#"){
			menu="management";
		}
		else{
			menu = getUrlVars()["menu"];	
		}
		
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});
		
		loadData("a.id","DESC");
		
	});
	
	
	$("#txtsearch").live('keyup change',function(){
		$("#supplier_list > tbody").empty();
		loadData("a.id","DESC");				
	})
	
	function loadData(sort,sortType){
		$("#supplier_list > tbody").empty();
		
		var url="functions.php?request=ajax&action=viewSupplierData&sort="+sort+"&sortType="+sortType+"&inputsearch="+$("#txtsearch").val()+"&category="+$("#category").val();
		var counter=0;
		
		$.getJSON(url,function(data){
			$.each(data.members, function(i,res){
				 
				$("#supplier_list > tbody").append("<tr class = 'x' onmouseover='clickSearch()'><td>"+res.supplier_name+"</td><td>"+res.street_num+", "+res.subd_brgy+", "+res.city_name+", "+res.province_name+"</td><td>"+res.telephone_number+"</td><td>"+res.contact_person+"</td><td><a href='#' class='edit' title='EDIT link' onclick=\"edit_supplier("+res.id+",'"+res.supplier_name+"')\"></a></td><td><a href='#' class='delete' title='DELETE link' onclick=delete_supplier("+res.id+")></a></td></tr>");
				counter++;
			});
			if (counter <= 0){
				$("#supplier_list > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
			}
			jpages();
		});
	}
	
	function add_supplier(){
		$("#add_items").attr("title","ADD SUPPLIER");
		$("#item_dialog").attr('src','addSupplier.php');
		$("#add_items").dialog({
			width: 905,
			height:380,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src',"about:blank");
				window.location.reload();
			}
		});
		return false;
	}
	
	function edit_supplier(id,name){

		$("#add_items").attr('title', "Edit Info");
		$("#item_dialog").attr('src', "editSupplier.php?supplier_id="+id+"&supplier_name="+name);
		$("#add_items").dialog({
			width: 905,
			height:380,
			modal: true,
			resizable:false,
			close: function () {
				$("#item_dialog").attr('src', "about:blank");
				window.location="supplier.php?menu=management";
			},
		});
		return false;
	}

	function delete_supplier(id){

		jConfirm('Do you really want to DELETE this SUPPLIER?','Confirmation Dialog',function(e){
			if(e){
				$.ajax({
					url: "functions.php",
					data:{"request":"ajax","action":"delete_supplier","id":id},
					success: function(reply){
						console.log(reply);
							if(reply == 'deleted'){
								jAlert('Supplier Deleted','Alert Dialog');
								loadData();
							}else{
								jAlert('Error','Alert Dialog');
								event.preventDefault();
							}
						
						}
				});
			}
		});

	}

	function closeIframe(action,id) {
		if (action=="add") {
			jAlert('Data was successfully Saved!');
		}
		
		else if (action=="edit") {
			jAlert('Data was successfully Updated!');
			window.location="supplier.php?menu=management";
		}
		else {
			
		}
		$("#add_items").dialog('close');
		loadData();
	}
	
	function clickSearch() {
	
		$("#txtsearch").blur();
	
	}

	/* $("#txtsearch").blur(function(){
		$(this).val("");
	});

	$("#txtsearch").bind('keyup change',function(){
		var url ="functions.php?request=ajax&action=searchSupplier&inputsearch="+$(this).val()+"&category="+$('#category').val();
		var counter=0;
			if($(this).val().trim() != ""){
		
				$("#supplier_list > tbody").empty();
				
				$.getJSON(url,function(data){
					$.each(data.members, function(i,res){
						 
						$("#supplier_list > tbody").append("<tr class = 'x' onmouseover = 'clickSearch();'><td>"+res.supplier_name+"</td><td>"+res.street_num+", "+res.subd_brgy+", "+res.city_name+", "+res.province_name+"</td><td>"+res.telephone_number+"</td><td>"+res.contact_person+"</td><td><a href='#' class='edit' title='EDIT link' onclick=\"edit_supplier("+res.id+",'"+res.supplier_name+"')\"></a></td><td><a href='#' class='delete' title='DELETE link' onclick=delete_supplier("+res.id+")></a></td></tr>");
						counter++;
					});
					if (counter <= 0){
						$("#supplier_list > tbody").append("<tr id = 'noItems'><th colspan = '7' align = 'center'> No Items on record! </th></tr>");
					}
					jpages();
				});
			}
			else{
				$("#supplier_list > tbody").empty();
				loadData();
			}
	}) */
	
	</script>
	
</body>
</html>