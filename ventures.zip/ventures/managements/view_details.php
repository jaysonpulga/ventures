<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Manufacturer</title>
<head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
.ui-dialog-title{
	text-align:left;
}
</style>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
   
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" /> 
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	
    <link rel="stylesheet" href="../css/jPages.css" type="text/css" media="screen">
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
    <script src="../js/jPages.js" type="text/javascript" ></script>
	<script src="../js/FormatNUmberBy3.js" type="text/javascript"></script>
    
     <link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
		<div id="main" align="center">
				<div id="options-top" align="center" style="width:780px;">
					<div>
						<table width="780px">
							<tr>
								<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
								<h2 style="margin-top:10px;"><?php echo strtoupper($_REQUEST['brand']); ?></h2>
								</td>
								<td style="text-align:right;background:#FFF;padding:0px;border:none">
								<form name="search" action="" method="POST">
								<input type="hidden" value = "<?php echo $_REQUEST['brand']; ?>" name="brandx" id="brandx" />
								
								<select id = 'category' name='category'>
									<option value="model">MODEL</option>
									<option value="engine_type">ENGINE TYPE</option>
									<option value="displacement">DISPLACEMENT</option>
									<option value="oil_capacity">OIL CAPACITY</option>
								</select>
									<input type="search" name="txtsearch" id="txtsearch" placeholder="Search Category">
									<input type="button" value="ADD UNIT" id='input' style="width:110px;" onClick="add_unit();">
									</form>
								</td>
							</tr>
						</table>
					</div>
					
					<div  class="contents" style="border:0px solid #000; margin-top:-10px; width:780px" cellspacing="0">
						<table   align="center" id="table">
						<input type="hidden"  value="<?php echo $_REQUEST['id']; ?>" name="brand" id="brand" >
							<thead>
							<tr>
							<th><a href = "#"   class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'model')">MODEL</a></th>
							<th><a href = "#"   class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'engine_type')">ENGINE TYPE</a></th>
							<th><a href = "#"   class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'displacement')">DISPLACEMENT</a></th>
							<th><a href = "#"   class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'oil_capacity')">OIL CAPACITY</a></th>
							<th><a href = "#"   class = "table_title" style='text-decoration:none;' onclick = "filter_list(1,'unit_cost')">UNIT COST</a></th>
							<th colspan="2">ACTION</th></tr>
							</thead>
							<tbody id="alldata"></tbody>
						</table>
					</div>	
					<div align="right" style="margin-top:10px">
						<input type="button" value="CANCEL" onClick="cancel(); ">
					<div>
					<div id="new_items" title="ADD UNIT " style="display:none;">
					<iframe id="item_dialog" width="380" height="300" style="border:none"></iframe>
					</div>
				</div>
                <div id="pagination" style="top:-50px;"> 
						<div class="holder" ></div>
						<div style='font-size:11px;margin-top:5px;' align='center'><i>Pages</i></div>
				</div>
			</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
<script>
$(document).ready(function(){
	var menu = getUrlVars()["menu"];
	
		if(menu=="management#"){
				menu="management";
		}
	
	$("."+menu).attr("class",menu+"-active");
	
	$("."+menu+"-active a").css({
	"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
	"padding":"30px 10px 0px 10px",
	"border-bottom":"4px solid #c95447"
	});
	loadData("ASC","model");	
});	
	
	
	var filter = 1;
	var display_result = [0,0,0,0,0];
	var sortType = "ASC";
	function filter_list(index,sorts){
		display_result[index] = display_result[index] == 0 ? 1 : 0;
		sortType = display_result[index] == 0 ? "ASC" : "DESC";
		loadData(sortType,sorts);			
	}

	var brand=$('#brand').val();
	var brandx=$('#brandx').val();

	
	$("#txtsearch").live('keyup change',function(){
		$("#table > tbody").empty();
		loadData("ASC","model");				
	});	

	function loadData(sortType,sort){
    		
	var count=0,x=0;	
	var container=$("#table > tbody");
		
		$.ajax({
			url:"function_items.php",
			data:{"request":"ajax","action":"load_details","brand":brand,"inputsearch":$("#txtsearch").val(),"category":$("#category").val(),"sort":sort,"sortType":sortType},
			dataType:'json',
			beforeSend: function(){
				
		},
			success: function(reply){
				//console.log(reply.length);
				if(reply.length > 0){
					container.empty();
						$.each(reply, function(i,res){
						 count++;
								
							container.append("<tr class='x' id='record"+res.motor_id+"' onmouseover='clickSearch()'></td><input type='hidden' name='cat"+res.motor_id+"' id='cat"+res.motor_id+"' value='"+res.brand+"' /><td align='center'>"+res.model+"</td><td align='center'>"+res.engine_type+"</td><td align='center'>"+res.displacement+"</td></td><td style='text-align:right;' >"+res.oil_capacity+"</td><td align='center'>"+FormatNumberBy3((Math.round(res.unit_cost)).toFixed(2))+"</td><td align='center'><a href='#' alt='Update' title='Update' class='edit' onclick='edit_unit("+res.motor_id+");'></a></td><td align='center'><a href='#' alt='Delete' title='DELETE' class='delete' onclick='deleteUnit("+res.motor_id+");'></a></td></tr>");
																	
						});
				jpages();
				}
				else{
					
					container.empty().append("<tr id = 'noItems'><th colspan = '13' align = 'center'> No Items on record! </th></tr>");
				}
			}
		});

	}
	
	function add_unit(){
		
			$("#item_dialog").attr('src','../managements/addUnit.php?brand='+brand+"&name="+brandx);
			$("#new_items").dialog({
				width:381,
				height: 350,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
	}
	
	function edit_unit(id){
	
			document.getElementById('new_items').title = 'EDIT UNIT';
			var brandx=$('#brandx').val();
			var brand=$('#brand').val();
			$("#item_dialog").attr('src','../managements/addUnit.php?status=update&brand='+brand+'&name='+brandx+'&motor_id='+id);
				$("#new_items").dialog({
						width: 381,
						height: 350,
						modal: true,
						resizable:false,
						close: function () {
							$("#item_dialog").attr('src', "about:blank");
							window.location.reload();
						//window.location='view_details.php?brand='+brandx+'&id='+brand+'&menu=management';
						}
				});
					return false;
	}
	
	
	
	
	function closeIframe(actions){
			
			if(actions=="add"){
				jAlert("Successfully Added");
			}
			else if(actions=="edit"){
				jAlert("Successfully Updated");
			}
			$('#new_items').dialog('close');
			 loadData();
			return false;
	}
	
	function cancel(){
			window.location = "itemsMotorcycle.php?category=motorcycle&menu=management";
	}
	
	function deleteUnit(id){

		jConfirm('Do you really want to DELETE this ITEM ?','Confirmation Dialog',function(e){	
			
			if(e){
				$.ajax({
				url: "function_items.php",
				data:{"request":"ajax","action":"deleteSingleItem","id":id,"table_name":"tbl_motorcycle","table_id":"motor_id"},
				success: function(reply){
				
				$('#record'+id).animate({ backgroundColor: '#fbc7c7' }, 'fast')
				.animate({ opacity: "hide" }, "slow");
				
				jAlert("Successfully Deleted");
				
				}
				});
					
				
			}
		
		});
	
	}
	
	function jpages(){
			$("div.holder").jPages({
			  containerID : "alldata",
			   previous : "←",
			  next : "→",
			  perPage : 10,
			  delay :10,
			  startPage    : 1,
			  startRange   : 1,
			  midRange     : 5,
			  endRange     : 1
			});
		}
		
	function clickSearch() {
	
		$("#txtsearch").blur();
	
	}
		
		
	</script>
	
</body>
</html>