<html>
<title>MOTORCYCLE STOCKS</title>
</html>
<?php
include('../database.php');  
$db = new Database();  
$db->connect(); 

	$dataArray=array();
	$sr_no=$_REQUEST["sr_no"];
	$row = "a.sr_no,a.date,a.sold,b.branch_name";
	$where="a.sr_no= '$sr_no' and a.branch_code = b.branch_code";

	$db->select('tbl_requisition a,tbl_branch b',$row,$where);

	$result = $db->getResult();
	
	foreach($result as $key){		

		
		 $sr_no=$key["sr_no"];
		 $date=$key["date"];
		 $sold=$key["sold"];
		 $branch_name=$key["branch_name"];
	}
	
	
	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$sr_no = $_REQUEST['sr_no'];
	
	$where = "sr_no='$sr_no'";
	$db->select("tbl_stock_requisition","*",$where);
	$result = $db->getResult();
	
	foreach($result as $key){
		 $category=$key["category"];
		 $sr_no=$key["sr_no"];
		 
		if($category == '1'){
		 
			
			$row = "a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.model";
			$table = "tbl_stock_requisition a,tbl_manufacturer b, tbl_motorcycle c";
			
			$where = "a.brand = b.id and a.item = c.motor_id and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray=$result;
			
			
		 }else if($category == '2'){

			$row = "a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.item_code";
			$table = "tbl_stock_requisition a,tbl_manufacturer b, tbl_parts c";
			
			$where = "a.brand = b.id and a.item = c.parts_id and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray2=$result;
		   
		 
		 }
		 else if($category == '3'){
			
			
			$row = "a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.item_code";
			$table = "tbl_stock_requisition a,tbl_manufacturer b, tbl_promo c";
			
			$where = "a.brand = b.id and a.item = c.promo_id and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray3=$result;
		  
		 }
		 else if($category == '4'){
			
			
			$row = "a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.item_code";
			$table = "tbl_stock_requisition a,tbl_manufacturer b,tbl_consumables c";
			
			$where = "a.brand = b.id and a.item = c.con_id and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray4=$result;
		   
		 }
		
		$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4);
	}
	
	
	if(!empty($output)){
	
	
		$i=0;
		foreach($output as $key2){
			
			
			 if($key2['category'] =='1'){	
			 
			 $particulars = $key2["brand"]." - ".$key2["model"]." - ".$key2["color"];
			
			 
			 }else if ($key2['category'] !='1'){
			 
			  $particulars=$key2["brand"]." - ".$key2["item_code"];
			  
			 }
			 
			
			$qty = $key2["quantity"];
			$cost = $key2["unit_cost"];
			
			
			
			
			$total = $qty * $cost;
			
			$item_details_arr[$i]=array(
				'particulars'=> $particulars,
				'quantity'=> $qty ,
				'unit_cost'=>$cost ,
				'total'=> $total ,
			);
			$i++;
		}
	}
	
	


echo" 
	<div align='center' style='font-family:Calibri'>
	<table border=0 width='1000' cellpadding=2 cellspacing=0>
		
		<tr>
		<td><b>S.R. No. :</b> $sr_no</td>
		<td align='right' colspan=4><b>Date:</b> $date</td>
		</tr>
		
		<tr>
		<td><b>TO:</b> $sold</td>
		<td align='right' colspan=4><b>Branch:</b> $branch_name</td>
		</tr>
		
		<tr>
		<td colspan=5 align='center' style='padding:25px 0px 10px 0px;border-bottom:2px solid #000'>
		<b>STOCKS DETAILS</b></td>
		</tr>
		
		<tr style='padding:20px 0px 10px 0px;border-bottom:2px solid #000'>
		<td align='center' width='35%' ><b>PARTICULARS</b></td>
		<td align='center' width='20%' ><b>QUANTITY</b></td>
		<td align='center' width='20%' ><b>UNIT COST</b></td>
		<td align='center' width='25%' ><b>AMOUNT</b></td>
		</tr>
		
		<tr>
		<td colspan=5 style='padding:0px 0px 5px 0px;border-bottom:2px solid #000'>
		</tr>";
		
		
		if(count($item_details_arr)>0){
		 $totalqty = 0;
		 $total_amt = 0;

		 foreach($item_details_arr as $keyx){
		
			echo "<tr style='padding:5px 0px 5px 0px;' >
			<td align='center'  >".strtoUpper($keyx['particulars'])."</td>
			<td align='center'  >".$keyx['quantity']."</td>
			<td align='center'  >".number_format((float)$keyx['unit_cost'], 2, '.', '')."</td>
			<td align='center'  >".number_format((float)$keyx['total'], 2, '.', '')."</td>
			</tr>";
			
			$totalqty += $keyx["quantity"];
			$total_amt += $keyx["quantity"] * $keyx["unit_cost"];
		
		 }
	}
	else{
		echo "<tr align='center'><td colspan=5  style='padding:20px 0px 5px 0px;'>*** NO ITEMS TO DISPLAY ***</td></tr>";
	}
	echo "<tr><td colspan=5 align='center' style='padding:0px 0px 5px 0px;border-bottom:2px solid #000'></td></tr>";
	
	
	
		echo "<tr><td colspan=4 align='left'  ><b>TOTAL QTY:</b> &nbsp;" .$totalqty."</td></tr>";
		echo "<tr><td colspan=4 align='left'  ><b>TOTAL AMT:</b> &nbsp;".number_format((float)$total_amt, 2, '.', '')."</td></tr>";
	
	echo "</table></div>";		
?>