<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
<form  name="frm"  method="POST">
<input type="hidden" id="brand" value="<?php echo $_REQUEST['brand']; ?>" name="brand" >
<input type="hidden" id="motor_id" value="<?php echo $_REQUEST['motor_id']; ?>" name="motor_id" >
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px;">
				<div style="margin-top:10px;">
					<span>
						<label>Manufacturer:</label>
						<input type="text"  value = "<?php echo $_REQUEST['name'] ;?>" style="margin-left:23px;text-align:center;" readonly>
					</span>
				</div>
				<div>
					<span>
						<label>Model:</label>
						<input type="text" id="Model" name="Model"  style="margin-left:67px">
					</span>
				</div>
				<div>
					<span>
						<label>Engine Type:</label>
						<input type="text" id="Engine" name="Engine" style="margin-left:32px">
					</span>
				</div>
				<div>
					<span>
						<label>Displacement(cc):</label>
						<input type="text"id="Displacement" name="Displacement"  >
					</span>
				</div>
				<div>
					<span>
						<label>Oil Capacity:</label>
						<input type="text" style="margin-left:34px"  id="Oil" name="Oil" >
					</span>
				</div>
				<div>
					<span>
						<label>Unit Cost:</label>
						<input type="text" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')" style="margin-left:50px"  id="unit_cost" name="unit_cost">
					</span>
				</div>
				<div align="center">
					<span><br>
					<?php
						if($_REQUEST['status'] =="update"){
					     echo '<input type="button" value="UPDATE" onClick="update_unit(this)" >';
						
						}else{
							echo '<input type="button" value="ADD" onClick="save_unit(this)" >';
						}
						?>
					<input type="button" value="CANCEL" onClick="Cancel();">
					</span>
				</div>
			</div>
		</div>
	</div>

	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		 loadData();
	});	
	function save_unit(obj){
	event.preventDefault();
	
	var brand = $('#brand').val();
	var Model = $('#Model').val();
	var Engine = $('#Engine').val();
	var Displacement = $('#Displacement').val();
	var Oil = $('#Oil').val();
	var unit_cost = $('#unit_cost').val();
	var errormsg="Please complete the following fields: \n";
	var emsg= errormsg.length;

		if(Model == ""){
			errormsg+="-Model\n";
			
		}
		if(Engine == ""){
			errormsg+="-Engine Type\n";
			
		}
		if(Displacement == ""){
			errormsg+="-Displacement\n";
			
		}
		if(Oil == ""){
			errormsg+="-Oil Capacity";
			
		}
		if(errormsg.length== emsg){
		
		
	$.ajax({
		
		       url: "function_items.php",
				data:{"request":"ajax","action":"add_unit","brand":brand,"Model":Model,"Engine":Engine,"Displacement":Displacement,"Oil":Oil,"unit_cost":unit_cost},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){	
							var actions="add";
							window.parent.closeIframe(actions);
						}else if(reply == 'duplicate'){
						 jAlert("The Model: "+Model+ " is already exist in database!","Alert Dialog");
						
						}else{
							jAlert("cannot add information","Alert Dialog");
						}
					
					}
		
		
		
		});
		
		}else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
		
	}
	

var motor_id=$('#motor_id').val();	
		
		function loadData(){
			
			var url="function_items.php?request=ajax&action=load_motor&motor_id="+motor_id;
			var counter=1;
		
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){
					$('#o_id').val(res.motor_id);
					$('#Model').val(res.model);
					$('#Engine').val(res.engine_type);
					$('#Displacement').val(res.displacement);
					$('#Oil').val(res.oil_capacity);
					$('#unit_cost').val(res.unit_cost);
					
	
				});	
			});
			
		}


		
		function update_unit(obj){
		event.preventDefault();
		
		
		var Model = $('#Model').val();
		var Engine = $('#Engine').val();
		var Displacement = $('#Displacement').val();
		var Oil = $('#Oil').val();
		var unit_cost = $('#unit_cost').val();
		var errormsg="Please complete the following fields: \n";
		var emsg= errormsg.length;

		if(Model == ""){
			errormsg+="-Model\n";
			
		}
		if(Engine == ""){
			errormsg+="-Engine Type\n";
			
		}
		if(Displacement == ""){
			errormsg+="-Displacement\n";
			
		}
		if(Oil == ""){
			errormsg+="-Oil Capacity";
			
		}
		if(errormsg.length== emsg){
		
		$.ajax({
			url: "function_items.php",
			data:{"request":"ajax","action":"updateUnit","motor_id":motor_id,"Model":Model,"Engine":Engine,"Displacement":Displacement,"Oil":Oil,"unit_cost":unit_cost},
				success: function(reply){
					console.log(reply);
						if(reply == 'updated'){
						    	
							var actions="edit";
							window.parent.closeIframe(actions);
							
						}else{
							jAlert("cannot update information","Alert Dialog");
					
					}
				}
			
			   });
				
		}
		
		else{
			jAlert(errormsg,"Alert Dialog");
			event.preventDefault();
		}
				
		}
		
		function Cancel(){
		var action = "cancel";
	window.parent.closeIframe(action);
}
	</script>
	
</body>
</html>