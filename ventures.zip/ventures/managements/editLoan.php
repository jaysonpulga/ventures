<html>
<title>Sales</title>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px; margin-left:15px;" >
			
			<input type = "hidden" name = "loan_id" id = "loanid" value = "<?php echo $_REQUEST["loan_id"]; ?>">
			<input type = "hidden" name = "loan_type" id = "loantype" value = "<?php echo $_REQUEST["loan_type"]; ?>">
			
						<div style="margin-top:10px">
							<span>
								<label>Type of Loan:</label>
								<input type="text" id = "txtloan" style="margin-left:48px">
								</select>
							</span>
						</div>
						<div>
							<span>
								<label>Method:</label>
								<select name = "brand" id = "txtmethod" style = "margin-left:77px;">
									<option value = "">- SELECT -</option>
									<option value = "Flat">Flat</option>
									<option value = "Diminishing">Diminishing</option>
								</select>
							</span>
						</div>
						<div  class="contents" style="border:0px solid #000; width:350px" cellspacing="0">	
							<table id="loan_list" border=1 align = "center">

								<thead align="center">
								<tr>
									<th style = "width:50px;">TERMS<br>(MONTHS)</th><th>INTEREST<br>(DECIMAL)</th>
								</tr>
								</thead>
								
								<tbody id="loan_data">
									<tr>
										<td style = "width:10px;">3</td><td><input type = "text" id = "txtinterest3" style = "width:100px; text-align:right" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')"></td>
									</tr>
									<tr>
										<td>6</td><td><input type = "text" id = "txtinterest6" style = "width:100px; text-align:right" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')"></td>
									</tr>
									<tr>
										<td>9</td><td><input type = "text" id = "txtinterest9" style = "width:100px; text-align:right" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')"></td>
									</tr>
									<tr>
										<td>12</td><td><input type = "text" id = "txtinterest12" style = "width:100px; text-align:right" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')"></td>
									</tr>
									<tr>
										<td>15</td><td><input type = "text" id = "txtinterest15" style = "width:100px; text-align:right" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')"></td>
									</tr>
									<tr>
										<td>18</td><td><input type = "text" id = "txtinterest18" style = "width:100px; text-align:right" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')"></td>
									</tr>
									<tr>
										<td>21</td><td><input type = "text" id = "txtinterest21" style = "width:100px; text-align:right" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')"></td>
									</tr>
									<tr>
										<td>24</td><td><input type = "text" id = "txtinterest24" style = "width:100px; text-align:right" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')"></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div style = "margin-top:5px;">
							<span>
								<label>Penalty Interest %:</label>
								<input type="text" id = "txtpenalty" style="margin-left:13px; text-align:right;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
							</span>
						</div>
						<div style = "margin-top:10px;">
							<span>
								<label><h3>FINANCE CHARGES</h3></label>
							</span>
						</div>
						<div>
							<span>
								<label>Mortgage Fee:</label>
								<input type="text" id = "txtmortfee" style="margin-left:41px; text-align:right;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
							</span>
						</div>
						<div>
							<span>
								<label style = "margin-left:143px; font-size:12px;">Percentage</label>
								<label style = "margin-left:35px; font-size:12px;">Amount</label>
							</span>
						</div>
						<div>
							<span>
								<label>Filing Fee:</label>
								<input type="text" id = "txtfpercent" style="margin-left:66px; text-align:right; width:80px;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
								<input type="text" id = "txtfamount" style="margin-left:6px; text-align:right; width:80px;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
							</span>
						</div>
						<div>
							<span>
								<label>Notary Fee:</label>
							</span>
						</div>
						<div>
							<span>
								<label style = "margin-left:51px;">New</label>
								<input type="text" id = "txtnotnew" style="margin-left:50px; text-align:right;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
							</span>
						</div>
						<div>
							<span>
								<label style = "margin-left:51px;">Old</label>
								<input type="text" id = "txtnotold" style="margin-left:57px; text-align:right;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
							</span>
						</div>
						<div>
							<span>
								<label>Doc Stamp:</label>
								<input type="text" id = "txtdocstamp" style="margin-left:61px; text-align:right;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
							</span>
						</div>
						<div>
							<span>
								<label>Inspection Fee:</label>
							</span>
						</div>
						<div>
							<span>
								<label style = "margin-left:51px;">New</label>
								<input type="text" id = "txtinspectionnew" style="margin-left:50px; text-align:right;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
							</span>
						</div>
						<div>
							<span>
								<label style = "margin-left:51px;">Old</label>
								<input type="text" id = "txtinspectionold" style="margin-left:57px; text-align:right;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
							</span>
						</div>
						<div>
							<span>
								<label>Insurance Fee:</label>
								<input type="text" id = "txtinfee" style="margin-left:40px; text-align:right;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
							</span>
						</div>
						<div>
							<span>
								<label>Others:</label>
								<input type="text" id = "txtothers" style="margin-left:84px; text-align:right;" onkeyup="javascript:this.value = this.value.replace(/[^0-9,.]/, '')">
							</span>
						</div>
						<div align="center" style="margin-top:15px">
							<span>
								<input type="button" value="SAVE" onclick = "Update();">
								<input type="button" value="CANCEL" onclick = "window.parent.closeIframe('cancel');">
							</span>
						</div>
			</div>
		<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
		$(document).ready(function(){
			var menu = getUrlVars()["menu"];
		
			$("."+menu).attr("class",menu+"-active");
			
			$("."+menu+"-active a").css({
			"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
			"padding":"30px 12px 0px 12px",
			"border-bottom":"4px solid #c95447"
			});
			
			loadBody();
			
		});
		
		function loadBody() {
			var uid=$("#loanid").val();
			var url="functions.php?request=ajax&action=viewLoanUpdate&loan_id="+uid;
			var filing_fee;
			var percent;
			var method;
			
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){
				
					$('#loanid').val(res.id);
					$('#txtloan').val(res.loan_type);
					method=res.method;
					$('#txtmethod option[value="'+method+'"]').attr('selected', 'selected');
					$('#txtinterest3').val(res.interest_rate_3);
					$('#txtinterest6').val(res.interest_rate_6);
					$('#txtinterest9').val(res.interest_rate_9);
					$('#txtinterest12').val(res.interest_rate_12);
					$('#txtinterest15').val(res.interest_rate_15);
					$('#txtinterest18').val(res.interest_rate_18);
					$('#txtinterest21').val(res.interest_rate_21);
					$('#txtinterest24').val(res.interest_rate_24);
					$('#txtpenalty').val(res.penalty_interest);
					$('#txtmortfee').val(res.mortgage_fee);
					$('#txtinfee').val(res.insurance_fee);
					$('#txtnotnew').val(res.notarial_fee_new);
					$('#txtnotold').val(res.notarial_fee_old);
					filing_fee = res.filing_fee_percent;
					percent = filing_fee*100;
					$('#txtfpercent').val(percent);
					$('#txtfamount').val(res.filing_amount);
					$('#txtdocstamp').val(res.doc_stamp);
					$('#txtinspectionnew').val(res.inspection_fee_new);
					$('#txtinspectionold').val(res.inspection_fee_old);
					$('#txtothers').val(res.others);
				
				});
				
			});

		}

		function Update(){
				
			var loan_id=$("#loanid").val();
			var type=$("#loantype").val();
			var loan_type=$("#txtloan").val();
			var method=$("#txtmethod :selected").val();
			var interest3=$("#txtinterest3").val();
			var interest6=$("#txtinterest6").val();
			var interest9=$("#txtinterest9").val();
			var interest12=$("#txtinterest12").val();
			var interest15=$("#txtinterest15").val();
			var interest18=$("#txtinterest18").val();
			var interest21=$("#txtinterest21").val();
			var interest24=$("#txtinterest24").val();
			var penalty=$("#txtpenalty").val();
			var mortgage=$("#txtmortfee").val();
			var insurance=$("#txtinfee").val();
			var notary_new=$("#txtnotnew").val();
			var notary_old=$("#txtnotold").val();
			var filing_percent=$("#txtfpercent").val();
			var filing_amount=$("#txtfamount").val();
			var docstamp=$("#txtdocstamp").val();
			var inspection_new=$("#txtinspectionnew").val();
			var inspection_old=$("#txtinspectionold").val();
			var others=$("#txtothers").val();
			
			var percent = filing_percent/100;
			
			var errormsg="Please complete the following fields: \n",emsg= errormsg.length,form_cont=$("#item_form");
			
			if(loan_type == ""){
				errormsg+="- Input Type of Loan.\n";
			}
			if(method == ""){
				errormsg+="- Select Method.\n";
			}
			if(penalty == ""){
				errormsg+="- Input Penalty Fee.\n";
			}
			if(mortgage == ""){
				errormsg+="- Input Mortgage Fee.\n";
			}
			if(insurance == ""){
				errormsg+="- Input Insurance Fee.\n";
			}
			if(notary_new == ""){
				errormsg+="- Input Notary Fee(New).\n";
			}
			if(notary_old == ""){
				errormsg+="- Input Notary Fee(Old)\n";
			}
			if(docstamp == ""){
				errormsg+="- Input Docstamp.\n";
			}
			if(inspection_new == ""){
				errormsg+="- Input Inspection Fee(New).\n";
			}
			if(inspection_old == ""){
				errormsg+="- Input Inspection Fee(Old).\n";
			}
			
			if(errormsg.length==emsg){
			
				jConfirm('Do you really want to UPDATE this LOAN?','Confirmation Dialog',function(e){
				
					if(e){
						
						if(type == loan_type) {
						
							$.ajax({
								url: "functions.php",
								data:{"request":"ajax","action":"updateLoanData1","loan_id":loan_id,"loan_type":loan_type,"method":method,"interest3":interest3,"interest6":interest6,"interest9":interest9,"interest12":interest12,"interest15":interest15,"interest18":interest18,"interest21":interest21,"interest24":interest24,"penalty":penalty,"mortgage":mortgage,"insurance_fee":insurance,"notary_new":notary_new,"notary_old":notary_old,"filing_percent":percent,"filing_amount":filing_amount,"docstamp":docstamp,"inspection_new":inspection_new,"inspection_old":inspection_old,"others":others},
								success: function(reply){
									console.log(reply);
										if(reply == 'updated'){
											window.parent.closeIframe('edit',loan_id);
										}
										else{
											jAlert('Error', 'Alert Dialog');
											event.preventDefault();
										}
									
									}
							});
						}
						
						else {
							$.ajax({
								url: "functions.php",
								data:{"request":"ajax","action":"updateLoanData2","loan_id":loan_id,"loan_type":loan_type,"method":method,"interest3":interest3,"interest6":interest6,"interest9":interest9,"interest12":interest12,"interest15":interest15,"interest18":interest18,"interest21":interest21,"interest24":interest24,"penalty":penalty,"mortgage":mortgage,"insurance_fee":insurance,"notary_new":notary_new,"notary_old":notary_old,"filing_percent":percent,"filing_amount":filing_amount,"docstamp":docstamp,"inspection_new":inspection_new,"inspection_old":inspection_old,"others":others},
								success: function(reply){
									console.log(reply);
										if(reply == 'updated'){
											window.parent.closeIframe('edit',loan_id);
										}
										else if(reply == 'exists'){
											jAlert('Loan Type Already Exists!', 'Alert Dialog');
										}
										else{
											jAlert('Error', 'Alert Dialog');
											event.preventDefault();
										}
									
									}
							});
						}
						
					}
				});
				
			}
			
			else{
				jAlert(errormsg,"Alert Dialog");
				event.preventDefault();
			}
			
		}
		
	</script>
	
</body>
</html>