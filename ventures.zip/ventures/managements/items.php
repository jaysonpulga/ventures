<?php
session_start();
if (!isset($_SESSION['username'])){
   header("Location:../index.php");
}

$_SESSION['username'];
$_SESSION['branch_id'];
$_SESSION['branch_name'];
$_SESSION['branch_code'];
?>
<html>
<title>Items</title>
<head>
<style>
.x:nth-child(even) td{
	background:#f8d1d1;
}
.ui-dialog-title{
	text-align:left;
}
</style>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div id="wrapper">
		<?php include '../menu.php'; ?>
		<div id="main" align="center">
			<div id="options-top" align="center" style="width:100%;">
				<table width="500px">
					<tr>
							<td style="text-align:left;background:#FFF;padding:0px;border:none" id="options-top-left">
							<h2>ITEMS</h2>
							</td>
							<td style="text-align:right;background:#FFF;padding:0px;border:none">
							<input type="button" value="ADD NEW" id='input' onclick="add_item();">
							</td>
					<tr>
				</table>
			</div>
			
				<div  class="contents" style="width:500px; margin-top:-10px;" cellspacing="0">
					<table align='center' id="table" >
					<thead><tr><th>CATEGORY</th><th>NO. OF ITEMS</th><th>ACTION</th></tr></thead>
					<tbody id="alldata"></tbody>
					</table>
				</div>
			<div id="new_items" title="NEW CATEGORY " style="display:none;">
			<iframe id="item_dialog" width="380" height="90" style="border:none"></iframe>
			</div>
		</div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
		
		if(menu=="management#"){
			menu="management";
		}
		else{
			menu = getUrlVars()["menu"];
		}
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') -249px 5px no-repeat",
		"padding":"30px 10px 0px 10px",
		"border-bottom":"4px solid #c95447"
		});
		loadData();	
	});	
	
	/* function add_item(){
		
			$("#item_dialog").attr('src','../managements/newCategory.php');
			$("#new_items").dialog({
				width:381,
				height: 135,
				modal: true,
				resizable:false,
				close: function () {
					$("#item_dialog").attr('src',"about:blank");
					window.location.reload();
				}
			});
			return false;
	} */
	
	
	function loadData(){
    		
	var url="function_items.php?request=ajax&action=load_category";
	var counter=1;
	var x = 1;

		$.getJSON(url,function(data){
	
		$("#table > tbody").empty();
		$.each(data.members, function(i,res){
    		
	$("#table > tbody").append("<tr class='x'  > </td><input type='hidden' name='cat"+res.id+"' id='cat"+res.id+"' value='"+res.category+"' /><td>"+res.category+"</td><td align='center'>"+res.no_of_item+"<td align='center'><a href='#' alt='Update' title='Update' class='view' onclick='view_item("+res.id+");'></a></td></tr>");
						
			 counter++;
			 x = x+1;
			 
			
		});
		
		$("#table > tbody").append("<tr bgcolor='black'><td colspan=3 height=1></td></tr>");	
	
		if (counter <= 1){
			$("#table > tbody").append("<tr id = 'noItems'><th colspan = '10' align = 'center'> No Items on record! </th></tr>");
		}
				
				
	});	

	}

		function closeIframe(actions){
			if(actions=="add"){
				alert("successfully insert");
			}
			else if(actions=="edit"){
			alert("successfully updated");
			}
			$('#new_items').dialog('close');
			loadData();
			return false;
		}
		
		function view_item(num){
		
		var cat = $('#cat'+num).val();
			switch (cat)
			{
			case "motorcycle":
			  window.location = "itemsMotorcycle.php?category="+cat+"&menu=management";
			break;
			
			case "parts":
			  window.location = "itemParts.php?category="+cat+"&menu=management";
			break;
			
			case "promo item":
			  window.location = "itemPromo.php?category="+cat+"&menu=management";
			break;
			
			case "consumables":
			  window.location = "itemConsumable.php?category="+cat+"&menu=management";
			break;
			
			
			}
			
		}



	</script>
	
</body>
</html>