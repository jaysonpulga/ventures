<?php
session_start();
include('../database.php');  
$db = new Database();  
$db->connect(); 
$action = $_REQUEST["action"];



function category_count($category,$table){     
	
	$sql = mysql_query("select count(brand) as c from $table ") or die ("Error".mysql_error());
	$row = mysql_fetch_array($sql);  
	return $row['c']; 
}


if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){

	switch($action){
	
	case 'load_category';
	
	$row = "*";
	$new_arr = array();
	$arr = array();
	$i = 0;


	$db->select('category',$row);

	$result = $db->getResult();

	foreach($result as $info){
	
		$id = $info['id'];
	    $category = $info['category'];
		
		switch($category){
		
		case 'motorcycle';
		$table = "tbl_motorcycle";
		break;
		
		case 'parts';
		$table = "tbl_parts";
		break;
		
		case 'promo item';
		$table = "tbl_promo";
		break;
		
		case 'consumables';
		$table = "tbl_consumables";
		break;
		
		}
		
		
		$no_of_item = category_count($category,$table);

		$new_arr[$i] =  array(
					
					'id' =>$id,
					'category' =>$category,
					'no_of_item'=>$no_of_item,
					);
		
	array_push($arr,$new_arr[$i]);
			$i++;
	
	}
	
	echo '{"members":'.json_encode($arr).'}';
	
	break;
	
	
	

	case 'load_item';
	
	$sort = $_REQUEST['sort'];
	$sortType = $_REQUEST['sortType'];
	$row = "a.id,a.brand,count(b.brand) as no_of_item";
	$order = "$sort $sortType";
	
	$category=$_REQUEST['category'];
	$trimmed=trim($_REQUEST['inputsearch']);
	$table = "tbl_manufacturer a left join tbl_motorcycle b on a.id = b.brand";
	
	$where = "a.category = 1 group by a.brand ";
	$db->select($table,$row,$where,$order);
	
	
	$result = $db->getResult();

	print json_encode($result);
		
	break;
	
	
	case 'load_data';
	
	$tablename = $_REQUEST['tablename'];
	
	$sort = $_REQUEST['sort'];
	$sortType = $_REQUEST['sortType'];
	$row = "a.*,b.brand,b.id";
	$order = "$sort $sortType";
	
	$category=$_REQUEST['category'];
	$trimmed=trim($_REQUEST['inputsearch']);
	$table = "$tablename a,tbl_manufacturer b";
	
	
	if($trimmed!=""){
	$wherex="a.brand = b.id and $category LIKE '%".$trimmed."%'";
	$db->select($table,$row,$wherex,$order);
	}
	else{
	$where='a.brand = b.id';
	$db->select($table,$row,$where,$order);
	}
	
	$result = $db->getResult();
	
	print json_encode($result);
	break;
	
	
	
	
	
	case 'load_details';
	
	$brand = $_REQUEST['brand'];
	$sort = $_REQUEST['sort'];
	$sortType = $_REQUEST['sortType'];
	
	$row = "*";
	
	$category=$_REQUEST['category'];
	$trimmed=trim($_REQUEST['inputsearch']);
	
	$order = "$sort $sortType";
	
	
	if($trimmed!=""){
	$wherex="brand = $brand and $category LIKE '%".$trimmed."%'";
	 $db->select('tbl_motorcycle',$row,$wherex,$order);
	}
	else{
	$where='brand='.$brand;
	$db->select('tbl_motorcycle',$row,$where,$order);
	}
	
	$order = "$sort $sortType";
	$new_arr = array();
	$arr = array();
	$i = 0;


	

	$result = $db->getResult();

	foreach($result as $info){
	
		$id = $info['motor_id'];
		$model = $info['model'];
		$brand = $info['brand'];
		$engine_type = $info['engine_type'];
	    $displacement = $info['displacement'];
		$oil_capacity = $info['oil_capacity'];
		$unit_cost = $info['unit_cost'];
		
		$new_arr[$i] =  array(
					
					'motor_id' =>$id,
					'model'=>$model,
					'brand' =>$brand,
					'engine_type'=>$engine_type,
					'displacement'=>$displacement,
					'oil_capacity'=>$oil_capacity,
					'unit_cost'=>$unit_cost,
					);
		
	array_push($arr,$new_arr[$i]);
			$i++;
	
	}
	print json_encode($arr);
	break;
	
	
	case 'load_motor';
	$motor_id = $_REQUEST["motor_id"];
	$where='motor_id='.$motor_id;
	$row = "*";
	$db->select('tbl_motorcycle',"*",$where);
			$result = $db->getResult();					

	print '{"members":'.json_encode($result).'}';

	break;
	
	
	
	
	
	case 'updateUnit';
	$motor_id=$_REQUEST['motor_id'];
	$Model=$_REQUEST['Model'];
	$Engine=$_REQUEST['Engine'];
	$Displacement=$_REQUEST['Displacement'];
	$Oil=$_REQUEST['Oil'];
	$unit_cost=$_REQUEST['unit_cost'];
	
	$where='motor_id='.$motor_id;
	
	$rows = array('model' => $Model
				  ,'engine_type' => $Engine
				  ,'displacement	' => $Displacement
				  ,'oil_capacity' => $Oil
				  ,'unit_cost' => $unit_cost
				  );
	
	$db->update('tbl_motorcycle',$rows,$where); 
	print "updated";

	break;
	
	
	
	case 'load_update';
	$id = $_REQUEST["id"];
	$pro = $_REQUEST["pro"];
	
	$tablename = $_REQUEST['tablename'];
	$row = "a.*,b.brand,b.id";
	 $where = "a.brand = b.id and ".$pro." = ".$id." ";
	$new_arr = array();
	$arr = array();
	
	$table = "$tablename a,tbl_manufacturer b";
	
	$i = 0;
	
	$db->select($table,$row,$where);
	$result = $db->getResult();

	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	case 'updateParts';
	$id_p=$_REQUEST['id_p'];
	
	 $item_code_a=$_REQUEST['item_code_a'];
	
	$manufacturer=$_REQUEST['manufacturer'];
	$item_code=$_REQUEST['item_code'];
	$parts=$_REQUEST['parts'];
	$unit_cost=$_REQUEST['unit_cost'];
	$description=$_REQUEST['description'];
	
	$where2 ="brand = '$manufacturer' and category = '2' ";
	$rows2 = '*';
	
	
	if($db->recordExist('tbl_manufacturer',$rows2,$where2) == 0){

	$rows ='brand,category';	
	$values = array(strtoupper($manufacturer),'2');
	$db->insert('tbl_manufacturer',$values,$rows);
		
	$where_x ="brand = '".$manufacturer."' and category = '2' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	$where='parts_id='.$id_p;
	
	$rows = array('brand' => $brand
				  ,'item_code' => $item_code
				  ,'parts' => $parts
				  ,'unit_cost' => $unit_cost
				  ,'description' => $description
				  );
	
	$db->update('tbl_parts',$rows,$where); 
	print "updated";
		
		
		
	
	}else{
	
	if($item_code_a != $item_code){
		
	if($db->recordExist('tbl_parts',"*","item_code = '$item_code' ") > 0){
	print 'duplicate';
	}else{
		
	$where_x ="brand = '".$manufacturer."' and category = '2' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	
	$where='parts_id='.$id_p;
	
	$rows = array('brand' => $brand
				  ,'item_code' => $item_code
				  ,'parts' => $parts
				  ,'unit_cost' => $unit_cost
				  ,'description' => $description
				  );
	
	$db->update('tbl_parts',$rows,$where); 
	print "updated";
		
		}
	
	}elseif($item_code_a == $item_code){
		$sql = mysql_query("select * from  tbl_manufacturer where brand = '".$manufacturer."' and category = '2' ") or die("Error select id in tbl_manufacturer".mysql_error());
			
		$rowx = mysql_fetch_array($sql);
			
		$brand = $rowx['id'];
		
		
		$where='parts_id='.$id_p;
		
		$rows = array('brand' => $brand
				  ,'item_code' => $item_code
				  ,'parts' => $parts
				  ,'unit_cost' => $unit_cost
				  ,'description' => $description
				  );
		
		$db->update('tbl_parts',$rows,$where); 
		print "updated";
	
	}
	
	
	
	}
	break;
	
	
	
	case 'updatePromo';
	$id_p=$_REQUEST['id_p'];
	
	$item_code_a=$_REQUEST['item_code_a'];
	$unit_cost=$_REQUEST['unit_cost'];

	$manufacturer=$_REQUEST['manufacturer'];
	$item_code=$_REQUEST['item_code'];
	$description=$_REQUEST['description'];
	
	$where2 ="brand = '$manufacturer' and category = '3' ";
	$rows2 = '*';
	
	
	if($db->recordExist('tbl_manufacturer',$rows2,$where2) == 0){

	$rows ='brand,category';	
	$values = array($manufacturer,'3');
	$db->insert('tbl_manufacturer',$values,$rows);
		
	$where_x ="brand = '".$manufacturer."' and category = '3' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	$where='promo_id='.$id_p;
	
	$rows = array('brand' => $brand
				  ,'item_code' => $item_code
				  ,'unit_cost' => $unit_cost
				  ,'description' => $description
				  );
	
	$db->update('tbl_promo',$rows,$where); 
	print "updated";
		
	}else{
	
	if($item_code_a != $item_code){
		
	if($db->recordExist('tbl_promo',"*","item_code = '$item_code' ") > 0){
	print 'duplicate';
	}else{
		
	$where_x ="brand = '".$manufacturer."' and category = '3' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	
	$where='promo_id='.$id_p;
	
	$rows = array('brand' => $brand
				  ,'item_code' => $item_code
				  ,'unit_cost' => $unit_cost
				  ,'description' => $description
				  );
	
	$db->update('tbl_promo',$rows,$where); 
	print "updated";
		
		}
	
	}elseif($item_code_a == $item_code){
		
		$sql = mysql_query("select * from  tbl_manufacturer where brand = '".$manufacturer."' and category = '3' ") or die("Error select id in tbl_manufacturer".mysql_error());
			
		$rowx = mysql_fetch_array($sql);
			
		$brand = $rowx['id'];
		
		
		$where='promo_id='.$id_p;
		
		$rows = array('brand' => $brand
				  ,'item_code' => $item_code
				  ,'unit_cost' => $unit_cost
				  ,'description' => $description
				  );
		
		$db->update('tbl_promo',$rows,$where); 
		print "updated";
	
	}
	
	
	
	}
	break;
	
	
	
	case 'updateConsumable';
	$id_p=$_REQUEST['id_p'];
	
	 $item_code_a=$_REQUEST['item_code_a'];
	
	$manufacturer=$_REQUEST['manufacturer'];
	$item_code=$_REQUEST['item_code'];
	$type=$_REQUEST['type'];
	$unit_cost=$_REQUEST['unit_cost'];
	$description=$_REQUEST['description'];
	
	$where2 ="brand = '$manufacturer' and category = '4' ";
	$rows2 = '*';
	
	
	if($db->recordExist('tbl_manufacturer',$rows2,$where2) == 0){

	$rows ='brand,category';	
	$values = array($manufacturer,'4');
	$db->insert('tbl_manufacturer',$values,$rows);
		
	$where_x ="brand = '".$manufacturer."' and category = '4' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	$where='con_id='.$id_p;
	
	$rows = array('brand' => $brand
				  ,'item_code' => $item_code
				  ,'type' => $type
				  ,'unit_cost' => $unit_cost
				  ,'description' => $description
				  );
	
	$db->update('tbl_consumables',$rows,$where); 
	print "updated";
		
	}else{
	
	if($item_code_a != $item_code){
		
	if($db->recordExist('tbl_consumables',"*","item_code = '$item_code' ") > 0){
	print 'duplicate';
	}else{
		
	$where_x ="brand = '".$manufacturer."' and category = '4' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	
	$where='con_id='.$id_p;
	
	$rows = array('brand' => $brand
				  ,'item_code' => $item_code
				  ,'type' => $type
				  ,'unit_cost' => $unit_cost
				  ,'description' => $description
				  );
	
	$db->update('tbl_consumables',$rows,$where); 
	print "updated";
		
		}
	
	}elseif($item_code_a == $item_code){
		
		$sql = mysql_query("select * from  tbl_manufacturer where brand = '".$manufacturer."' and category = '4' ") or die("Error select id in tbl_manufacturer".mysql_error());
			
		$rowx = mysql_fetch_array($sql);
			
		$brand = $rowx['id'];
		
		
		$where='con_id='.$id_p;
		
		$rows = array('brand' => $brand
				  ,'item_code' => $item_code
				  ,'type' => $type
				  ,'unit_cost' => $unit_cost
				  ,'description' => $description
				  );
		
		$db->update('tbl_consumables',$rows,$where); 
		print "updated";
	
	}
	
	
	
	}
	break;
	
	
	case 'deleteSingleItem';
	$id=$_REQUEST['id'];
	$table_name=$_REQUEST['table_name'];
	$table_id=$_REQUEST['table_id'];
	
	$where=" $table_id = ".$id;
	$db->delete($table_name,$where);
	break;
	
	
	case 'deleteTwotable';
	 $id=$_REQUEST['id'];
	$table1=$_REQUEST['table1'];
	$table2=$_REQUEST['table2'];
	$table_id=$_REQUEST['table_id'];
	
	$where="$table_id = '$id' ";
	$db->delete($table1,$where);
	$db->delete($table2,$where);
	break;
	
	
	case 'add_category';
	
	$rows ='category';	
	$values = array($_REQUEST['category']);
	
	$db->insert('category',$values,$rows);
	print 'saved';
	break;
	
	
	case 'add_brand';
	
	$brand = $_REQUEST['brand'];
	

	$where ="brand = '$brand' and category = 1";
	
	$rows = '*';
	if($db->recordExist('tbl_manufacturer',$rows,$where) > 0){
		print 'duplicate';
	}else{
	
	$rows ='brand,category';	
	$values = array(strtoupper($_REQUEST['brand']),'1');
	
	$db->insert('tbl_manufacturer',$values,$rows);
	
	print 'saved';
	}
	break;
	
	
	
	
	case 'add_unit';
	
	$brand = $_REQUEST['brand'];
	$Model = $_REQUEST['Model'];
	$Engine = $_REQUEST['Engine'];
	$Displacement = $_REQUEST['Displacement'];
	$Oil = $_REQUEST['Oil'];
	$unit_cost = $_REQUEST['unit_cost'];
	
	$where ="model = '$Model' and brand = '$brand'";
	$rows = '*';
	if($db->recordExist('tbl_motorcycle',$rows,$where) > 0){
		print 'duplicate';
	}else{
	
	$rows ='model,brand,engine_type,displacement,oil_capacity,unit_cost';	
	$values = array($Model,$brand,$Engine,$Displacement,$Oil,$unit_cost);
	
	$db->insert('tbl_motorcycle',$values,$rows);
	
	print 'saved';
	}
	break;
	
	
	case 'add_parts';
	
	$manufacturer = $_REQUEST['manufacturer'];
	$item_codex = $_REQUEST['item_code'];
	$parts = $_REQUEST['parts'];
	$unit_cost = $_REQUEST['unit_cost'];
	$description = $_REQUEST['description'];
	$item_code = 'PA-'.$item_codex;
	
	$where ="brand = '$manufacturer' and category = '2' ";
	$where2 ="item_code = '$item_code' ";
	
	$rows = '*';
	
	if($db->recordExist('tbl_parts',$rows,$where2) > 0){
		
		print 'duplicate';
		
	}elseif($db->recordExist('tbl_manufacturer',$rows,$where) == 0){
		
	$rows ='brand,category';	
	$values = array($manufacturer,'2');
	$db->insert('tbl_manufacturer',$values,$rows);
	
	
	$where_x ="brand = '".$manufacturer."' and category = '2' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	$rows ='brand,item_code,parts,unit_cost,description';	
	$values = array($brand,$item_code,$parts,$unit_cost,$description);
	
	$db->insert('tbl_parts',$values,$rows);
	
	print 'saved';
	
	}else{
	
	$where_x ="brand = '".$manufacturer."' and category = '2' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	$rows ='brand,item_code,parts,unit_cost,description';	
	$values = array($brand,$item_code,$parts,$unit_cost,$description);
	
	$db->insert('tbl_parts',$values,$rows);
	
	print 'saved';
	}
	break;
	
	
	case 'add_promo';
	
	$manufacturer = $_REQUEST['manufacturer'];
	$item_codex = $_REQUEST['item_code'];
	$unit_cost = $_REQUEST['unit_cost'];
	$description = $_REQUEST['description'];
	$item_code = 'PI-'.$item_codex;
	
	$where ="brand = '$manufacturer' and category = '3' ";
	$where2 ="item_code = '$item_code' ";
	
	$rows = '*';
	
	if($db->recordExist('tbl_promo',$rows,$where2) > 0){
		
		print 'duplicate';
		
	}elseif($db->recordExist('tbl_manufacturer',$rows,$where) == 0){
		
	$rows ='brand,category';	
	$values = array($manufacturer,'3');
	$db->insert('tbl_manufacturer',$values,$rows);
	
	
	$where_x ="brand = '".$manufacturer."' and category = '3' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	$rows ='brand,item_code,unit_cost,description';	
	$values = array($brand,$item_code,$unit_cost,$description);
	
	$db->insert('tbl_promo',$values,$rows);
	
	print 'saved';
	
	}else{
	
	$where_x ="brand = '".$manufacturer."' and category = '3' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	$rows ='brand,item_code,unit_cost,description';	
	$values = array($brand,$item_code,$unit_cost,$description);
	
	$db->insert('tbl_promo',$values,$rows);
	
	print 'saved';
	}
	break;
	
	
	case 'add_consumable';
	
	$manufacturer = $_REQUEST['manufacturer'];
	$item_codex = $_REQUEST['item_code'];
	$type = $_REQUEST['type'];
	$unit_cost = $_REQUEST['unit_cost'];
	$description = $_REQUEST['description'];
	$item_code = 'CS-'.$item_codex;
	
	$where ="brand = '$manufacturer' and category = '4' ";
	$where2 ="item_code = '$item_code' ";
	
	$rows = '*';
	
	if($db->recordExist('tbl_consumables',$rows,$where2) > 0){
		
		print 'duplicate';
		
	}elseif($db->recordExist('tbl_manufacturer',$rows,$where) > 0){
	

	$where_x ="brand = '".$manufacturer."' and category = '4' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	$rows ='brand,item_code,type,unit_cost,description';	
	$values = array($brand,$item_code,$type,$unit_cost,$description);
	
	$db->insert('tbl_consumables',$values,$rows);
	
	print 'saved';
	
	}else{
	
	$rows ='brand,category';	
	$values = array($manufacturer,'4');
	$db->insert('tbl_manufacturer',$values,$rows);
	

	$where_x ="brand = '".$manufacturer."' and category = '2' ";
	$db->select("tbl_manufacturer","*",$where_x);
	$result = $db->getResult();
			
	foreach($result as $info){
		$brand = $info['id'];
	}
	
	$rows ='brand,item_code,type,unit_cost,description';	
	$values = array($brand,$item_code,$type,$unit_cost,$description);
	
	$db->insert('tbl_consumables',$values,$rows);
	
	print 'saved';
	}
	
	break;
	
	
	
	
	case 'edit_category';
	
	$id=$_REQUEST['id'];
	$category=$_REQUEST['category'];
	
	$where='id='.$id;
	
	$rows = array('category' => $category);
	
	$db->update('category',$rows,$where); 
	print "updated";
	
	break;
	

	
	
	case 'load_price';
	
	$tablename = $_REQUEST['table_name'];
	$sort = $_REQUEST['sort'];
	$sortType = $_REQUEST['sortType'];

	$category=$_REQUEST['category'];
	$trimmed=trim($_REQUEST['inputsearch']);

	//$where = "a.brand = b.id ";
	
	$row = "a.*,b.brand,b.id";
	
	$table = "$tablename a,tbl_manufacturer b";
	
	$order = "$sort $sortType";
	
	if($trimmed!=""){
	$wherex="a.brand = b.id and $category LIKE '%".$trimmed."%'";
	 $db->select($table,$row,$wherex,$order);
	}
	else{
	$where = "a.brand = b.id ";
	$db->select($table,$row,$where,$order);
	}
	

	$result = $db->getResult();

	//echo '{"members":'.json_encode($result).'}';
	print json_encode($result);
	
	break;
	
	
	
	case 'updatePrice';
	$id_p=$_REQUEST['id_p'];
	$tablename=$_REQUEST['tablename'];
	$selling=$_REQUEST['selling'];
	$installment=$_REQUEST['installment'];
	 $tbl_id=$_REQUEST['tbl_id'];
	
	
	$where="$tbl_id=".$id_p;
	if($tablename == "tbl_motorcycle"){
	$rows = array('selling_price' =>$selling
				  ,'installment' =>$installment
				  );
	}else{
	$rows = array('selling_price' => $selling
				  );
	}
	$db->update($tablename,$rows,$where); 
	print "updated";

	break;
	
	
	
	
	case 'load_select_model';	
	$id = $_REQUEST['id'];
	$where="brand = ".$id;
	$db->select("tbl_motorcycle","*",$where,"model ASC");
	
	$result = $db->getResult();
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	case 'load_select_ItemCode';	
	$id = $_REQUEST['id'];
	 $table = $_REQUEST['table'];
	$where="brand = ".$id;
	$db->select($table,"*",$where,"item_code ASC");
	
	$result = $db->getResult();
	
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	case 'load_select';	
	$category = $_REQUEST['category'];
	$where="category = ".$category;
	$db->select("tbl_manufacturer","*",$where,"brand ASC");
	
	$result = $db->getResult();
	
	print json_encode($result);
	break;
	
	
	case 'select_unit_cost';	
	$id = $_REQUEST['id'];
	$table = $_REQUEST['table'];
	
		if($table =="tbl_motorcycle" ){
			$where="motor_id = ".$id;
		}else if($table =="tbl_parts"){
			$where="parts_id = ".$id;
		}else if($table =="tbl_promo"){
			$where="promo_id = ".$id;
		}else if($table =="tbl_consumables"){
			$where="con_id = ".$id;
		}
	$db->select($table,"*",$where);
	
	$result = $db->getResult();
	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	case 'add_SRNO';
	
	 $sr_no = $_REQUEST['sr_no'];
	 $date = $_REQUEST['date'];
	 $branch = $_REQUEST['branch'];
	 $to = $_REQUEST['to'];
	
	$where ="sr_no = '$sr_no' ";
	$rows = '*';
	if($db->recordExist('tbl_requisition',$rows,$where) > 0){
		print 'duplicate';
	}else{
	
	$rows ="sr_no,date,branch_code,sold";
	$values = array($sr_no,$date,$branch,$to);
	$db->insert('tbl_requisition',$values,$rows);
	
	print 'saved';
	}
	break;
	
	case 'load_SR';
	$sr_no = $_REQUEST["sr_no"];

	$where = "sr_no = '$sr_no' ";
	
	$db->select("tbl_requisition","*",$where);
	$result = $db->getResult();

	echo '{"members":'.json_encode($result).'}';
	break;
	
	
	
	case 'select_branch';
	$db->select("tbl_branch","*");
	$result = $db->getResult();
	
	print json_encode($result);
	break;
	
	
	case 'load_requisition';
	
	$sort = $_REQUEST['sort'];
	$sortType = $_REQUEST['sortType'];
	$branch_code = $_REQUEST['branch_code'];
	
	$row = "a.sr_no,a.date,sum(b.quantity) as quantity,sum(b.quantity * b.unit_cost) as total_amt";
	$order = "$sort $sortType";
	
	$category=$_REQUEST['category'];
	$trimmed=trim($_REQUEST['inputsearch']);
	
	$table = "tbl_requisition a left join tbl_stock_requisition b on a.sr_no = b.sr_no";
	if($branch_code != "3SS"){
	$where = "a.branch_code = '$branch_code' AND $category LIKE '%".$trimmed."%' group by a.sr_no";
	}else{
	$where = "$category LIKE '%".$trimmed."%' group by a.sr_no";
	}
	
	
	$db->select($table,$row,$where,$order);
	
	
	$result = $db->getResult();

	print json_encode($result);
		
	break;
	
	
	case 'add_stock';
	
	$sr_no = $_REQUEST['sr_no'];
	$category = $_REQUEST['category'];
	$brand = $_REQUEST['brand'];
	
	$item_code = $_REQUEST['item_code'];
	$model = $_REQUEST['model'];
	$color = $_REQUEST['color'];
	
	$qty = $_REQUEST['qty'];
	$unit_cost = $_REQUEST['unit_cost'];
	
	
	if($category == '1'){
		
		$where2 ="sr_no = '$sr_no' and category = '$category' and brand = '$brand' and item = '$model' and color = '$color'";
	
	}else if ($category != '1'){
		
		$where2 ="sr_no = '$sr_no' and category = '$category' and brand = '$brand' and item = '$item_code'";
	}
	
	$rows2 = '*';
	
	if($db->recordExist('tbl_stock_requisition',$rows2,$where2) > 0){
		
			$where_x ="category = '$category' and brand = '$brand' and item = '$model' or item = '$item_code'";
			$db->select("tbl_stock_requisition","*",$where_x);
			$result = $db->getResult();
			
			foreach($result as $info){
				$qty2 = $info['quantity'];
				$unit2 = $info['unit_cost'];
			}
	
			$qty = $qty + $qty2 ;
			$unit_cost = $unit_cost + $unit2;
			
			$where_y ="category = '$category' and brand = '$brand' and item = '$model' or item = '$item_code'";
			
			$rows_y = array('unit_cost' => $unit_cost ,'quantity' => $qty);
			
			$db->update('tbl_stock_requisition',$rows_y,$where_y); 
			print "saved";
	
	}else{
	
	
			if($category == '1'){
		
			$rows ='sr_no,category,brand,item,color,quantity,unit_cost';	
			$values = array($sr_no,$category,$brand,$model,$color,$qty,$unit_cost);
			
			}else if ($category != '1'){
		
			$rows ='sr_no,category,brand,item,quantity,unit_cost';	
			$values = array($sr_no,$category,$brand,$item_code,$qty,$unit_cost);
			
			}
	
			$db->insert('tbl_stock_requisition',$values,$rows);
		
	print 'saved';
	}
	break;
	
	
	
	
	case 'load_ko';
	
	$dataArray=array();
	$dataArray2=array();
	$dataArray3=array();
	$dataArray4=array();
	$sr_no = $_REQUEST['sr_no'];
	
	$where = "sr_no='$sr_no'";
	$db->select("tbl_stock_requisition","*",$where);
	$result = $db->getResult();
	
	foreach($result as $key){
		 $category=$key["category"];
		 $sr_no=$key["sr_no"];
		 
		if($category == '1'){
		 
			
			$row = "a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.model";
			$table = "tbl_stock_requisition a,tbl_manufacturer b, tbl_motorcycle c";
			
			$where = "a.brand = b.id and a.item = c.motor_id and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray=$result;
			
			
		 }else if($category == '2'){

			$row = "a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.item_code";
			$table = "tbl_stock_requisition a,tbl_manufacturer b, tbl_parts c";
			
			$where = "a.brand = b.id and a.item = c.parts_id and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray2=$result;
		   
		 
		 }
		 else if($category == '3'){
			
			
			$row = "a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.item_code";
			$table = "tbl_stock_requisition a,tbl_manufacturer b, tbl_promo c";
			
			$where = "a.brand = b.id and a.item = c.promo_id and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray3=$result;
		  
		 }
		 else if($category == '4'){
			
			
			$row = "a.category,a.stock_id,a.color,a.quantity,a.unit_cost,b.brand,c.item_code";
			$table = "tbl_stock_requisition a,tbl_manufacturer b,tbl_consumables c";
			
			$where = "a.brand = b.id and a.item = c.con_id and a.category = '$category' and a.sr_no = '$sr_no' ";
			$db->select($table,$row,$where);
			$result = $db->getResult();
			$dataArray4=$result;
		   
		 }
		
		$output = array_merge($dataArray, $dataArray2,$dataArray3,$dataArray4);
	}
	

		if(empty($output)){
		
			echo '{"members":'.json_encode($result).'}';
			
		}else{

			echo '{"members":'.json_encode($output).'}';
		}
	break;
	
	
	case 'update_SRNO';
	$sr_no=$_REQUEST['sr_no'];
	$date=$_REQUEST['date'];	
	$branch=$_REQUEST['branch'];
	$to=$_REQUEST['to'];
	
	$where ="sr_no = '$sr_no'";
		
	$rows = array('date' => $date
				,'branch_code' => $branch
				,'sold' => $to
			  );
			  
	$db->update('tbl_requisition',$rows,$where); 	
	print "updated";
	
	break;
	
	case 'update_stock_item';
	$id=$_REQUEST['id'];
	$unit_cost=$_REQUEST['unit_cost'];	
	$quantity=$_REQUEST['quantity'];

	$where ="stock_id = '$id'";
		
	$rows = array('quantity' => $quantity
				,'unit_cost' => $unit_cost
			  );		  
	$db->update('tbl_stock_requisition',$rows,$where); 	
	print "updated";
	
	break;
	
	
	case "login";
					if($db->select('tbl_security','*','username = "'.$_REQUEST["username"].'" AND password = "'.$_REQUEST["password"].'"  AND branch_id = "'.$_REQUEST["branch"].'"  ' )){
						if(count($db->getResult()) > 0){
							$result = $db->getResult();
							
								
							 $_SESSION['branch_id'] = $_REQUEST["branch"];
							 $_SESSION["username"] = $_REQUEST["username"];
							 
							
							 $db->select("tbl_branch","*",'id = "'.$_SESSION['branch_id'].'" ');
							 $result = $db->getResult();
							 
									 foreach($result as $info){
										 $_SESSION["branch_name"] = $info["branch_name"];
										 $_SESSION["branch_code"] = $info["branch_code"];
										 $_SESSION['branch_id'] = 	$info["id"];
									 }
									
							
							print "YOSH!";
						} else {
							print "ERROR: Username, Password and Branch code  did not match.";
						}
					}else{
						print "ERROR: Username, Password and Branch code  did not match.";
					}
				break;

	}
	

}


?>