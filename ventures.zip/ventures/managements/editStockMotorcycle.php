<html>
<title>Sales</title>
<head>
<?php
include('../database.php');  
$db = new Database();  
$db->connect();
?>

	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px;">
					<div style="margin-top:10px" align="center">
						<span>
						<input type="hidden" id="table" value="<?php echo $_REQUEST['table']; ?>" name="table" >
						<input type="hidden" id="cat" value="<?php echo $_REQUEST['cat']; ?>" name="cat" >
						<input type="text" id="sr_no" value="<?php echo $_REQUEST['sr_no']; ?>"  name="sr_no" >
						<input type="text" id="id" value="<?php echo $_REQUEST['id']; ?>"  name="id" >
						<input type="hidden" id="br" name="br" >
							<label>Manufacturer:</label>
							<select id= 'brand' name='brand' onchange = "changeCategory(this.value)" >
							</select>			
						</span>
					</div>
					<div id="second" align="center">
					</div>
					<div align="center">
						<span>
							<label>Unit Cost:</label>
							<input type="text" id="unit_cost" name="unit_cost" style="margin-left:35px">
						</span>
					</div>
					<div align="center">
						<span>
							<label>Quantity:</label>
							<input type="text" id="qty" name="qty" style="margin-left:35px">
						</span>
					</div>
					<div id="fourth">
					</div>
					
					<div align="center">
						<span>
							<br>
							<input type="button" value="ADD" onclick="Add_stock()" style="width:100px;top:1px;">
							<input type="button" value="CANCEL" onclick="Cancel()" style="width:100px;top:1px;">
						</span>
					</div>
			</div>
		<div>
	</div>
	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		
		var brand = $("#brand").val()
		var cat = $("#cat").val();
		var table = $('#table').val();
		$('#br').val(brand);
		var b = $('#br').val();
		
		select_model(b);
		select_Item_code(b,table);
		secondinput(cat);
				
	});	
	
	
	var sr_no = $('#sr_no').val();
	var id = $('#id').val();	
	function loadData(){
			
			var url="function_items.php?request=ajax&action=edit_sotckMotor&sr_no="+sr_no+"&id="+id;
		
			$.getJSON(url,function(data){
				$.each(data.members, function(i,res){
					$('#sr').val(res.sr_no);
					$('#date').val(res.date);
					var brand = res.brand;
					$('#to').val(res.sold);load_select(brand);
				});	
			});
			
	}
	
	
	
	function secondinput(cat){
		if(cat == "1"){
		$("#second").append('<span><label>Model:</label><select id = "model" name="model" style="margin-left:45px" onchange = "Select_unit_Cost(this.value)" ></select></span>');
		$("#fourth").append('<span><label style="margin-left:57px">Color:</label><input type="text" id="color" name="color" style="margin-left:58px"></span>');
		
		}else{
		$("#second").append('<span><label>Item Code:</label><select id = "item_code" name="item_code" style="margin-left:20px" onchange = "Select_unit_Cost(this.value)"</select></span>');
		$("#fourth").append('<span><label style="margin-left:55px" >Description:</label><br><span><textarea readonly="readonly" rows="3" id="description" name="description" style="margin-left:150px; margin-top:-17px"></textarea></span>');
		}
	}
	
	function Cancel(){
		var action = "cancel";
		window.parent.closeIframe(action);
	}
	
	
	function changeCategory(brand){
	var table = $('#table').val();
		$('#br').val(brand);	
		$("#unit_cost").val("");
		$("#description").val("");
		select_model(brand);
		select_Item_code(brand,table)
		
	}
	
	function select_model(brand){

	event.preventDefault();

	var url="function_items.php?request=ajax&action=load_select_model&id="+brand;
	var counter=1;

		$.getJSON(url,function(data){
	
		$("#model").empty();
		$("#unit_cost").val("");
		
			$("#model").append("<option  value=''>--Select Model--</option>");
			$.each(data.members, function(i,res){
						
			$("#model").append("<option value='"+res.motor_id+"' >"+res.model+"</option>");
			
			counter++;
				
			});
			if (counter <= 1){
			$("#model").append("<option>NO RECORD</option>");
			}
		});	
	
	}
	
	
	function select_Item_code(brand,table){

	event.preventDefault();

	var url="function_items.php?request=ajax&action=load_select_ItemCode&id="+brand+"&table="+table;
	var counter=1;

		$.getJSON(url,function(data){
	
		$("#item_code").empty();
		$("#unit_cost").val("");
		
			$("#item_code").append("<option  value=''>--Select--</option>");
			$.each(data.members, function(i,res){
			if(res.parts_id){
				var id = res.parts_id;
			}
			else if(res.promo_id){
				var id = res.promo_id;
			}
			else if(res.con_id){
				var id = res.con_id;
			}
					
			$("#item_code").append("<option value='"+id+"' >"+res.item_code+"</option>");
			
			counter++;
				
			});
			if (counter <= 1){
			$("#item_code").append("<option>NO RECORD</option>");
			}
		});	
	
	}
	
	
	function Select_unit_Cost(motor_id){
	var table = $('#table').val();
	if(motor_id == ""){
	$("#unit_cost").val("");
	$("#description").val("");
	}

	event.preventDefault();

	var url="function_items.php?request=ajax&action=select_unit_cost&id="+motor_id+"&table="+table;
		$.getJSON(url,function(data){
	
		$("#unit_cost").val("");
		$("#description").val("");
			$.each(data.members, function(i,res){
						
			$("#unit_cost").val(res.unit_cost);
			$("#description").val(res.description);
			
			});
			
		});	
	
	}
	
	function Add_stock(){
	
	event.preventDefault();
	
	var sr_no = $('#sr_no').val();
	var category = $('#cat').val();
	
	
	var brand = $('#brand').val();
	var item_code = $('#item_code').val();
	
	var model = $('#model').val();
	var color = $('#color').val();
	
	var color = $('#color').val();
	var unit_cost = $('#unit_cost').val();
	var qty = $('#qty').val();
	
	var errormsg="Please complete the following fields: \n";
	var emsg= errormsg.length;

		if(brand == ""){
			errormsg+="-Manufacturer\n";
			
		}
		if(item_code == "" && category != "1"){
			errormsg+="-Item Code \n";
			
		}
		if(model == "" && category == "1"){
			errormsg+="-Model \n";
			
		}
		if(unit_cost == "") {
			errormsg+="-Unit Cost \n";
			
		}
		if(color == "" && category == "1") {
			errormsg+="-Color \n";
			
		}
		if(qty == "" ) {
			errormsg+="-Quantity \n";
			
		}
		
		if(errormsg.length== emsg){
		
		
	$.ajax({
		
		       url: "function_items.php",
				data:{"request":"ajax","action":"add_stock","sr_no":sr_no,"category":category,"brand":brand,"item_code":item_code,"model":model,"color":color,"unit_cost":unit_cost,"qty":qty},
				success: function(reply){
					console.log(reply);
						if(reply == 'saved'){	
							var actions="add";
							window.parent.closeIframe(actions);
						}else{
							jAlert("cannot add information");
						}
					
					}
		
		
		
		});
		
		}else{
			jAlert(errormsg);
			event.preventDefault();
		}
	
	}
	
	
	function load_select(brand){
		var count=0, x=0;
		var select = $("#branch");

		$.ajax({
				url:"function_items.php",
				data:{"request":"ajax","action":"select_brand"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					if(reply.length > 0){
						select.empty();
							$.each(reply, function(i,res){
							 count++;
							if(res.id == brand){
							select.append("<option  value='"+res.id+"' selected='selected' >"+res.brand+"</option>");
							}	else{
							select.append("<option  value='"+res.id+"'>"+res.branch_name+"</option>");
							}	
								
																		
							});
			
					}
				}
			});
	}
	
	
	
	</script>
	
</body>
</html>