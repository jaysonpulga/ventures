<html>
<title>Sales</title>
<head>
<?php
include('../database.php');  
$db = new Database();  
$db->connect();
?>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	<link rel='stylesheet' type='text/css' href='../css/styles.css' />
	<link rel="stylesheet" type="text/css" href="../css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="../css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="../css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="../js/jquery-1.8.3.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.js"></script>
	<script src="../js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="../js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script>
</head>
<body>
<form  name="frm"  method="POST">
<input type="hidden" id="promo_id" value="<?php echo $_REQUEST['promo_id']; ?>" name="promo_id" >
<input type="hidden" id="id_p"  name="id_p" >
<input type="hidden" id="item_code_a"  name="item_code_a" >
	<div style="width:100%;position:relative;">
		<div id="options-top" style="margin:0px auto" align="center">
			<div id="sample" style="text-align:left;padding:10px;">
				<div  align="center" style="margin-top:15px;">
					<span>
						<label>S.R NO:</label>
						<input type="text"id="sr_no" name="sr_no"  style="margin-left:10px" >
					</span>
				</div>
				<div align="center" style="margin-top:5px;">
					<span>
						<label>Date:</label>
						<input type="date" id="date" name="date" style="margin-left:15px">
					</span>
				</div>
				<div align="center" style="margin-top:5px;">
					<span>
						<label >Branch:</label>
						<select id ='branch' name='branch' style="margin-left:5px" >
										
									
						</select>
					</span>
				</div>
				<div align="center" style="margin-top:5px;">
					<span>
						<label style="margin-left:20px">To:</label>
						<input type="text" id="to" name="to" style="margin-left:20px">
					</span>
				</div>
			
				<div align="center">
					<span><br>
						<input type="button" value="ADD" onClick="save_requisition(this)" >
						<input type="button" value="CANCEL" onClick="Cancel();">
					
					</span>
				</div>
			</div>
		</div>
	</div>

	
	<script src='../js/dropdowntabs.js'></script>
	<script>
	$(document).ready(function(){
		var menu = getUrlVars()["menu"];
	
		$("."+menu).attr("class",menu+"-active");
		
		$("."+menu+"-active a").css({
		"background":"#4b4c51 url('../images/icons.png') 50px 5px no-repeat",
		"padding":"30px 12px 0px 12px",
		"border-bottom":"4px solid #c95447"
		});
		load_select();
	});	
	



	function save_requisition(obj){
		event.preventDefault();
		
		var sr_no = $('#sr_no').val();
		var date = $('#date').val();
		var branch = $('#branch').val();
		var to = $('#to').val();
		var errormsg="Please complete the following fields: \n";
		var emsg= errormsg.length;

			if(sr_no == ""){
				errormsg+="-S.R NO:\n";
				
			}
			if(date == ""){
				errormsg+="-Date \n";
				
			}
			if(branch == ""){
				errormsg+="-Branch \n";
				
			}
			if(errormsg.length== emsg){
			
			
		$.ajax({
			
				  url: "function_items.php",
					data:{"request":"ajax","action":"add_SRNO","sr_no":sr_no,"date":date,"branch":branch,"to":to},
						success: function(reply){
							console.log(reply);
								if(reply == 'saved'){
									var actions="add";
									var link ="addStock.php?sr_no="+sr_no+"&menu=management";
									window.parent.Nexturl(actions,link);
									
								
								}else if(reply == 'duplicate'){
								 jAlert("The S.R NO:"+sr_no+ " is already exist in database!");
								
								}else{
									jAlert("cannot add information");
								}
							
							}
			
			
			
			});
			
			}else{
				jAlert(errormsg);
				event.preventDefault();
			}
			
	}
	
			
	function Cancel(){
		var action = "cancel";
	window.parent.closeIframe(action);
	}
	
	
	function load_select(){

		var count=0, x=0;
		var select = $("#branch");

		$.ajax({
				url:"function_items.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					//console.log(reply.length);
					
					if(reply.length > 0){
						select.empty();
						select.append("<option  value=''>-Select Branch--</option>");
							$.each(reply, function(i,res){
							 count++;
									
								select.append("<option  value='"+res.branch_code+"' >"+res.branch_name+"</option>");
																		
							});
			
					}
				}
			});
	}
	
	</script>
	
</body>
</html>