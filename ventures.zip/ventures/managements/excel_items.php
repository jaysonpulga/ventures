<?php
include('../database.php');
$db = new Database();
$db->connect();
$category = $_REQUEST['category'];

//if this parameter is included ($w=1), file returned will be in word format ('.doc')
//if parameter is not included, file returned will be in excel format ('.xls')
if (isset($w) && ($w==1))
{
	$file_type = "msword";
	$file_ending = "doc";
}else {
	$file_type = "vnd.ms-excel";
	$file_ending = "xls";
}
$date = date('Y-m-d');
//header info for browser: determines file type ('.doc' or '.xls')
@header("Content-Type: application/$file_type");
@header("Content-Disposition: attachment; filename=($category)$date.$file_ending");
@header("Pragma: no-cache");
@header("Expires: 0");
?>

<?php 
	
	$tablename = $_REQUEST['tablename'];
	$row = "a.*,b.brand,b.id";
	$where = "a.brand = b.id";
	
	
	if($tablename == "tbl_motorcycle"){
		echo "<table align='left' border='1' cellpadding='1'; style='width:900px;'>";
			echo "<tr align ='center'>";
				echo "<th>MANUFACTURER</th>";
				echo "<th>MODEL</th>";
				echo "<th>ENGINE TYPE</th>";
				echo "<th>DISPLACEMENT</th>";
				echo "<th>OIL CAPACITY</th>";
				echo "<th>SELLING PRICE</th>";
				echo "<th>INSTALLMENT</th>";
			echo "</tr>";
	}
	elseif($tablename == "tbl_parts"){
	
	echo "<table align='left' border='1' cellpadding='1'; style='width:800px;'>";
			echo "<tr align ='center'>";
				echo "<th>MANUFACTURER</th>";
				echo "<th>ITEM CODE</th>";
				echo "<th>PARTS</th>";
				echo "<th>DESCRIPTION</th>";
				echo "<th>SELLING PRICE</th>";
			echo "</tr>";
	
	}
	
	elseif($tablename == "tbl_promo"){
	
	echo "<table align='left' border='1' cellpadding='1'; style='width:800px;'>";
			echo "<tr align ='center'>";
				echo "<th>MANUFACTURER</th>";
				echo "<th>ITEM CODE</th>";
				echo "<th>DESCRIPTION</th>";
				echo "<th>SELLING PRICE</th>";
			echo "</tr>";
	
	}
	
	elseif($tablename == "tbl_consumables"){
	
	echo "<table align='left' border='1' cellpadding='1'; style='width:800px;'>";
			echo "<tr align ='center'>";
				echo "<th>MANUFACTURER</th>";
				echo "<th>ITEM CODE</th>";
				echo "<th>TYPE</th>";
				echo "<th>DESCRIPTION</th>";
				echo "<th>SELLING PRICE</th>";
			echo "</tr>";
	
	}
	
	
	
	
	$table = "$tablename a,tbl_manufacturer b";
	$db->select($table,$row,$where);
	$result = $db->getResult();
	
	foreach( $result  as $info){
	
	if($tablename == "tbl_motorcycle"){
	
	echo "<tr align ='center' >";
				echo "<td>".$info['brand']."</td>";
				echo "<td>".$info['model']."</th>";
				echo "<td>".$info['engine_type']."</td>";
				echo "<td>".$info['displacement']."</td>";
				echo "<td>".$info['oil_capacity']."</td>";
				echo "<td>".$info['selling_price']."</td>";
				echo "<td>".$info['installment']."</td>";
	echo "</tr>";
	
	}
	elseif($tablename == "tbl_parts"){
	
	echo "<tr align ='center' >";
				echo "<td>".$info['brand']."</td>";
				echo "<td>".$info['item_code']."</th>";
				echo "<td>".$info['parts']."</td>";
				echo "<td>".$info['description']."</td>";
				echo "<td>".$info['selling_price']."</td>";
	echo "</tr>";
	}
	
	elseif($tablename == "tbl_promo"){
	
	echo "<tr align ='center' >";
				echo "<td>".$info['brand']."</td>";
				echo "<td>".$info['item_code']."</th>";
				echo "<td>".$info['description']."</td>";
				echo "<td>".$info['selling_price']."</td>";
	echo "</tr>";
	}
	
	elseif($tablename == "tbl_consumables"){
	
	echo "<tr align ='center' >";
				echo "<td>".$info['brand']."</td>";
				echo "<td>".$info['item_code']."</th>";
				echo "<td>".$info['type']."</th>";
				echo "<td>".$info['description']."</td>";
				echo "<td>".$info['selling_price']."</td>";
	echo "</tr>";
	}
	
	
	
	}

	
				
		
?>