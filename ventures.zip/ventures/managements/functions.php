<?php
	session_start();
	include('../database.php');
	$db = new Database();  
	$db->connect();
	
	$action = $_REQUEST["action"];
	
	if(isset($_REQUEST["request"]) && $_REQUEST["request"] == 'ajax'){
		
		switch($action){
		//BRANCH
			case 'viewBranchData';
			
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$category=$_REQUEST['category'];
				$trimmed=trim($_REQUEST['inputsearch']);
			
				$rows ='a.*, b.province_name as province_name';
				$where = "a.province_id=b.id and $category LIKE '%".$trimmed."%'";
				$order="$sort $sortType";
				$db->select('tbl_branch a, tbl_province b',$rows,$where,$order); 
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'loadBranchRegion';
			
				$rows="id,region_name";
				$where="";
				$order = "region_name ASC";
				$db->select('tbl_region',$rows,$where,$order);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'loadBranchProvince';
				
				$region_id=$_REQUEST["region_id"];
				$where='region_id='.$region_id;
				$rows="*";
				$order = "province_name ASC";
				$db->select('tbl_province',$rows,$where,$order);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'loadBranchCity';
				
				$province_id=$_REQUEST["province_id"];
				$where='province_id='.$province_id;
				$rows="*";
				$order = "city_name ASC";
				$db->select('tbl_city',$rows,$where,$order);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'searchBranch';
				
				$search=trim($_REQUEST['inputsearch']);
				$category=$_REQUEST['category'];
				
				if($category=="province_id"){
					$rows ='a.*, b.province_name as province_name';
					$where = "a.province_id=b.id AND b.province_name LIKE '%".$search."%'";
					$db->select('tbl_branch a, tbl_province b',$rows,$where); 
				}
				else{
					$rows = "a.*,b.province_name as province_name ";
					$where = "a.province_id=b.id AND a.$category LIKE '%".$search."%'";		
					$db->select('tbl_branch a, tbl_province b', $rows, $where);
				}	
				
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			break;
			
			case 'saveBranchData';
			
				$bcode=$_REQUEST["branch_code"];
				$bname=$_REQUEST["branch_name"];
				$lend=$_REQUEST["lending"];
				$reg_fee=$_REQUEST["registration_fee"];
				$reg_id=$_REQUEST["region_id"];
				$prov_id=$_REQUEST["province_id"];
				$city_id=$_REQUEST["city"];
				$subd_brgy=$_REQUEST["subd"];
				$street_num=$_REQUEST["street"];
				$telnum=$_REQUEST["telno"];
				$faxnum=$_REQUEST["faxno"];
				$email_add=$_REQUEST["email"];
				
				$rows1 = "*";
				$where1 = "branch_code='$bcode'";
				
				$db->select("tbl_branch", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
					
					$rows2 ='branch_code,branch_name,lending,registration_fee,region_id,province_id,city_town_id,subd_brgy,street_num,tel_no,fax_no,email_add';
					$values2 = array($bcode,$bname,$lend,$reg_fee,$reg_id,$prov_id,$city_id,$subd_brgy,$street_num,$telnum,$faxnum,$email_add);
					
					$db->insert('tbl_branch',$values2,$rows2);
					
					echo "saved";

				}
				
			break;
			
			case 'viewBranchUpdate';
				$branch_id = $_REQUEST['branch_id'];
				
				$where="a.id='$branch_id' AND b.id=a.region_id AND c.id=a.province_id AND d.id=city_town_id";
				$rows ='a.*,b.region_name as r_name,c.province_name as p_name, d.city_name as c_name';
				
				$db->select('tbl_branch a,tbl_region b,tbl_province c, tbl_city d',$rows,$where); 
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			
			break;
			
			case 'delete_branch';
			
				$id=$_REQUEST["id"];
				$db->delete("tbl_branch","id='$id'");  
				
				print "deleted";
			
			break;
			
			case 'updateBranchData1';
				
				$bid=$_REQUEST["branch_id"];
				$bcode=$_REQUEST["branch_code"];
				$bname=$_REQUEST["branch_name"];
				$lend=$_REQUEST["lending"];
				$reg_fee=$_REQUEST["registration_fee"];
				$reg_id=$_REQUEST["region_id"];
				$prov_id=$_REQUEST["province_id"];
				$city_id=$_REQUEST["city"];
				$subd_brgy=$_REQUEST["subd"];
				$street_num=$_REQUEST["street"];
				$telnum=$_REQUEST["telno"];
				$faxnum=$_REQUEST["faxno"];
				$email_add=$_REQUEST["email"];
				
				$where='id='.$bid;
	
				$rows = array('branch_code' => $bcode , 'branch_name' => $bname , 'lending' => $lend , 'registration_fee' => $reg_fee , 'region_id' => $reg_id , 'province_id' => $prov_id , 'city_town_id' => $city_id , 'subd_brgy' => $subd_brgy , 'street_num' => $street_num , 'tel_no' => $telnum , 'fax_no' => $faxnum , 'email_add' => $email_add);
				$db->update('tbl_branch',$rows, $where);
				
				echo "updated";
			break;
			
			case 'updateBranchData2';
				
				$bid=$_REQUEST["branch_id"];
				$bcode=$_REQUEST["branch_code"];
				$bname=$_REQUEST["branch_name"];
				$lend=$_REQUEST["lending"];
				$reg_fee=$_REQUEST["registration_fee"];
				$reg_id=$_REQUEST["region_id"];
				$prov_id=$_REQUEST["province_id"];
				$city_id=$_REQUEST["city"];
				$subd_brgy=$_REQUEST["subd"];
				$street_num=$_REQUEST["street"];
				$telnum=$_REQUEST["telno"];
				$faxnum=$_REQUEST["faxno"];
				$email_add=$_REQUEST["email"];
				
				$rows1 = "*";
				$where1 = "branch_code='$bcode'";
				
				$db->select("tbl_branch", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
					$where='id='.$bid;
		
					$rows = array('branch_code' => $bcode , 'branch_name' => $bname , 'lending' => $lend , 'registration_fee' => $reg_fee , 'region_id' => $reg_id , 'province_id' => $prov_id , 'city_town_id' => $city_id , 'subd_brgy' => $subd_brgy , 'street_num' => $street_num , 'tel_no' => $telnum , 'fax_no' => $faxnum , 'email_add' => $email_add);
					$db->update('tbl_branch',$rows, $where);
					
					echo "updated";
				}
			break;
			
			//SUPPLIER
			
			case 'viewSupplierData';
			
				$sort=$_REQUEST["sort"];
				$sortType=$_REQUEST["sortType"];
				$category=$_REQUEST['category'];
				$trimmed=trim($_REQUEST['inputsearch']);
				
				$rows ='a.*, b.province_name as province_name, c.city_name as city_name';
				$where = "a.province_id=b.id AND a.city_town_id=c.id and $category LIKE '%".$trimmed."%'";
				$order="$sort $sortType";
				$db->select('tbl_supplier a, tbl_province b, tbl_city c',$rows,$where,$order); 
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			
			break;
			
			case 'loadSupplierRegion';
			
				$rows="id,region_name";
				$where="";
				$order = "region_name ASC";
				$db->select('tbl_region',$rows,$where,$order);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'loadSupplierProvince';
				
				$region_id=$_REQUEST["region_id"];
				$where='region_id='.$region_id;
				$rows="*";
				$order = "province_name ASC";
				$db->select('tbl_province',$rows,$where,$order);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'loadSupplierCity';
				
				$province_id=$_REQUEST["province_id"];
				$where='province_id='.$province_id;
				$rows="*";
				$order = "city_name ASC";
				$db->select('tbl_city',$rows,$where,$order);
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
			
			break;
			
			case 'searchSupplier';
				
				$search=trim($_REQUEST['inputsearch']);
				$category=$_REQUEST['category'];
				
				if($category=="province_id"){
					$rows ='a.*, b.province_name as province_name, c.city_name as city_name';
					$where = "a.province_id=b.id AND a.city_town_id=c.id AND b.province_name LIKE '%".$search."%'";
					$db->select('tbl_supplier a, tbl_province b, tbl_city c',$rows,$where);
				}
				else{
					$rows = "a.*,b.province_name as province_name, c.city_name as city_name";
					$where = "a.province_id=b.id AND a.city_town_id=c.id AND  a.$category LIKE '%".$search."%'";		
					$db->select('tbl_supplier a, tbl_province b, tbl_city c', $rows, $where);
				}	
				
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			break;
			
			case 'saveSupplierData';
			
				$supplier=$_REQUEST["supplier"];
				$telnum=$_REQUEST["telno"];
				$person=$_REQUEST["person"];
				$reg_id=$_REQUEST["region_id"];
				$prov_id=$_REQUEST["province_id"];
				$city_id=$_REQUEST["city"];
				$subd_brgy=$_REQUEST["subd"];
				$street_num=$_REQUEST["street"];
				
				$rows1 = "*";
				$where1 = "supplier_name='$supplier'";
				
				$db->select("tbl_supplier", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
					
					$rows2 ='supplier_name,telephone_number,contact_person,region_id,province_id,city_town_id,subd_brgy,street_num';
					$values2 = array($supplier,$telnum,$person,$reg_id,$prov_id,$city_id,$subd_brgy,$street_num);
					
					$db->insert('tbl_supplier',$values2,$rows2);
					
					echo "saved";

				}
				
			break;
			
			case 'viewSupplierUpdate';
				$supplier_id = $_REQUEST['supplier_id'];
				
				$where="a.id='$supplier_id' AND b.id=a.region_id AND c.id=a.province_id AND d.id=a.city_town_id";
				$rows ='a.*,b.region_name as r_name,c.province_name as p_name, d.city_name as c_name';
				
				$db->select('tbl_supplier a,tbl_region b,tbl_province c, tbl_city d',$rows,$where); 
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			break;
			
			case 'delete_supplier';
			
				$id=$_REQUEST["id"];
				$db->delete("tbl_supplier","id='$id'");  
				
				print "deleted";
			
			break;
			
			case 'updateSupplierData1';
				
				$sid=$_REQUEST["supplier_id"];
				$sname=$_REQUEST["supplier_name"];
				$telnum=$_REQUEST["telno"];
				$person=$_REQUEST["person"];
				$reg_id=$_REQUEST["region_id"];
				$prov_id=$_REQUEST["province_id"];
				$city_id=$_REQUEST["city"];
				$subd_brgy=$_REQUEST["subd"];
				$street_num=$_REQUEST["street"];
				
				$where='id='.$sid;
	
				$rows = array('supplier_name' => $sname , 'telephone_number' => $telnum ,'contact_person' => $person , 'region_id' => $reg_id , 'province_id' => $prov_id , 'city_town_id' => $city_id , 'subd_brgy' => $subd_brgy , 'street_num' => $street_num);
				$db->update('tbl_supplier',$rows, $where);
				
				echo "updated";
			break;
			
			case 'updateSupplierData2';
				
				$sid=$_REQUEST["supplier_id"];
				$sname=$_REQUEST["supplier_name"];
				$telnum=$_REQUEST["telno"];
				$person=$_REQUEST["person"];
				$reg_id=$_REQUEST["region_id"];
				$prov_id=$_REQUEST["province_id"];
				$city_id=$_REQUEST["city"];
				$subd_brgy=$_REQUEST["subd"];
				$street_num=$_REQUEST["street"];
				
				$rows1 = "*";
				$where1 = "supplier_name='$sname'";
				
				$db->select("tbl_supplier", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
				
					$where='id='.$sid;
		
					$rows = array('supplier_name' => $sname , 'telephone_number' => $telnum ,'contact_person' => $person , 'region_id' => $reg_id , 'province_id' => $prov_id , 'city_town_id' => $city_id , 'subd_brgy' => $subd_brgy , 'street_num' => $street_num);
					$db->update('tbl_supplier',$rows, $where);
					
					echo "updated";
				
				}
			break;
			
			//LOAN
			
			case 'viewLoanData';
				$loans=array();
				$category=$_REQUEST['category'];
				$trimmed=trim($_REQUEST['inputsearch']);
				
				$sort=$_REQUEST["sort"];
				
				$sortType=$_REQUEST["sortType"];
				$rows ="*";
				$where="";
				$db->select("tbl_loan",$rows,$where);
				$res = $db->getResult();
				$i=0;
				
				foreach($res as $loan){
					$interest3 = $loan['interest_rate_3'];
					$interest6 = $loan['interest_rate_6'];
					$interest9 = $loan['interest_rate_9'];
					
					if($interest3 > 0) {
						$interest_rate = $interest3;
					}
					else if($interest3 == 0 || $interest6 > 0) {
						$interest_rate = $interest6;
					}
					else if($interest3 == 0 || $interest6 == 0 || $interest9 > 0) {
						$interest_rate = $interest9;
					}
					else {
					}
					
					$where="id= '".$loan['id']."' and $category LIKE '%".$trimmed."%'";
					$rows="id,loan_type,method,$interest_rate as interest_rate,(mortgage_fee+insurance_fee+notarial_fee_new+filing_amount+doc_stamp+inspection_fee_new+others) as total";
					
					$db->select('tbl_loan',$rows,$where);
					$result = $db->getResult();
					
					for($i=0;$i<count($result);$i++){
						
						array_push($loans,$result[$i]);
					}
					
				}
				
				if(count($loans) > 0) {
						
						$sortArray = array(); 

						foreach($loans as $total){ 
							foreach($total as $key=>$value){
								if(!isset($sortArray[$key])){
									$sortArray[$key] = array(); 
								} 
								$sortArray[$key][] = $value;
							} 
						}

						$orderby = $sort;
						if($sortType=="ASC"){
							array_multisort($sortArray[$orderby],SORT_ASC,$loans);
						}
						else{
							array_multisort($sortArray[$orderby],SORT_DESC,$loans);
						}	
						
					
				}
				
				print '{"members":'.json_encode($loans).'}';
				
			break;
			
			case 'searchLoan';
				
				$search=trim($_REQUEST['inputsearch']);
				$category=$_REQUEST['category'];
				
				$rows = "*,(insurance_fee+notarial_fee+filing_fee+loan_advances+doc_stamp) as total";
				$where = "$category LIKE '%".$search."%'";		
				$db->select('tbl_loan', $rows, $where);	
			
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			break;
			
			case 'saveLoanData';
			
				$loan_type=$_REQUEST["loan_type"];
				$method=$_REQUEST["method"];
				$interest3=$_REQUEST["interest3"];
				$interest6=$_REQUEST["interest6"];
				$interest9=$_REQUEST["interest9"];
				$interest12=$_REQUEST["interest12"];
				$interest15=$_REQUEST["interest15"];
				$interest18=$_REQUEST["interest18"];
				$interest21=$_REQUEST["interest21"];
				$interest24=$_REQUEST["interest24"];
				$penalty=$_REQUEST["penalty"];
				$mortgage=$_REQUEST["mortgage"];
				$insurance_fee=$_REQUEST["insurance_fee"];
				$notary_new=$_REQUEST["notary_new"];
				$notary_old=$_REQUEST["notary_old"];
				$filing_percent=$_REQUEST["filing_percent"];
				$filing_amount=$_REQUEST["filing_amount"];
				$docstamp=$_REQUEST["docstamp"];
				$inspection_new=$_REQUEST["inspection_new"];
				$inspection_old=$_REQUEST["inspection_old"];
				$others=$_REQUEST["others"];
				
				$rows ='loan_type,method,interest_rate_3,interest_rate_6,interest_rate_9,interest_rate_12,interest_rate_15,interest_rate_18,interest_rate_21,interest_rate_24,penalty_interest,mortgage_fee,insurance_fee,notarial_fee_new,notarial_fee_old,filing_fee_percent,filing_amount,inspection_fee_new,inspection_fee_old,doc_stamp,others';
				$values = array($loan_type,$method,$interest3,$interest6,$interest9,$interest12,$interest15,$interest18,$interest21,$interest24,$penalty,$mortgage,$insurance_fee,$notary_new,$notary_old,$filing_percent,$filing_amount,$docstamp,$inspection_new,$inspection_old,$others);
				
				$db->insert('tbl_loan',$values,$rows);
				
				echo "saved";
			
			break;
			
			case 'viewLoanUpdate';
				$loan_id = $_REQUEST['loan_id'];
				
				$where="id='$loan_id'";
				$rows ='*';
				
				$db->select('tbl_loan',$rows,$where); 
				$res = $db->getResult();
				
				print '{"members":'.json_encode($res).'}';
				
			break;
			
			
			case 'delete_loan';
			
				$id=$_REQUEST["id"];
				$db->delete("tbl_loan","id='$id'");  
				
				print "deleted";
			
			break;
			
			case 'updateLoanData1';
				
				$loan_id=$_REQUEST["loan_id"];
				$loan_type=$_REQUEST["loan_type"];
				$method=$_REQUEST["method"];
				$interest3=$_REQUEST["interest3"];
				$interest6=$_REQUEST["interest6"];
				$interest9=$_REQUEST["interest9"];
				$interest12=$_REQUEST["interest12"];
				$interest15=$_REQUEST["interest15"];
				$interest18=$_REQUEST["interest18"];
				$interest21=$_REQUEST["interest21"];
				$interest24=$_REQUEST["interest24"];
				$penalty=$_REQUEST["penalty"];
				$mortgage=$_REQUEST["mortgage"];
				$insurance_fee=$_REQUEST["insurance_fee"];
				$notary_new=$_REQUEST["notary_new"];
				$notary_old=$_REQUEST["notary_old"];
				$filing_percent=$_REQUEST["filing_percent"];
				$filing_amount=$_REQUEST["filing_amount"];
				$docstamp=$_REQUEST["docstamp"];
				$inspection_new=$_REQUEST["inspection_new"];
				$inspection_old=$_REQUEST["inspection_old"];
				$others=$_REQUEST["others"];
				
				$where='id='.$loan_id;
	
				$rows = array('loan_type' => $loan_type , 'method' => $method , 'interest_rate_3' => $interest3 , 'interest_rate_6' => $interest6 , 'interest_rate_9' => $interest9 , 'interest_rate_12' => $interest12 , 'interest_rate_15' => $interest15 , 'interest_rate_18' => $interest18 , 'interest_rate_21' => $interest21 , 'interest_rate_24' => $interest24 , 'penalty_interest' => $penalty , 'mortgage_fee' => $mortgage , 'insurance_fee' => $insurance_fee , 'notarial_fee_new' => $notary_new , 'notarial_fee_old' => $notary_old , 'filing_fee_percent' => $filing_percent , 'filing_amount' => $filing_amount , 'doc_stamp' => $docstamp , 'inspection_fee_new' => $inspection_new , 'inspection_fee_old' => $inspection_old , 'others' => $others);
				$db->update('tbl_loan',$rows, $where);
				
				echo "updated";
			break;
			
			case 'updateLoanData2';
				
				$loan_id=$_REQUEST["loan_id"];
				$loan_type=$_REQUEST["loan_type"];
				$method=$_REQUEST["method"];
				$interest3=$_REQUEST["interest3"];
				$interest6=$_REQUEST["interest6"];
				$interest9=$_REQUEST["interest9"];
				$interest12=$_REQUEST["interest12"];
				$interest15=$_REQUEST["interest15"];
				$interest18=$_REQUEST["interest18"];
				$interest21=$_REQUEST["interest21"];
				$interest24=$_REQUEST["interest24"];
				$penalty=$_REQUEST["penalty"];
				$mortgage=$_REQUEST["mortgage"];
				$insurance_fee=$_REQUEST["insurance_fee"];
				$notary_new=$_REQUEST["notary_new"];
				$notary_old=$_REQUEST["notary_old"];
				$filing_percent=$_REQUEST["filing_percent"];
				$filing_amount=$_REQUEST["filing_amount"];
				$docstamp=$_REQUEST["docstamp"];
				$inspection_new=$_REQUEST["inspection_new"];
				$inspection_old=$_REQUEST["inspection_old"];
				$others=$_REQUEST["others"];
				
				$rows1 = "*";
				$where1 = "loan_type='$loan_type'";
				
				$db->select("tbl_loan", $rows1, $where1);
				$result = $db->getResult();
				
				if(count($result)>0){
					echo "exists";
				}
				
				else {
				
					$where='id='.$loan_id;
		
					$rows = array('loan_type' => $loan_type , 'method' => $method , 'interest_rate_3' => $interest3 , 'interest_rate_6' => $interest6 , 'interest_rate_9' => $interest9 , 'interest_rate_12' => $interest12 , 'interest_rate_15' => $interest15 , 'interest_rate_18' => $interest18 , 'interest_rate_21' => $interest21 , 'interest_rate_24' => $interest24 , 'penalty_interest' => $penalty , 'mortgage_fee' => $mortgage , 'insurance_fee' => $insurance_fee , 'notarial_fee_new' => $notary_new , 'notarial_fee_old' => $notary_old , 'filing_fee_percent' => $filing_percent , 'filing_amount' => $filing_amount , 'doc_stamp' => $docstamp , 'inspection_fee_new' => $inspection_new , 'inspection_fee_old' => $inspection_old , 'others' => $others);
					$db->update('tbl_loan',$rows, $where);
				
					echo "updated";
				}
			break;
			
		}
		
	}

?>