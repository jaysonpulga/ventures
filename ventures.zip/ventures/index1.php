<?php
	session_start();

?>

<!DOCTYPE HTML>
<html lang="en">
</style>
	 <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="author" lang="en" content="Maestro Systemas">
	<meta name="copyright" lang="en" content="2014">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<meta name="robots" content="index,follow">
	
	<link rel='stylesheet' type='text/css' href='css/styles.css' />
	<link rel="stylesheet" type="text/css" href="css/bluetabs.css" />
	<link rel="shortcut icon" type="image/x-icon" href="">
	<link href="css/jquery-ui-1.9.2.custom.css" rel="stylesheet"/>
	<link href="css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script src="js/jquery-1.8.3.js"></script>
	<script src="js/jquery-ui-1.9.2.custom.js"></script>
	<script src="js/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="js/jquery.alerts.js" type="text/javascript"></script>
	<script type="text/javascript" src=""></script> 
</head>
<style>

.formlog{
	width:370px;
	border:1px solid #000;
	text-align:center;
	padding-top:30px;
	padding-bottom:20px;
	background:#f4f4f4;
	box-shadow: 1px 2px 3px gray;
	border: 1px solid #c5c5c5;
	border-radius:4px;
	
}	
#login_formlog{ 
	padding:30px;
}
<!---
#login_formlog input[type="submit"]{ 
	width:120px;
	border:1px solid #323a45;
	border-radius:3px;
	height:23px;
	text-align:center;
	border: 1px solid #ccc;
	height:30px;
	font-size:13px;
	letter-spacing:1px;
	color:#FFF;
	font-weight:bold;
	cursor:pointer;
	background-color: #323a45;
	margin-top:10px;
	text-align:center;
}
input[type="submit"]{ 
	width:120px;
	border:1px solid #323a45;
	border-radius:3px;
	height:23px;
	text-align:center;
	border: 1px solid #ccc;
	height:30px;
	font-size:13px;
	letter-spacing:1px;
	color:#FFF;
	font-weight:bold;
	cursor:pointer;
	background-color: #323a45;
	margin-top:10px;
	text-align:center;
}

#login_formlog label{ 
	text-align:left;
	font-size:16px;
	font-weight:bold;
	letter-spacing:1px;
}-->

</style>

<body>
	<div id="wrapper" style="margin:0px auto;" align="center">
	
		<div id="container" style="margin:50px auto;">
			<img src="images/logo1.png" />
			<div id="login_formlog">
				<div class="formlog">
					<form name="frm" id="frm" action="index.php" method="POST">
							<label>Branch</label>
							<select id ='branch' name='branch' style="margin-left:13px;margin-bottom:10px">
							</select>
						
							<input type="text" name="username" id = "username" style ="text-align:left;margin-bottom:10px" placeholder="Username" onKeyPress="javascript:testEnter()">


							<input type="password" name="password" id = "password"  style ="text-align:left;margin-bottom:10px" placeholder="Password" onKeyPress="javascript:testEnter()">


							<input type="button" name="loginRequest" id="login" style="width:248px;height:30px;margin-bottom:10px"value="LOGIN" onclick = "checkLogin()" >

					</form>
				</div>
			</div>
		</div>
	</div>
</body>
<script>

	$(document).ready(function(){
		
			load_branch();
			
		$('#branch')
		.prop('disabled', false)
		.empty()
		.append('<option value="">SELECT</option>')
		.find('option:first')
		.attr("selected","selected");
	
	});

	var selectedID = -1;

	function testEnter() {
		if(event.keyCode==13){
			
			var elem_1 = document.getElementById('username');
			var elem_2 = document.getElementById('password');
			
			var inp_1 = elem_1.value;
			var inp_2 = elem_2.value;
			if (inp_1 == ""){
				//jAlert('Username Field Required',"Alert Dialog");
				elem_1.focus();
			}else if (inp_2 == ""){
				//jAlert('Password Field Required',"Alert Dialog");
				elem_2.focus();
			}
			else {
			   if (inp_1 && inp_2  != "")
			   {
					document.getElementById("login").click();
			   }
			
			}
		}
	}
	function checkLogin(){
	
	
			$.ajax({
				url: 'managements/function_items.php',
				data: {'request':'ajax','action':'login','username': $("#username").val(), 'password':$("#password").val()},
				beforeSend: function(){		
				}, 
				success : function(reply){
					if(reply == "YOSH!"){
						window.location = "transaction/sales.php?menu=transaction";
					} else {
						jAlert(reply,"Alert Dialog");
						reset_field();
					}
					
				}, 
				error: function(xhr, status, error) {
					console.log(xhr.responseText+" "+status+" "+error )
				}
			});
	
	
	}
	function reset_field(){
		$('#username').val("");
		$('#password').val("");
	}
	
	function load_branch(){
		var count=0, x=0;
		var select = $("#branch");

		$.ajax({
				url:"managements/function_items.php",
				data:{"request":"ajax","action":"select_branch"},
				dataType:'json',
				beforeSend: function(){
					
			},
				success: function(reply){
					
					if(reply.length > 0){
						
							$.each(reply, function(i,res){
							 count++;
							
							select.append("<option  value='"+res.id+"'  >"+res.branch_code+"</option>");
																		
							});
			
					}
				}
			});
	}
</script>
</html>

		
	
	